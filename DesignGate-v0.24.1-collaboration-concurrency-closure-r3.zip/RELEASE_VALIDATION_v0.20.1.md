# DesignGate v0.20.1 Fix Release

## Fixed closure defects

| Problem | Root cause | Fix | Regression result |
| --- | --- | --- | --- |
| Planned or unknown DFMEA test became verified | Any status other than `FAILED` counted as tested | Explicit status enum; only complete, evidence-bound current `PASS` verifies | PASS |
| Empty DFMEA evaluated | Empty arrays passed the evaluator | Missing/invalid failure modes return `NOT_EVALUATED_MISSING_INPUT` | PASS |
| Reopened risk was report-only | Professional capability ran after Gate | DFMEA becomes formal Gate check/finding; reopened risk is `FAIL` | PASS |
| Risk definition did not invalidate validation | DFMEA absent from baseline | Risk-definition fingerprint is included in `basis_hash`; validation outcomes are excluded | PASS |
| Revision inherited test conclusion | Tests were retained without state migration | Tests remain historical as `STALE` | PASS |
| Decision-to-requirement edge disappeared | `requirement_ids` were dropped on save | IDs are preserved and validated | PASS |
| Rule IDs were emitted as evidence | CMF rule and project evidence were conflated | Rule/source/project evidence IDs are separated; unreviewed rules are reference-only | PASS |
| Zero force/arm rejected | Positive-only validation and fixed risk bands | Non-negative physical inputs accepted; no risk band without reviewed reference | PASS |

## Commands run

```powershell
npm test
npm run check
```

The local automated suite and static/data checks are required engineering software checks. They do not prove real industrial-design quality, prototype safety, supplier compatibility, CAE validity, production readiness, production approval, live-model performance, or expert review.

## Unverified items

- Desktop click-through validation of the new optional DFMEA JSON input was attempted with `npm start`, but the source ZIP has no local Electron executable (`electron` was not recognized). Renderer contract tests passed; native desktop interaction remains **NOT_RUN**.
- No paid model, production connector, external archive, external solver, real project validation, multi-trial live-model evaluation, or independent expert review was run.
