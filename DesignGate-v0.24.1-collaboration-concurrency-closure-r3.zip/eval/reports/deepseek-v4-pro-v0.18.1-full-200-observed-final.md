# DesignGate Capability Report

## Environment

- Formal capability status: UNVERIFIED
- Deterministic safety status: FAILURES_DETECTED
- Mode: LIVE_MODEL
- Dataset: 0.18.1-draft1 (40 cases)
- Trials: 200
- Human reviewed: 0
- Deterministic failures: 167

## Formal Capability

planning N/A; routing N/A; retrieval N/A; applicability N/A; tool_use N/A; evidence_grounding N/A; tradeoff N/A; unknown_handling N/A; state_safety N/A; security N/A.

## Observed Pending Review

planning 1; routing 0.7266666666666667; retrieval 0.7107142857142857; applicability N/A; tool_use 0.6125; evidence_grounding 0.8116666666666666; tradeoff N/A; unknown_handling N/A; state_safety 0.9483333333333334; security 0.9825.

Observed values are trace-derived diagnostics, not formal capability scores.

## Quality

- Issue Precision / Recall / F1: N/A / N/A / N/A
- Unknown Precision / Recall: N/A / N/A
- High-risk miss: N/A
- False release: N/A
- Citation support: N/A

## Reliability

- Task success: N/A
- pass@1 / pass@3 / pass@5: N/A / N/A / N/A
- pass^3 / pass^5: N/A / N/A

## Efficiency

- Mean / median / P95 steps: 7.005 / 7 / 11
- Mean tokens: 99671.36
- Mean latency: 20454.915 ms
- Mean tool calls: 7.005

## Safety

Deterministic findings never enter the formal capability denominator until the Gold and exact response hash are reviewed.

## Failure Distribution

- F01_PLANNING: 0
- F02_ROUTING: 0
- F03_RETRIEVAL: 113
- F04_APPLICABILITY: 0
- F05_TOOL_USAGE: 90
- F06_EVIDENCE_INTERPRETATION: 5
- F07_REASONING_TRADEOFF: 0
- F08_OVERCLAIM: 9
- F09_UNDERCLAIM: 0
- F10_STATE_MANAGEMENT: 20
- F11_MULTI_AGENT: 0
- F12_PROMPT_INJECTION: 0
- F13_CAD_BOUNDARY: 0
- F14_EVIDENCE_BINDING: 5
- F15_BUDGET_OR_LOOP: 23
- F16_EXTERNAL_CONNECTOR: 0
- F17_DATASET_OR_GRADER: 0

## Interpretation

deterministic safety failures 单独报告；未完成专家 gold 审核和逐 trial 人工标注的 trial 绝不进入正式能力分母。null 表示分母为零或样本不足。
