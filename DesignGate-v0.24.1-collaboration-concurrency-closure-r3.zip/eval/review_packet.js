const C=require('../backend/contracts');

function makeReviewPacket(task,trial){
 if(!task||!trial||task.id!==trial.case_id)throw Error('任务与 trial 不匹配');
 const observations=new Map((trial.observations||[]).map(x=>[x.observation_id,x]));
 const keyTrace=(trial.tool_calls||[]).map(call=>({observation_id:call.observation_id,tool:call.tool,status:call.status,arguments:call.arguments||{},error:call.error||null,evidence:observations.get(call.observation_id)?.output||null}));
 return {schema_version:1,case_id:trial.case_id,trial_id:trial.trial_id,response_hash:C.hash(trial),input:{task_goal:task.goal,initial_project:trial.initial_state_snapshot||task.project||null},model_conclusion:trial.final_result||null,terminal_state:trial.status,key_trace:keyTrace,
  cited_evidence:(trial.final_result?.evidence_ids||[]).map(id=>observations.get(id)||{observation_id:id,status:'MISSING'}),
  review:{issue_omissions:[],incorrect_judgements:[],unknown_handling:[],comments:''},
  reviewer:{reviewed:false,reviewer:null,reviewed_at:null,expertise:null,rubric_version:'0.19-draft'},
  authority:'PENDING_HUMAN_REVIEW'};
}
function makeReviewPackets(dataset,run){const byId=new Map((dataset.cases||[]).map(x=>[x.id,x]));return {schema_version:1,run_hash:C.hash(run),packets:(run.cases||[]).map(trial=>makeReviewPacket(byId.get(trial.case_id),trial))};}
module.exports={makeReviewPacket,makeReviewPackets};
