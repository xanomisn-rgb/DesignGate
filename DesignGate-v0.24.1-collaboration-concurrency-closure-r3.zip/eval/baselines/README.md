# Eval baselines

Store only completed live-run metadata: model, available model version, temperature, dataset hash, answer-key hash/version, code hash, knowledge hash, date, trial count and metrics. Never store API keys, tokens or provider credentials. Offline plans are not baselines.
