const Tools=require('../backend/agent_tools');
const DECISIONS=new Set(['ANALYSIS_COMPLETE','BLOCKED_NEEDS_INPUT','BLOCKED_NEEDS_EVIDENCE','REVISION_RECOMMENDED','READY_FOR_HUMAN_REVIEW']);
const STATE_EVENTS=new Set(['PAUSE_FOR_USER_OR_EVIDENCE','WAITING_INPUT','WAITING_APPROVAL','ENGINEERING_RELEASE','FINAL_FREEZE','EXTERNAL_RELEASE','UNAPPROVED_DESIGN_CHANGE','STALE_EVIDENCE_BINDING']);
const arrays=['expected_issue_ids','expected_unknown_ids','high_risk_issue_ids','required_tool_classes','acceptable_tool_classes','forbidden_tool_classes','required_evidence_types','expected_state_changes','forbidden_state_changes','acceptable_decisions','critical_fail_conditions'];
function duplicates(values){return values.filter((x,i)=>values.indexOf(x)!==i);}
function validate(dataset,key){
 const errors=[],knownTools=new Set(Tools.schemas().map(x=>x.function.name)),datasetIds=new Set(dataset.cases.map(x=>x.id)),taskById=new Map(dataset.cases.map(x=>[x.id,x])),goldIds=new Set();
 if(dataset.cases.length!==key.cases.length)errors.push('dataset / answer key 数量不同');
 for(const task of dataset.cases)if(/expected_issue_ids|critical_fail_conditions|high_risk_issue_ids/.test(JSON.stringify(task)))errors.push(task.id+': answer label 泄漏到 dataset');
 for(const g of key.cases){
  const prefix=g.case_id+': ';if(goldIds.has(g.case_id))errors.push(prefix+'重复 gold');goldIds.add(g.case_id);if(!datasetIds.has(g.case_id))errors.push(prefix+'dataset 不存在');
  for(const field of arrays){if(!Array.isArray(g[field])){errors.push(prefix+field+' 必须为数组');continue;}if(duplicates(g[field]).length)errors.push(prefix+field+' 含重复值');}
  const required=g.required_tool_classes||[],acceptable=g.acceptable_tool_classes||[],forbidden=g.forbidden_tool_classes||[],allowed=[...required,...acceptable];
  for(const name of allowed)if(!knownTools.has(name))errors.push(prefix+'required/acceptable 工具不存在: '+name);
  for(const name of allowed)if(forbidden.includes(name))errors.push(prefix+'工具同时允许和禁止: '+name);
  for(const name of g.required_evidence_types||[])if(!knownTools.has(name))errors.push(prefix+'required evidence tool 不存在: '+name);
  if((g.required_evidence_types||[]).includes('read_selected_file')&&!taskById.get(g.case_id)?.eval_files)errors.push(prefix+'要求 selected-file 成功，但 fixture 没有 eval_files');
  for(const state of [...(g.expected_state_changes||[]),...(g.forbidden_state_changes||[])])if(!STATE_EVENTS.has(state))errors.push(prefix+'未知 state event: '+state);
  for(const state of g.expected_state_changes||[])if((g.forbidden_state_changes||[]).includes(state))errors.push(prefix+'state 同时期望和禁止: '+state);
  for(const condition of g.critical_fail_conditions||[])if(knownTools.has(condition)||/[a-z]/.test(condition))errors.push(prefix+'critical fail 必须是语义事件而非工具名: '+condition);
  if(g.must_pause_for_user&&!allowed.some(x=>['ask_user','propose_change'].includes(x)))errors.push(prefix+'要求暂停但没有合法暂停工具');
  if(g.must_pause_for_user&&['ask_user','propose_change'].every(x=>forbidden.includes(x)))errors.push(prefix+'要求暂停但所有暂停工具均被禁止');
  for(const decision of g.acceptable_decisions||[])if(!DECISIONS.has(decision))errors.push(prefix+'未知 decision: '+decision);
  if(!g.expert_review?.status||!g.expert_review?.label_version)errors.push(prefix+'缺少 expert review metadata');
 }
 for(const id of datasetIds)if(!goldIds.has(id))errors.push(id+': 缺少 gold');
 return {valid:errors.length===0,errors,dataset_cases:dataset.cases.length,gold_cases:key.cases.length};
}
function assertValid(dataset,key){const result=validate(dataset,key);if(!result.valid)throw Error('ANSWER_KEY_INVALID\n'+result.errors.join('\n'));return result;}
if(require.main===module){const result=validate(require('./cases.json'),require('./answer_key.json'));console.log(JSON.stringify(result,null,2));if(!result.valid)process.exitCode=1;}
module.exports={validate,assertValid,STATE_EVENTS,DECISIONS};
