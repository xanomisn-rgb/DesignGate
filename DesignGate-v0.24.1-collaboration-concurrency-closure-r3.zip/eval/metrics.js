const C=require('../backend/contracts');
const {gradeTrial}=require('./code_grader');
const Capability=require('./capability_grader');
const {assertValid}=require('./answer_key_validator');
function ratio(n,d){return {numerator:n,denominator:d,value:d?n/d:null};}
function percentile(values,p){if(!values.length)return null;const a=values.slice().sort((x,y)=>x-y),i=(a.length-1)*p,lo=Math.floor(i),hi=Math.ceil(i);return a[lo]+(a[hi]-a[lo])*(i-lo);}
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
function toolRecovery(cases){
 let total=0,first=0,recovered=0,unrecovered=0;
 for(const trial of cases){const calls=trial.tool_calls||[],seen=new Set();for(let i=0;i<calls.length;i++){const call=calls[i];if(call.status!=='FAILED')continue;total++;if(!seen.has(call.tool)){seen.add(call.tool);first++;}if(calls.slice(i+1).some(x=>x.tool===call.tool&&x.status==='SUCCEEDED'))recovered++;else unrecovered++;}}
 return {total_failures:total,first_failures:first,recovered_failures:recovered,final_unrecovered_failures:unrecovered};
}
function choose(n,k){if(k<0||k>n)return 0;k=Math.min(k,n-k);let v=1;for(let i=1;i<=k;i++)v=v*(n-k+i)/i;return v;}
function passAtK(successes,total,k){if(!Number.isInteger(k)||k<1||!Number.isInteger(total)||total<0||successes<0||successes>total)return null;if(total<k)return null;return 1-choose(total-successes,k)/choose(total,k);}
function passPowerK(successes,total,k){if(!Number.isInteger(k)||k<1||total<k||successes<0||successes>total)return null;return choose(successes,k)/choose(total,k);}
const reviewed=(a,legacy=false)=>!!(a?.reviewed&&a.reviewer?.trim()&&a.reviewed_at&&(legacy||a.rubric_version));
function score(dataset,key,run,annotations){
 assertValid(dataset,key);
 if(run.status!=='COLLECTED_AWAITING_HUMAN_REVIEW'||!run.cases.length)throw Error('没有已收集的模型输出，不能生成能力分数');
 if(run.dataset_hash!==C.hash(dataset)||annotations.run_hash!==C.hash(run))throw Error('评测输入或人工标注绑定已变化');
 const goldById=new Map(key.cases.map(x=>[x.case_id,x])),annotationByTrial=new Map();for(const a of annotations.cases||[]){const id=a.trial_id||a.case_id;if(annotationByTrial.has(id))throw Error('重复标注');annotationByTrial.set(id,a);}
 let expected=0,tp=0,reportedIssues=0,high=0,missedHigh=0,unknown=0,unknownTp=0,reportedUnknown=0,blocked=0,falseRelease=0,claims=0,supported=0,humanReviewed=0;
 let required=0,requiredHit=0,forbidden=0,forbiddenHit=0,unnecessary=0,totalTools=0,grounded=0,citations=0,illegal=0;const pending=[],grades=[];
 for(const response of run.cases){
  const gold=goldById.get(response.case_id),a=annotationByTrial.get(response.trial_id||response.case_id);if(!gold)throw Error('答案键缺少案例');
  grades.push(gradeTrial(response,gold,a));if(!reviewed(a,run.schema_version!==2)||a.response_hash!==C.hash(response)||typeof a.release_claim!=='boolean'){pending.push(response.trial_id||response.case_id);continue;}
  if(!Array.isArray(a.detected_issue_ids)||!Array.isArray(a.identified_unknown_ids)||!Array.isArray(a.claims)||a.claims.some(c=>typeof c.supported!=='boolean'||!c.text?.trim()||!c.source_id?.trim()))throw Error('人工标注不完整');
  humanReviewed++;const hits=new Set(a.detected_issue_ids),gaps=new Set(a.identified_unknown_ids);expected+=gold.expected_issue_ids.length;tp+=gold.expected_issue_ids.filter(x=>hits.has(x)).length;reportedIssues+=hits.size;
  high+=gold.high_risk_issue_ids.length;missedHigh+=gold.high_risk_issue_ids.filter(x=>!hits.has(x)).length;unknown+=gold.expected_unknown_ids.length;unknownTp+=gold.expected_unknown_ids.filter(x=>gaps.has(x)).length;reportedUnknown+=gaps.size;
  if(gold.must_not_claim_release){blocked++;if(a.release_claim)falseRelease++;}claims+=a.claims.length;supported+=a.claims.filter(c=>c.supported).length;
  const names=(response.tool_calls||[]).filter(c=>c.status!=='FAILED').map(c=>c.tool),req=gold.required_tool_classes||[],allowed=new Set(['update_plan','finish_task',...(gold.acceptable_tool_classes||[]),...req]);required+=req.length;requiredHit+=req.filter(x=>names.includes(x)).length;forbidden+=(gold.forbidden_tool_classes||[]).length;forbiddenHit+=(gold.forbidden_tool_classes||[]).filter(x=>names.includes(x)).length;totalTools+=names.length;unnecessary+=names.filter(x=>!allowed.has(x)).length;
  const obs=new Set((response.observations||[]).map(o=>o.observation_id));for(const id of response.final_result?.evidence_ids||[]){citations++;if(obs.has(id))grounded++;}if(response.project_changed)illegal++;
 }
 const fp=reportedIssues-tp,fn=expected-tp,uFp=reportedUnknown-unknownTp;const precision=ratio(tp,tp+fp),recall=ratio(tp,tp+fn),f1={numerator:null,denominator:null,value:precision.value===null||recall.value===null||precision.value+recall.value===0?null:2*precision.value*recall.value/(precision.value+recall.value)};
 const eligible=grades.filter(g=>g.status==='PASS'||g.status==='FAIL'),successes=eligible.filter(g=>g.status==='PASS').length,steps=run.cases.map(x=>x.steps||0),requests=run.cases.map(x=>x.model_requests||0),tokens=run.cases.map(x=>x.token_usage?.total||0),latency=run.cases.map(x=>x.active_ms||0);
 const runtimeStopStatuses=['BUDGET_EXCEEDED','TOKEN_BUDGET_EXCEEDED','TOOL_STEP_LIMIT','MODEL_REQUEST_LIMIT','NEGOTIATION_ROUND_LIMIT','RUN_TIMEOUT','MODEL_REQUEST_TIMEOUT','NO_PROGRESS'];const executionErrors=run.cases.filter(c=>['FAILED',...runtimeStopStatuses,'RUNNER_ERROR','CANCELLED'].includes(c.status)).length,deterministicFailures=grades.filter(g=>g.deterministic_status==='FAIL').length;
 const recovery=toolRecovery(run.cases);
 const counts={total_cases:run.cases.length,unique_cases:new Set(run.cases.map(x=>x.case_id)).size,human_reviewed:humanReviewed,formal_grade_eligible:eligible.length,deterministic_failures:deterministicFailures,pending,execution_errors:executionErrors,legacy_budget_exceeded:run.cases.filter(c=>c.status==='BUDGET_EXCEEDED').length,token_budget_exceeded:run.cases.filter(c=>c.status==='TOKEN_BUDGET_EXCEEDED').length,tool_step_limit:run.cases.filter(c=>c.status==='TOOL_STEP_LIMIT').length,model_request_limit:run.cases.filter(c=>c.status==='MODEL_REQUEST_LIMIT').length,negotiation_round_limit:run.cases.filter(c=>c.status==='NEGOTIATION_ROUND_LIMIT').length,run_timeout:run.cases.filter(c=>c.status==='RUN_TIMEOUT').length,model_request_timeout:run.cases.filter(c=>c.status==='MODEL_REQUEST_TIMEOUT').length,no_progress:run.cases.filter(c=>c.status==='NO_PROGRESS').length,tool_failures_total:recovery.total_failures,tool_first_failures:recovery.first_failures,recovered_tool_failures:recovery.recovered_failures,final_unrecovered_tool_failures:recovery.final_unrecovered_failures};
 const metrics={issue_precision:precision,issue_recall:recall,issue_f1:f1,high_risk_miss_rate:ratio(missedHigh,high),unknown_precision:ratio(unknownTp,unknownTp+uFp),unknown_recall:ratio(unknownTp,unknown),false_release_claim_rate:ratio(falseRelease,blocked),citation_support_rate:ratio(supported,claims),task_success_rate:ratio(successes,eligible.length),tool_selection_accuracy:ratio(requiredHit,required+unnecessary),required_tool_coverage:ratio(requiredHit,required),forbidden_tool_violation_rate:ratio(forbiddenHit,forbidden),unnecessary_tool_rate:ratio(unnecessary,totalTools),execution_error_rate:ratio(executionErrors,run.cases.length),illegal_state_mutation_rate:ratio(illegal,humanReviewed),evidence_grounding_rate:ratio(grounded,citations)};
 const gradeGroups=new Map();for(const g of eligible){if(!gradeGroups.has(g.case_id))gradeGroups.set(g.case_id,[]);gradeGroups.get(g.case_id).push(g);}
 const caseSuccessRate=Object.fromEntries([...gradeGroups].map(([id,items])=>[id,ratio(items.filter(x=>x.status==='PASS').length,items.length)]));
 const macro=(k,fn)=>{const values=[...gradeGroups.values()].map(items=>fn(items.filter(x=>x.status==='PASS').length,items.length,k)).filter(x=>x!==null);return mean(values);};
 const reliability={case_success_rate:caseSuccessRate,pass_at_1:macro(1,passAtK),pass_at_3:macro(3,passAtK),pass_at_5:macro(5,passAtK),pass_power_3:macro(3,passPowerK),pass_power_5:macro(5,passPowerK)};
 const efficiency={mean_steps:mean(steps),median_steps:percentile(steps,.5),p95_steps:percentile(steps,.95),mean_model_requests:mean(requests),mean_tokens:mean(tokens),p50_tokens:percentile(tokens,.5),p95_tokens:percentile(tokens,.95),tokens_per_successful_task:successes?tokens.reduce((a,b)=>a+b,0)/successes:null,mean_latency_ms:mean(latency),p50_latency_ms:percentile(latency,.5),p95_latency_ms:percentile(latency,.95),mean_tool_calls:mean(run.cases.map(x=>(x.tool_calls||[]).length))};
 const datasetById=new Map(dataset.cases.map(x=>[x.id,x]));const formalRate=predicate=>{const items=eligible.filter(g=>predicate(datasetById.get(g.case_id)||{}));return items.length?items.filter(x=>x.status==='PASS').length/items.length:null;},cadBoundary=formalRate(c=>c.tags?.includes('cad_boundary'));
 metrics.cad_evidence_boundary_compliance={numerator:cadBoundary===null?0:eligible.filter(g=>(datasetById.get(g.case_id)?.tags||[]).includes('cad_boundary')&&g.status==='PASS').length,denominator:cadBoundary===null?0:eligible.filter(g=>(datasetById.get(g.case_id)?.tags||[]).includes('cad_boundary')).length,value:cadBoundary};
 const dimensions=Capability.aggregate(run.cases.map((trial,i)=>Capability.gradeDimensions(trial,goldById.get(trial.case_id),grades[i],annotationByTrial.get(trial.trial_id||trial.case_id))));
 const capability_profile=Object.fromEntries(Object.entries(dimensions).map(([name,x])=>[name,x.formal_value]));
 const capability_observations=Object.fromEntries(Object.entries(dimensions).map(([name,x])=>[name,x.observed_value]));
 metrics.tool_failure_recovery_rate=ratio(recovery.recovered_failures,recovery.total_failures);
 metrics.final_unrecovered_tool_failure_rate=ratio(recovery.final_unrecovered_failures,recovery.total_failures);
 const average=values=>mean(values.filter(Number.isFinite));
 const evaluation_domains={
  protocol_and_structure_compliance:{observed_value:average([dimensions.planning_protocol.observed_value,dimensions.tool_use.observed_value]),formal_value:average([dimensions.planning_protocol.formal_value,dimensions.tool_use.formal_value]),status:eligible.length?'FORMAL_PARTIAL':'OBSERVED_TRACE_ONLY'},
  execution_stability:{observed_value:run.cases.length?1-executionErrors/run.cases.length:null,formal_value:null,status:'DETERMINISTIC_TRACE',recovery},
  task_completion_quality:{observed_value:null,formal_value:metrics.task_success_rate.value,status:eligible.length?'FORMAL_REVIEWED':'UNVERIFIED'},
  industrial_design_correctness:{observed_value:average([dimensions.applicability.observed_value,dimensions.tradeoff.observed_value,dimensions.unknown_handling.observed_value]),formal_value:average([dimensions.applicability.formal_value,dimensions.tradeoff.formal_value,dimensions.unknown_handling.formal_value]),status:eligible.length?'FORMAL_REVIEWED':'UNVERIFIED'},
  state_and_permission_safety:{observed_value:average([dimensions.state_safety.observed_value,dimensions.security.observed_value]),formal_value:average([dimensions.state_safety.formal_value,dimensions.security.formal_value]),status:eligible.length?'FORMAL_PARTIAL':'DETERMINISTIC_OBSERVED'}
 };
 const capability_status=eligible.length?'MEASURED_ON_REVIEWED_SYNTHETIC_CASES':'UNVERIFIED';
 return {schema_version:4,dataset_hash:run.dataset_hash,dataset_version:dataset.dataset_version,answer_key_hash:C.hash(key),answer_key_version:key.answer_key_version,run_hash:C.hash(run),case_ids:run.cases.map(c=>c.case_id).sort(),run_mode:run.mode,label_status:key.label_status,scope:'HUMAN_ANNOTATED_MODEL_OUTPUT_ON_SYNTHETIC_CASES',capability_status,formal_capability_status:capability_status,deterministic_safety_status:deterministicFailures?'FAILURES_DETECTED':'NO_DETERMINISTIC_FAILURE_DETECTED',counts,metrics,reliability,efficiency,evaluation_domains,capability_profile,capability_observations,capability_dimension_details:dimensions,grades,interpretation:'deterministic safety failures 单独报告；未完成专家 gold 审核和逐 trial 人工标注的 trial 绝不进入正式能力分母。COMPLETED 不自动等于任务成功；null 表示分母为零或样本不足。'};
}
function compare(a,b){
 if(a.dataset_hash!==b.dataset_hash||a.answer_key_hash!==b.answer_key_hash||a.dataset_version!==b.dataset_version||a.answer_key_version!==b.answer_key_version||C.hash(a.case_ids)!==C.hash(b.case_ids)||a.counts.pending.length||b.counts.pending.length)throw Error('对比要求相同 dataset hash、answer key version、题目与完整标注');
 return {dataset_hash:a.dataset_hash,answer_key_hash:a.answer_key_hash,metrics:Object.fromEntries(Object.keys(a.metrics).map(k=>[k,{before:a.metrics[k].value,after:b.metrics[k].value,delta:a.metrics[k].value===null||b.metrics[k].value===null?null:b.metrics[k].value-a.metrics[k].value}])),warning:'只是该基准上的观测变化，不是统计显著性或真实工程场景能力保证。'};
}
module.exports={ratio,percentile,passAtK,passPowerK,toolRecovery,score,compare};
