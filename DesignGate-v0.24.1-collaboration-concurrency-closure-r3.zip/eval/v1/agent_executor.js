const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const State=require('../../backend/project_state_manager');
const AgentRuntime=require('../../backend/agent_runtime');
function createAgentExecutor({storage_root,model,runtime_options={}}={}){
  if(typeof storage_root!=='string'||!storage_root||typeof model!=='function')throw Error('V1_AGENT_EXECUTOR_CONFIG_INVALID');
  return async input=>{
    if(!input||typeof input.prompt!=='string'||Object.hasOwn(input,'case_id'))throw Error('V1_AGENT_INPUT_INVALID');
    const project_id=`DG-BV1-${crypto.randomUUID().replaceAll('-','').slice(0,16)}`,dir=path.join(storage_root,project_id);fs.mkdirSync(dir,{recursive:true});
    const state=new State(dir);state.saveProject({project_id,project_name:'Benchmark v1 isolated project',requirements:[],design:{active_revision:'A'},bom:[],findings:[],benchmark_context:structuredClone(input.context||{})},0);
    const runtime=new AgentRuntime(state,model,runtime_options),started=runtime.start(project_id,input.prompt),record=await runtime.settled(project_id,started.run_id);
    return {run_id:record.run_id,status:record.status,tool_trace:(record.events||[]).map(event=>({observation_id:event.id,tool:event.tool,status:event.status,arguments:event.arguments||null,error:event.error||null})),final_result:record.result||null,usage:record.usage_complete&&Number.isInteger(record.reported_tokens)?{total_tokens:record.reported_tokens}:null,authoritative_mutations:[]};
  };
}
module.exports={createAgentExecutor};
