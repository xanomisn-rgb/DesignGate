const fs=require('fs');
const path=require('path');
const Canonical=require('../../backend/crypto/canonical_json');
function fail(code){const error=Error(code);error.code=code;throw error;}
function freeze(value){if(value&&typeof value==='object'){Object.freeze(value);for(const child of Object.values(value))freeze(child);}return value;}
class BenchmarkLoader{
  constructor({fixture_root=path.join(__dirname,'fixtures')}={}){if(typeof fixture_root!=='string'||!fixture_root)fail('BENCHMARK_FIXTURE_ROOT_REQUIRED');this.fixture_root=path.resolve(fixture_root);}
  loadDev(){
    let document,freezeManifest;try{document=JSON.parse(fs.readFileSync(path.join(this.fixture_root,'dev_cases.json'),'utf8'));freezeManifest=JSON.parse(fs.readFileSync(path.join(this.fixture_root,'freeze_manifest.json'),'utf8'));}catch{fail('BENCHMARK_FIXTURE_UNAVAILABLE');}
    if(document?.benchmark_version!=='1.0.0'||!Array.isArray(document.cases)||document.cases.length!==21)fail('BENCHMARK_FIXTURE_INVALID');
    const ids=new Set();for(const item of document.cases)if(!item||item.split!=='dev'||typeof item.case_id!=='string'||ids.has(item.case_id)||typeof item.agent_input?.prompt!=='string')fail('BENCHMARK_FIXTURE_INVALID');else ids.add(item.case_id);
    const fixture_hash=Canonical.sha256(document);if(freezeManifest?.benchmark_version!==document.benchmark_version||freezeManifest?.canonical_fixture_sha256!==fixture_hash)fail('BENCHMARK_FREEZE_HASH_MISMATCH');
    const cases=freeze(structuredClone(document.cases));
    return Object.freeze({benchmark_version:document.benchmark_version,fixture_hash,status:'FROZEN',cases,agentInput:caseItem=>{if(!cases.includes(caseItem))fail('BENCHMARK_CASE_SCOPE_DENIED');return structuredClone({prompt:caseItem.agent_input.prompt,context:caseItem.agent_input.context||{}});}});
  }
  loadHeldout(){fail('HELDOUT_PAYLOAD_UNAVAILABLE');}
}
module.exports=BenchmarkLoader;
