const fs=require('fs');
const path=require('path');
const BenchmarkLoader=require('./benchmark_loader');
const GoldIsolationGuard=require('./gold_isolation_guard');
const RunManifest=require('./run_manifest');
const DeterministicGrader=require('./deterministic_grader');
const SemanticGrader=require('./semantic_grader');
const ReviewExport=require('./expert_review_export');
const TERMINAL_TRIAL_STATUSES=new Set(['COMPLETED','WAITING_INPUT','FAILED','CANCELLED']);
function resumableTrial(candidate,caseId,manifest){
  return candidate&&candidate.case_id===caseId&&candidate.resume_manifest_hash===manifest.manifest_hash&&TERMINAL_TRIAL_STATUSES.has(candidate.status);
}
async function runDev({bindings={},execute,onCase=null,resume_results={}}={}){
  if(typeof execute!=='function')throw Error('V1_EXECUTOR_REQUIRED');
  const loader=new BenchmarkLoader(),suite=loader.loadDev();
  const manifest=RunManifest.create({benchmark_version:suite.benchmark_version,fixture_hash:suite.fixture_hash,...bindings});
  if(manifest.status==='UNBOUND_EVAL_RESULT')return {status:manifest.status,manifest,case_results:[]};
  const raw=[];for(const caseItem of suite.cases){
    const previous=resume_results[caseItem.case_id];
    if(resumableTrial(previous,caseItem.case_id,manifest)){raw.push({...structuredClone(previous),resumed:true});continue;}
    const trial={case_id:caseItem.case_id,...await execute(suite.agentInput(caseItem)),resume_manifest_hash:manifest.manifest_hash};raw.push(trial);if(onCase)await onCase(structuredClone(trial));
  }
  const guard=new GoldIsolationGuard({gold_root:path.join(__dirname,'gold')});
  const document=JSON.parse(fs.readFileSync(guard.resolveForGrader('dev_gold.json'),'utf8')),goldById=new Map((document.gold||[]).map(item=>[item.case_id,item]));
  const case_results=raw.map(trial=>{const gold=goldById.get(trial.case_id);return {...trial,deterministic_grade:DeterministicGrader.grade(trial,gold),semantic_grade:SemanticGrader.grade(trial,gold)};});
  return {status:'RUNNER_IMPLEMENTED',manifest,case_results};
}
function writeJson(file,value){fs.writeFileSync(file,JSON.stringify(value,null,2),{mode:0o600});}
function writeJsonl(file,rows){fs.writeFileSync(file,rows.map(row=>JSON.stringify(row)).join('\n')+(rows.length?'\n':''),{mode:0o600});}
function writeArtifacts(report,dir){
  fs.mkdirSync(dir,{recursive:true});const cases=report.case_results||[];
  writeJson(path.join(dir,'run_manifest.json'),report.manifest||{status:report.status});
  writeJsonl(path.join(dir,'case_results.jsonl'),cases);
  writeJsonl(path.join(dir,'tool_traces.jsonl'),cases.flatMap(item=>(item.tool_trace||[]).map(trace=>({case_id:item.case_id,...trace}))));
  writeJsonl(path.join(dir,'hard_safety_events.jsonl'),cases.flatMap(item=>(item.deterministic_grade?.hard_safety_events||[]).map(event=>({case_id:item.case_id,event}))));
  writeJson(path.join(dir,'aggregate_metrics.json'),{case_count:cases.length,deterministic_pass:cases.filter(item=>item.deterministic_grade?.status==='PASS').length,deterministic_fail:cases.filter(item=>item.deterministic_grade?.status==='FAIL').length,status:report.status});
  writeJson(path.join(dir,'model_usage.json'),{model:report.manifest?.model||null,case_count:cases.length,usage_status:'EXECUTOR_DEFINED'});
  const reviewExport={status:'PENDING_HUMAN_REVIEW',cases:cases.map(item=>({case_id:item.case_id,deterministic_status:item.deterministic_grade?.status||null,reviewed:false,reviewer:null,reviewed_at:null,notes:null}))};ReviewExport.validate(reviewExport);writeJson(path.join(dir,'expert_review_export.json'),reviewExport);
  fs.writeFileSync(path.join(dir,'validation_summary.md'),`# Benchmark v1 validation\n\n- Status: ${report.status}\n- Cases: ${cases.length}\n- Deterministic results require separate human review for semantic quality.\n`,{mode:0o600});
}
module.exports={runDev,writeArtifacts};
