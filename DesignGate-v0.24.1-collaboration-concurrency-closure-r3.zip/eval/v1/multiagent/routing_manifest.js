const Canonical=require('../../../backend/crypto/canonical_json');
function fail(code){const error=Error(code);error.code=code;throw error;}
function create({fixture_hash,knowledge_snapshot_hash,shared_budget,variants}={}){
  if(!/^[a-f0-9]{64}$/.test(fixture_hash||'')||!/^[a-f0-9]{64}$/.test(knowledge_snapshot_hash||'')||!Number.isInteger(shared_budget?.max_tokens)||shared_budget.max_tokens<1||!Array.isArray(variants)||variants.length!==3||new Set(variants.map(item=>item.name)).size!==3||variants.some(item=>!['A','B','C'].includes(item.name)||typeof item.model!=='string'||!item.model))fail('MULTIAGENT_FAIRNESS_BINDING_INVALID');
  if(new Set(variants.map(item=>item.model)).size!==1)fail('MULTIAGENT_FAIRNESS_BINDING_INVALID');
  const manifest={schema_version:'v1-multiagent-routing',fixture_hash,knowledge_snapshot_hash,shared_budget:structuredClone(shared_budget),variants:structuredClone(variants),same_base_model_limitation:true,status:'ROUTING_CONFIGURED_NOT_VALIDATED'};
  return {...manifest,manifest_hash:Canonical.sha256(manifest)};
}
module.exports={create};
