const AgentModelClient=require('../../../connectors/agent_model_client');
const {create}=require('./agent_adapter');
const Runner=require('./runner');
const fs=require('fs');
const path=require('path');
const Canonical=require('../../../backend/crypto/canonical_json');
const BenchmarkLoader=require('../benchmark_loader');
function bindings(model){
  const root=path.resolve(__dirname,'../../..'),suite=new BenchmarkLoader().loadDev();
  return {fixture_hash:suite.fixture_hash,knowledge_snapshot_hash:Canonical.sha256(fs.readFileSync(path.join(root,'knowledge/curated/records.json'),'utf8')),model};
}
async function run({env=process.env,input={prompt:'Bounded A/B/C review',context:{}},shared_budget={max_tokens:12000},route_reserve_tokens=null,storage_root='eval/v1/runs/multiagent-live'}={}){
  const required=['DESIGNGATE_EVAL_API_KEY','DESIGNGATE_EVAL_BASE_URL','DESIGNGATE_EVAL_MODEL'],missing=required.filter(key=>!env[key]);
  if(missing.length)return {status:'BLOCKED_BY_ENVIRONMENT',milestone:'MULTIAGENT_LIVE_VALIDATION_NOT_RUN',missing};
  const client=new AgentModelClient(()=>({apiKey:env.DESIGNGATE_EVAL_API_KEY,baseUrl:env.DESIGNGATE_EVAL_BASE_URL,model:env.DESIGNGATE_EVAL_MODEL}));
  const execute=create({storage_root,model:request=>client.call(request)});
  return Runner.run({...bindings(env.DESIGNGATE_EVAL_MODEL),shared_budget,route_reserve_tokens,input,execute});
}
module.exports={run,bindings};
