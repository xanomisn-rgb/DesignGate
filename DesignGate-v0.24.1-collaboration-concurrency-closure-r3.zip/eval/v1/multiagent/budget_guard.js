function fail(code){const error=Error(code);error.code=code;throw error;}
class BudgetGuard{
  constructor({max_tokens}={}){if(!Number.isInteger(max_tokens)||max_tokens<1)fail('MULTIAGENT_BUDGET_INVALID');this.max_tokens=max_tokens;this.used_tokens=0;this.by_role={};}
  reserve({role,tokens}={}){if(typeof role!=='string'||!role||!Number.isInteger(tokens)||tokens<0)fail('MULTIAGENT_BUDGET_INVALID');if(this.used_tokens+tokens>this.max_tokens)fail('MULTIAGENT_SHARED_BUDGET_EXCEEDED');this.used_tokens+=tokens;this.by_role[role]=(this.by_role[role]||0)+tokens;return this.snapshot();}
  snapshot(){return {max_tokens:this.max_tokens,used_tokens:this.used_tokens,remaining_tokens:this.max_tokens-this.used_tokens,by_role:structuredClone(this.by_role)};}
}
module.exports=BudgetGuard;
