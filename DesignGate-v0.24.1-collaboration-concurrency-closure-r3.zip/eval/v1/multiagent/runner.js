const RoutingManifest=require('./routing_manifest');
const BudgetGuard=require('./budget_guard');
function fail(code){const error=Error(code);error.code=code;throw error;}
async function run({fixture_hash,knowledge_snapshot_hash,model,shared_budget,input,execute,route_reserve_tokens=null}={}){
  if(typeof model!=='string'||!model||typeof execute!=='function')fail('MULTIAGENT_RUNNER_CONFIG_INVALID');
  const variants=['A','B','C'].map(name=>({name,model}));
  const manifest=RoutingManifest.create({fixture_hash,knowledge_snapshot_hash,shared_budget,variants});
  if(route_reserve_tokens!==null&&(!Number.isInteger(route_reserve_tokens)||route_reserve_tokens<1))fail('MULTIAGENT_ROUTE_RESERVE_INVALID');
  const budget=new BudgetGuard(shared_budget),results=[];
  for(const variant of variants){
    if(route_reserve_tokens!==null&&budget.snapshot().remaining_tokens<route_reserve_tokens)return {status:'MULTIAGENT_SHARED_BUDGET_EXCEEDED',manifest,results,budget:budget.snapshot(),blocked_route:variant.name,blocked_before_execution:true,same_base_model_limitation:true};
    const result=await execute({variant:structuredClone(variant),input:structuredClone(input)});
    if(!result||!Number.isInteger(result.usage?.total_tokens)||result.usage.total_tokens<0)fail('MULTIAGENT_USAGE_UNAVAILABLE');
    try{budget.reserve({role:variant.name,tokens:result.usage.total_tokens});}
    catch(error){if(error.code==='MULTIAGENT_SHARED_BUDGET_EXCEEDED')return {status:error.code,manifest,results,budget:budget.snapshot(),blocked_route:variant.name,same_base_model_limitation:true};throw error;}
    results.push({variant:variant.name,result:structuredClone(result)});
  }
  return {status:'MULTIAGENT_RUNNER_IMPLEMENTED_PENDING_HUMAN_REVIEW',manifest,results,budget:budget.snapshot(),same_base_model_limitation:true};
}
module.exports={run};
