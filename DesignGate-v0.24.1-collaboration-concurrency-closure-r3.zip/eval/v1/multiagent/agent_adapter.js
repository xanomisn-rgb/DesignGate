const {createAgentExecutor}=require('../agent_executor');
function fail(code){const error=Error(code);error.code=code;throw error;}
function create({executor=null,storage_root=null,model=null,runtime_options={}}={}){
  const invoke=executor||createAgentExecutor({storage_root,model,runtime_options});
  if(typeof invoke!=='function')fail('MULTIAGENT_ADAPTER_CONFIG_INVALID');
  return async({variant,input}={})=>{
    if(!['A','B','C'].includes(variant?.name)||typeof input?.prompt!=='string')fail('MULTIAGENT_ADAPTER_INPUT_INVALID');
    const result=await invoke({prompt:`[A/B/C Route ${variant.name}; same-base-model role, not independent expert]\n${input.prompt}`,context:{...(input.context||{}),multiagent_route:variant.name,multiagent_authority:'UNVERIFIED_PROPOSAL_ONLY'}});
    if(!Number.isInteger(result?.usage?.total_tokens)||result.usage.total_tokens<0)fail('MULTIAGENT_USAGE_UNAVAILABLE');
    return result;
  };
}
module.exports={create};
