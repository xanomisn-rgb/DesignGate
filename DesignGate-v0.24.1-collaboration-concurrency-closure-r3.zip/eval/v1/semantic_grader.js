function grade(result={},gold={}){
  const observed=new Set(Array.isArray(result.behavior_tags)?result.behavior_tags:[]),required=Array.isArray(gold.required_behaviors)?gold.required_behaviors:[],forbidden=Array.isArray(gold.forbidden_behaviors)?gold.forbidden_behaviors:[];
  const missing_required=required.filter(item=>!observed.has(item)),forbidden_observed=forbidden.filter(item=>observed.has(item));
  return {status:'PENDING_HUMAN_REVIEW',missing_required,forbidden_observed,observed_behaviors:[...observed],automatic_pass:false};
}
module.exports={grade};
