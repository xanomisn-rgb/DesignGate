const fs=require('fs');
const path=require('path');
const Canonical=require('../../backend/crypto/canonical_json');
const AgentModelClient=require('../../connectors/agent_model_client');
const {createAgentExecutor}=require('./agent_executor');
const {runDev,writeArtifacts}=require('./runner');
const BenchmarkLoader=require('./benchmark_loader');
const RunManifest=require('./run_manifest');
const LiveJournal=require('./live_journal');
function sourceHash(file){return Canonical.sha256(fs.readFileSync(file,'utf8'));}
function manifestFor(bindings){const suite=new BenchmarkLoader().loadDev();return RunManifest.create({benchmark_version:suite.benchmark_version,fixture_hash:suite.fixture_hash,...bindings});}
function resumeResults(file,bindings){
  const byRepeat=LiveJournal.loadForManifest(file,manifestFor(bindings).manifest_hash);
  return Object.fromEntries([...byRepeat.entries()].map(([repeat,records])=>[repeat,Object.fromEntries(records)]));
}
async function run({env=process.env,output_dir=null,repeats=3}={}){
  if(!Number.isInteger(repeats)||repeats<1||repeats>10)throw Error('LIVE_REPEAT_COUNT_INVALID');
  const required=['DESIGNGATE_EVAL_API_KEY','DESIGNGATE_EVAL_BASE_URL','DESIGNGATE_EVAL_MODEL'];
  const missing=required.filter(name=>!env[name]);if(missing.length)return {status:'BLOCKED_BY_ENVIRONMENT',milestone:'LIVE_MODEL_VALIDATION_NOT_RUN',missing,planned_runs:21*repeats};
  const root=path.resolve(__dirname,'../..'),client=new AgentModelClient(()=>({apiKey:env.DESIGNGATE_EVAL_API_KEY,baseUrl:env.DESIGNGATE_EVAL_BASE_URL,model:env.DESIGNGATE_EVAL_MODEL}));
  const bindings={code_artifact_hash:sourceHash(path.join(root,'backend/agent_runtime.js')),tool_registry_hash:sourceHash(path.join(root,'backend/agent_tools.js')),knowledge_snapshot_hash:sourceHash(path.join(root,'knowledge/curated/records.json')),runtime_config_hash:Canonical.sha256({maxToolSteps:80,maxModelRequests:120,maxDurationMs:900000}),model:{provider:'CONFIGURED_PROVIDER',name:env.DESIGNGATE_EVAL_MODEL,version:env.DESIGNGATE_EVAL_MODEL}};
  const target=output_dir||path.join(root,'eval/v1/runs'),journal=path.join(target,'live_case_journal.jsonl');fs.mkdirSync(target,{recursive:true});
  const lock=LiveJournal.acquireLock(journal);try{
    const resume=resumeResults(journal,bindings),reports=[];for(let repeat=0;repeat<repeats;repeat++)reports.push(await runDev({bindings,resume_results:resume[repeat+1]||{},execute:createAgentExecutor({storage_root:path.join(target,'.work',`repeat-${repeat+1}`),model:request=>client.call(request)}),onCase:trial=>LiveJournal.append(journal,{repeat:repeat+1,...trial})}));
    const report={...reports[0],case_results:reports.flatMap((item,repeat)=>item.case_results.map(row=>({...row,repeat:repeat+1}))),planned_runs:21*repeats};
    if(output_dir)writeArtifacts(report,output_dir);return {...report,milestone:'LIVE_MODEL_DEV_VALIDATED_PENDING_AUDIT'};
  }finally{LiveJournal.releaseLock(lock);}
}
module.exports={run,manifestFor,resumeResults};
