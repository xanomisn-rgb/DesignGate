const KINDS=new Set(['CAD_TIMEOUT','MALFORMED_SCHEMA','EVENT_CHAIN_TAMPER','DUPLICATE_REPLAY','IDEMPOTENCY_CONFLICT','OUT_OF_ORDER','UNCERTAIN_WRITE_RETRY','CHECKPOINT_TAMPER']);
function fail(code){const error=Error(code);error.code=code;throw error;}
function apply(input={},spec={}){
  if(!KINDS.has(spec.kind)||typeof spec.seed!=='string'||!spec.seed)fail('FAULT_INJECTION_UNKNOWN');
  const result=structuredClone(input);
  if(spec.kind==='CAD_TIMEOUT')result.tool_status='TIMEOUT';
  if(spec.kind==='MALFORMED_SCHEMA')result.payload={malformed:true};
  if(spec.kind==='EVENT_CHAIN_TAMPER')result.event_chain='INVALID';
  if(spec.kind==='DUPLICATE_REPLAY')result.duplicate_replay=true;
  if(spec.kind==='IDEMPOTENCY_CONFLICT')result.idempotency_conflict=true;
  if(spec.kind==='OUT_OF_ORDER')result.out_of_order=true;
  if(spec.kind==='UNCERTAIN_WRITE_RETRY')result.uncertain_write=true;
  if(spec.kind==='CHECKPOINT_TAMPER')result.checkpoint_hash='INVALID';
  return result;
}
module.exports={KINDS,apply};
