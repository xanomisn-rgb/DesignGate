const fs=require('fs');
const Canonical=require('../../backend/crypto/canonical_json');
const TERMINAL=new Set(['COMPLETED','WAITING_INPUT','FAILED','CANCELLED']);
function journalError(message){const error=Error(message);error.code=message;return error;}
function readRows(file){
  if(!fs.existsSync(file))return [];
  return fs.readFileSync(file,'utf8').split(/\r?\n/).filter(Boolean).map((line,index)=>{
    try{return JSON.parse(line);}catch{throw journalError(`LIVE_JOURNAL_INVALID_LINE_${index+1}`);}
  });
}
function verifiedRows(file){
  let previousHash=null;const valid=[];
  for(const row of readRows(file)){
    if(!row.journal_hash)continue; // Legacy entries remain historical, never resumable.
    const {journal_hash,...unsigned}=row;
    if(!/^[a-f0-9]{64}$/.test(journal_hash)||unsigned.journal_prev_hash!==previousHash||Canonical.sha256(unsigned)!==journal_hash)throw journalError('LIVE_JOURNAL_INTEGRITY_INVALID');
    previousHash=journal_hash;valid.push(row);
  }
  return {valid,previousHash};
}
function append(file,row){
  if(!row||!Number.isInteger(row.repeat)||row.repeat<1||typeof row.case_id!=='string'||!row.case_id||typeof row.resume_manifest_hash!=='string')throw journalError('LIVE_JOURNAL_RECORD_INVALID');
  const {previousHash}=verifiedRows(file),unsigned={...structuredClone(row),journal_prev_hash:previousHash},record={...unsigned,journal_hash:Canonical.sha256(unsigned)};
  fs.mkdirSync(require('path').dirname(file),{recursive:true});fs.appendFileSync(file,JSON.stringify(record)+'\n',{mode:0o600});return record;
}
function acquireLock(file){
  const lock=`${file}.lock`;fs.mkdirSync(require('path').dirname(lock),{recursive:true});
  let descriptor;try{descriptor=fs.openSync(lock,'wx',0o600);}catch(error){if(error.code==='EEXIST')throw journalError('LIVE_JOURNAL_LOCKED');throw error;}
  try{fs.writeFileSync(descriptor,JSON.stringify({pid:process.pid,acquired_at:new Date().toISOString()})+'\n');}finally{fs.closeSync(descriptor);}
  return lock;
}
function releaseLock(lock){if(typeof lock==='string'&&fs.existsSync(lock))fs.unlinkSync(lock);}
function loadForManifest(file,manifestHash){
  const result=new Map();
  for(const row of verifiedRows(file).valid){
    if(row.resume_manifest_hash!==manifestHash||!TERMINAL.has(row.status))continue;
    if(!result.has(row.repeat))result.set(row.repeat,new Map());
    const bucket=result.get(row.repeat),existing=bucket.get(row.case_id);
    if(existing&&existing.journal_hash!==row.journal_hash)throw journalError('LIVE_JOURNAL_DUPLICATE_CONFLICT');
    bucket.set(row.case_id,row);
  }
  return result;
}
module.exports={append,loadForManifest,acquireLock,releaseLock,TERMINAL};
