const Canonical=require('../../backend/crypto/canonical_json');
const REQUIRED_HASHES=['fixture_hash','code_artifact_hash','tool_registry_hash','knowledge_snapshot_hash','runtime_config_hash'];
function hash(value){return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);}
function create(input={}){
  const missing=[...REQUIRED_HASHES.filter(key=>!hash(input[key])),...(!input.benchmark_version?['benchmark_version']:[]),...(!input.model?.provider||!input.model?.name||!input.model?.version?['model']:[])];
  const manifest={schema_version:'benchmark-run-manifest-v1',benchmark_version:input.benchmark_version||null,fixture_hash:input.fixture_hash||null,code_artifact_hash:input.code_artifact_hash||null,tool_registry_hash:input.tool_registry_hash||null,knowledge_snapshot_hash:input.knowledge_snapshot_hash||null,runtime_config_hash:input.runtime_config_hash||null,model:input.model||null,temperature:input.temperature??null,seed:input.seed??null,status:missing.length?'UNBOUND_EVAL_RESULT':'RUNNER_IMPLEMENTED',missing_bindings:missing};
  return {...manifest,manifest_hash:Canonical.sha256(manifest)};
}
module.exports={create,REQUIRED_HASHES};
