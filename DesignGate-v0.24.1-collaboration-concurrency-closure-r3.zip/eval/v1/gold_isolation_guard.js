const path=require('path');
function fail(code){const error=Error(code);error.code=code;throw error;}
class GoldIsolationGuard{
  constructor({gold_root}={}){if(typeof gold_root!=='string'||!gold_root)fail('GOLD_ROOT_REQUIRED');this.gold_root=path.resolve(gold_root);}
  resolveForAgent(){fail('GOLD_ACCESS_DENIED');}
  resolveForGrader(name){if(typeof name!=='string'||!/^[-_a-zA-Z0-9]+\.json$/.test(name))fail('GOLD_PATH_INVALID');return path.join(this.gold_root,name);}
}
module.exports=GoldIsolationGuard;
