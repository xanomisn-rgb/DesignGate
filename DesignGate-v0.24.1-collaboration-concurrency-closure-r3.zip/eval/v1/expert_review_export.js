function fail(code){const error=Error(code);error.code=code;throw error;}
function validate(exportDocument={}){
  if(exportDocument.status!=='PENDING_HUMAN_REVIEW'||!Array.isArray(exportDocument.cases))fail('EXPERT_REVIEW_INVALID');
  for(const row of exportDocument.cases){if(typeof row?.case_id!=='string'||!row.case_id)fail('EXPERT_REVIEW_INVALID');if(row.reviewed===true&&(!String(row.reviewer||'').trim()||!Number.isFinite(Date.parse(row.reviewed_at||''))))fail('EXPERT_REVIEW_INVALID');}
  return true;
}
module.exports={validate};
