/* Offline planning is the default. --live is the only mode that sends model requests. */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const C=require('../backend/contracts'),State=require('../backend/project_state_manager'),Agent=require('../backend/agent_runtime'),Client=require('../connectors/agent_model_client');
const {makeReviewPackets}=require('./review_packet');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const integer=(value,name,{min=1,max=Number.MAX_SAFE_INTEGER}={})=>{const n=Number(value);if(!Number.isInteger(n)||n<min||n>max)throw Error(name+' 必须是 '+min+'..'+max+' 的整数');return n;};
function snapshot(root){
 const files=['backend/agent_runtime.js','backend/agent_tools.js','backend/negotiation_service.js','backend/role_boundary.js','backend/context_projection.js','backend/action_patch.js','backend/proposal_critique.js','backend/engineering_assets.js','backend/rule_engine.js','backend/check_engine.js','backend/knowledge_service.js','backend/measurement_observation.js','connectors/agent_model_client.js','knowledge/curated/records.json','knowledge/curated/sources.json','knowledge/curated/executable_rules.json','tools/brep_analyzer.py','tools/brep_measurements.py','tools/geometry_analyzer.py','backend/handover_service.js','tools/handover_package.py','eval/run.js','eval/code_grader.js','eval/metrics.js','eval/failure_taxonomy.js','eval/answer_key_validator.js','eval/capability_grader.js','eval/scenario_runner.js','eval/scenario_grader.js','eval/multi_agent_live_runner.js','eval/multi_agent_benchmark.js'];
 return Object.fromEntries(files.filter(f=>fs.existsSync(path.join(root,f))).map(f=>[f,C.hash(fs.readFileSync(path.join(root,f),'utf8'))]));
}
function projectHash(project){const copy=structuredClone(project);delete copy.updated_at;return C.hash(copy);}
function validateDataset(dataset){
 if(!dataset||!Array.isArray(dataset.cases)||dataset.cases.length<1)throw Error('数据集缺少 cases');
 const ids=new Set();for(const task of dataset.cases){C.id(task.id,'case');C.id(task.project?.project_id);if(ids.has(task.id))throw Error('重复案例编号');ids.add(task.id);if(!task.goal?.trim())throw Error(task.id+' 缺少目标');}
 return dataset;
}
function selectCases(dataset,{caseId=null,limit=null}={}){
 let selected=caseId?dataset.cases.filter(c=>c.id===caseId):dataset.cases.slice();
 if(caseId&&!selected.length)throw Error('未知案例 '+caseId);
 if(limit!==null){const n=integer(limit,'limit',{max:selected.length});selected=selected.slice(0,n);}
 return selected;
}
function resolveEvalFiles(task,root){const out={};for(const [kind,relative] of Object.entries(task.eval_files||{})){if(!['briefFile','designFile','bomFile','cadFile'].includes(kind)||typeof relative!=='string')throw Error(task.id+' eval_files 无效');const file=path.resolve(root,relative),prefix=path.resolve(root)+path.sep;if(!file.toLowerCase().startsWith(prefix.toLowerCase())||!fs.existsSync(file))throw Error(task.id+' eval file 不存在或超出仓库');out[kind]=file;}return out;}
async function mapConcurrent(items,concurrency,fn){
 const results=new Array(items.length);let cursor=0;
 async function worker(){for(;;){const i=cursor++;if(i>=items.length)return;results[i]=await fn(items[i],i);}}
 await Promise.all(Array.from({length:Math.min(concurrency,items.length)},worker));return results;
}
function trialRecord(task,index,record,initial,final,error=null){
 const events=record?.events||[],success=events.filter(e=>e.status==='SUCCEEDED');
 const observation=e=>{const output=e.output,revision=output?.revision||output?.project?.design?.active_revision||final?.design?.active_revision||null,source_sha256=output?.source_sha256||output?.geometry?.source_sha256||output?.result?.source_sha256||output?.project?.design?.cad_geometry?.source_sha256||null;return {observation_id:e.id,tool:e.tool,run_id:record?.run_id||null,project_id:output?.project_id||record?.project_id||final?.project_id||null,revision,source_sha256,output};};
 return {case_id:task.id,trial_id:`${task.id}-T${String(index+1).padStart(3,'0')}-${crypto.randomUUID()}`,trial_index:index+1,
  run_id:record?.run_id||null,model:null,temperature:null,seed_if_supported:null,status:record?.status||'RUNNER_ERROR',steps:record?.steps||0,model_requests:record?.rounds||0,
  tool_calls:events.map(e=>({observation_id:e.id,tool:e.tool,status:e.status,arguments:e.arguments||null,error:e.error||null,error_class:e.error_class||null,recovery_action:e.recovery_action||null,recovered_by:e.recovered_by||null,recovered_failures:e.recovered_failures||[],tool_duration_ms:e.tool_duration_ms??null})),successful_tool_calls:success.length,failed_tool_calls:events.filter(e=>['FAILED','INTERRUPTED'].includes(e.status)).length,
  observations:success.map(observation),pause_reason:record?.question||record?.error||null,final_result:record?.result||null,
  initial_project_hash:projectHash(initial),final_project_hash:projectHash(final),project_changed:projectHash(initial)!==projectHash(final),initial_state_snapshot:initial,final_state_snapshot:final,
  token_usage:{estimated:record?.token_estimate||0,reported:record?.reported_tokens||0,cached:record?.cached_tokens||0,total:Math.max(record?.token_estimate||0,record?.reported_tokens||0)},model_telemetry:record?.model_telemetry||[],active_ms:record?.active_ms||0,error:error?String(error.message||error):record?.error||null};
}
async function run({dataset,output,live=false,limit=null,env=process.env,model=null,caseId=null,trials=1,seed=null,concurrency=1,temperature=0.1}={}){
 validateDataset(dataset);trials=integer(trials,'trials',{max:100});concurrency=integer(concurrency,'concurrency',{max:16});if(seed!==null)seed=integer(seed,'seed',{min:0});
 const selected=selectCases(dataset,{caseId,limit});if(fs.existsSync(output))throw Error('输出文件已存在，请使用新的运行文件名');
 if(live&&!model&&(!env.DESIGNGATE_EVAL_API_KEY||!env.DESIGNGATE_EVAL_BASE_URL||!env.DESIGNGATE_EVAL_MODEL))throw Error('真实评测需配置 DESIGNGATE_EVAL_API_KEY / BASE_URL / MODEL；未发出请求');
 const root=path.join(__dirname,'..'),modelName=live?(env.DESIGNGATE_EVAL_MODEL||'TEST_TRANSPORT'):null;
 const providerSeedSupported=!model&&env.DESIGNGATE_EVAL_PROVIDER_SEED_SUPPORTED==='true';
 const codeAndKnowledge=snapshot(root),budget={max_tool_steps:80,max_model_requests:120,max_negotiation_rounds:24,token_budget_enabled:false,max_tokens:null,max_active_ms:900000},configuration={trials,requested_seed:seed,provider_seed_supported:providerSeedSupported,provider_seed_applied:providerSeedSupported&&seed!==null,concurrency};
 const answerKeyFile=path.join(__dirname,'answer_key.json'),frozenInputs={code_hash:C.hash(codeAndKnowledge),case_hash:C.hash(selected),knowledge_hash:C.hash(Object.fromEntries(Object.entries(codeAndKnowledge).filter(([name])=>name.startsWith('knowledge/')))),answer_hash:fs.existsSync(answerKeyFile)?C.hash(read(answerKeyFile)):C.hash(null),config_hash:C.hash({budget,configuration,model:modelName,temperature:live?temperature:null,mode:live?(model?'INJECTED_TEST_TRANSPORT':'LIVE_MODEL'):'OFFLINE_PLAN_ONLY'})};
 const result={schema_version:4,dataset_hash:C.hash(dataset),dataset_version:dataset.dataset_version,status:live?'RUNNING':'NOT_RUN',capability_status:live?'PENDING_REVIEW':'UNVERIFIED',model:modelName,temperature:live?temperature:null,endpoint_hash:live?C.hash(env.DESIGNGATE_EVAL_BASE_URL||'TEST'):null,mode:live?(model?'INJECTED_TEST_TRANSPORT':'LIVE_MODEL'):'OFFLINE_PLAN_ONLY',created_at:new Date().toISOString(),code_and_knowledge:codeAndKnowledge,frozen_inputs:frozenInputs,budget,configuration,selected_cases:selected.map(c=>c.id),planned_trial_count:selected.length*trials,cases:[]};
 fs.mkdirSync(path.dirname(output),{recursive:true});const save=()=>{const tmp=output+'.tmp';fs.writeFileSync(tmp,JSON.stringify(result,null,2),{mode:0o600});fs.renameSync(tmp,output);};save();if(!live)return result;
 const client=model?null:new Client(()=>({apiKey:env.DESIGNGATE_EVAL_API_KEY,baseUrl:env.DESIGNGATE_EVAL_BASE_URL,model:env.DESIGNGATE_EVAL_MODEL,temperature,seedSupported:providerSeedSupported}));
 const workRoot=fs.mkdtempSync(path.join(path.dirname(output),'.dg-eval-work-'));
 const jobs=selected.flatMap(task=>Array.from({length:trials},(_,trialIndex)=>({task,trialIndex})));
 try{
  const collected=await mapConcurrent(jobs,concurrency,async({task,trialIndex},jobIndex)=>{
   const trialDir=path.join(workRoot,task.id,'trial-'+String(trialIndex+1).padStart(3,'0'));const sm=new State(trialDir);sm.saveProject(structuredClone(task.project),0);
   const initial=structuredClone(sm.getProject(task.project.project_id));let record=null,error=null;
   try{const runtime=new Agent(sm,model||((req)=>client.call({...req,seed:seed===null?undefined:seed+jobIndex})),{maxToolSteps:budget.max_tool_steps,maxModelRequests:budget.max_model_requests,maxNegotiationRounds:budget.max_negotiation_rounds,maxDurationMs:budget.max_active_ms,cumulativeTokenBudget:budget.max_tokens,tokenBudgetEnabled:budget.token_budget_enabled});const files=resolveEvalFiles(task,root);const start=runtime.start(task.project.project_id,task.goal,{files,cadOptions:task.cad_options||{}});record=await runtime.settled(task.project.project_id,start.run_id);}
   catch(e){error=e;}
   const final=structuredClone(sm.getProject(task.project.project_id));const trial=trialRecord(task,trialIndex,record,initial,final,error);trial.model=modelName;trial.temperature=temperature;trial.requested_seed=seed===null?null:seed+jobIndex;trial.provider_seed_supported=providerSeedSupported;trial.provider_seed_applied=providerSeedSupported&&seed!==null;trial.seed_if_supported=trial.provider_seed_applied?trial.requested_seed:null;result.cases[jobIndex]=trial;save();return trial;
  });
  result.cases=collected;
  result.status='COLLECTED_AWAITING_HUMAN_REVIEW';result.capability_status='UNVERIFIED';save();
  const template={schema_version:2,run_hash:C.hash(result),rubric_version:'0.18-draft',cases:result.cases.map(c=>({case_id:c.case_id,trial_id:c.trial_id,response_hash:C.hash(c),reviewed:false,reviewer:'',reviewed_at:null,rubric_version:'0.18-draft',detected_issue_ids:[],identified_unknown_ids:[],release_claim:null,claims:[],tradeoff_quality:null,explanation_quality:null,communication_quality:null,notes:''}))};
  fs.writeFileSync(output+'.annotations.json',JSON.stringify(template,null,2),{mode:0o600,flag:'wx'});
  fs.writeFileSync(output+'.review-packets.json',JSON.stringify(makeReviewPackets(dataset,result),null,2),{mode:0o600,flag:'wx'});return result;
 }finally{fs.rmSync(workRoot,{recursive:true,force:true});}
}
function cli(argv=process.argv.slice(2)){
 const known=new Set(['--live','--limit','--out','--case','--trials','--seed','--concurrency']);for(const arg of argv.filter(x=>x.startsWith('--')))if(!known.has(arg))throw Error('未知参数 '+arg);
 const value=(key,fallback=null)=>{const i=argv.indexOf(key);if(i<0)return fallback;if(i===argv.length-1||argv[i+1].startsWith('--'))throw Error(key+' 缺少值');return argv[i+1];};
 const dataset=read(path.join(__dirname,'cases.json')),output=path.resolve(value('--out',path.join(__dirname,'runs','run-'+Date.now()+'.json')));
 return {dataset,output,live:argv.includes('--live'),limit:value('--limit'),caseId:value('--case'),trials:value('--trials',1),seed:value('--seed'),concurrency:value('--concurrency',1)};
}
if(require.main===module){const options=cli();run(options).then(r=>console.log(JSON.stringify({status:r.status,capability_status:r.capability_status,trials:r.cases.length,planned_trials:r.planned_trial_count,output:options.output}))).catch(e=>{console.error(e.message);process.exitCode=1;});}
module.exports={run,snapshot,projectHash,validateDataset,selectCases,resolveEvalFiles,mapConcurrent,cli};
