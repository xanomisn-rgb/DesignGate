# v0.15.0-alpha 验证记录

日期：2026-09-07。执行环境：当前 Linux 开发环境；不是 Windows Electron、FreeCAD 或生产模型环境。

| 检查 | 结果 | 可以证明什么 |
|---|---|---|
| npm test | 148 / 148 通过 | 规则、状态机、工具契约及新增权限/记忆/导出行为的自动化回归；模型相关测试使用替身 |
| npm run check | 67 个 JavaScript 文件及 JSON 通过 | 语法和 JSON 可解析 |
| python tools/test_parameter_adapter.py | 5 / 5 通过 | 替身对象下的 dry-run、旧值、表达式、事务提交与回滚检查 |
| python tools/test_brep.py | 2 / 2 通过 | OCP 8.0.1.0.0 下解析样件及损坏 STEP 路径；不是壁厚/倒扣金标准 |
| 工程 ZIP 回读 | 通过 | ZIP CRC、条目数量、文件字节数、SHA-256、空报价保持 null |

本次先发现旧模型传输测试写死 15 个工具，已改为比对完整工具 schema；目前新增导出准备工具后共 16 个。未以删除测试或放宽权限解决回归。

可选 OCP 在当前 Python 环境起初缺失，安装 requirements-cad.txt 后两项样件测试通过。发布包不包含 Python 运行时、OCP 或 node_modules，使用者须在本机安装依赖。

仍未验证：真实模型质量 baseline、专家标签复核、Windows 桌面启动、WebGL 视口与 Finding 定位的实际显示、FreeCAD 实际对象修改、任意 STEP 抽壳/倒角。前端沿用 v0.14 的未完成视觉验收记录，本轮只加了后端操作控件。未提供正式签核、法定符合性证明或完整 PDF/XLSX 工程交接包。
