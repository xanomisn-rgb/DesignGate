const fs = require('fs');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');
const { buildMigrationPlan, executeMigration } = require('../backend/collaboration/solo_team_migration');

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : null;
}

function required(name) {
  const value = argument(name);
  if (!value || value.startsWith('--')) throw new Error(`MIGRATION_ARGUMENT_REQUIRED:${name}`);
  return value;
}

function main() {
  const projectFile = path.resolve(required('--project'));
  const target_project_id = required('--target');
  const soloProject = JSON.parse(fs.readFileSync(projectFile, 'utf8'));
  const plan = buildMigrationPlan({ soloProject, target_project_id });
  if (!process.argv.includes('--execute')) return plan;
  if (plan.status !== 'READY') throw new Error('MIGRATION_MISSING_ARTIFACTS');
  const owner = required('--owner');
  const dataDirectory = path.resolve(required('--data-dir'));
  const artifactDirectory = path.resolve(argument('--artifact-dir') || path.join(dataDirectory, 'artifacts'));
  const store = new TeamStore({ directory: path.join(dataDirectory, 'database') });
  try {
    return executeMigration({ plan, soloProject, store, artifactStore: new LocalImmutableArtifactStore({ directory: artifactDirectory }), actor: { user_id: owner } });
  } finally {
    store.close();
  }
}

try {
  process.stdout.write(`${JSON.stringify(main(), null, 2)}\n`);
} catch (error) {
  process.stderr.write(`${error.code || error.message}\n`);
  process.exitCode = 1;
}
