"""Analytic solid regression; no model transport and no expert golden set."""
import tempfile, os, math, unittest
from brep_analyzer import analyze_step
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.STEPControl import STEPControl_Writer, STEPControl_AsIs
from OCP.gp import gp_Pnt

class BrepTests(unittest.TestCase):
    def test_box(self):
        with tempfile.TemporaryDirectory() as directory:
            filename=os.path.join(directory,'known-box.step')
            writer=STEPControl_Writer(); writer.Transfer(BRepPrimAPI_MakeBox(20,30,1.3).Shape(),STEPControl_AsIs); writer.Write(filename)
            result=analyze_step(filename,{})
            self.assertTrue(result['success'])
            self.assertAlmostEqual(result['bounding_box']['height_mm'],1.3,places=5)
            self.assertAlmostEqual(result['mass_properties']['volume_mm3'],780,places=4)
            self.assertEqual(result['topology']['solids'],1)
            self.assertEqual(result['topology']['faces'],6)
            self.assertEqual(len(result['display_mesh']['positions']),108)
            self.assertIsNone(result['wall_thickness']['minimum_mm'])
            self.assertIsNone(result['undercut_analysis']['has_undercuts'])
    def test_invalid(self):
        with tempfile.TemporaryDirectory() as directory:
            filename=os.path.join(directory,'invalid.step')
            with open(filename,'w') as file: file.write('not a STEP file')
            self.assertFalse(analyze_step(filename,{})['success'])
    def test_multi_solid_reports_every_face_as_unmeasured(self):
        with tempfile.TemporaryDirectory() as directory:
            filename=os.path.join(directory,'two-boxes.step')
            writer=STEPControl_Writer()
            writer.Transfer(BRepPrimAPI_MakeBox(10,10,10).Shape(),STEPControl_AsIs)
            writer.Transfer(BRepPrimAPI_MakeBox(gp_Pnt(20,0,0),10,10,10).Shape(),STEPControl_AsIs)
            writer.Write(filename)
            result=analyze_step(filename,{})
            measurement=result['surface_measurements']
            self.assertEqual(result['topology']['solids'],2)
            self.assertEqual(measurement['coverage']['sampled_faces'],0)
            self.assertEqual(measurement['coverage']['skipped_faces'],result['topology']['faces'])
            self.assertEqual({f['reason'] for f in measurement['coverage']['unmeasured_faces']},{'MULTI_SOLID_UNSUPPORTED'})
            self.assertEqual(result['assembly_analysis']['status'],'ASSEMBLY_PAIR_ANALYZED')
            self.assertEqual(result['assembly_analysis']['pairs'][0]['pair_status'],'SEPARATED_CLEARANCE')

if __name__=='__main__': unittest.main()
