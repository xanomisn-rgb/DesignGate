from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

def _volume(shape):
    props=GProp_GProps(); BRepGProp.VolumeProperties_s(shape,props)
    return props.Mass()

def _aabb_status(shape_a,shape_b):
    def bounds(shape):
        box=Bnd_Box(); BRepBndLib.AddOptimal_s(shape,box,False,False)
        low,high=box.CornerMin(),box.CornerMax()
        return [low.X(),low.Y(),low.Z()],[high.X(),high.Y(),high.Z()]
    low_a,high_a=bounds(shape_a); low_b,high_b=bounds(shape_b)
    return 'DISJOINT' if any(high_a[i]<low_b[i] or high_b[i]<low_a[i] for i in range(3)) else 'OVERLAPPING_OR_TOUCHING'

def _witness_points(shape_a,shape_b):
    distance=BRepExtrema_DistShapeShape(shape_a,shape_b); distance.Perform()
    if not distance.IsDone(): raise RuntimeError('CAD_SHAPE_DISTANCE_FAILED')
    first,second=distance.PointOnShape1(1),distance.PointOnShape2(1)
    return distance.Value(),[[first.X(),first.Y(),first.Z()],[second.X(),second.Y(),second.Z()]]

def assembly_pair(part_a_id,shape_a,part_b_id,shape_b):
    broad_phase=_aabb_status(shape_a,shape_b)
    common=BRepAlgoAPI_Common(shape_a,shape_b); common.Build()
    if not common.IsDone(): raise RuntimeError('CAD_BOOLEAN_COMMON_FAILED')
    overlap=max(0.0,_volume(common.Shape()))
    if overlap>1e-9:
        _,witnesses=_witness_points(shape_a,shape_b)
        return {'analysis':'EXACT_BREP_PAIR','aabb_broad_phase':broad_phase,'pair_status':'INTERFERENCE_VOLUME_OVERLAP','part_a_id':part_a_id,'part_b_id':part_b_id,'interference':True,'intersection_volume_mm3':overlap,'minimum_clearance_mm':0.0,'witness_points_mm':witnesses,'global_mathematical_proof':False,'limitations':['Exact result applies only to the two supplied B-Rep shapes.']}
    clearance,witnesses=_witness_points(shape_a,shape_b)
    return {'analysis':'EXACT_BREP_PAIR','aabb_broad_phase':broad_phase,'pair_status':'TOUCHING_NO_VOLUME_OVERLAP' if clearance<=1e-7 else 'SEPARATED_CLEARANCE','part_a_id':part_a_id,'part_b_id':part_b_id,'interference':False,'intersection_volume_mm3':0.0,'minimum_clearance_mm':clearance,'witness_points_mm':witnesses,'global_mathematical_proof':False,'limitations':['Exact result applies only to the two supplied B-Rep shapes.']}

def assembly_pairs(components):
    if not isinstance(components,list) or len(components)<2: raise ValueError('CAD_ASSEMBLY_REQUIRES_AT_LEAST_TWO_COMPONENTS')
    ids=[item.get('component_id') if isinstance(item,dict) else None for item in components]
    if any(not isinstance(value,str) or not value for value in ids) or len(set(ids))!=len(ids): raise ValueError('CAD_COMPONENT_ID_INVALID_OR_DUPLICATE')
    if any(not isinstance(item,dict) or item.get('shape') is None for item in components): raise ValueError('CAD_COMPONENT_SHAPE_MISSING')
    pairs=[assembly_pair(left['component_id'],left['shape'],right['component_id'],right['shape']) for index,left in enumerate(components) for right in components[index+1:]]
    return {'status':'ASSEMBLY_PAIR_ANALYZED','pair_count':len(pairs),'pairs':pairs,'global_mathematical_proof':False,'limitations':['Only supplied component shapes and pairs are analysed; missing components are not inferred.']}

def thickness_oracle(measurement):
    if not isinstance(measurement,dict) or not isinstance(measurement.get('coverage'),dict): raise ValueError('CAD_THICKNESS_MEASUREMENT_INVALID')
    coverage=measurement['coverage']; candidate=measurement.get('sampled_minimum_chord_mm')
    if candidate is not None and (not isinstance(candidate,(int,float)) or isinstance(candidate,bool) or candidate<0): raise ValueError('CAD_THICKNESS_CANDIDATE_INVALID')
    adaptive_attempted=coverage.get('adaptive_attempted',0); adaptive_accepted=coverage.get('adaptive_accepted',0)
    return {'status':'THICKNESS_CANDIDATE' if candidate is not None else 'THICKNESS_CANDIDATE_UNAVAILABLE','minimum_candidate_mm':candidate,'search_coverage':{'sample_count':coverage.get('sample_count',0),'sampled_faces':coverage.get('sampled_faces',0),'total_faces':coverage.get('total_faces',0),'time_limit_reached':bool(coverage.get('time_limit_reached',False))},'local_refinement':{'performed':adaptive_attempted>0,'attempted_samples':adaptive_attempted,'accepted_samples':adaptive_accepted},'global_mathematical_proof':False,'limitations':['Candidate derives from bounded normal-chord samples and can miss local features.','This is not a global wall-thickness proof or manufacturing approval.']}

def undercut_oracle(measurement):
    if not isinstance(measurement,dict) or not isinstance(measurement.get('samples'),list): raise ValueError('CAD_UNDERCUT_MEASUREMENT_INVALID')
    direction=measurement.get('pull_direction')
    if not isinstance(direction,list) or len(direction)!=3: raise ValueError('CAD_PULL_DIRECTION_REQUIRED')
    faces=sorted({row.get('face_id') for row in measurement['samples'] if isinstance(row,dict) and isinstance(row.get('face_id'),int) and row.get('visibility_plus')=='OCCLUDED' and row.get('visibility_minus')=='OCCLUDED'})
    return {'status':'UNDERCUT_CANDIDATE' if faces else 'NO_UNDERCUT_CANDIDATE_IN_SAMPLES','pull_direction':direction,'affected_faces':faces,'blocked_area_or_candidate_region':'SAMPLED_FACES_ONLY' if faces else None,'possible_side_action_requirement':bool(faces),'confidence':'BOUNDED_SCREENING','global_mathematical_proof':False,'limitations':['Directional visibility is sampled and does not prove complete mould withdrawal or absence of undercuts.']}
