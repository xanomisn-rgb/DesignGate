function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
}

async function request(url, options) {
  const response = await fetch(url, options);
  return { status: response.status, body: await response.json() };
}

async function main() {
  const input = JSON.parse(process.env.DG_CONCURRENCY_WORKER_INPUT || 'null');
  if (!input?.base || !input?.username || !input?.password || !input?.project_id || (!input?.command && !input?.commands)) throw Error('EXTERNAL_COMMAND_INPUT_REQUIRED');
  const login = await request(`${input.base}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: input.username, password: input.password })
  });
  if (login.status !== 200 || typeof login.body?.token !== 'string') throw Error(`EXTERNAL_LOGIN_FAILED:${login.status}:${login.body?.code || 'UNKNOWN'}`);
  const commands = input.commands || [input.command];
  if (!Array.isArray(commands) || !commands.length) throw Error('EXTERNAL_COMMAND_REQUIRED');
  const results = [];
  for (const command of commands) {
    const started = process.hrtime.bigint();
    const result = await request(`${input.base}/api/projects/${encodeURIComponent(input.project_id)}/commands`, {
      method: 'POST',
      headers: { authorization: `Bearer ${login.body.token}`, 'content-type': 'application/json' },
      body: JSON.stringify({ project_id: input.project_id, ...command })
    });
    results.push({ ...result, latency_ms: Number(process.hrtime.bigint() - started) / 1e6 });
  }
  process.stdout.write(JSON.stringify(input.commands ? { results } : results[0]));
}

main().catch(error => fail(error.stack || error.message || String(error)));
