const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const WebSocket = require('ws');
const IdentityService = require('../../backend/collaboration/identity_service');
const TeamStore = require('../../backend/collaboration/team_store');
const LocalImmutableArtifactStore = require('../../backend/collaboration/local_immutable_artifact_store');
const CollaborationServer = require('../../backend/collaboration/server');

function createBarrier(count) {
  let arrived = 0;
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  return { ready: async () => { arrived += 1; if (arrived === count) release(); await gate; } };
}

async function request(base, pathname, options = {}) {
  const response = await fetch(`${base}${pathname}`, options);
  const body = response.status === 204 ? null : await response.json();
  return { status: response.status, body };
}

async function createNetworkFixture({ userCount = 2 } = {}) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-concurrency-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: `test-${crypto.randomUUID()}` });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  const artifactStore = new LocalImmutableArtifactStore({ directory: path.join(directory, 'artifacts') });
  const uploadTempDir = path.join(directory, 'uploads');
  fs.mkdirSync(uploadTempDir, { recursive: true });
  const password = 'concurrency-test-password';
  for (let index = 0; index < userCount; index += 1) identity.register({ user_id: `USER-${index}`, username: `user${index}`, password });
  const server = new CollaborationServer({ identity, store, artifactStore, host: '127.0.0.1', port: 0, uploadTempDir });
  await server.start();
  const base = `http://127.0.0.1:${server.address().port}`;
  const clients = await Promise.all(Array.from({ length: userCount }, async (_, index) => {
    const login = await request(base, '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: `user${index}`, password }) });
    const headers = { authorization: `Bearer ${login.body.token}`, 'content-type': 'application/json' };
    return {
      user_id: `USER-${index}`,
      async createProject(payload) { const result = await request(base, '/api/projects', { method: 'POST', headers, body: JSON.stringify(payload) }); if (result.status !== 201) throw Error(result.body.code); return result.body.project; },
      async project(projectId) { const result = await request(base, `/api/projects/${projectId}`, { headers }); if (result.status !== 200) throw Error(result.body.code); return result.body.project; },
      async command(projectId, command, { allowError = false } = {}) {
        const result = await request(base, `/api/projects/${projectId}/commands`, { method: 'POST', headers, body: JSON.stringify({ command_id: command.command_id || `CMD-${crypto.randomUUID()}`, base_project_version: command.base_project_version ?? (await this.project(projectId)).version, base_entity_version: command.base_entity_version ?? 0, project_id: projectId, ...command }) });
        if (!allowError && result.status !== 200) throw Error(result.body.code);
        return result;
      },
      async addMember(projectId, member) { const result = await request(base, `/api/projects/${projectId}/members`, { method: 'POST', headers, body: JSON.stringify(member) }); if (result.status !== 201) throw Error(result.body.code); return result.body.member; }
      ,async uploadArtifact(projectId, { revision_id, artifact_type, filename, bytes }) {
        const form = new FormData();
        form.set('revision_id', revision_id);
        form.set('artifact_type', artifact_type);
        form.set('file', new Blob([bytes]), filename);
        const response = await fetch(`${base}/api/projects/${projectId}/artifacts`, { method: 'POST', headers: { authorization: headers.authorization }, body: form });
        return { status: response.status, body: await response.json() };
      }
      ,async subscribe(projectId) {
        const events = [];
        const waiters = [];
        const socket = new WebSocket(`${base.replace(/^http/, 'ws')}/api/projects/${projectId}/events`, { headers: { authorization: headers.authorization } });
        await new Promise((resolve, reject) => { socket.once('open', resolve); socket.once('error', reject); });
        socket.on('message', raw => {
          const event = JSON.parse(String(raw));
          if (!Number.isInteger(event.event_seq)) return;
          events.push(event);
          for (const waiter of [...waiters]) if (events.length >= waiter.count) { clearTimeout(waiter.timer); waiters.splice(waiters.indexOf(waiter), 1); waiter.resolve(); }
        });
        return {
          events,
          waitFor(count, timeoutMs) { return new Promise((resolve, reject) => { if (events.length >= count) return resolve(); const waiter = { count, resolve, timer: setTimeout(() => { waiters.splice(waiters.indexOf(waiter), 1); reject(Error(`WEBSOCKET_TIMEOUT:${events.length}/${count}`)); }, timeoutMs) }; waiters.push(waiter); }); },
          close() { return new Promise(resolve => { if (socket.readyState === WebSocket.CLOSED) return resolve(); socket.once('close', resolve); socket.close(); }); }
        };
      }
    };
  }));
  return {
    directory, store, artifactStore, server, base, clients,
    async addCollaborators(projectId, role_id = 'STUDENT_STRUCTURE') { for (const client of clients.slice(1)) await clients[0].addMember(projectId, { user_id: client.user_id, role_id }); },
    async close() { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); }
  };
}

module.exports = { createBarrier, createNetworkFixture };
