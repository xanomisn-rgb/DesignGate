const Canonical = require('../../backend/crypto/canonical_json');

function validateProjectConcurrencyInvariants({ store, artifactStore = null, project_id } = {}) {
  if (!store || !project_id) throw new Error('CONCURRENCY_INVARIANT_INPUT_REQUIRED');
  const violations = [];
  const events = store.listEvents(project_id, { after: 0, limit: 500 });
  let previousHash = null;
  let previousSeq = 0;
  for (const event of events) {
    if (event.event_seq !== previousSeq + 1) violations.push({ code: 'EVENT_SEQUENCE_INVALID', event_id: event.event_id });
    if (event.previous_event_hash !== previousHash) violations.push({ code: 'EVENT_CHAIN_LINK_INVALID', event_id: event.event_id });
    const { event_hash, payload_json, ...hashInput } = event;
    if (Canonical.sha256(hashInput) !== event_hash) violations.push({ code: 'EVENT_HASH_INVALID', event_id: event.event_id });
    previousSeq = event.event_seq;
    previousHash = event.event_hash;
  }
  const artifacts = store.listArtifacts(project_id);
  const ids = new Set();
  for (const artifact of artifacts) {
    if (ids.has(artifact.artifact_id)) violations.push({ code: 'DUPLICATE_ARTIFACT_ID', artifact_id: artifact.artifact_id });
    ids.add(artifact.artifact_id);
    const metadata = artifactStore?.getMetadata?.(artifact.artifact_id);
    if (!metadata || metadata.project_id !== project_id || metadata.sha256 !== artifact.sha256 || !artifactStore.verifyHash(metadata)) violations.push({ code: 'ARTIFACT_INTEGRITY_INVALID', artifact_id: artifact.artifact_id });
  }
  const state = store.getProjectForActor(project_id, store.listMembers(project_id)[0]?.user_id);
  for (const evidence of state.evidence || []) {
    const artifact = artifacts.find(item => item.artifact_id === evidence.artifact_id);
    if (!artifact || evidence.project_id !== project_id || evidence.artifact_sha256 !== artifact.sha256) violations.push({ code: 'EVIDENCE_BINDING_INVALID', evidence_id: evidence.evidence_id });
  }
  return { project_id, event_count: events.length, artifact_count: artifacts.length, violations, valid: violations.length === 0 };
}

module.exports = { validateProjectConcurrencyInvariants };
