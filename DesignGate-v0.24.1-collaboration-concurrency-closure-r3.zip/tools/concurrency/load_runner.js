const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { createNetworkFixture } = require('./harness');
const { validateProjectConcurrencyInvariants } = require('./invariants');

function percentile(values, quantile) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * quantile) - 1)];
}

function resourceSnapshot() {
  const memory = process.memoryUsage();
  const usage = process.resourceUsage();
  return { rss_bytes: memory.rss, heap_used_bytes: memory.heapUsed, cpu_user_ms: usage.userCPUTime / 1000, cpu_system_ms: usage.systemCPUTime / 1000, max_rss_kb: usage.maxRSS };
}

function resourceDelta(start, end) {
  return {
    scope: 'RUNNER_AND_IN_PROCESS_SERVER_ONLY_EXCLUDES_EXTERNAL_CLIENT_PROCESSES',
    rss_bytes_start: start.rss_bytes,
    rss_bytes_end: end.rss_bytes,
    heap_used_bytes_start: start.heap_used_bytes,
    heap_used_bytes_end: end.heap_used_bytes,
    cpu_user_ms: end.cpu_user_ms - start.cpu_user_ms,
    cpu_system_ms: end.cpu_system_ms - start.cpu_system_ms,
    max_rss_kb: end.max_rss_kb
  };
}

function runExternalClient(input) {
  const worker = path.join(__dirname, 'http_command_worker.js');
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [worker], { env: { ...process.env, DG_CONCURRENCY_WORKER_INPUT: JSON.stringify(input) }, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.once('error', reject);
    child.once('close', code => {
      if (code !== 0) return reject(Error(`EXTERNAL_CLIENT_EXIT_${code}:${stderr || stdout}`));
      try { resolve(JSON.parse(stdout)); } catch (error) { reject(Error(`EXTERNAL_CLIENT_INVALID_JSON:${error.message}:${stdout}`)); }
    });
  });
}

function metricsFor(results, elapsedMs) {
  const latencies = results.map(result => result.latency_ms).filter(Number.isFinite);
  const statuses = Object.fromEntries(results.reduce((counts, result) => counts.set(String(result.status), (counts.get(String(result.status)) || 0) + 1), new Map()));
  const failures = results.filter(result => result.status < 200 || result.status >= 300);
  return {
    command_count: results.length,
    success_count: results.length - failures.length,
    unexpected_5xx_count: results.filter(result => result.status >= 500).length,
    status_counts: statuses,
    error_codes: Object.fromEntries(failures.reduce((counts, result) => {
      const code = result.body?.code || `HTTP_${result.status}`;
      counts.set(code, (counts.get(code) || 0) + 1);
      return counts;
    }, new Map())),
    command_latency_ms: { min: latencies.length ? Math.min(...latencies) : null, p50: percentile(latencies, 0.5), p95: percentile(latencies, 0.95), p99: percentile(latencies, 0.99), max: latencies.length ? Math.max(...latencies) : null },
    elapsed_ms: elapsedMs,
    throughput_commands_per_second: elapsedMs > 0 ? results.length / (elapsedMs / 1000) : 0
  };
}

async function runExternalLoadProfile({ profile = 'C1', clientCount = 20, commandsPerClient = 5, rounds = 1, outputDirectory = path.join(process.cwd(), 'artifacts', 'concurrency') } = {}) {
  if (!Number.isInteger(clientCount) || clientCount < 1 || clientCount > 100) throw Error('LOAD_CLIENT_COUNT_INVALID');
  if (!Number.isInteger(commandsPerClient) || commandsPerClient < 1 || commandsPerClient > 100) throw Error('LOAD_COMMANDS_PER_CLIENT_INVALID');
  if (!Number.isInteger(rounds) || rounds < 1 || rounds > 10_000) throw Error('LOAD_ROUNDS_INVALID');
  const run_id = `LOAD-${crypto.randomUUID()}`;
  const started_at = new Date().toISOString();
  const started = process.hrtime.bigint();
  const resourcesAtStart = resourceSnapshot();
  const fixture = await createNetworkFixture();
  try {
    const owner = fixture.clients[0];
    const project_id = `DG-${run_id.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 100)}`;
    const project = await owner.createProject({ project_id, project_name: `Concurrency ${profile} ${run_id}` });
    const workerResults = [];
    for (let roundIndex = 0; roundIndex < rounds; roundIndex += 1) {
      const workers = Array.from({ length: clientCount }, (_, clientIndex) => ({
        base: fixture.base,
        username: 'user0',
        password: 'concurrency-test-password',
        project_id: project.project_id,
        commands: Array.from({ length: commandsPerClient }, (_, commandIndex) => {
          const suffix = `${roundIndex}-${clientIndex}-${commandIndex}`;
          return {
            command_id: `CMD-${run_id}-${suffix}`,
            idempotency_key: `IDEMP-${run_id}-${suffix}`,
            base_project_version: 1,
            base_entity_version: 0,
            entity_type: 'BOM_ITEM',
            entity_id: `BOM-${suffix}`,
            command_type: 'UPDATE_BOM_ITEM',
            payload: { part_id: `BOM-${suffix}`, part_name: `Load item ${suffix}`, quantity: 1 }
          };
        })
      }));
      workerResults.push(...await Promise.all(workers.map(runExternalClient)));
    }
    const results = workerResults.flatMap(result => result.results || []);
    const elapsed_ms = Number(process.hrtime.bigint() - started) / 1e6;
    const metrics = metricsFor(results, elapsed_ms);
    metrics.runner_resources = resourceDelta(resourcesAtStart, resourceSnapshot());
    const invariants = validateProjectConcurrencyInvariants({ store: fixture.store, artifactStore: fixture.artifactStore, project_id: project.project_id });
    const status = metrics.success_count === metrics.command_count && metrics.unexpected_5xx_count === 0 && invariants.valid ? 'PASSED' : 'FAILED';
    const report = {
      run_id, profile, status, started_at, completed_at: new Date().toISOString(),
      execution: { transport: 'EXTERNAL_NODE_PROCESS_HTTP', client_count: clientCount, commands_per_client: commandsPerClient, rounds, project_id: project.project_id, physical_devices: 0 },
      metrics, invariants,
      limits: ['LOCALHOST_ONLY', 'NO_CAPACITY_OR_PRODUCTION_CLAIM', 'NO_REAL_MULTI_DEVICE_VALIDATION']
    };
    fs.mkdirSync(outputDirectory, { recursive: true });
    const report_path = path.join(outputDirectory, `${run_id}.json`);
    fs.writeFileSync(report_path, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
    return { ...report, report_path };
  } finally {
    await fixture.close();
  }
}

if (require.main === module) {
  const [profile = 'C1', clients = '20', commands = '5', rounds = '1', outputDirectory] = process.argv.slice(2);
  runExternalLoadProfile({ profile, clientCount: Number(clients), commandsPerClient: Number(commands), rounds: Number(rounds), ...(outputDirectory ? { outputDirectory } : {}) })
    .then(report => { process.stdout.write(`${JSON.stringify(report, null, 2)}\n`); process.exitCode = report.status === 'PASSED' ? 0 : 1; })
    .catch(error => { process.stderr.write(`${error.stack || error.message}\n`); process.exitCode = 1; });
}

module.exports = { runExternalLoadProfile, metricsFor, percentile, resourceSnapshot, resourceDelta };
