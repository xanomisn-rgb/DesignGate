const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { runExternalLoadProfile } = require('./load_runner');

const DEFAULT_PROFILES = Object.freeze([
  { profile: 'C1', clientCount: 20, commandsPerClient: 5, rounds: 1 },
  { profile: 'C2', clientCount: 30, commandsPerClient: 5, rounds: 1 },
  { profile: 'C3', clientCount: 40, commandsPerClient: 5, rounds: 1 }
]);

async function runProfiles({ profiles = DEFAULT_PROFILES, outputDirectory = path.join(process.cwd(), 'artifacts', 'concurrency') } = {}) {
  if (!Array.isArray(profiles) || !profiles.length) throw Error('CONCURRENCY_PROFILES_REQUIRED');
  const started_at = new Date().toISOString();
  const runs = [];
  for (const profile of profiles) runs.push(await runExternalLoadProfile({ ...profile, outputDirectory }));
  const aggregate = {
    aggregate_id: `CONCURRENCY-PROFILES-${crypto.randomUUID()}`,
    status: runs.every(run => run.status === 'PASSED') ? 'PASSED' : 'FAILED',
    started_at,
    completed_at: new Date().toISOString(),
    execution: 'SEQUENTIAL_ISOLATED_LOCALHOST_PROFILES',
    runs: runs.map(run => ({ run_id: run.run_id, profile: run.profile, status: run.status, metrics: run.metrics, invariants: run.invariants, report_path: run.report_path })),
    limits: ['SEQUENTIAL_RUNS_NOT_A_CAPACITY_BENCHMARK', 'LOCALHOST_ONLY', 'NO_REAL_MULTI_DEVICE_VALIDATION', 'NO_PRODUCTION_CLAIM']
  };
  fs.mkdirSync(outputDirectory, { recursive: true });
  const manifest_path = path.join(outputDirectory, `${aggregate.aggregate_id}.json`);
  fs.writeFileSync(manifest_path, `${JSON.stringify(aggregate, null, 2)}\n`, 'utf8');
  return { ...aggregate, manifest_path };
}

if (require.main === module) {
  const outputDirectory = process.argv[2] || path.join(process.cwd(), 'artifacts', 'concurrency');
  runProfiles({ outputDirectory })
    .then(report => { process.stdout.write(`${JSON.stringify(report, null, 2)}\n`); process.exitCode = report.status === 'PASSED' ? 0 : 1; })
    .catch(error => { process.stderr.write(`${error.stack || error.message}\n`); process.exitCode = 1; });
}

module.exports = { DEFAULT_PROFILES, runProfiles };
