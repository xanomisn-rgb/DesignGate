"""Bounded BRep surface samples. Chords and visibility are NOT global DFM approval.
Reference: OpenCascade BRepAdaptor_Surface / IntCurvesFace_ShapeIntersector.
"""
import math
import time

def measure(shape, faces, extent, params, source_hash):
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.BRepClass import BRepClass_FaceClassifier
    from OCP.BRepClass3d import BRepClass3d_SolidClassifier
    from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
    from OCP.TopAbs import TopAbs_IN, TopAbs_OUT, TopAbs_REVERSED
    from OCP.gp import gp_Pnt, gp_Pnt2d, gp_Vec, gp_Dir, gp_Lin

    direction=params.get('pull_direction')
    if direction is not None:
        if (not isinstance(direction,list) or len(direction)!=3 or
            any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in direction)):
            raise ValueError('pull_direction must contain three finite numbers')
        norm=math.hypot(*direction)
        if not math.isfinite(norm) or norm==0: raise ValueError('pull_direction must be nonzero and finite')
        direction=[x/norm for x in direction]
    # Numerical tolerances and resource bounds, not manufacturing acceptance thresholds.
    tol=1e-7; offset=max(1e-5,extent*1e-8); reach=extent*4+1
    adaptive=params.get('adaptive_sampling',True) is not False
    requested_limit=params.get('sampling_time_limit_seconds',12)
    if isinstance(requested_limit,bool) or not isinstance(requested_limit,(int,float)) or not math.isfinite(requested_limit):
        raise ValueError('sampling_time_limit_seconds must be a finite number')
    time_limit=max(.001,min(float(requested_limit),12.0))
    classifier=BRepClass3d_SolidClassifier(shape)
    intersector=IntCurvesFace_ShapeIntersector(); intersector.Load(shape,tol)
    def state(point):
        classifier.Perform(point,tol); return classifier.State()
    def moved(p,n,d): return gp_Pnt(p.X()+n[0]*d,p.Y()+n[1]*d,p.Z()+n[2]*d)
    def hits(point, vector):
        intersector.Perform(gp_Lin(point,gp_Dir(*vector)),offset/10,reach)
        if not intersector.IsDone(): raise ValueError('Ray intersection incomplete')
        return sorted([intersector.WParameter(i) for i in range(1,intersector.NbPnt()+1)
                       if intersector.WParameter(i)>offset/10])

    rows=[]; coverage=[]; started=time.monotonic(); timed_out=False; failure_reasons={}
    def failure(reason): failure_reasons[reason]=failure_reasons.get(reason,0)+1
    for face_id,face in enumerate(faces[:64],1):
        surface=BRepAdaptor_Surface(face,True)
        limits=[surface.FirstUParameter(),surface.LastUParameter(),surface.FirstVParameter(),surface.LastVParameter()]
        counts={'face_id':face_id,'state':'UNMEASURED','attempted':0,'accepted':0,'trimmed_out':0,'failed':0,
                'base_attempted':0,'base_accepted':0,'adaptive_attempted':0,'adaptive_accepted':0,'failure_reasons':{}}
        coverage.append(counts)
        if any(not math.isfinite(x) or abs(x)>1e50 for x in limits):
            counts['reason']='UNBOUNDED_UV'; failure('UNBOUNDED_UV'); continue
        u0,u1,v0,v1=limits
        seen=set()
        def sample_grid(grid,phase):
            nonlocal timed_out
            for iu in range(grid):
              for iv in range(grid):
                if time.monotonic()-started>time_limit:
                    timed_out=True;failure('TIME_LIMIT_REACHED');return
                key=(round((iu+.5)/grid,12),round((iv+.5)/grid,12))
                if key in seen: continue
                seen.add(key)
                counts['attempted']+=1
                counts[phase+'_attempted']+=1
                u=u0+(u1-u0)*key[0]; v=v0+(v1-v0)*key[1]
                if BRepClass_FaceClassifier(face,gp_Pnt2d(u,v),tol).State()!=TopAbs_IN:
                    counts['trimmed_out']+=1; continue
                try:
                    p=gp_Pnt(); du=gp_Vec(); dv=gp_Vec();surface.D1(u,v,p,du,dv)
                    normal=du.Crossed(dv)
                    if normal.Magnitude()<1e-14: raise ValueError('Singular normal')
                    normal.Normalize()
                    if face.Orientation()==TopAbs_REVERSED: normal.Reverse()
                    n=[normal.X(),normal.Y(),normal.Z()]
                    if any(not math.isfinite(x) for x in [p.X(),p.Y(),p.Z(),*n]): raise ValueError('Nonfinite surface')
                    inside=moved(p,n,-offset);outside=moved(p,n,offset)
                    if state(inside)!=TopAbs_IN or state(outside)!=TopAbs_OUT:
                        raise ValueError('Cannot verify outward orientation at numerical offset')
                    inward=[-x for x in n]; intersections=hits(inside,inward)
                    chord=None
                    if intersections:
                        distance=intersections[0]
                        if (state(moved(inside,inward,distance/2))==TopAbs_IN and
                            state(moved(inside,inward,distance+offset))==TopAbs_OUT):
                            chord=distance+offset
                    row={'sample_id':f'F{face_id}-{phase.upper()}-G{grid}-U{iu}-V{iv}','face_id':face_id,
                         'point_mm':[p.X(),p.Y(),p.Z()],'normal':n,'normal_chord_mm':chord}
                    if direction is not None:
                        row['signed_draft_deg']=math.degrees(math.asin(max(-1,min(1,sum(n[i]*direction[i] for i in range(3))))))
                        row['visibility_plus']='OCCLUDED' if hits(outside,direction) else 'CLEAR_AT_SAMPLE'
                        row['visibility_minus']='OCCLUDED' if hits(outside,[-x for x in direction]) else 'CLEAR_AT_SAMPLE'
                    rows.append(row);counts['accepted']+=1
                    counts[phase+'_accepted']+=1
                except (RuntimeError,ValueError) as error:
                    counts['failed']+=1
                    reason=str(error) if isinstance(error,ValueError) else 'OCP_RUNTIME_ERROR'
                    counts['failure_reasons'][reason]=counts['failure_reasons'].get(reason,0)+1;failure(reason)
        sample_grid(5,'base')
        if adaptive and not timed_out and (counts['accepted']==0 or counts['accepted']/max(counts['attempted'],1)<.5):
            sample_grid(9,'adaptive')
            if not timed_out and counts['adaptive_accepted']==0:sample_grid(17,'adaptive')
        if counts['accepted']:
            counts['state']='PARTIALLY_MEASURED' if counts['failed'] or counts['trimmed_out'] else 'MEASURED'
        elif timed_out: counts['reason']='TIME_LIMIT_REACHED'
        elif counts['trimmed_out']==counts['attempted']: counts['reason']='ALL_SAMPLES_TRIMMED_OUT'
        elif counts['failed']: counts['reason']='ALL_VALID_SAMPLES_FAILED'
        else: counts['reason']='NO_VALID_SAMPLES'
        if timed_out: break
    values=[r['normal_chord_mm'] for r in rows if r['normal_chord_mm'] is not None]
    elapsed=time.monotonic()-started
    unmeasured=[{'face_id':c['face_id'],'state':'UNMEASURED','reason':c.get('reason','NO_VALID_SAMPLES')} for c in coverage if not c['accepted']]
    if len(coverage)<min(len(faces),64):
        reason='TIME_LIMIT_REACHED' if timed_out else 'NOT_VISITED'
        unmeasured.extend({'face_id':i,'state':'UNMEASURED','reason':reason} for i in range(len(coverage)+1,min(len(faces),64)+1))
    if len(faces)>64:
        unmeasured.extend({'face_id':i,'state':'UNMEASURED','reason':'FACE_LIMIT_EXCEEDED'} for i in range(65,len(faces)+1))
    adaptive_attempted=sum(c['adaptive_attempted'] for c in coverage)
    adaptive_accepted=sum(c['adaptive_accepted'] for c in coverage)
    skipped_samples=sum(c['trimmed_out'] for c in coverage)
    return {'status':'SAMPLED_BREP_ONLY' if rows else 'NO_VALID_SAMPLES','source_sha256':source_hash,
            'algorithm_revision':'normal-ray-adaptive-uv-v2','unit':'mm','pull_direction':direction,
            'coverage':{'total_faces':len(faces),'visited_faces':len(coverage),'sampled_faces':sum(c['accepted']>0 for c in coverage),
                        'sample_count':len(rows),'chord_count':len(values),'face_limit':64,'grid_per_face':[5,5],
                        'adaptive_sampling':adaptive,'adaptive_grid_levels':[9,17] if adaptive else [],
                        'adaptive_attempted':adaptive_attempted,
                        'adaptive_accepted':adaptive_accepted,
                        'adaptive_recovered_faces':sum(c['base_accepted']==0 and c['adaptive_accepted']>0 for c in coverage),
                        'attempted_samples':sum(c['attempted'] for c in coverage),
                        'skipped_samples':skipped_samples,'skip_reasons':{'TRIMMED_OUT':skipped_samples},
                        'adaptive_acceptance_rate':adaptive_accepted/adaptive_attempted if adaptive_attempted else None,
                        'skipped_faces':len(unmeasured),'unmeasured_faces':unmeasured,
                        'failure_reasons':failure_reasons,'time_limit_seconds':time_limit,
                        'elapsed_seconds':elapsed,'time_limit_reached':timed_out,
                        'time_interruption':{'reached':timed_out,'elapsed_seconds':elapsed,'limit_seconds':time_limit},
                        'face_coverage':coverage,'global_minimum_proven':False},
            'numerics':{'classification_tolerance_mm':tol,'normal_offset_mm':offset},
            'sampled_minimum_chord_mm':min(values) if values else None,
            'sampled_maximum_chord_mm':max(values) if values else None,'samples':rows,
            'limitations':['Normal chords are directional distances through one solid, not local-feature-size or global minimum wall thickness.',
                           'Uniform UV samples are not area-weighted and can miss narrow features, corners and thin regions.',
                           'Signed normal angles include end faces; negative angles alone do not establish undercuts.',
                           'Visibility uses normal-offset sample points; clear rays do not prove mould release or absence of undercuts.',
                           'Face/sample identifiers are meaningful only with this exact STEP SHA-256.']}
