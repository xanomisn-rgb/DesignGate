"""STL screening and optional BRep sampling; neither provides mouldability certification."""
import sys,json,os,struct,math,re
MAX_TRIANGLES=250000

def analyze(params):
 f=params.get('cad_file')
 if not f or not os.path.isfile(f):return {'success':False,'error':'有效 CAD 文件未提供'}
 if os.path.getsize(f)>50*1024*1024:return {'success':False,'error':'文件超过50MB'}
 ext=os.path.splitext(f)[1].lower()
 if ext in ('.step','.stp'):
  from brep_analyzer import analyze_step
  # OCCT emits native parser diagnostics on stdout; reserve stdout for JSON IPC.
  sys.stdout.flush()
  saved=os.dup(1)
  try:
   os.dup2(2,1)
   return analyze_step(f,params)
  finally:
   os.dup2(saved,1);os.close(saved)
 if ext!='.stl':return {'success':False,'error':'仅支持 STL 筛查和 STEP 摄入'}
 data=open(f,'rb').read();triangles=[]
 if len(data)>=84 and 84+50*struct.unpack_from('<I',data,80)[0]==len(data):
  count=struct.unpack_from('<I',data,80)[0]
  if count>MAX_TRIANGLES:return {'success':False,'status':'RESOURCE_LIMIT','error':'面片数量超过限制；未输出不完整分析'}
  for i in range(count):
   values=struct.unpack_from('<12f',data,84+i*50);triangles.append([values[3:6],values[6:9],values[9:12]])
 else:
  try:text=data.decode('utf8')
  except UnicodeDecodeError:return {'success':False,'error':'二进制 STL 长度与面片数不符'}
  vertices=[tuple(map(float,m))for m in re.findall(r'\bvertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)',text)]
  if not vertices or len(vertices)%3:return {'success':False,'error':'STL 三角面片不完整'}
  triangles=[vertices[i:i+3]for i in range(0,len(vertices),3)]
  if len(triangles)>MAX_TRIANGLES:return {'success':False,'error':'面片数量超过限制'}
 if not triangles or any(not math.isfinite(x)for t in triangles for v in t for x in v):return {'success':False,'error':'无有效有限坐标'}
 unit=params.get('unit');scale={'mm':1,'cm':10,'m':1000,'in':25.4}.get(unit)
 vertices=[v for t in triangles for v in t]
 bounds=[max(v[i]for v in vertices)-min(v[i]for v in vertices)for i in range(3)]
 box={'raw_extents':bounds,'unit':unit or 'UNKNOWN','unit_verified':scale is not None}
 if scale is not None:box.update(dict(zip(['length_mm','width_mm','height_mm'],[round(v*scale,6)for v in bounds])))
 direction=params.get('pull_direction');normals=[];degenerate=0
 for a,b,c in triangles:
  u=[b[i]-a[i]for i in range(3)];v=[c[i]-a[i]for i in range(3)]
  n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(x*x for x in n))
  if length<=1e-12:degenerate+=1
  else:normals.append([x/length for x in n])
 draft={'status':'NEED_PULL_DIRECTION','insufficient_draft_facets':None}
 if direction is not None:
  if not isinstance(direction,list)or len(direction)!=3 or any(isinstance(x,bool)or not isinstance(x,(int,float))or not math.isfinite(x)for x in direction):return {'success':False,'error':'开模方向需为3个有限数值'}
  length=math.hypot(*direction)
  if length==0 or not math.isfinite(length):return {'success':False,'error':'开模方向必须为有限非零向量'}
  d=[x/length for x in direction];angles=[]
  for n in normals:
   dot=sum(n[i]*d[i]for i in range(3))
   if abs(dot)<0.866:angles.append(math.degrees(math.asin(min(1,abs(dot)))))
  draft={'status':'HEURISTIC_ONLY'if angles and not degenerate else 'INCOMPLETE_GEOMETRY','pull_direction':d,'evaluated_side_walls':len(angles),'insufficient_draft_facets':None,'reference_angle_deg':None,'sampled_side_min_deg':min(angles) if angles else None,'sampled_side_max_deg':max(angles) if angles else None,'note':'仅相对指定方向的面片角度筛查；侧面选择为启发式。没有通用合格角度，未计算分型、遮挡或工艺适用性。'}
 return {'success':True,'status':'ANALYZED','tool':'DesignGate_Mesh_Screening_0.8','mesh_stats':{'total_facets':len(triangles),'degenerate_facets':degenerate,'complete_read':True},'bounding_box':box,'draft_analysis':draft,'undercut_analysis':{'status':'NOT_EVALUATED_REQUIRES_VISIBILITY_AND_PARTING','has_undercuts':None,'action_required':'需要 CAD 工具与模具工程师验证'},'limitations':['STL 单位由用户声明。','外包络不能自动等同局部握持截面。','不输出壁厚、倒扣确定性结论或直接脱模承诺。']}
if __name__=='__main__':
 try:print(json.dumps(analyze(json.load(sys.stdin)),ensure_ascii=False,allow_nan=False))
 except Exception as e:print(json.dumps({'success':False,'error':str(e)},ensure_ascii=False))
