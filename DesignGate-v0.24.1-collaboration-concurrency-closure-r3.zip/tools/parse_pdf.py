import sys
import json
import pypdf

def extract_pdf(pdf_path):
    try:
        reader = pypdf.PdfReader(pdf_path)
        pages_data = []
        for idx, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            pages_data.append({
                "page_number": idx + 1,
                "text": text
            })
        return {
            "success": True,
            "total_pages": len(reader.pages),
            "pages": pages_data
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "error": "Missing pdf file path"}))
        sys.exit(1)
    result = extract_pdf(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False))
