# PDF Chinese font

Noto Sans SC, downloaded from the official Google Fonts repository:
https://github.com/google/fonts/tree/main/ofl/notosanssc

NotoSansSC-Regular.ttf is a weight-400 static instance of NotoSansSC[wght].ttf, generated with fontTools for ReportLab compatibility. The complete upstream OFL license is retained in OFL.txt. The font is embedded in generated reports so Chinese text does not depend on the recipient's installed fonts.
