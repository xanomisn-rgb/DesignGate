const C=require('../backend/contracts');
class SchemaValidator{
 static validateFinding(f){return C.finding(f);}
 static validateEvidence(e){if(!e.source_id||!e.source_url||!e.evidence_level)throw Error('Evidence 契约无效');return true;}
 static validatePipelineResult(r){C.id(r.project_id);if(!Array.isArray(r.findings)||!Array.isArray(r.checks)||!r.gate||!r.review_id)throw Error('Pipeline 契约无效');r.findings.forEach(C.finding);return true;}
}
module.exports=SchemaValidator;
