import hashlib,json,unittest
from pathlib import Path
from brep_analyzer import analyze_step

class StepFixtures(unittest.TestCase):
    def test_serialized_step_fixtures(self):
        root=Path(__file__).resolve().parents[1]/'samples'/'brep'
        cases=json.loads((root/'expectations.json').read_text())
        for case in cases['cases']:
            with self.subTest(file=case['file']):
                file=root/case['file'];r=analyze_step(str(file),{'pull_direction':cases['pull_direction']})
                self.assertTrue(r['success']);self.assertEqual(r['source_sha256'],case['source_sha256'])
                m=r['surface_measurements'];self.assertIsNone(r['wall_thickness']['minimum_mm']);self.assertIsNone(r['undercut_analysis']['has_undercuts'])
                self.assertFalse(r['thickness_oracle']['global_mathematical_proof'])
                self.assertFalse(r['undercut_oracle']['global_mathematical_proof'])
                e=case['expected']
                if 'sampled_minimum_chord_mm' in e:self.assertAlmostEqual(m['sampled_minimum_chord_mm'],e['sampled_minimum_chord_mm'],places=5)
                if 'absolute_side_normal_angle_deg' in e:
                    angles=[abs(s['signed_draft_deg']) for s in m['samples'] if abs(s['signed_draft_deg'])<80]
                    self.assertTrue(angles)
                    for a in angles:self.assertAlmostEqual(a,e['absolute_side_normal_angle_deg'],places=5)
                if 'both_directions_occluded_samples_gt' in e:self.assertGreater(r['undercut_analysis']['both_directions_occluded_samples'],0)
if __name__=='__main__':unittest.main()
