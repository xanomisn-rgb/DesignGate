"""CLI boundary for the existing OCP B-Rep analyzer; it does not implement geometry algorithms."""
import argparse
import hashlib
import importlib.metadata
import json
from brep_analyzer import analyze_step

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',required=True)
    parser.add_argument('--params',default='{}')
    args=parser.parse_args()
    params=json.loads(args.params)
    result=analyze_step(args.input,params)
    topology=result.get('topology') or {}
    mass=result.get('mass_properties') or {}
    measurements=result.get('surface_measurements') or {}
    with open(args.input,'rb') as source:
        digest=hashlib.sha256(source.read()).hexdigest()
    try:
        version=importlib.metadata.version('cadquery-ocp')
    except importlib.metadata.PackageNotFoundError:
        version=None
    output={
        'schema_version':'1.0',
        'analyzer_backend':'OCP',
        'analyzer_version':version,
        'file_sha256':digest,
        'solid_count':topology.get('solids',0),
        'face_count':topology.get('faces',0),
        'bounding_box':result.get('bounding_box'),
        'volume':mass.get('volume_mm3'),
        'centroid':mass.get('centroid_mm'),
        'measurements':measurements,
        'thickness_oracle':result.get('thickness_oracle'),
        'assembly_analysis':result.get('assembly_analysis'),
        'undercut_oracle':result.get('undercut_oracle'),
        'capabilities':['EXACT_TOPOLOGY','EXACT_BOUNDING_BOX','EXACT_VOLUME_FOR_VALID_SOLIDS','SAMPLED_SURFACE_MEASUREMENTS'],
        'limitations':result.get('limitations',[]) + ['SAMPLED / HEURISTIC measurements are not global proof.'],
        'sampling':measurements.get('coverage') or {},
        'analysis_status':result.get('status','NOT_EVALUATED'),
        'analysis_success':bool(result.get('success')),
        'error':result.get('error'),
    }
    print(json.dumps(output,separators=(',',':'),allow_nan=False))

if __name__=='__main__':
    main()
