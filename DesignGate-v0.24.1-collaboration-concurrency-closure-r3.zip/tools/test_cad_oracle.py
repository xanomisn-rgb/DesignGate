import unittest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Ax1,gp_Ax2,gp_Dir,gp_Pnt,gp_Trsf
from cad_oracle import assembly_pair,assembly_pairs,thickness_oracle,undercut_oracle

class CadOracleTests(unittest.TestCase):
    def test_exact_boxes_report_known_clearance_and_overlap(self):
        first=BRepPrimAPI_MakeBox(10,10,10).Shape()
        separated=BRepPrimAPI_MakeBox(gp_Pnt(12,0,0),10,10,10).Shape()
        overlap=BRepPrimAPI_MakeBox(gp_Pnt(9,0,0),10,10,10).Shape()
        gap=assembly_pair('A',first,'B',separated)
        self.assertEqual(gap['minimum_clearance_mm'],2.0)
        self.assertEqual(len(gap['witness_points_mm']),2)
        self.assertEqual(gap['aabb_broad_phase'],'DISJOINT')
        result=assembly_pair('A',first,'B',overlap)
        self.assertTrue(result['interference'])
        self.assertAlmostEqual(result['intersection_volume_mm3'],100.0,places=5)
        self.assertEqual(len(result['witness_points_mm']),2)

    def test_touching_boxes_are_not_promoted_to_interference(self):
        first=BRepPrimAPI_MakeBox(10,10,10).Shape()
        touching=BRepPrimAPI_MakeBox(gp_Pnt(10,0,0),10,10,10).Shape()
        result=assembly_pair('A',first,'B',touching)
        self.assertFalse(result['interference'])
        self.assertEqual(result['minimum_clearance_mm'],0.0)
        self.assertEqual(result['pair_status'],'TOUCHING_NO_VOLUME_OVERLAP')

    def test_assembly_entry_preserves_component_pair_identity(self):
        first=BRepPrimAPI_MakeBox(10,10,10).Shape()
        second=BRepPrimAPI_MakeBox(gp_Pnt(12,0,0),10,10,10).Shape()
        result=assembly_pairs([{'component_id':'housing','shape':first},{'component_id':'lid','shape':second}])
        self.assertEqual(result['status'],'ASSEMBLY_PAIR_ANALYZED')
        self.assertEqual(result['pairs'][0]['part_a_id'],'housing')
        self.assertEqual(result['pairs'][0]['part_b_id'],'lid')

    def test_exact_pair_handles_rotated_box(self):
        rotated=BRepPrimAPI_MakeBox(10,10,10).Shape()
        transform=gp_Trsf();transform.SetRotation(gp_Ax1(gp_Pnt(5,5,0),gp_Dir(0,0,1)),0.7853981633974483)
        rotated=BRepBuilderAPI_Transform(rotated,transform,True).Shape()
        result=assembly_pair('rotated',rotated,'component',BRepPrimAPI_MakeBox(10,10,10).Shape())
        self.assertTrue(result['interference'])
        self.assertGreater(result['intersection_volume_mm3'],0)

    def test_exact_pair_detects_cylinder_through_wall(self):
        from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
        wall=BRepPrimAPI_MakeBox(10,10,10).Shape()
        cylinder=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(5,5,-2),gp_Dir(0,0,1)),1,14).Shape()
        result=assembly_pair('wall',wall,'cylinder',cylinder)
        self.assertTrue(result['interference'])
        self.assertAlmostEqual(result['intersection_volume_mm3'],31.4159265359,places=5)

    def test_exact_pair_measures_clearance_inside_nested_enclosure(self):
        outer=BRepPrimAPI_MakeBox(20,20,20).Shape()
        cavity=BRepPrimAPI_MakeBox(gp_Pnt(2,2,2),16,16,16).Shape()
        enclosure=BRepAlgoAPI_Cut(outer,cavity).Shape()
        insert=BRepPrimAPI_MakeBox(gp_Pnt(5,5,5),10,10,10).Shape()
        result=assembly_pair('enclosure',enclosure,'insert',insert)
        self.assertFalse(result['interference'])
        self.assertAlmostEqual(result['minimum_clearance_mm'],3.0,places=5)

    def test_thickness_oracle_keeps_candidates_bounded_and_non_global(self):
        output=thickness_oracle({'sampled_minimum_chord_mm':1.2,'coverage':{'sample_count':15,'sampled_faces':3,'total_faces':5,'adaptive_attempted':9,'adaptive_accepted':4,'time_limit_reached':False}})
        self.assertEqual(output['status'],'THICKNESS_CANDIDATE')
        self.assertEqual(output['minimum_candidate_mm'],1.2)
        self.assertFalse(output['global_mathematical_proof'])
        self.assertTrue(output['local_refinement']['performed'])

    def test_undercut_oracle_reports_only_sampled_candidate(self):
        output=undercut_oracle({'pull_direction':[0,0,1],'samples':[{'face_id':7,'visibility_plus':'OCCLUDED','visibility_minus':'OCCLUDED'}]})
        self.assertEqual(output['status'],'UNDERCUT_CANDIDATE')
        self.assertEqual(output['affected_faces'],[7])
        self.assertTrue(output['possible_side_action_requirement'])
        self.assertFalse(output['global_mathematical_proof'])

if __name__=='__main__': unittest.main()
