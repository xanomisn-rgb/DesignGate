const { runPython } = require("./python_runner");
const { execFileSync } = require("child_process");
const path = require("path");

class CADGeometryTool {
  static analyze(params = {}) {
    const pyScript = path.join(__dirname, "geometry_analyzer.py");
    try {
      const inputJson = JSON.stringify(params);
      const output = runPython(pyScript, [], { input: inputJson });
      return JSON.parse(output);
    } catch (e) {
      return {
        success: false,
        error: e.message
      };
    }
  }
}

module.exports = CADGeometryTool;
