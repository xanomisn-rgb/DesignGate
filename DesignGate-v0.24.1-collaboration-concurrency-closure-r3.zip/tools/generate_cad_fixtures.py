"""Generate synthetic STEP fixtures with construction-based expectations."""
import hashlib,json,math,sys
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCone
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
from OCP.IFSelect import IFSelect_RetDone
from OCP.gp import gp_Pnt

root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'samples'/'brep'
root.mkdir(parents=True,exist_ok=True)
items=[('plate_1_3mm',BRepPrimAPI_MakeBox(20,30,1.3).Shape(),{'sampled_minimum_chord_mm':1.3}),
       ('open_shell_1_2mm',BRepAlgoAPI_Cut(BRepPrimAPI_MakeBox(20,30,15).Shape(),BRepPrimAPI_MakeBox(gp_Pnt(1.2,1.2,1.2),17.6,27.6,15).Shape()).Shape(),{'sampled_minimum_chord_mm':1.2}),
       ('cone_draft_0_8deg',BRepPrimAPI_MakeCone(10,10+20*math.tan(math.radians(.8)),20).Shape(),{'absolute_side_normal_angle_deg':.8}),
       ('enclosed_cavity',BRepAlgoAPI_Cut(BRepPrimAPI_MakeBox(20,20,20).Shape(),BRepPrimAPI_MakeBox(gp_Pnt(4,4,4),12,12,12).Shape()).Shape(),{'both_directions_occluded_samples_gt':0})]
if any((root/(name+'.step')).exists() for name,_,_ in items) or (root/'expectations.json').exists():
    raise FileExistsError('Choose a new output directory; existing fixtures are not overwritten')
records=[]
for name,shape,expected in items:
    file=root/(name+'.step');writer=STEPControl_Writer();writer.Transfer(shape,STEPControl_AsIs)
    if writer.Write(str(file))!=IFSelect_RetDone:raise RuntimeError('Fixture write failed')
    records.append({'file':file.name,'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'expected':expected})
(root/'expectations.json').write_text(json.dumps({'authority':'ANALYTIC_CONSTRUCTION_NOT_EXPERT_PROJECT','pull_direction':[0,0,1],'cases':records},indent=2))
