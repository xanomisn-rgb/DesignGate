"""Experimental adapter for EXISTING parametric properties, not arbitrary STEP editing.
Call apply_parameter_plan(App.ActiveDocument, plan, bindings, dry_run=True) first.
No file is saved. Binding a field to CAD remains an explicit human responsibility.
"""
import math
import re

TYPES={'mm':'App::PropertyLength','deg':'App::PropertyAngle'}

def apply_parameter_plan(document, plan, bindings, dry_run=True):
    if not isinstance(dry_run,bool): raise ValueError('Explicit boolean dry_run required')
    if not document or document.Name != bindings.get('document_name'):
        raise ValueError('Document name mismatch')
    if plan.get('status') != 'APPROVED_PROJECT_PARAMETERS_NOT_CAD_APPLIED':
        raise ValueError('Plan is not an approved parameter snapshot')
    changes=plan.get('changes',[])
    if not changes or len(changes)>50: raise ValueError('Expected 1..50 mapped changes')
    pending=[];seen=set()
    for change in changes:
        binding=bindings.get('fields',{}).get(change['field'])
        if not binding: raise ValueError('Missing explicit binding: '+change['field'])
        name,prop=binding.get('object'),binding.get('property')
        if any(not isinstance(x,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,99}',x) for x in [name,prop]):
            raise ValueError('Invalid object / property identifier')
        if (name,prop) in seen: raise ValueError('Duplicate CAD property target')
        seen.add((name,prop));obj=document.getObject(name)
        if not obj or prop not in obj.PropertiesList: raise ValueError('CAD property missing')
        if change['unit'] not in TYPES or obj.getTypeIdOfProperty(prop)!=TYPES[change['unit']]:
            raise ValueError('Property unit / type mismatch')
        if any(item[0]==prop for item in getattr(obj,'ExpressionEngine',[])):
            raise ValueError('Expression-driven property cannot be overwritten')
        old,new=change['old_value'],change['new_value']
        if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or x<0 for x in [old,new]):
            raise ValueError('Finite nonnegative old / new values required')
        actual=float(getattr(obj,prop).Value)
        if not math.isclose(actual,old,rel_tol=0,abs_tol=1e-6): raise ValueError('Old value mismatch')
        pending.append((obj,prop,new,change['unit']))
    if dry_run: return {'status':'DRY_RUN_ONLY','changes':len(pending),'saved':False}
    document.openTransaction('DesignGate approved parameters')
    try:
        for obj,prop,new,unit in pending: setattr(obj,prop,str(new)+' '+unit)
        document.recompute()
        for obj in document.Objects:
            if any(x in ['Invalid','Error'] for x in getattr(obj,'State',[])):
                raise ValueError('CAD recompute error')
            if hasattr(obj,'Shape') and (obj.Shape.isNull() or not obj.Shape.isValid()):
                raise ValueError('CAD shape is empty or invalid')
        document.commitTransaction()
    except Exception:
        document.abortTransaction()
        raise
    return {'status':'APPLIED_IN_MEMORY_REQUIRES_ENGINEER_REVIEW','saved':False,'changes':len(pending)}
