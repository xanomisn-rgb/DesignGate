#!/usr/bin/env node
// Explicitly synthetic device publisher. It never sends PASS/FAIL; DesignGate derives that from its verification plan.
const crypto=require('crypto');
const mqtt=require('mqtt');
const Canonical=require('../backend/crypto/canonical_json');

const brokerUrl=process.env.DG_MQTT_BROKER_URL||'mqtt://127.0.0.1:18883';
const username=process.env.DG_MQTT_USERNAME;
const password=process.env.DG_MQTT_PASSWORD;
const secret=process.env.DG_MQTT_DEVICE_SECRET;
if(!username||!password||!secret)throw Error('DG_MQTT_USERNAME, DG_MQTT_PASSWORD and DG_MQTT_DEVICE_SECRET are required for the mock device');
const input={
  device_id:process.env.DG_MQTT_DEVICE_ID||'MOCK-ESP32-01',
  project_id:process.env.DG_MQTT_PROJECT_ID||'DG-MQTT-DEMO',
  revision:process.env.DG_MQTT_REVISION||'A',
  test_id:process.env.DG_MQTT_TEST_ID||'T-TEMP',
  sequence:Number(process.env.DG_MQTT_SEQUENCE||1),
  metric:process.env.DG_MQTT_METRIC||'temperature',
  value:Number(process.env.DG_MQTT_VALUE||((20+Math.random()*5).toFixed(2))),
  unit:process.env.DG_MQTT_UNIT||'degC',
  source_timestamp:new Date().toISOString(),
  idempotency_key:process.env.DG_MQTT_IDEMPOTENCY_KEY||`mock-${crypto.randomUUID()}`,
  source:'MOCK'
};
if(!Number.isFinite(input.value)||!Number.isInteger(input.sequence)||input.sequence<0)throw Error('DG_MQTT_VALUE and DG_MQTT_SEQUENCE must be valid finite values');
input.signature=crypto.createHmac('sha256',secret).update(Canonical.telemetrySigningInput(input).text,'utf8').digest('hex');
const client=mqtt.connect(brokerUrl,{protocolVersion:4,username,password,clientId:`designgate-mock-esp32-${process.pid}`,clean:true,reconnectPeriod:0});
client.once('connect',()=>client.publish(process.env.DG_MQTT_TOPIC||'lab/telemetry',JSON.stringify(input),{qos:1},error=>{client.end(true,()=>{if(error)throw error;console.log(JSON.stringify({source:'MOCK',transport:'MQTT',topic:process.env.DG_MQTT_TOPIC||'lab/telemetry',device_id:input.device_id,metric:input.metric,value:input.value,unit:input.unit,status:'PUBLISHED_NO_RESULT_ASSERTED'}));});}));
client.once('error',error=>{console.error(JSON.stringify({source:'MOCK',status:'CONNECTION_FAILED',message:error.message,returnCode:error.returnCode||null}));process.exitCode=1;});
