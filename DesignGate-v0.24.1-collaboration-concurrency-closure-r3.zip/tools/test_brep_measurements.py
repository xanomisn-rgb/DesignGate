"""Analytical geometry regression, not an expert-labelled industrial gold set."""
import math
import unittest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCone
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.TopoDS import TopoDS
from OCP.gp import gp_Pnt,gp_Trsf,gp_Ax1,gp_Dir
from brep_measurements import measure

def inspect(shape,params=None):
    faces=[];e=TopExp_Explorer(shape,TopAbs_FACE)
    while e.More(): faces.append(TopoDS.Face(e.Current()));e.Next()
    return measure(shape,faces,100,params if params is not None else {'pull_direction':[0,0,1]},'analytic-fixture')

class Measurements(unittest.TestCase):
    def test_thin_plate_is_measured_not_input_nominal(self):
        r=inspect(BRepPrimAPI_MakeBox(20,30,1.3).Shape(),{'pull_direction':[0,0,1],'nominalWall':99})
        self.assertAlmostEqual(r['sampled_minimum_chord_mm'],1.3,places=6)
        self.assertEqual(r['coverage']['sample_count'],150)
        self.assertFalse(r['coverage']['global_minimum_proven'])
        self.assertEqual({round(s['signed_draft_deg']) for s in r['samples']},{-90,0,90})
    def test_open_shell_1_2_mm(self):
        outer=BRepPrimAPI_MakeBox(20,30,15).Shape()
        cavity=BRepPrimAPI_MakeBox(gp_Pnt(1.2,1.2,1.2),17.6,27.6,15).Shape()
        r=inspect(BRepAlgoAPI_Cut(outer,cavity).Shape())
        self.assertAlmostEqual(r['sampled_minimum_chord_mm'],1.2,places=6)
    def test_actual_conical_surface_0_8_degrees(self):
        r=inspect(BRepPrimAPI_MakeCone(10,10+20*math.tan(math.radians(.8)),20).Shape())
        angles=[abs(s['signed_draft_deg']) for s in r['samples'] if abs(s['signed_draft_deg'])<80]
        self.assertGreater(len(angles),0)
        for a in angles:self.assertAlmostEqual(a,.8,places=6)
    def test_rotation_preserves_distance_and_direction_is_respected(self):
        s=BRepPrimAPI_MakeBox(20,30,1.3).Shape();t=gp_Trsf();t.SetRotation(gp_Ax1(gp_Pnt(),gp_Dir(1,0,0)),math.pi/2)
        r=inspect(BRepBuilderAPI_Transform(s,t,True).Shape(),{'pull_direction':[0,-1,0]})
        self.assertAlmostEqual(r['sampled_minimum_chord_mm'],1.3,places=6)
        self.assertEqual({round(s['signed_draft_deg']) for s in r['samples']},{-90,0,90})
    def test_enclosed_cavity_yields_directional_occlusion(self):
        shape=BRepAlgoAPI_Cut(BRepPrimAPI_MakeBox(20,20,20).Shape(),BRepPrimAPI_MakeBox(gp_Pnt(4,4,4),12,12,12).Shape()).Shape()
        r=inspect(shape)
        self.assertTrue(any(s['visibility_plus']==s['visibility_minus']=='OCCLUDED' for s in r['samples']))
        self.assertNotIn('has_undercuts',r)
    def test_missing_direction_keeps_normal_chords(self):
        r=inspect(BRepPrimAPI_MakeBox(20,30,1.3).Shape(),{})
        self.assertAlmostEqual(r['sampled_minimum_chord_mm'],1.3)
        self.assertTrue(all('signed_draft_deg' not in s and 'visibility_plus' not in s for s in r['samples']))
    def test_invalid_directions_rejected(self):
        shape=BRepPrimAPI_MakeBox(1,2,3).Shape()
        for d in [[0,0,0],[True,0,1],[float('inf'),0,1],[1,2],'0,0,1']:
            with self.assertRaises(ValueError):inspect(shape,{'pull_direction':d})
    def test_source_and_sample_ids_are_explicit(self):
        r=inspect(BRepPrimAPI_MakeBox(1,2,3).Shape())
        self.assertEqual(r['source_sha256'],'analytic-fixture')
        self.assertEqual(len({s['sample_id'] for s in r['samples']}),len(r['samples']))
    def test_adaptive_sampling_recovers_narrow_trimmed_ring(self):
        outer=BRepPrimAPI_MakeBox(20,20,1.3).Shape()
        opening=BRepPrimAPI_MakeBox(gp_Pnt(.8,.8,-.1),18.4,18.4,1.5).Shape()
        shape=BRepAlgoAPI_Cut(outer,opening).Shape()
        coarse=inspect(shape,{'adaptive_sampling':False})
        adaptive=inspect(shape,{'adaptive_sampling':True})
        self.assertGreater(adaptive['coverage']['sampled_faces'],coarse['coverage']['sampled_faces'])
        self.assertGreater(adaptive['coverage']['adaptive_attempted'],0)
        self.assertGreater(adaptive['coverage']['adaptive_accepted'],0)
    def test_adaptive_sampling_reports_bounded_cost_and_recovered_faces(self):
        outer=BRepPrimAPI_MakeBox(20,20,1.3).Shape()
        opening=BRepPrimAPI_MakeBox(gp_Pnt(.8,.8,-.1),18.4,18.4,1.5).Shape()
        r=inspect(BRepAlgoAPI_Cut(outer,opening).Shape(),{'adaptive_sampling':True})
        c=r['coverage']
        self.assertGreater(c['adaptive_recovered_faces'],0)
        self.assertLessEqual(c['attempted_samples'],c['visited_faces']*(25+81+289))
        self.assertEqual(c['adaptive_acceptance_rate'],c['adaptive_accepted']/c['adaptive_attempted'])
    def test_face_limit_marks_unvisited_faces_unmeasured(self):
        shape=BRepPrimAPI_MakeBox(10,10,10).Shape()
        faces=[];e=TopExp_Explorer(shape,TopAbs_FACE)
        while e.More(): faces.append(TopoDS.Face(e.Current()));e.Next()
        r=measure(shape,(faces*11)[:65],100,{'adaptive_sampling':False},'face-limit-fixture')
        self.assertEqual(r['coverage']['visited_faces'],64)
        self.assertEqual(r['coverage']['skipped_faces'],1)
        self.assertEqual(r['coverage']['unmeasured_faces'],[{'face_id':65,'state':'UNMEASURED','reason':'FACE_LIMIT_EXCEEDED'}])
    def test_timeout_is_counted_as_a_failure_reason(self):
        shape=BRepPrimAPI_MakeBox(10,10,10).Shape()
        r=inspect(shape,{'sampling_time_limit_seconds':.001})
        self.assertTrue(r['coverage']['time_limit_reached'])
        self.assertGreater(r['coverage']['failure_reasons']['TIME_LIMIT_REACHED'],0)
    def test_skipped_trimmed_regions_are_aggregated_and_auditable(self):
        outer=BRepPrimAPI_MakeBox(20,20,1.3).Shape()
        opening=BRepPrimAPI_MakeBox(gp_Pnt(.8,.8,-.1),18.4,18.4,1.5).Shape()
        c=inspect(BRepAlgoAPI_Cut(outer,opening).Shape(),{'adaptive_sampling':False})['coverage']
        self.assertGreater(c['skipped_samples'],0)
        self.assertEqual(c['skip_reasons']['TRIMMED_OUT'],c['skipped_samples'])
        self.assertEqual(c['attempted_samples'],c['sample_count']+c['skipped_samples']+sum(x['failed'] for x in c['face_coverage']))

if __name__=='__main__': unittest.main()
