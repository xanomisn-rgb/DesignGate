"""Protocol tests with doubles. These do NOT validate FreeCAD execution."""
import unittest
from types import SimpleNamespace
from freecad_parameter_adapter import apply_parameter_plan
class Doc:
    Name='Design'
    def __init__(self):
        self.obj=SimpleNamespace(PropertiesList=['Radius'],Radius=SimpleNamespace(Value=1),ExpressionEngine=[],State=[])
        self.obj.getTypeIdOfProperty=lambda p:'App::PropertyLength'
        self.Objects=[self.obj];self.events=[]
    def getObject(self,name): return self.obj if name=='Fillet' else None
    def openTransaction(self,name): self.events.append('open')
    def recompute(self): self.events.append('recompute')
    def commitTransaction(self): self.events.append('commit')
    def abortTransaction(self): self.events.append('abort')
class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.doc=Doc();self.plan={'status':'APPROVED_PROJECT_PARAMETERS_NOT_CAD_APPLIED','changes':[{'field':'internalCornerRadius','unit':'mm','old_value':1,'new_value':2}]}
        self.bind={'document_name':'Design','fields':{'internalCornerRadius':{'object':'Fillet','property':'Radius'}}}
    def test_dry_run_never_opens_transaction(self):
        self.assertEqual(apply_parameter_plan(self.doc,self.plan,self.bind)['status'],'DRY_RUN_ONLY');self.assertEqual(self.doc.events,[])
    def test_old_value_mismatch(self):
        self.plan['changes'][0]['old_value']=3
        with self.assertRaisesRegex(ValueError,'Old value'): apply_parameter_plan(self.doc,self.plan,self.bind,False)
        self.assertEqual(self.doc.events,[])
    def test_expression_guard(self):
        self.doc.obj.ExpressionEngine=[('Radius','Length / 2')]
        with self.assertRaisesRegex(ValueError,'Expression'): apply_parameter_plan(self.doc,self.plan,self.bind,False)
    def test_commit_is_explicit_and_never_saves(self):
        result=apply_parameter_plan(self.doc,self.plan,self.bind,False)
        self.assertEqual(self.doc.events,['open','recompute','commit']);self.assertFalse(result['saved'])
    def test_recompute_failure_aborts(self):
        self.doc.obj.State=['Invalid']
        with self.assertRaisesRegex(ValueError,'recompute'): apply_parameter_plan(self.doc,self.plan,self.bind,False)
        self.assertEqual(self.doc.events[-1],'abort')
if __name__=='__main__': unittest.main()
