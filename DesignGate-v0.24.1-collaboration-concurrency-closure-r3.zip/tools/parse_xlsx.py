import sys
import json
import openpyxl

def extract_xlsx(xlsx_path):
    try:
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
        sheets_data = {}
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
                if any(cell is not None for cell in row):
                    rows.append({
                        "row_number": r_idx,
                        "values": [str(c) if c is not None else "" for c in row]
                    })
            sheets_data[sheet_name] = rows
        return {
            "success": True,
            "sheets": sheets_data
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "error": "Missing xlsx file path"}))
        sys.exit(1)
    result = extract_xlsx(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False))
