"""Optional OpenCascade intake. Exact mass properties, bounded display tessellation.
No wall-thickness or undercut certification is inferred from a mesh normal.
"""
import hashlib
import math

def analyze_step(filename, params):
    try:
        from OCP.STEPControl import STEPControl_Reader
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepGProp import BRepGProp
        from OCP.GProp import GProp_GProps
        from OCP.BRepMesh import BRepMesh_IncrementalMesh
        from OCP.TopExp import TopExp_Explorer
        from OCP.TopAbs import TopAbs_FACE, TopAbs_SOLID, TopAbs_REVERSED
        from OCP.TopoDS import TopoDS
        from OCP.BRep import BRep_Tool
        from OCP.TopLoc import TopLoc_Location
        from OCP.Bnd import Bnd_Box
        from OCP.BRepBndLib import BRepBndLib
    except ImportError:
        return {'success':True,'status':'NOT_EVALUATED_REQUIRES_BREP_TOPOLOGY',
                'message':'Optional cadquery-ocp is unavailable. No STEP measurement performed.',
                'bounding_box':None,'draft_analysis':{'status':'NOT_EVALUATED_REQUIRES_BREP_TOPOLOGY'},
                'undercut_analysis':{'status':'NOT_EVALUATED_REQUIRES_BREP_TOPOLOGY','has_undercuts':None}}
    reader=STEPControl_Reader()
    if reader.ReadFile(filename)!=IFSelect_RetDone:
        return {'success':False,'status':'BREP_INVALID_INPUT','bounding_box':None,'error':'STEP reader rejected the file'}
    reader.SetSystemLengthUnit(1.0)  # millimetres, converted from STEP declared units
    if reader.TransferRoots()==0:
        return {'success':False,'status':'BREP_INVALID_INPUT','bounding_box':None,'error':'STEP contains no transferable roots'}
    shape=reader.OneShape()
    if shape.IsNull() or not BRepCheck_Analyzer(shape).IsValid():
        return {'success':False,'error':'Invalid B-Rep topology; no trusted measurements emitted'}
    solids=TopExp_Explorer(shape,TopAbs_SOLID); solid_shapes=[]
    while solids.More():
        solid_shapes.append(TopoDS.Solid(solids.Current()))
        solids.Next()
    solid_count=len(solid_shapes)
    bounds=Bnd_Box(); BRepBndLib.AddOptimal_s(shape,bounds,False,False)
    low,high=bounds.CornerMin(),bounds.CornerMax()
    lo_x,lo_y,lo_z=low.X(),low.Y(),low.Z()
    hi_x,hi_y,hi_z=high.X(),high.Y(),high.Z()
    mass=None
    if solid_count:
        props=GProp_GProps(); BRepGProp.VolumeProperties_s(shape,props)
        centre=props.CentreOfMass()
        mass={'volume_mm3':props.Mass(),'centroid_mm':[centre.X(),centre.Y(),centre.Z()],
              'scope':'Uniform-density aggregate of solids; overlaps are not subtracted',
              'mass_kg':None,'density_status':'NOT_PROVIDED'}
    mesher=BRepMesh_IncrementalMesh(shape,0.15,False,0.3,False); mesher.Perform()
    positions=[]; face_ids=[]; face_count=0; faces=[]
    explorer=TopExp_Explorer(shape,TopAbs_FACE)
    while explorer.More():
        face=TopoDS.Face(explorer.Current()); face_count+=1; faces.append(face)
        loc=TopLoc_Location(); mesh=BRep_Tool.Triangulation_s(face,loc)
        if mesh is not None:
            for i in range(1,mesh.NbTriangles()+1):
                indices=list(mesh.Triangle(i).Get())
                if face.Orientation()==TopAbs_REVERSED: indices[1],indices[2]=indices[2],indices[1]
                for j in indices:
                    point=mesh.Node(j).Transformed(loc.Transformation())
                    positions.extend([round(point.X(),6),round(point.Y(),6),round(point.Z(),6)])
                face_ids.append(face_count)
                if len(face_ids)>30000:
                    return {'success':False,'status':'RESOURCE_LIMIT','error':'Display tessellation exceeds 30000 triangles; simplify STEP first'}
        explorer.Next()
    if not positions or any(not math.isfinite(x) for x in positions):
        return {'success':False,'error':'No finite display triangulation'}
    with open(filename,'rb') as file: digest=hashlib.sha256(file.read()).hexdigest()
    unsupported_reason='MULTI_SOLID_UNSUPPORTED' if solid_count>1 else 'NO_SOLID_TO_MEASURE'
    measurement={'status':'NOT_EVALUATED_REQUIRES_SINGLE_SOLID','source_sha256':digest,'samples':[],
                 'coverage':{'total_faces':face_count,'visited_faces':0,'sampled_faces':0,'sample_count':0,
                             'chord_count':0,'skipped_faces':face_count,
                             'unmeasured_faces':[{'face_id':i,'state':'UNMEASURED','reason':unsupported_reason}
                                                 for i in range(1,face_count+1)],
                             'failure_reasons':{unsupported_reason:face_count},'time_limit_reached':False,
                             'global_minimum_proven':False}}
    if solid_count==1:
        from brep_measurements import measure
        measurement=measure(shape,faces,max(hi_x-lo_x,hi_y-lo_y,hi_z-lo_z),params,digest)
    samples=measurement['samples']
    angles=[s['signed_draft_deg'] for s in samples if 'signed_draft_deg' in s]
    from cad_oracle import assembly_pairs, thickness_oracle, undercut_oracle
    thickness_result=thickness_oracle(measurement)
    assembly_result=assembly_pairs([{'component_id':f'SOLID-{index + 1}','shape':solid}
                                    for index,solid in enumerate(solid_shapes)]) if solid_count>1 else {
        'status':'ASSEMBLY_NOT_APPLICABLE_REQUIRES_MULTIPLE_SOLIDS','pair_count':0,'pairs':[],
        'global_mathematical_proof':False,
        'limitations':['Assembly pair analysis requires at least two supplied B-Rep solids.']}
    undercut_result=undercut_oracle(measurement) if measurement.get('pull_direction') is not None else {
        'status':'UNDERCUT_NOT_EVALUATED_PULL_DIRECTION_REQUIRED','pull_direction':None,'affected_faces':[],
        'blocked_area_or_candidate_region':None,'possible_side_action_requirement':None,'confidence':'NOT_EVALUATED',
        'global_mathematical_proof':False,'limitations':['Pull direction is required for bounded undercut screening.']}
    return {'success':True,'status':'BREP_ANALYZED_PARTIAL','tool':'OpenCascade / OCP',
            'source_sha256':digest,'topology':{'valid':True,'faces':face_count,'solids':solid_count},
            'bounding_box':{'length_mm':hi_x-lo_x,'width_mm':hi_y-lo_y,'height_mm':hi_z-lo_z,'unit':'mm','unit_verified':True},
            'mass_properties':mass,
            'display_mesh':{'positions':positions,'face_ids':face_ids,'source_sha256':digest,'unit':'mm','tolerance_mm':0.15,'engineering_evidence':False},
            'surface_measurements':measurement,
            'draft_analysis':{'status':'SAMPLED_SURFACE_NORMAL_ANGLES' if angles else 'NEED_PULL_DIRECTION_OR_VALID_SAMPLES',
                              'pull_direction':measurement.get('pull_direction'),'sampled_min_signed_deg':min(angles) if angles else None,
                              'sampled_max_signed_deg':max(angles) if angles else None,'manufacturing_pass':None},
            'wall_thickness':{'status':'SAMPLED_NORMAL_CHORDS' if measurement.get('sampled_minimum_chord_mm') is not None else 'NOT_EVALUATED',
                              'minimum_mm':None,'sampled_minimum_chord_mm':measurement.get('sampled_minimum_chord_mm'),'global_minimum_proven':False},
            'thickness_oracle':thickness_result,
            'assembly_analysis':assembly_result,
            'undercut_analysis':{'status':'SAMPLED_VISIBILITY_NOT_PARTING_ANALYSIS' if angles else 'NOT_EVALUATED_REQUIRES_VISIBILITY_AND_PARTING',
                                 'both_directions_occluded_samples':sum(s.get('visibility_plus')=='OCCLUDED' and s.get('visibility_minus')=='OCCLUDED' for s in samples) if angles else None,'has_undercuts':None},
            'undercut_oracle':undercut_result,
            'limitations':['Surface sampling is bounded and can miss small features; inspect coverage.','Normal chords and display tessellation are not global wall thickness, draft certification, or interference analysis.','Face IDs are bound to the source hash and are not stable across edited files.']}
