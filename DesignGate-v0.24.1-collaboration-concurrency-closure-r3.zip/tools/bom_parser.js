const { runPython } = require("./python_runner");
const { execFileSync } = require("child_process");
const path = require("path");
const fs = require("fs");

class BOMParser {
  static parseXLSX(xlsxPath) {
    if (!fs.existsSync(xlsxPath)) {
      throw new Error(`XLSX file not found: ${xlsxPath}`);
    }

    const pyScript = path.join(__dirname, "parse_xlsx.py");
    try {
      const output = runPython(pyScript, [xlsxPath]);
      const data = JSON.parse(output);
      if (!data.success) {
        throw new Error(data.error || "Failed to extract XLSX");
      }

      const fileName = path.basename(xlsxPath);
      const components = [];

      const aliases={part_id:['partid','id','序号','零件编号','部件编号'],part_name:['partname','name','零件名称','部件名称'],material_specified:['materialspecified','material','材料','材料牌号'],process:['manufacturingprocess','process','工艺','制造工艺'],quantity:['quantity','qty','数量'],unit_cost:['unitcost','unitprice','单价'],currency:['currency','币种'],quote_source:['quotesource','报价来源']};
      const norm=x=>String(x??'').toLowerCase().replace(/[\s_-]/g,'');
      for(const [sheetName,rows]of Object.entries(data.sheets)){
        const headerIndex=rows.findIndex(r=>r.values.some(v=>aliases.part_name.includes(norm(v))));
        if(headerIndex<0)continue;
        const header=rows[headerIndex].values.map(norm),columns=Object.fromEntries(Object.entries(aliases).map(([k,words])=>[k,header.findIndex(v=>words.includes(v))]));
        for(const r of rows.slice(headerIndex+1)){
          const get=k=>columns[k]<0?null:r.values[columns[k]];
          if(!String(get('part_name')||'').trim())continue;
          const numeric=k=>{const v=get(k);if(v==null||String(v).trim()==='')return null;const n=Number(v);return Number.isFinite(n)&&n>=0?n:null;};
          components.push({source_pointer:{file:fileName,sheet:sheetName,row:r.row_number},part_id:String(get('part_id')||`BOM-${r.row_number}`),part_name:String(get('part_name')),material_specified:get('material_specified')||null,process:get('process')||null,quantity:numeric('quantity'),unit_cost:numeric('unit_cost'),currency:get('currency')||null,quote_source:get('quote_source')||null});
        }
      }
      if(!components.length)throw new Error('未找到包含 Part Name / 零件名称 的 BOM 表头或有效零件行');

      return {
        success: true,
        file: fileName,
        components
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  static parseBOMText(text, sourceFile = "manual_input.txt") {
    if (!text) return [];
    const lines = text.split("\n");
    const components = [];

    lines.forEach((line, idx) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith("|---")) return;

      if (trimmed.includes("|")) {
        const parts = trimmed.split("|").slice(1, -1).map(p => p.trim());
        if (parts.length >= 2 && parts[0] !== "部件序号" && parts[0] !== "序号") {
          components.push({
            source_pointer: { file: sourceFile, row: idx + 1 },
            part_id: `BOM-${String(components.length + 1).padStart(3, "0")}`,
            part_name: parts[1] || parts[0],
            material_specified: parts[2] || "未指定具体牌号",
            process: (parts[3] && parts[3].trim() !== "") ? parts[3].trim() : null
          });
        }
      } else if (/^\d+[.、]/.test(trimmed)) {
        const content = trimmed.replace(/^\d+[.、]\s*/, "");
        components.push({
          source_pointer: { file: sourceFile, row: idx + 1 },
          part_id: `BOM-${String(components.length + 1).padStart(3, "0")}`,
          part_name: content.split(/[(（]/)[0].trim(),
          material_specified: content.includes("(") ? content.split(/[(（]/)[1].replace(/[)）]/, "").trim() : "未指定具体牌号"
        });
      }
    });

    return components;
  }
}

module.exports = BOMParser;
