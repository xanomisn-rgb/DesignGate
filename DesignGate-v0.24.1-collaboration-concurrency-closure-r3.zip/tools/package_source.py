"""Create a clean, portable source release; does not delete working files."""
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
output = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent / 'DesignGate-Agent-v0.17.0-alpha.zip'
excluded = {'__pycache__', 'node_modules', '.git', 'dist', '.venv', 'venv', 'data', 'runs'}
files = []
for file in sorted(root.rglob('*')):
    rel = file.relative_to(root)
    if not file.is_file() or file.is_symlink() or file.resolve() == output:
        continue
    if any(part in excluded for part in rel.parts) or file.suffix in {'.pyc', '.pyo', '.tmp', '.lock'} or file.name.startswith('.env'):
        continue
    files.append((file, 'DesignGate/' + rel.as_posix()))
output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file, name in files:
        archive.write(file, name)
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert all('\\' not in name and '__pycache__' not in name and not name.endswith('.pyc') for name in archive.namelist())
print(f'{output} ({len(files)} files)')
