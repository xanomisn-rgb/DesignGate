"""Serialize a bounded flat archive; no extraction or user-selected input paths."""
import sys,json,io,zipfile,base64,re
data=json.loads(sys.stdin.read(9*1024*1024))
if not isinstance(data,dict) or len(data)>20: raise ValueError('Invalid asset set')
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,content in data.items():
        if not re.fullmatch(r'[A-Za-z0-9_]+\.(json|md|py)',name) or not isinstance(content,str):
            raise ValueError('Unsafe asset entry')
        archive.writestr(name,content.encode('utf-8'))
print(base64.b64encode(buffer.getvalue()).decode('ascii'))
