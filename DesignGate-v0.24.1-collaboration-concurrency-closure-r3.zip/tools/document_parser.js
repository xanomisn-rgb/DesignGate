const { runPython } = require("./python_runner");
const { execFileSync } = require("child_process");
const path = require("path");
const fs = require("fs");

class DocumentParser {
  static parsePDF(pdfPath) {
    if (!fs.existsSync(pdfPath)) {
      throw new Error(`PDF file not found: ${pdfPath}`);
    }

    const pyScript = path.join(__dirname, "parse_pdf.py");
    try {
      // 安全使用 execFileSync 传参，避免 shell 注入
      const output = runPython(pyScript, [pdfPath]);
      const data = JSON.parse(output);
      if (!data.success) {
        throw new Error(data.error || "Failed to extract PDF text");
      }

      const extractedItems = [];
      data.pages.forEach(p => {
        const dims = DocumentParser.extractDimensions(p.text);
        if (dims.nominalWall !== null || dims.localMaxWall !== null || dims.ribThickness !== null || dims.draftAngle !== null) {
          extractedItems.push({
            page: p.page_number,
            file: path.basename(pdfPath),
            dimensions: dims,
            snippet: p.text.slice(0, 120).trim()
          });
        }
      });

      return {
        success: true,
        file: path.basename(pdfPath),
        total_pages: data.total_pages,
        pages: data.pages,
        extracted_dimensions_by_page: extractedItems
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  static extractDimensions(text) {
    if (!text || typeof text !== "string") {
      return { nominalWall: null, localMaxWall: null, ribThickness: null, draftAngle: null };
    }

    const nominalMatch = text.match(/(?:公称壁厚|主壁厚|基准壁厚|nominal\s*wall)[^\d+\-。；;\n]*?([+-]?\d+(?:\.\d+)?)\s*(?:mm|毫米)/i);
    const nominalWall = nominalMatch ? parseFloat(nominalMatch[1]) : null;

    const maxMatch = text.match(/(?:局部最大壁厚|最大胶位|局部厚肉|螺柱肉厚|local\s*max\s*wall)[^\d+\-。；;\n]*?([+-]?\d+(?:\.\d+)?)\s*(?:mm|毫米)/i);
    const localMaxWall = maxMatch ? parseFloat(maxMatch[1]) : null;

    const ribMatch = text.match(/(?:加强筋厚度|筋位厚度|筋厚|rib\s*thickness)[^\d+\-。；;\n]*?([+-]?\d+(?:\.\d+)?)\s*(?:mm|毫米)/i);
    const ribThickness = ribMatch ? parseFloat(ribMatch[1]) : null;

    const draftMatch = text.match(/(?:拔模斜度|拔模角|脱模斜度|draft\s*angle)[^\d+\-。；;\n]*?([+-]?\d+(?:\.\d+)?)\s*(?:°|度|deg)/i);
    const draftAngle = draftMatch ? parseFloat(draftMatch[1]) : null;

    return { nominalWall, localMaxWall, ribThickness, draftAngle };
  }
}

module.exports = DocumentParser;
