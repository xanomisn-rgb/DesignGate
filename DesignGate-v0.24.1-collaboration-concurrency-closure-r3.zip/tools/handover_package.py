"""Frozen local records -> portable PDFs/CSV/MD/JSON. No factory signature."""
import sys,json,io,zipfile,base64,csv,hashlib
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pathlib import Path
from reportlab.lib.colors import HexColor

pdfmetrics.registerFont(TTFont('DesignGate-CJK',str(Path(__file__).parent/'fonts'/'NotoSansSC-Regular.ttf')))
body=ParagraphStyle('body',fontName='DesignGate-CJK',fontSize=10,leading=16,spaceAfter=7,wordWrap='CJK',textColor=HexColor('#17354a'))
heading=ParagraphStyle('heading',parent=body,fontSize=19,leading=26,spaceAfter=16)
label=ParagraphStyle('label',parent=body,fontSize=12,leading=18,spaceBefore=10)
def text(value):return '未提供 / UNKNOWN' if value is None or value=='' else str(value)
def fields(value):
    if not value:return '未提供 / UNKNOWN'
    names={'active_revision':'修订版','material':'材料声明','process':'工艺','finish':'表面处理','check_id':'检查编号','status':'状态','description':'说明','source_pointer':'来源定位','basis_hash':'基线哈希','reviewer':'记录人','observed_result':'观测结果','evidence_id':'证据编号','req_id':'需求编号'}
    if isinstance(value,list):return '\n\n'.join(fields(v) for v in value)
    if isinstance(value,dict):return '\n'.join(names.get(k,k)+'：'+(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else text(v)) for k,v in value.items())
    return text(value)
def paragraph(value,style=body):return Paragraph(escape(text(value)).replace('\n','<br/>'),style)
def footer(c,doc):
    c.setFont('Helvetica',8);c.setFillColor(HexColor('#65727c'))
    c.drawString(40,25,'LOCAL FREEZE RECORD - FACTORY SIGN-OFF PENDING')
    c.drawRightString(555,25,str(doc.page))
def pdf(title,p,sections):
    stream=io.BytesIO();story=[paragraph('DESIGNGATE / '+title,heading),paragraph(p['project_name']),
      paragraph('项目 '+p['project_id']+' · Revision '+p['design']['active_revision']+' · 状态：本地冻结记录'),
      paragraph('本报告整理已有记录，不是工厂签核、符合性证书或开模授权。')]
    for title,content in sections:story.extend([paragraph(title,label),paragraph(content)])
    SimpleDocTemplate(stream,pagesize=(595,842),leftMargin=40,rightMargin=40,topMargin=42,bottomMargin=45).build(story,onFirstPage=footer,onLaterPages=footer)
    return stream.getvalue()
def build(payload):
    p=payload['project'];freeze=p.get('freeze') or {}
    if not freeze.get('freeze_id') or freeze.get('revision')!=p['design']['active_revision']:raise ValueError('Frozen snapshot required')
    files={};sections=[]
    for r in p.get('requirements',[]):
        ver=[v for v in p.get('verifications',[]) if v.get('req_id')==r.get('req_id')]
        sections.append((text(r.get('req_id')),text(r.get('text'))+'\n验证方法：'+text(r.get('verification_method'))+'\n接受判据：'+text(r.get('acceptance_criteria'))+'\n来源：'+fields(r.get('source_pointer'))+'\n本地验证记录：'+fields(ver)))
    if not sections:sections=[('需求记录','未提供需求行；不得据此声称需求已验证。')]
    files['01_需求基线与追溯矩阵.pdf']=pdf('需求基线与追溯矩阵',p,sections)
    sections=[('审批范围','本机审批人：'+text(freeze.get('approved_by'))+'\n时间：'+text(freeze.get('approved_at'))+'\n意见：'+text(freeze.get('reason'))+'\n工厂签核人、签名、开模费用与工期：未提供。'),
              ('设计参数',fields(p.get('design',{}))),
              ('测量边界','BRep 结果为有限采样；不证明全局最小壁厚、无倒扣、强度合格或无装配干涉。')]
    for c in p.get('checks',[]):sections.append((text(c.get('check_id'))+' · '+text(c.get('status')),fields(c)))
    for f in p.get('findings',[]):sections.append(('Finding '+text(f.get('issue_id')),fields(f)))
    files['02_DFM评审记录_工厂签核待完成.pdf']=pdf('DFM 评审记录',p,sections)
    def safe(v):
        s=text(v)
        return "'"+s if s.lstrip().startswith(('=','+','-','@')) or s.startswith(('\t','\r','\n')) else s
    stream=io.StringIO(newline='');w=csv.writer(stream,quoting=csv.QUOTE_ALL)
    w.writerow(['Part ID','零件名称','数量','原厂材料牌号','工艺','表面处理','咬花代号','报价','状态'])
    for b in p.get('bom',[]):w.writerow([safe(b.get(k)) for k in ['part_id','part_name','quantity','material_specified','process','finish','texture_code','unit_cost']]+['本地记录，供应商需复核'])
    files['03_CMF工程规格表.csv']=('\ufeff'+stream.getvalue()).encode('utf-8')
    statement='# '+text(p.get('project_name'))+'\n\n设计陈述工作稿 / Design statement working draft\n\n此稿未按特定奖项规则审定。/ Not reviewed against any award submission rules.\n\n## 已登记设计意图 / Recorded design intent\n\n'+json.dumps(p.get('memory',{}).get('design_intent',{}),ensure_ascii=False,indent=2)+'\n\n## 待设计师完善 / Author input required\n\n用户洞察、原创贡献、形态与体验论证、量产及可持续性证据请据实补充。\nAdd documented user insights, original contributions, form and experience rationale, and validated production or sustainability evidence.\n'
    files['04_设计大奖申报设计陈述_工作稿.md']=statement.encode('utf-8')
    audit={'project_id':p['project_id'],'version':p['version'],'revision':p['design']['active_revision'],'freeze':freeze,'changes':p.get('agent_changes',[]),'decisions':p.get('decisions',[]),'tasks':payload.get('tasks',[]),'task_history_complete':False,'task_limit':30,'external_release':False}
    files['05_工程变更决策审计日志.json']=json.dumps(audit,ensure_ascii=False,indent=2).encode('utf-8')
    manifest={'scope':'LOCAL_FROZEN_HANDOVER_NOT_FACTORY_SIGNOFF','project_sha256':payload['project_sha256'],'signature':None,'external_release':False,'entries':[{'name':n,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in files.items()]}
    files['MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in files.items():z.writestr(name,data)
    return stream.getvalue()
if __name__=='__main__':
    raw=sys.stdin.read(8*1024*1024+1)
    if len(raw)>8*1024*1024:raise ValueError('Handover snapshot too large')
    print(base64.b64encode(build(json.loads(raw))).decode('ascii'))
