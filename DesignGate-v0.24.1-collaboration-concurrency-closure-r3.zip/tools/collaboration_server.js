const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');
const CollaborationServer = require('../backend/collaboration/server');

const root = process.env.DESIGNGATE_COLLABORATION_DIR || path.join(process.cwd(), 'data', 'collaboration');
const secret = process.env.DESIGNGATE_SESSION_SECRET;
if (!secret || secret === 'replace_with_a_long_random_local_secret') throw new Error('DESIGNGATE_SESSION_SECRET_REQUIRED');
const identity = new IdentityService({ directory: path.join(root, 'identity'), sessionSecret: secret });
const store = new TeamStore({ directory: path.join(root, 'database') });
const artifactStore = new LocalImmutableArtifactStore({ directory: process.env.DESIGNGATE_ARTIFACT_DIR || path.join(root, 'artifacts') });
const server = new CollaborationServer({ identity, store, artifactStore, host: process.env.DESIGNGATE_SERVER_HOST || '127.0.0.1', port: Number(process.env.DESIGNGATE_SERVER_PORT || 43124) });
server.start().then(address => process.stdout.write(`DesignGate Collaboration Server listening on ${address.address}:${address.port}\n`));
const stop = async () => { await server.stop(); store.close(); process.exit(0); };
process.once('SIGINT', stop); process.once('SIGTERM', stop);
