import unittest,io,zipfile,json,hashlib,sys
from pathlib import Path
from pypdf import PdfReader
from handover_package import build,pdf

def sample():
    return {'project_sha256':'SYNTHETIC_NOT_A_REAL_PROJECT','tasks':[],'project':{
      'project_id':'DG-SYNTHETIC','project_name':'合成验收项目 · 非真实签核','version':3,'design':{'active_revision':'A','material':'待供应商确认','process':'注塑'},
      'freeze':{'freeze_id':'SYNTHETIC','revision':'A','approved_by':'合成测试人员','reason':'仅用于版式和格式测试','approved_at':'2026-09-07'},
      'requirements':[{'req_id':'REQ-01','text':'外壳采用可拆卸连接，易损件应可更换。','verification_method':'人工核对拆解步骤和样件记录','acceptance_criteria':'待项目定义'},
                      {'req_id':'REQ-02','text':'保持预定外观轮廓与主视觉面连续性。','verification_method':'对照效果图与实物样板','acceptance_criteria':'待签样'}],
      'bom':[{'part_id':'BOM-1','part_name':'外壳','quantity':1,'material_specified':'待原厂牌号','process':'注塑','finish':'哑光','unit_cost':None},{'part_id':'BOM-2','part_name':'=UNTRUSTED_FORMULA','unit_cost':None}],
      'checks':[{'check_id':'SYNTHETIC-01','status':'UNKNOWN','description':'合成格式测试：没有供应商原厂依据，不可放行。'}]}}
class HandoverTests(unittest.TestCase):
    def test_archive_pdf_text_fonts_and_csv(self):
        with zipfile.ZipFile(io.BytesIO(build(sample()))) as z:
            self.assertIsNone(z.testzip());manifest=json.loads(z.read('MANIFEST.json'));self.assertFalse(manifest['external_release'])
            for e in manifest['entries']:
                b=z.read(e['name']);self.assertEqual(hashlib.sha256(b).hexdigest(),e['sha256'])
                if e['name'].endswith('.pdf'):
                    reader=PdfReader(io.BytesIO(b));self.assertIn('合成验收项目',reader.pages[0].extract_text())
                    fonts=reader.pages[0]['/Resources']['/Font'].get_object().values()
                    self.assertTrue(any('/FontFile2' in f.get_object().get('/FontDescriptor',{}).get_object() for f in fonts if f.get_object().get('/FontDescriptor')))
                if e['name'].endswith('.csv'):
                    s=b.decode('utf-8-sig');self.assertIn("'=UNTRUSTED_FORMULA",s);self.assertIn('UNKNOWN',s)
    def test_unfrozen_payload_is_rejected(self):
        p=sample();p['project']['freeze']={}
        with self.assertRaises(ValueError):build(p)
    def test_long_chinese_record_paginates(self):
        b=pdf('分页测试',sample()['project'],[('长记录','可追溯的工程依据与待验证条件。'*400)])
        self.assertGreater(len(PdfReader(io.BytesIO(b)).pages),1)
if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--sample-output':Path(sys.argv[2]).write_bytes(build(sample()))
    else:unittest.main()
