const { execSync, execFileSync } = require("child_process");

let cachedConfig = null;

function detectPythonCommand() {
  if (cachedConfig) return cachedConfig;

  if (process.env.PYTHON_BIN) {
    cachedConfig = { executable: process.env.PYTHON_BIN, baseArgs: [] };
    return cachedConfig;
  }

  // Windows 常用候选列表
  if (process.platform === "win32") {
    const winCandidates = [
      { executable: "python", baseArgs: [] },
      { executable: "py", baseArgs: ["-3"] },
      { executable: "py", baseArgs: [] },
      { executable: "python3", baseArgs: [] }
    ];

    for (const c of winCandidates) {
      try {
        execFileSync(c.executable, [...c.baseArgs, "--version"], { stdio: "ignore" });
        cachedConfig = c;
        return cachedConfig;
      } catch (e) {}
    }
  } else {
    // POSIX 候选列表
    const posixCandidates = [
      { executable: "python3", baseArgs: [] },
      { executable: "python", baseArgs: [] }
    ];

    for (const c of posixCandidates) {
      try {
        execFileSync(c.executable, [...c.baseArgs, "--version"], { stdio: "ignore" });
        cachedConfig = c;
        return cachedConfig;
      } catch (e) {}
    }
  }

  // 默认兜底
  cachedConfig = process.platform === "win32" 
    ? { executable: "python", baseArgs: [] } 
    : { executable: "python3", baseArgs: [] };
  return cachedConfig;
}

function runPython(scriptPath, scriptArgs = [], options = {}) {
  const cfg = detectPythonCommand();
  const path = require('path');
  const resolvedScript = scriptPath.replace(path.sep + 'app.asar' + path.sep, path.sep + 'app.asar.unpacked' + path.sep);
  const allArgs = [...cfg.baseArgs, resolvedScript, ...scriptArgs];
  return execFileSync(cfg.executable, allArgs, {
    encoding: "utf-8",
    timeout: 30000,
    maxBuffer: 16 * 1024 * 1024,
    ...options
  });
}

function checkPythonHealth() {
  const cfg = detectPythonCommand();
  const health = {
    available: false,
    command: cfg.executable + (cfg.baseArgs.length ? " " + cfg.baseArgs.join(" ") : ""),
    version: null,
    modules: {
      pypdf: false,
      openpyxl: false
    }
  };

  try {
    const vOut = execFileSync(cfg.executable, [...cfg.baseArgs, "--version"], { encoding: "utf-8" }).trim();
    health.available = true;
    health.version = vOut;

    try {
      execFileSync(cfg.executable, [...cfg.baseArgs, "-c", "import pypdf; import openpyxl"], { stdio: "ignore" });
      health.modules.pypdf = true;
      health.modules.openpyxl = true;
    } catch (err) {}
  } catch (e) {
    health.available = false;
  }

  return health;
}

module.exports = {
  detectPythonCommand,
  runPython,
  checkPythonHealth
};
