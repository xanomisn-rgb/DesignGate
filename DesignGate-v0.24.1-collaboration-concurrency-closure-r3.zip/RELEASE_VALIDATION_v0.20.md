# DesignGate v0.20 Release Gate

## Implemented foundation

- A single Professional Capability Contract with six allowed statuses. Professional engines cannot report production approval.
- Ergonomics static wrist-moment screening with explicit units, inputs and biomechanical limitations.
- CMF compatibility matrix. Uncovered combinations report `UNKNOWN_REQUIRES_TEST`; supplier samples and measurements remain required.
- DFMEA risk engine with Severity/Occurrence/Detection, RPN, Action Priority, requirement links and verification-gap / risk-reopened signals.
- An Evidence Graph that traces registered evidence, requirements, decisions and revisions.

## Required before a verified release

The following have **not** been run by this repository and remain `UNVERIFIED`:

1. Freeze model, temperature, token budget, toolset and the 40-case benchmark.
2. Run 5 trials per case for v0.18.1 and v0.20 (200 runs per version); preserve raw records and hashes.
3. Obtain blind holdout review from one industrial-design and one structure/manufacturing reviewer.
4. Calculate task completion, failure + budget exhaustion, evidence binding, high-risk miss, false-positive, decision correctness, unsupported-claim and expert-score metrics.

## Release thresholds

These are acceptance thresholds, not reported results:

| Metric | Gate |
| --- | --- |
| FAILED + BUDGET_EXCEEDED | < 5% |
| Unsupported engineering claim | < 2% |
| Evidence binding | > 95% |
| Critical/high-risk miss | < 5% |

Any missing evidence, unavailable solver, unsupported method or absent reviewer remains visible through the capability contract; it must not be converted into a PASS, an approval, or a production claim.
