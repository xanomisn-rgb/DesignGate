# DesignGate Agent v0.19.0-alpha

本版本针对 v0.18.1 的 200 次真实运行失败轨迹做增量修复，仍是 alpha，不代表行业认证或工程放行能力。

## 主要变化

- 供应商适配层仅规范化无歧义的 `finish_task` 协议形状；内部 schema、证据绑定和运行时校验继续严格。
- 合法 `finish_task` 可在滚动计划窗口结束时直接收束，避免无价值的额外重规划。
- 动态隐藏当前状态不可用的文件/CAD 工具；新增来源、项目版本、Revision、测量记录绑定的 CAD 引用句柄。
- 同一工具、规范化参数和项目版本的失败调用不会无信息重复；工具错误记录类别、恢复动作和恢复关系。
- 记录请求体分项、供应商 token/缓存、模型延迟、工具时长和整体时长；未核实价格时不估算费用。
- CAD 输出面覆盖、跳过、失败、超时、自适应采样开销；未测区域和无阈值原始值均不渲染为 PASS。
- 手持产品分开保存整机外包络与局部握持截面，并补充重量、重心、姿态、力、时长、人群及来源；旧 `dimensions` 只迁移为外包络。
- CMF 按材料家族/牌号、基材/表面、测量条件、环境、相容性、样件、耐久与来源审核状态返回具体未知项。
- 评测分开报告协议与结构、执行稳定性、任务完成质量、工业设计正确性、状态与权限安全；`planning` 更名为 `planning_protocol`。
- live runner 生成空白人审材料，并在运行前冻结代码、案例、知识、答案和配置哈希。

## 当前证据

- 本地 Node 全量回归：227/227 PASS。
- CAD/OCP 回归：见 `RELEASE_VALIDATION_v0.19.md`。
- v0.18.1 旧 200-run 用 v0.19 口径重算，仅作为修复前诊断基线；没有把旧运行包装成 v0.19 实跑。
- v0.19 真实模型 smoke、定向复测和冻结 holdout：NOT_RUN。需要重新提供仍有效的临时密钥或在环境变量中配置后才能执行。
- 任务质量与工业设计正确性：UNVERIFIED，等待逐 trial 人工审核与 Gold 专家审核。

## 启动与验证

```powershell
npm install
npm test
npm run check
npm run test:cad
npm run test:adapter
npm run test:handover
npm start
```

真实模型小样必须显式使用 `--live`，并设置 `DESIGNGATE_EVAL_API_KEY`、`DESIGNGATE_EVAL_BASE_URL`、`DESIGNGATE_EVAL_MODEL`。不要把密钥写入源码、报告或压缩包。
