class LMSAdapter{
 async readAssignment(){return {status:'NOT_IMPLEMENTED',reason:'需要实际 LMS 身份认证与作业协议'};}
 async writeGradeAndFeedback(){return {status:'NOT_SENT',reason:'禁止由 Gate 自动推导课程成绩；请教师确认评分后通过已联调 LMS 接口写入'};}
}
module.exports=LMSAdapter;
