/* Native tool-call transport. Credentials never enter persisted task records. */
const upperIfAllowed=(value,allowed)=>typeof value==='string'&&allowed.includes(value.toUpperCase())?value.toUpperCase():value;
function normalizeProviderMessage(message){
  const copy=structuredClone(message);
  for(const call of copy?.tool_calls||[]){
    if(call?.function?.name!=='finish_task'||typeof call.function.arguments!=='string')continue;
    let args;try{args=JSON.parse(call.function.arguments);}catch{continue;}
    if(typeof args.limitations==='string'&&args.limitations.trim()){
      try{const parsed=JSON.parse(args.limitations);args.limitations=Array.isArray(parsed)&&parsed.every(x=>typeof x==='string')?parsed:[args.limitations];}
      catch{args.limitations=[args.limitations];}
    }
    for(const claim of Array.isArray(args.claims)?args.claims:[]){
      claim.status=upperIfAllowed(claim.status,['SUPPORTED','PARTIALLY_SUPPORTED','UNKNOWN']);
      claim.confidence=upperIfAllowed(claim.confidence,['HIGH','MEDIUM','LOW']);
    }
    call.function.arguments=JSON.stringify(args);
  }
  return copy;
}
function positiveInt(value,fallback){return Number.isInteger(value)&&value>0?value:fallback;}
function outputLimit(config,explicit){
  const value=explicit===undefined?config.maxOutputTokens:explicit;
  if(value===undefined||value===null||value==='')return null;
  if(!Number.isInteger(value)||value<=0)throw Error('模型单次最大输出 token 必须为正整数或留空由供应商决定');
  return value;
}
function requestByteBreakdown(messages,tools,body){
  const bytes=value=>Buffer.byteLength(typeof value==='string'?value:JSON.stringify(value)||'','utf8'),firstUser=messages.findIndex(m=>m.role==='user');
  return {total:bytes(body),system:messages.filter(m=>m.role==='system').reduce((n,m)=>n+bytes(m),0),tool_schemas:bytes(tools),
    project_data:firstUser<0?0:bytes(messages[firstUser]),tool_observations:messages.filter(m=>m.role==='tool').reduce((n,m)=>n+bytes(m),0),
    history_messages:messages.reduce((n,m,i)=>n+(m.role!=='system'&&m.role!=='tool'&&i!==firstUser?bytes(m):0),0),
    format_repair:messages.filter(m=>typeof m.content==='string'&&m.content.includes('FINISH_SCHEMA_REPAIR_REQUIRED')).reduce((n,m)=>n+bytes(m),0)};
}
class AgentModelClient {
  constructor(getConfig,fetchImpl=globalThis.fetch){this.getConfig=getConfig;this.fetch=fetchImpl;}
  async call({messages,tools,signal,maxTokens=undefined,forcePlan=false,forceTool=null,seed=null}){
    const config=this.getConfig();
    if(!config.apiKey)throw Error('Agent 需要先配置支持工具调用的模型 API；本地固定评审仍可独立使用。');
    const timeoutMs=positiveInt(config.modelRequestTimeoutMs,120000),lengthLimit=Math.min(4,positiveInt(config.maxLengthRecoveryAttempts,2)),limit=outputLimit(config,maxTokens);
    const controller=new AbortController(),abort=()=>controller.abort(),timer=setTimeout(abort,timeoutMs);signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)controller.abort();
    let providerAttempts=0,lengthRecoveries=0,totalLatency=0,lastRequestBytes=null,accumulatedText='',currentMessages=structuredClone(messages||[]),currentForce=forceTool;
    const retryable=new Set([408,409,429,500,502,503,504]),maxRetries=Math.min(2,Math.max(0,config.maxProviderRetries??1));
    try{
      while(true){
        const hasTools=Array.isArray(tools)&&tools.length>0;
        const payload={model:config.model,temperature:Math.min(config.temperature??.1,.3),messages:currentMessages,
          ...(hasTools?{tools,tool_choice:forcePlan?{type:'function',function:{name:'update_plan'}}:currentForce?{type:'function',function:{name:currentForce}}:'auto'}:{}),
          ...(limit===null?{}:{max_tokens:limit}),
          ...(config.seedSupported&&Number.isInteger(seed)?{seed}:{}),
          ...(new URL(config.baseUrl).hostname==='api.deepseek.com'?{thinking:{type:'disabled'}}:{})};
        const body=JSON.stringify(payload);lastRequestBytes=requestByteBreakdown(currentMessages,tools||[],body);
        const started=Date.now();let response,retries=0;
        do{providerAttempts++;response=await this.fetch(config.baseUrl.replace(/\/$/,'')+'/chat/completions',{method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json',Authorization:'Bearer '+config.apiKey},body});if(response.ok)break;retries++;}while(retryable.has(response.status)&&retries<=maxRetries);
        totalLatency+=Date.now()-started;
        if(!response.ok)throw Error('模型工具调用失败 HTTP '+response.status+'；请核对端点、模型、账号配额和工具调用支持。');
        const data=await response.json(),choice=data.choices?.[0];if(!choice?.message)throw Error('模型没有返回有效 message');
        if(choice.finish_reason!=='length'){
          const msg=normalizeProviderMessage(choice.message);if(accumulatedText&&typeof msg.content==='string')msg.content=accumulatedText+msg.content;
          const usage=data.usage||null,cachedTokens=usage?.prompt_cache_hit_tokens??usage?.prompt_tokens_details?.cached_tokens??null;
          return {message:msg,usage,provider_seed_applied:!!(config.seedSupported&&Number.isInteger(seed)),telemetry:{request_bytes:lastRequestBytes,model_latency_ms:totalLatency,cached_tokens:Number.isFinite(cachedTokens)?cachedTokens:null,provider_attempts:providerAttempts,length_recoveries:lengthRecoveries,output_limit_tokens:limit}};
        }
        if(lengthRecoveries>=lengthLimit)throw Error('MODEL_OUTPUT_TRUNCATED_AFTER_RECOVERY: 模型单次输出达到供应商限制，已完成受控恢复尝试；未执行任何截断工具调用。');
        lengthRecoveries++;
        const truncated=choice.message,toolCalls=Array.isArray(truncated.tool_calls)?truncated.tool_calls:[];
        if(toolCalls.length){
          // Never return or execute truncated tool arguments. Ask the provider to regenerate the whole structure from scratch.
          const name=toolCalls.length===1&&typeof toolCalls[0]?.function?.name==='string'?toolCalls[0].function.name:null;
          currentMessages=[...messages,{role:'user',content:'上一轮工具调用在供应商输出边界被截断，参数未执行也未产生任何副作用。请从头重新生成完整的单个工具调用，并确保参数是完整 JSON。'}];
          currentForce=name||forceTool;forcePlan=false;accumulatedText='';continue;
        }
        if(typeof truncated.content==='string'&&truncated.content.length){
          accumulatedText+=truncated.content;
          currentMessages=[...currentMessages,{role:'assistant',content:truncated.content},{role:'user',content:'继续上一段文本，不要重复已经输出的内容；只补完被截断的剩余部分。'}];
          currentForce=null;forcePlan=false;continue;
        }
        throw Error('MODEL_OUTPUT_TRUNCATED_EMPTY: 供应商报告 length，但没有可恢复的文本或完整工具调用。');
      }
    }catch(e){if(controller.signal.aborted)throw Error(signal?.aborted?'任务已停止':`模型调用超过${timeoutMs}毫秒，当前请求已中断并可从检查点恢复`);throw e;}
    finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
  }
}
AgentModelClient.normalizeProviderMessage=normalizeProviderMessage;AgentModelClient.outputLimit=outputLimit;
module.exports=AgentModelClient;
