const {request}=require('./http_client');
class PLMAdapter{
 constructor(c={}){this.mode=c.mode||process.env.DESIGNGATE_MODE||'mock';this.endpoint=c.endpoint||process.env.PLM_ENDPOINT;this.apiKey=c.apiKey||process.env.PLM_API_KEY||'';this.fetchImpl=c.fetchImpl;}
 async createReviewRecord(projectId,revision,findings,gateDecision,reviewId){
  if(this.mode!=='production')return {status:'MOCK_ONLY',mode:'mock'};
  try{if(!this.endpoint)throw Error('未配置 PLM 审查记录网关 URL');const r=await request(this.endpoint,{payload:{projectId,revision,findings,gateDecision,reviewId},apiKey:this.apiKey,idempotencyKey:reviewId,fetchImpl:this.fetchImpl});if(!r.review_id||r.status!=='CREATED')throw Error('缺少有效 PLM 审查回执');return {...r,mode:'production'};}catch(e){return {status:'WRITE_FAILED',mode:'production',error:e.message};}
 }
 async releaseDesignFreeze(){return {status:'NOT_IMPLEMENTED',reason:'本版只支持本地冻结；真实 PLM 放行需额外权限与协议联调'};}
}
module.exports=PLMAdapter;
