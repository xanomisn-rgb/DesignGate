const {request}=require('./http_client');
class InAgentAdapter{
 constructor(c={}){this.mode=c.mode||process.env.DESIGNGATE_MODE||'mock';this.endpoint=c.endpoint||process.env.INAGENT_ENDPOINT;this.apiKey=c.apiKey||process.env.INAGENT_API_KEY||'';this.fetchImpl=c.fetchImpl;}
 async searchEvidence(query,category='DFM'){
  if(this.mode!=='production')return {status:'MOCK_ONLY',mode:'mock',results:[],message:'未执行真实平台检索'};
  if(!this.endpoint)return {status:'CONNECTION_FAILED',mode:'production',error:'未配置已确认协议的检索网关 URL'};
  try{const body=await request(this.endpoint,{payload:{query,category},apiKey:this.apiKey,fetchImpl:this.fetchImpl});if(!Array.isArray(body.results))throw Error('响应必须包含 results 数组；请按真实平台协议实现网关');return {...body,status:'RETRIEVED',mode:'production'};}catch(e){return {status:'CONNECTION_FAILED',mode:'production',error:e.message};}
 }
 async parseDocument(){return {status:'NOT_IMPLEMENTED',mode:this.mode,reason:'本版使用本地解析器；尚未实现真实平台文档上传协议'};}
 async triggerWorkflow(){return {status:'NOT_IMPLEMENTED',mode:this.mode,reason:'需依据实际平台协议实现工作流接口'};}
}
module.exports=InAgentAdapter;
