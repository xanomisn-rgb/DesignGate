async function request(url,{method='POST',payload,apiKey='',timeoutMs=15000,idempotencyKey,fetchImpl=fetch}={}){
 const u=new URL(url);if(!['http:','https:'].includes(u.protocol))throw Error('仅支持 HTTP(S) 接口');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{const res=await fetchImpl(u,{method,signal:controller.signal,headers:{'Content-Type':'application/json',...(apiKey?{Authorization:'Bearer '+apiKey}:{}),...(idempotencyKey?{'Idempotency-Key':idempotencyKey}:{})},...(payload===undefined?{}:{body:JSON.stringify(payload)})});if(!res.ok)throw Error('HTTP '+res.status);const body=await res.json();if(body?.error||body?.exception||body?.success===false)throw Error(body.message||body.error||body.exception);return body;}finally{clearTimeout(timer);}
}
module.exports={request};
