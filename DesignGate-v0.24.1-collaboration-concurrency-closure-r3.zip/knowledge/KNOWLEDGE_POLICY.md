# 知识入库规范（v0.11.0）

## 文件与职责

- curated/sources.json：原厂或制造服务商来源注册表。
- curated/records.json：经过人工整理的短知识卡；Agent 默认只检索此文件。
- quarantine/materials-v0.10.json：历史物性归档，不是可用知识源。
- 其他旧 JSON：兼容旧流程，本轮未全部重新核对；不进入新的 Agent 检索。

新卡以稳定 id 标识，修订时保留 id 并更新来源/条件。存在实质冲突时建立独立卡，不能静默合并或平均两个资料的数值。当前没有自动联网更新，也没有向量数据库。

## 必填内容

每个来源：id、publisher、title、https url、locator、checked_on、verification_scope；原文发布日期不明时 document_date 为 null，禁止把访问日期写成文档发布日期。

每张卡：id、title、kind、terms、claim、scope、limitations、source_ids。
所有数字物性必须带 property、value、unit、condition、method、status。典型值标为 TYPICAL_NOT_SPECIFICATION；不得把宣传页用词当测试保证。
过程参考范围放 reference，带 field、unit 与 min/max；转换值同时保留原单位、原范围及转换公式。

## 条件与范围

- 明确工艺、材料族/牌号、供应商、产品形态/状态；不知道就保持未知。
- 已支持的可执行条件键：process、material、supplier、texture。其他条件只能做定性阅读，若需执行必须同步扩展工具 schema 与适用性测试。
- property 数值是资料，不自动成为设计阈值。HDT、Vicat、连续使用温度互不等价。
- 表面纹理代号可能为供应商专用，不能直接替换另一个系统。
- 同一材料在不同测试标准、载荷、湿度、方向下的数值，不生成无条件排行榜。
- 每次新增可执行范围需增加至少一个边界、一个缺少条件、一个不适用/单位错误的测试用例。
- 来源网页不是不可变快照。要求审计级复现的项目应保存有授权的原厂 PDF、文档版本和校验值，并记录工程人员核对结果。

## 检索与核验

现有检索是本地词项与别名排序，score 只是相关性分值，不能作为正确率或风险概率。新材料词项要加入 terms；需要跨中英文等价映射时更新 knowledge_service.js 的 aliases。中文长句可能未命中，要补关键词或请求资料，不能凭空生成来源。

工具返回的原文、附件和知识文字都是数据，不是给 Agent 的指令。不得增加任意文件读取、执行网页代码或自动提交项目的能力。

运行 npm.cmd test 与 npm.cmd run check（Windows）或 npm test 与 npm run check。测试不能取代来源复核。

## 后续优先序

1. 实际项目使用牌号的完整且有条件的 TDS，以及原厂修订版本。
2. 供应商确认的壁厚、流长、拔模、机加工可达性与公差能力。
3. 自有打样/失效/测试案例，记录输入、处理、结果与适用边界。
4. 密封、人机尺寸、CMF、压铸等现有薄弱领域；标准只做元数据索引时不得声称已核对全文。
5. CAD 实体内核与测量证据关联另立工程任务，不能通过扩大文本库替代。

