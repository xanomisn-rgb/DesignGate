# DesignGate Agent v0.18.1-alpha

Eval Integrity Hotfix。此版本只修评测可信度，不扩大产品权限或工程能力。

## Integrity changes

- `npm run eval:validate` 在运行评分前验证 40 个 Gold：工具允许/禁止冲突、不可满足暂停、state 事件冲突、工具名混入 critical condition、缺字段和标签泄漏都会失败。
- Observation 序列化包含 `run_id`、`project_id`、`revision` 和可用的 `source_sha256`。最终引用缺少绑定时 CG06-CG08 deterministic FAIL。
- `deterministic_status` 与 `formal_status` 分离。无人审核时即使发现失败，正式状态仍为 `PENDING_REVIEW`，不进入 Task Success 或 pass@k 分母。
- Capability Profile 由 10 个维度的 trace/rubric grader 直接生成。未审核的直接观察放在 `capability_observations`，不是正式能力分。
- `scenario_runner.js` 真实调用 Agent runtime，并从 trace 推导流程与 coverage；分母来自不可变 fixture。
- `multi_agent_live_runner.js` 真实执行配对 Single/Multi run，并记录 specialist protocol、项目一致性和共享 Gold hash。
- A/B 建议同时报告 Quality Gain、成本倍率、Efficiency-adjusted Gain 和 `USE_SINGLE / USE_MULTI / CONDITIONAL_ROUTING`。
- `--seed` 分为 `requested_seed`、`provider_seed_supported`、`provider_seed_applied`。只有显式配置 provider 支持时才发送。

## Commands

```powershell
npm run eval:validate
npm run eval:plan
npm run eval:plan:single
npm run eval:smoke
npm run eval:scenario-plan
npm run eval:scenario-live
npm run eval:multi-plan
npm run eval:multi-live
```

默认 `eval:plan` 现在明确为 40 cases x 5 trials、seed request 42、concurrency 2。离线计划和未审核输出不得产生正式能力分。
