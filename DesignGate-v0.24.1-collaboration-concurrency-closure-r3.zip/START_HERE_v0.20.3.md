# DesignGate Agent v0.20.3-alpha

本版主要修复长任务运行限制、模型输出截断安全、DFMEA 基线/复测绕过和残余风险接受闭环。

先运行：

```powershell
npm.cmd install
npm.cmd test
npm.cmd run check
npm.cmd start
```

有 CAD Python 依赖时：

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-cad.txt
npm.cmd run test:cad
npm.cmd run test:adapter
npm.cmd run test:handover
```

## 重要配置变化

默认不再有 180000 累计 token 硬上限；累计预算默认关闭。模型单次输出也不再固定为 1800/2500。详见 `LIMITS_v0.20.3.md`。

旧配置和旧 DFMEA 执行历史迁移见 `MIGRATION_v0.20.3.md`。

完整用户说明书：`docs/DesignGate-Agent-v0.20.3-使用说明书.docx`。当前 Agent 工具与运行说明：`docs/AGENT_GUIDE.md`。版本历史：`CHANGELOG.md`。

完整修复/测试证据见：

- `RELEASE_VALIDATION_v0.20.3.md`
- `FIX_TEST_MATRIX_v0.20.3.md`
- `UNVERIFIED_v0.20.3.md`

本地冻结不是生产放行；没有真实模型、真实项目和独立专家验收时，不得宣称生产级或专业工业设计能力已得到证明。
