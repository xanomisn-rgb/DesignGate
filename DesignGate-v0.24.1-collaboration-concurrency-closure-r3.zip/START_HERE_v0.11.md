# DesignGate Agent v0.11.0 — 知识增强版

本次在 v0.10.0 的目标驱动 Agent 上增强知识能力。保留现有前端和执行循环，没有新增 CAD 实体内核。

## 已交付

| 能力 | 本版实现 |
| --- | --- |
| 经整理知识 | 26 张卡：13 张材料卡、13 张工艺卡 |
| 来源 | 10 个原厂或制造服务商公开页面/文档，2026-09-06 核对所采字段 |
| 可执行参考 | 9 张：6 个材料族壁厚范围、1 个筋壁比上限、2 个供应商纹理拔模下限 |
| 检索 | 中英文术语映射、材料/工艺过滤、独立条目排序、明确无结果 |
| 工具 | search_knowledge 升级；新增 read_knowledge、check_knowledge_reference；共 13 个工具 |
| 旧资料处置 | 原 6 张材料记录的数值归档隔离；旧证据注册不再自动 verified |
| 数据纠正 | T65 XF 密度按来源换算为 1.13 g/cm³，另存测试条件 |
| 验证 | 95/95 测试；47 个 JS 文件和 JSON 语法检查通过 |

**计数不等于能力评分。** 26 张卡不是 26 条正式工程放行规则，13 张材料卡也不是 13 套完整 TDS：其中包括选材方向和特定打印粉末简介。目前只有 T65 XF 收录了选定的、附测试条件的数值物性。

## 启动

在解压后的 DesignGate 目录打开 PowerShell：

```powershell
node --version
python --version
python -m pip install -r requirements.txt
npm.cmd install
npm.cmd test
npm.cmd run check
npm.cmd start
```

Windows 的 npm.cmd 可避开 npm.ps1 的脚本执行策略问题，不需要修改系统策略。
如果 python --version 没有显示 Python 版本，需要先安装 Python 并加入 PATH，然后重新打开 PowerShell。若此前已装好依赖，无需重复安装。

在应用设置中配置支持原生工具调用的模型与 API Key，然后进入“任务 Agent”。资料检索和核对在本机执行；完整自主循环需要模型连接。提交给模型的上下文仍遵循现有配置与资料传输提示。

## 可直接输入的任务

1. “假设由 Protolabs 注塑 ABS 外壳，名义壁厚 2 mm。请查资料、读取适用条件并核对参考范围，说明尚需确认什么。不要修改项目。”
2. “比较 6061 和 6063 挤压型材用于桌面灯支架的选材方向，重点关注结构、加工与阳极氧化外观。没有来源支持的强度数值不要补写。”
3. “查 Bayblend T65 XF 的密度与热变形温度，列出测试条件，解释为什么不能把 HDT 当连续使用温度。”
4. “评估 PM-T2 纹理表面的 3° 拔模角；先确认这个纹理编码属于哪家供应商，再核对对应建议。”

第 1 个示例应得到 WITHIN_REFERENCE，含 ABS、注塑、Protolabs 与 mm 条件；这不等于工程 PASS。第 4 个示例在 Protolabs 条件下落在参考下限之外。实际模型可能需要补充提问，代码不保证每次生成完全相同的回答。

## 数值核对的边界

- WITHIN_REFERENCE：给定输入落在该供应商建议范围内。
- OUTSIDE_REFERENCE：超出该建议范围，需工程讨论，不等于零件必然失效。
- NEED_CONTEXT：缺少材料、工艺、供应商或纹理条件。
- NOT_APPLICABLE：输入条件与知识卡不匹配。
- UNIT_MISMATCH：单位不同，工具不做隐式换算。
- NOT_EXECUTABLE：卡片仅有定性资料或物性，不能拿来做范围判定。

材料族不能替代牌号；牌号后缀、金属状态、产品形态、测试载荷、样条厚度和打印方向都可能影响适用性。知识核对不改变项目 Gate、验证证据或冻结状态。

## 本次纠错与兼容性

旧 materials.json 的原始数值保存在 knowledge/quarantine/materials-v0.10.json，带隔离标记，不进入新检索。兼容材料索引继续保留名称匹配接口，但不再返回脱离条件的数值。已有项目和历史报告不会被回溯重写；历史记录不能因升级而自动变成经复核事实。

旧 EvidenceRegistry 中的内置规则、材料、标准索引及密封指南不再自动标为 verified=true。原先依赖该标记的外部扩展需要改用自己的核验流程。新知识通过专用工具读取，不伪装成项目实测证据。

原确定性规则引擎的大部分阈值仍是旧版本本地筛查策略。本版没有批量改写正式 Gate 规则；Agent 的 screen_design 返回明确的旧规则边界。CNC 小内角提示已去掉“无法加工”的绝对结论。压铸、纹理深度换算、密封、人体工学及标准正文仍待逐项复核，不应把旧阈值当通用行业标准。

## 如何继续扩大知识库

参见 knowledge/KNOWLEDGE_POLICY.md。优先增加用户实际项目中的材料牌号、供应商工艺能力与可追溯试验记录，而不是堆积通用网页摘要。

## 验证范围

新增 12 项测试包括：来源字段、10 个预设中文检索问题、无结果、筛选隔离、牌号变体、密度换算与 HDT 条件、旧数值隔离、范围边界、单位/上下文拒绝、纹理适用性、工具参数防越界，以及 Agent 到实际知识工具的完整循环。

测试模型为脚本替身，不是线上模型能力评测；10 个预设问题不能代表开放问题检索准确率。尚未验证真实模型 API 调用、Windows Electron 安装打包和桌面运行。没有新增 STEP BRep、装配干涉、结构/热仿真或合规认证能力。

## 原始来源清单

以下均为资料来源，不是对当前项目的认证背书。核对日期只表示本次读取时间，不表示未来持续有效；没有抓取受限全文，也没有重新发布完整原厂文档。

- **COV-T65 · Covestro**：[Bayblend T65 XF — Typical Values](https://solutions.covestro.com/zh/products/bayblend/bayblend-t65-xf_000000000006563805)；定位：Typical Values / Mechanical / Thermal / Other properties。
- **PL-WALL · Protolabs**：[Improving Part Design with Uniform Wall Thickness](https://www.protolabs.com/resources/design-tips/improving-part-design-with-uniform-wall-thickness/)；定位：Recommended wall thickness table。
- **PL-RIB · Protolabs**：[Design Stronger Molded Parts](https://www.protolabs.com/resources/design-tips/design-stronger-molded-parts/)；定位：Reinforce Bosses and Walls with Gussets。
- **PL-DRAFT · Protolabs**：[Improving Part Moldability with Draft](https://www.protolabs.com/resources/design-tips/improving-part-moldability-with-draft/)；定位：Basic Guidelines。
- **PL-CNC · Protolabs**：[Mastering Complex Features on Machined Parts](https://www.protolabs.com/resources/design-tips/mastering-complex-features-on-machined-parts/)；定位：5. Radii: Watch Your Corners。
- **PL-SHEET · Protolabs**：[The Basics of Bend Radii in Sheet Metal](https://www.protolabs.com/resources/design-tips/the-basics-of-bend-radii-in-sheet-metal/)；定位：Bend radii / Relief cuts。
- **HY-AL · Hydro**：[Aluminum Extrusion Alloys](https://www.hydro.com/us/us/aluminum/products/extruded-profiles/north-america-resources/extruded-aluminum-products/aluminum-extrusion-alloys/)；定位：1060 / 3003 / 6061 / 6063 / 6262 Alloy。
- **BASF-PBT · BASF**：[Ultradur B4520 Processing Data Sheet](https://download.basf.com/p1/8a8082587fd4b608017fd665c21c2622/en/ULTRADUR%25C2%25AE_B4520)；定位：Processing data, February 2026。
- **CEL-POM · Celanese**：[Low-emission Hostaform POM XAP3](https://explore.celanese.com/202506_POM_LowEmissionXAP3_LP-Registration.html)；定位：Public product introduction; gated content not accessed。
- **FL-SLS · Formlabs**：[Fuse Series SLS Design Guide](https://formlabs.com/white-papers/fuse-series-sls-design-guide/)；定位：Material-Specific Design Considerations。

