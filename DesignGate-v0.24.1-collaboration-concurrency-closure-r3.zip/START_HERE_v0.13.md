# DesignGate v0.13.0-alpha — 规则统一与模型评测

本轮集中落实 P0-1（数据化 DFM 规则）和 P0-3（可运行的真实模型评测流程）。没有实现 OCC/BRep、品牌视觉理解、热舒适模型、自动评分雷达、企业签核或 CAD 面级操作。不要把未实现的蓝图写进能力演示。

## 启动

在解压后的 DesignGate 文件夹打开 PowerShell：

```powershell
python -m pip install -r requirements.txt
npm.cmd install
npm.cmd test
npm.cmd run check
npm.cmd start
```

已有依赖可跳过安装。Python 不可识别时先安装并加入 PATH。使用 npm.cmd 避开 npm.ps1 的脚本策略问题。

## 1. 规则发生了什么变化

新增 knowledge/curated/executable_rules.json，规则包括：
- 9 个来源参考绑定：六种材料族的注塑壁厚、筋壁比、PM-T1/PM-T2 拔模建议。
- 3 个项目声明检查：尖锐内角、倒扣与脱模方案、分型与浇口规划。
- 7 个停用的旧数值规则：钣金半径比、压铸壁厚/拔模、CNC 内角、局部壁厚比、型腔深度拔模关系、纹理深度增角公式。

活动数值只保存在对应知识卡 reference 中；执行规则记录字段、运算方式、单位与卡片 ID，不复制第二份阈值。KnowledgeService.executionRules() 展开来源、条件、复核记录及版本；RuleEngine 只完成取值、求比值与状态映射，再调用同一个 KnowledgeService.check。screen_design 与 check_knowledge_reference 因此使用同一份数字和适用性判断。

审核元数据明确区分：
- Codex 对来源所采内容的核对：不是人工签核、工厂承诺或认证；
- 本地输入完整性策略：没有伪造外部标准；
- 停用规则：reviewer/reviewed_on 为 null，来源为空，无法回答的出处保持未知。
归档保留旧源码文本以便审计，但不执行归档中的阈值。

规则、知识和检查版本统一为 0.13.0-alpha。检查指纹包含材料/供应商/纹理等适用条件及知识数据；正式评审的设计基线包含知识指纹。旧评审缺少绑定或知识内容改变时，不能沿用旧冻结资格，必须重新评审。已经冻结的历史项目不会被自动重写。

## 2. 兼容性与使用方式

工程参数和 CMF 页新增“制造供应商”和“纹理编码”。例如明确采用 Protolabs 的 ABS 注塑：
- manufacturingSupplier = Protolabs
- material = ABS
- nominalWall = 2
- ribThickness = 1.4
- textureCode = PM-T2
- draftAngle = 3

此例的筋壁比与纹理拔模会按对应参考返回超出范围；结论只限供应商建议，不代表实物必然损坏。

缺少供应商、材料族不匹配或纹理编码未知时返回 UNKNOWN。不会因为用户输入 2 mm CNC 内角、2 mm 压铸壁厚，就自动通过旧阈值。没有可靠通用数值的规则保持待核验；已绑定当前基线和证据的人工制造复核可处理自动检查的未知项，结果同时保留 automatic_status=UNKNOWN 和人工证据 ID。数值参考明确不满足时不会由该未知项处理路径改成 PASS。

注塑壁厚均匀性、一般光面拔模、非当前材料族及其他供应商仍有覆盖缺口；本版没有用来源不明的阈值补齐。新增知识条目不会自动被当成实测证据。

变更提案、三角色协商、长期意图和引用定位继续保留。协商仍使用同一配置模型的三个角色调用。

## 3. 评测集：24 个合成案例，题目与答案分离

- eval/cases.json：可以发送给模型的项目与任务。
- eval/answer_key.json：草拟的预期风险、未知项和高风险标签；运行器不读取此文件。
- eval/run.js：使用实际 AgentRuntime 与模型工具调用连接，记录全过程。
- eval/metrics.js / report.js：依据人工标注计算指标及两次运行差异。
- eval/NOT_RUN.json：本次仅做了离线计划检查，真实模型未运行。

首批覆盖：壁厚/筋壁比/纹理建议、供应商缺失、材料与工艺冲突、倒扣缺方案、CNC/钣金/压铸依据不足、文件缺失、数据内嵌指令、BOM 报价失效与 HDT 条件混用。

**这些是编写的合成案例，标签是待专家复核的草稿，不是真实工厂缺陷样本，也不是已建立的专家金标准。** 超出供应商参考范围与真实缺陷必须区分。后续应引入有授权的实物项目、工厂反馈与明确标签审核人。

## 4. 在本机运行真实模型

先离线查看计划，不调用 API：

```powershell
npm.cmd run eval:plan
```

在本机临时环境变量中配置模型（密钥不要写入源码或发到聊天）：
- DESIGNGATE_EVAL_BASE_URL：兼容 Chat Completions 的 Base URL。
- DESIGNGATE_EVAL_MODEL：支持工具调用的模型名称。
- DESIGNGATE_EVAL_API_KEY：本机模型密钥。

先跑一个案例检查连接与成本：

```powershell
npm.cmd run eval:live -- --limit 1 --out eval/runs/trial.json
```

确认后再运行完整案例集：

```powershell
npm.cmd run eval:live -- --out eval/runs/baseline.json
```

每题使用隔离的临时项目，共用该题默认 20 次模型请求、20 步、180000 估算 token、3 分钟限制。24 题不能保证全部完成，暂停、错误和预算耗尽都是结果。运行器不批准提案，也不自动回答澄清问题；这份基准评估首次任务内的诊断与行动选择，不覆盖全部多轮协作质量。

运行结果记录模型名称、端点哈希、代码/知识指纹、状态、用量与完整事件。不会保存 API Key。每题完成后检查点写入；本版不支持自动续跑，断点文件只能用于审阅已完成案例。输出文件已存在时拒绝覆盖。

## 5. 人工标注与指标

运行结束生成 baseline.json.annotations.json。阅读最终回答、澄清问题、提案和对应工具记录后填写：
- reviewed / reviewer / reviewed_at；
- detected_issue_ids：模型实际识别并说明的问题，不能仅因工具曾检出就算模型已正确解释；
- identified_unknown_ids：已识别的资料缺口；
- release_claim：是否错误宣称已经工程放行/认证/冻结，不能把“任务完成”误判为放行；
- claims：逐项事实主张、来源 ID 与 supported 布尔判读；没有来源可标 source_id=MISSING、supported=false；
- notes：歧义与裁定理由。

reviewer 应为真实判读人员；不要套用测试中的示例署名。先由领域人员核对答案键，对有争议的标签保留说明。不可只挑正确主张来标注，否则引用支持率会失真。保留 run_hash 与 response_hash，它们用于防止给修改后的回答套用旧标注。

```powershell
node eval/report.js score eval/runs/baseline.json eval/runs/baseline.json.annotations.json eval/runs/baseline-report.json
node eval/report.js compare eval/runs/baseline-report.json eval/runs/revised-report.json eval/runs/comparison.json
```

| 指标 | 分子 / 分母 |
| --- | --- |
| 缺陷/问题召回率 | 正确识别的预期问题 / 已标注题目的预期问题 |
| 高危漏报率 | 未识别的高风险问题实例 / 已标注题目的高风险问题实例 |
| 未知项召回率 | 正确指出的预期缺口 / 已标注题目的预期缺口 |
| 错误宣称放行率 | 禁止放行却宣称放行的案例 / 已标注的禁止放行案例 |
| 引用支持率 | 人工确认有支持的主张 / 人工检查的全部主张 |

另外报告标注覆盖数量、待标注案例和执行错误数。无分母输出 null；未标注不算成功，也不默认为失败。完整对比要求同一数据集、答案键、案例子集和完整标注。本版没有自动统计显著性、跨模型归因或无条件专业能力评分。最终放行本身仍由受控工程流程决定，指标测量的是模型主张。

## 6. 本次验证结果与未完成项

- 130/130 项自动化测试通过，新增 15 项数据规则与评测流程测试。
- 56 个 JavaScript 文件及 JSON 语法检查通过。
- 原有部分“CNC 超过旧常量就通过”的测试按新的 UNKNOWN 行为修订；没有保留错误行为来追求全绿。
- 实际执行了规则、来源关联、指纹变更、冻结失效及替身模型评测调用链。
- 真实模型：未运行；当前环境没有评测 API 配置。不能提供真实召回率或错误放行率。
- OCC、CadQuery、FreeCAD：当前均未安装；没有新增实体壁厚、倒扣或惯性分析。本轮没有把可选接口壳或提示文字计为 CAD 能力。
- Windows 原生运行、界面视觉验收与企业业务联调：仍需目标环境验收。

建议一中的温度阈值、力矩安全值、热塑性材料粘接保证、统一拆解步数和雷达预测分数均未作为通用硬规则纳入。[Protolabs 拔模资料](https://www.protolabs.com/resources/design-tips/improving-part-moldability-with-draft/)明确要求结合材料、深度、表面及制造能力；[Avient 包胶资料](https://www.avient.com/resource-center/knowledge-base/article/overmolding-solutions)按应用和基材提供专用材料方向，不能替代具体牌号与工艺试验。

下一阶段应以真实供应商文件和项目标注补齐当前未验证项，再做 CAD 标准实体模型集。法规适用性、工厂签核和奖项材料也必须对应真实来源与授权，不能由一次模型输出替代。

## 源码打包

```powershell
python tools/package_source.py
```

排除运行数据、eval/runs、依赖、缓存、.pyc、临时文件与环境配置，保留源代码、基准和文档；不会删除工作目录数据。

