# DesignGate Agent v0.18.0-alpha

Capability & Scenario Validation Release。这个版本的目标是测量 Agent 能力和失败方式，而不是扩大工程放行权限。

## 启动与回归

```powershell
npm.cmd install
npm.cmd run check
npm.cmd test
npm.cmd run test:cad
npm.cmd run test:adapter
npm.cmd run test:handover
```

## Eval

`npm run eval:plan` 只生成离线执行计划；`npm run eval:live` 才会发出真实模型请求。runner 支持 `--case E17`、`--trials 5`、`--seed 42`、`--concurrency 2` 与 `--out <file>`。每个 trial 使用独立项目目录、状态管理器、runtime、run ID、trace、预算与最终快照。

40 个 atomic case 位于 `eval/cases.json`，行为 gold 单独位于 `eval/answer_key.json`，不会进入模型上下文。`eval/scenarios` 包含 4 个流程型合成工业设计项目。`eval/multi_agent_cases.json` 包含 10 个 Single vs Multi 冲突任务；两组必须共享相同 gold。

未经专家审核的 gold 和未经人工审核的输出不能成为正式 PASS。无真实模型配置时报告必须显示 `NOT_RUN` 和 `UNVERIFIED`。

## 当前 CAD 边界

已确认：STEP 基础 BRep 解析，以及带项目/Revision/源 SHA/面编号绑定的有界曲面法线、导数、穿实体弦长和方向遮挡采样。

未确认或未实现：全局最小壁厚、全局无倒扣证明、装配干涉、CAE、模具批准。允许使用 “Sampled Draft Screening”“Sampled Thickness Candidate”“Undercut Candidate”“Bounded Surface Samples”；不得把它们改写为全局确定性。

## 外部系统

inAgent 和 LMS 未接真实合同则为 `NOT_IMPLEMENTED`；PLM 保持 `MOCK_ONLY`；没有真实权限的 `releaseDesignFreeze` 为 `NOT_IMPLEMENTED`。mock 响应不能作为生产成功回执。
