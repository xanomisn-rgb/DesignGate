# DesignGate Agent v0.20.0-alpha

## This upgrade

v0.20 changes the professional layer from prose-first assistance into bounded, structured capability results:

- `backend/capability_contract.js` is the common result contract.
- `backend/ergonomics_service.js` performs only a declared static wrist-moment screen.
- `backend/cmf_service.js` uses an explicit compatibility matrix and fails closed to test-required for unmatched combinations.
- `backend/fmea_service.js` models DFMEA failure modes and verification coverage.
- `backend/evidence_graph.js` tracks evidence, requirements, decisions and revisions.

Pipeline outputs now include `professional_capabilities` and `evidence_graph`. The desktop assessment report renders each capability's method and current status.

## Operating limits

`EVALUATED` describes only the stated method and inputs. It does not indicate production approval. External CAE, CFD, mold-flow, RF and certification results remain external-solver or expert-review work until an actual adapter and evidence binding exist.

Read `RELEASE_VALIDATION_v0.20.md` before representing this build as validated. The true live-model A/B benchmark and independent expert review have not been run.

## Local verification

```powershell
npm test
npm run check
```

The tests cover the contract and foundation behaviour. They do not replace prototype measurement, supplier qualification, solver output or a human design review.
