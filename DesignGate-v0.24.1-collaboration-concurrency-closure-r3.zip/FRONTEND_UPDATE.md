# DesignGate 0.19 · 参考图前端版

本版本基于用户提供的 v0.19.0-alpha，仅更新前端展示层。使用图一的 DG Logo，按其余参考图统一深色顶栏与侧栏、浅色内容面板、蓝色选中态、信息卡片与工程工作区。

## 本次更新

- 项目总览：指标卡片、浅色三维视口、问题列表、动态与三阶段 Gate。
- 需求资料：左侧需求目录、中间可编辑需求、右侧判据填写完成度。保留 BOM 与成本表单。
- 工程评审：深色三维视口、可选择的问题列表及详情；原有全部工程参数、评审标签与操作继续保留。
- 设置与管理：配置状态、原有模型连接与外部服务表单，未提供的配额统计保持空状态。
- 全部七个导航页面沿用统一主题，适配桌面和窄屏，保留 Agent 协作、文件选择及审批功能。

**项目总览和工程评审均未嵌入任何参考图里的示例产品。没有模型时显示空状态和网格，导入真实 STL 或项目 STEP 显示网格后才展示模型。**

本次新增的图片素材只有 Logo。浏览器预览中的文字项目是明确标注的合成资料，未附示例 CAD、伪造缺陷或工程结论。桌面端不加载该预览项目。

## 运行

在本文件所在目录运行，沿用原项目 Node.js 20+ 与 Python 依赖：

```powershell
npm install
python -m pip install -r requirements.txt
npm start
```

STEP/BRep 的可选依赖和完整使用说明见 `START_HERE_v0.19.md`。Windows 若自动寻找 Python 失败，可在启动前设置 `$env:PYTHON_BIN` 为已安装 Python 的绝对路径。

仅查看前端布局：

```powershell
npm run dev
```

打开 http://localhost:4173 。这是只读预览；本地 STL 可以查看，但保存项目、模型服务、工程评审及文件归档需要桌面端。不能通过双击 HTML 启动后端。

## 文件范围

- 新增 `src/reference-ui.js`、`src/reference-ui.css` 与 `src/assets/designgate-logo.png`。
- `src/index.html` 加载新主题。
- `src/viewport.mjs` 仅更新视口配色和模型空状态展示标识。
- `src/preview.js` 仅更新隔离的浏览器预览文字资料。
- 后端、IPC、业务表单处理、工程规则和数据结构不变；原始 ZIP 未修改。

## 验证与边界

- 原有 `npm test`：227 / 227 通过（使用明确指定的 Python 可执行文件）。
- 补充运行 `node --test tests/professional_v019.test.js`：10 / 10 通过。
- `npm run check`：JavaScript/JSON 及评测数据检查通过。
- Edge 无头浏览器：七个页面导航、需求增删、需求目录聚焦、BOM 添加、草稿保持、新建弹窗开关、Logo 资源、STL 上传、线框切换、视角重置和跨页面模型保持通过。
- 四个主要页面在 1672、1200、1024、768、390 px 下，共 20 组检查无页面级横向溢出；无页面运行时错误。
- 本次没有连接真实模型供应商，也没有执行完整 Electron 安装包启动或实际生产项目验收。已有工程能力边界仍以原版文档为准。
- 与源 ZIP 的 234 个原有文件逐一比较，只有 `src/index.html`、`src/preview.js`、`src/viewport.mjs` 发生变更；其他原有文件保持一致。

参考图中的团队账号、五阶段 Gate、云端用量和额外 CAD 分析工具不是本项目现有能力，本版未伪造这些功能。
