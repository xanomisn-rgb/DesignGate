# DesignGate v0.19 Validation

## 修复前真实运行诊断

来源：`eval/runs/deepseek-v4-pro-v0.18.1-full-200-valid.json`。

- FAILED + BUDGET_EXCEEDED：54/200（27%）。
- 严格工具失败：188；后续恢复：80；最终未恢复：108。
- 高频失败工具：`show_reference` 49、`read_knowledge` 37、`finish_task` 36、`read_selected_file` 25。
- E25、E33–E35 的主要压力来自错误参数后的重复、强制重规划及协商模型请求预算。
- E28–E30、E39 的主要问题是模型猜测 CAD 面号、文件 ID 或旧 source hash。

重算报告：`eval/reports/deepseek-v4-pro-v0.18.1-full-200-v019-regraded.json`。该报告是旧运行的诊断，不是修复后成绩。

## v0.19 本地验证

- `npm test`: PASS（227/227）。
- `npm run check`: PASS（95 个 JavaScript/JSON 文件；Gold 40/40）。
- `npm run test:cad`: BLOCKED；当前默认 Python 缺少可选 `OCP`，命令真实失败于 `ModuleNotFoundError`。Node CAD 边界回归已包含在 227/227 中。
- `npm run test:adapter`: PASS（5/5）。
- `npm run test:handover`: PASS（3/3）。
- 合成产品生命周期：PASS；覆盖提案拒绝、补证暂停、运行时重建与恢复、修订提案、测试批准、复审、非法冻结阻断、工程记录准备，以及新 Revision 对旧 CAD/验证的作废。该离线长链测试使用显式有界 `maxTokens=500000`，不代表真实模型 token 用量或默认预算成绩。

## 未运行与阻塞

- 真实模型 smoke / 定向失败类别复测 / 未见 holdout：NOT_RUN。
- v0.19 FAILED + BUDGET_EXCEEDED 是否低于 5%：UNVERIFIED。
- 逐 trial 人工审核：0；Gold 专家审核：0；任务质量及工业设计正确性保持 UNVERIFIED。
- Electron 桌面端人工操作：NOT_RUN；组件与 IPC 自动化测试不能替代桌面人工验收。
- inAgent、PLM、LMS 真实联调：BLOCKED（缺少官方协议、凭据、权限与真实业务回执）。适配器继续 fail-closed。
