# DesignGate Agent v0.18.0-alpha Release Validation

## Version

Capability & Scenario Validation Release.

## Architecture changes

- `eval/run.js` is a multi-trial runner with case selection, seed metadata, bounded concurrency, isolated state/runtime/run IDs, incremental checkpoints, observable traces, project hashes, token usage and active time.
- `eval/code_grader.js` performs deterministic tool, evidence, state, approval, quote, Gate, CAD, external-write, pause and anti-spoof checks.
- `eval/metrics.js` reports issue/unknown quality, behavior, efficiency and per-case stability. Zero denominators are `null`.
- `eval/failure_taxonomy.js` maps deterministic failures to F01-F17 and marks unresolved cause analysis for manual review.
- `finish_task` supports structured claims, unknowns and a restricted decision enum while preserving legacy calls. Engineering release remains false.

## Dataset and scenarios

- Atomic cases: 40 total, preserving E01-E24 and adding E25-E40.
- Coverage counts: Requirement 6, DFM/CAD 7, Material/CMF 5, BOM/Cost 4, Quality 12, Trade-off 5, Revision/Gate 10, Security/Unknown 12.
- Special coverage: 12 long-chain, 8 stateful, 5 multidisciplinary, 8 trap, 3 prompt-injection and 6 CAD-boundary cases.
- Scenarios: 4 projects, each with 7 required files and a nine-milestone workflow.
- A/B: 10 cross-discipline Single vs Multi cases with shared-gold and case-set guards.

All datasets are `AUTHORED_SYNTHETIC`. Gold labels remain `AUTHOR_DRAFT_REQUIRES_EXPERT_REVIEW`.

## Tests actually executed

| Command | Result |
| --- | --- |
| `npm test` | 183/183 PASS (162 retained + 21 new Eval tests) |
| `npm run check` | PASS, 85 JavaScript/JSON files |
| `npm run test:cad` | PASS, 2 + 8 + 1 tests |
| `npm run test:adapter` | PASS, 5/5 |
| `npm run test:handover` | PASS, 3/3 |

Failed tests: none after the locked optional CAD dependency was installed. The initial CAD command did not reach assertions because `OCP` was absent; after installing `cadquery-ocp==8.0.1.0.0` from `requirements-cad.txt`, all CAD tests passed.

## Eval result

- Offline plan: `NOT_RUN`, 40 cases x 5 planned trials = 200.
- Live model: `NOT_RUN`; `DESIGNGATE_EVAL_API_KEY`, `DESIGNGATE_EVAL_BASE_URL` and `DESIGNGATE_EVAL_MODEL` were not configured.
- Capability status: `UNVERIFIED`. No capability score, pass rate, or Multi-Agent gain was fabricated.

## CONFIRMED

- Existing project isolation, proposal approval, stale revision, observation validation, budget, role boundary, Gate safety and evidence binding regressions still pass.
- STEP BRep basic parsing and bounded derivative, normal, chord and visibility sampling tests pass.
- Multi-trial isolation, answer-key context exclusion, code grader, metrics formulas, failure taxonomy, scenario structure and A/B comparison guards pass automated tests.

## UNVERIFIED

- Real-model planning, routing, retrieval, trade-off, unknown handling and stability.
- Human expert validity of authored gold labels and open-ended scenario judgments.
- Measurable Multi-Agent gain versus its token and latency cost.
- Real industrial project performance and Windows Electron/WebGL acceptance.

## NOT_IMPLEMENTED

- Global minimum wall-thickness solver, global no-undercut proof, assembly interference, CAE and mold approval.
- Production inAgent/LMS/PLM integration and enterprise-authorized external release.
- Statistical significance testing for A/B results.

## Known limitations and deferred work

The benchmark is synthetic and may saturate or encode author bias. Human annotations are required for open-ended judgments. Dynamic specialist routing remains deferred; v0.18 first measures the existing fixed roles. External connectors remain fail-closed.

## Recommended v0.19 scope

Run reviewed multi-trial baselines on at least one declared model, complete expert label review, add anonymized real-project-derived scenarios with permissions, calibrate false positives, and implement evidence-based dynamic specialist routing only if the v0.18 A/B data shows worthwhile gain.
