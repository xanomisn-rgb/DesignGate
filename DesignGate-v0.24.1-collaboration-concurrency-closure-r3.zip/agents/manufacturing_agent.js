class ManufacturingAgent {
  constructor(ruleEngine) {
    this.agent_id = "A03";
    this.name = "Manufacturing & DFM Agent";
    this.ruleEngine = ruleEngine;
  }

  evaluate(projectState) {
    const design = projectState.design || {};
    return this.ruleEngine.evaluateGeometry(design);
  }
}

module.exports = ManufacturingAgent;
