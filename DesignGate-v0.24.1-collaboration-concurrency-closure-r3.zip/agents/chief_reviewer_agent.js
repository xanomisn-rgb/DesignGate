class ChiefReviewerAgent {
  constructor() {
    this.agent_id = "A06";
    this.name = "Chief Reviewer & Gate Arbiter";
  }

  synthesize(allFindings = [], gateResult = {}, projectState = {}) {
    let tradeOffRationale = "";

    const criticalReqs = allFindings.filter(f => f.category === "Requirements" && f.severity === "CRITICAL");
    const highDfms = allFindings.filter(f => f.category === "DFM" && (f.severity === "CRITICAL" || f.severity === "HIGH"));
    const highQualities = allFindings.filter(f => f.category === "Quality/FMEA" && (f.severity === "CRITICAL" || f.severity === "HIGH"));

    if (criticalReqs.length > 0) {
      tradeOffRationale += `【需求基线冲突仲裁】：存在 ${criticalReqs.length} 项与立项 Brief 违背的致命冲突：` +
        criticalReqs.map(i => `[${i.issue_id}] ${i.finding} (整改建议: ${i.recommendation})`).join("；") + "。\n";
    }

    if (highDfms.length > 0) {
      tradeOffRationale += `【制造可行性裁决】：识别到 ${highDfms.length} 项高风险开模/成型工程缺陷：` +
        highDfms.map(i => `[${i.issue_id}] ${i.finding} (整改建议: ${i.recommendation})`).join("；") + "。\n";
    }

    if (highQualities.length > 0) {
      tradeOffRationale += `【质量合规与失效链对策】：` +
        highQualities.map(i => `[${i.issue_id}] ${i.finding}`).join("；") + "。\n";
    }

    if (!tradeOffRationale) {
      tradeOffRationale = "方案各专业工程指标平衡良好，未检出阻断性或跨专业不可调和之工程冲突。";
    }

    const openActionItems = allFindings
      .filter(f => f.status === "OPEN" || f.status === "NEED_HUMAN_REVIEW")
      .map(f => `[${f.issue_id}] (${f.severity}) ${f.recommendation}`);

    return {
      reviewer: this.name,
      gate_decision: gateResult.decision,
      trade_off_rationale: tradeOffRationale,
      action_items: openActionItems
    };
  }
}

module.exports = ChiefReviewerAgent;
