const C=require('../backend/contracts');
class ProductDesignAgent{
 evaluate(p){const d=p.design||{},prod=p.product||{};if(!/手持|handheld/i.test(prod.category||''))return [];
 const findings=[],m=String(d.gripSection||'').match(/^(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)(?:\s*mm)?$/i);
 if(!m)findings.push(C.gap('DG-ERG-GRIP-UNKNOWN','局部握持截面（宽×厚，mm）未知；已保留整机外包络，但它不能替代局部握持截面。',{agent_id:'A02',category:'Ergonomics'}));
 else {const width=Number(m[1]),thickness=Number(m[2]),a=width/2,b=thickness/2;if(!a||!b)findings.push(C.gap('DG-ERG-GRIP-UNKNOWN','局部握持截面尺寸必须大于0。',{agent_id:'A02',category:'Ergonomics'}));else {const h=(a-b)**2/(a+b)**2,circ=Math.PI*(a+b)*(1+3*h/(10+Math.sqrt(4-3*h)));findings.push(C.gap('DG-ERG-GRIP-ESTIMATE',`输入：局部握持截面宽 ${width} mm、厚 ${thickness} mm。假设截面为椭圆，按 Ramanujan 近似式 π(a+b)[1+3h/(10+√(4-3h))] 估算周长 ${circ.toFixed(1)} mm；这只是几何估算，不是舒适性合格结论。`,{agent_id:'A02',category:'Ergonomics',record_type:'HEURISTIC',recommendation:'用当前版本样机执行覆盖目标人群的试握，记录姿态、操作力、持续时间、主观量表及失败样本。'}));}}
 const required=[['weightG','重量'],['cogCoordinatesMm','重心坐标'],['cogReference','重心参考坐标系'],['gripPosture','姿态'],['operationForceN','操作力'],['operationDurationS','时长'],['targetPopulation','目标人群'],['populationSource','来源']],missing=required.filter(([key])=>d[key]===undefined||d[key]===null||d[key]==='').map(([,label])=>label);
 if(missing.length)findings.push(C.gap('DG-ERG-TASK-UNKNOWN',`人机任务依据不完整，缺少：${missing.join('、')}。`,{agent_id:'A02',category:'Ergonomics',recommendation:'明确目标人群及来源，定义握持姿态、力和持续时间；用当前版本样机开展试握并记录原始结果、偏差和异常。'}));
 const serviceFields=[['fastenerType','紧固件'],['serviceTool','工具'],['servicePart','易损/维修件'],['serviceAccess','可达性'],['disassemblySteps','拆解步骤'],['irreversibleJoints','不可逆连接']],serviceMissing=serviceFields.filter(([key])=>!d[key]).map(([,label])=>label);
 if(serviceMissing.length)findings.push(C.gap('DG-SERVICE-INFO-UNKNOWN',`装配与维修输入不足，缺少：${serviceMissing.join('、')}；这是一项信息缺口，不代表已经发现结构缺陷。`,{agent_id:'A02',category:'Assembly & Service',recommendation:'按实际 BOM 和当前版本样机记录连接件、所需工具、维修件可达路径、逐步拆解过程以及不可逆连接（没有时明确记录“无”）。'}));
 if(d.assemblyServiceConflicts)findings.push({issue_id:'DG-SERVICE-CONFLICT',agent_id:'A02',category:'Assembly & Service',finding:`用户记录的装配/维修冲突：${d.assemblyServiceConflicts}`,severity:'HIGH',record_type:'USER_DECLARED_CONFLICT',evidence_refs:['design.assemblyServiceConflicts'],impact:'当前连接或装配方案可能阻止无损维修。',recommendation:'比较可逆连接方案，并在当前版本样机上验证拆卸、复装及易损件更换。',confidence:1,status:'OPEN'});
 return findings;
 }
 generateConceptArtifacts(p={}){return {status:'DESIGN_DRAFT',concept_statement:`围绕 ${p.targetUsers||'待确认用户'} 的具体任务验证需求。`,form_dna:['记录使用动作与接触面','比较形态、结构与制造取舍','通过草模或样机验证关键假设'],ai_commercial_render_prompt:`Industrial design study of ${p.name||'the proposed product'}, show user interaction and assembly. Concept visualization only; no engineering verification implied.`};}
}
module.exports=ProductDesignAgent;
