const C=require('../backend/contracts');
class CMFAgent{
 constructor(v){this.verifier=v;this.agent_id='A04';}
 evaluate(p){const f=[],d=p.design||{},gap=(id,text,recommendation)=>f.push(C.gap(id,text,{agent_id:this.agent_id,category:'CMF',recommendation}));
  if(!d.material&&!d.materialFamily)gap('DG-MAT-001','未指定材料家族；不能判断材料与表面工艺的适用范围。','指定材料家族、具体牌号及供货状态。');
  if(!d.materialGrade)gap('DG-CMF-MATERIAL-GRADE-UNKNOWN','具体材料牌号未知；不得从 ABS、PC 等材料简称推导相容性或量产结论。','记录供应商、完整牌号和供货状态，并取得对应 TDS/加工指南。');
  if(!d.substrate||!d.finish||!d.color||!d.gloss)gap('DG-CMF-001','CMF 规格缺少基材、表面处理、颜色或光泽定义。','按零件分别定义基材、表面处理、颜色编码和光泽目标。');
  if(!Number.isFinite(d.glossMeasurementAngleDeg))gap('DG-CMF-MEASUREMENT-CONDITION-UNKNOWN','光泽值缺少测量角度，当前数值不可复现；颜色也应记录样板、仪器或观察条件。','指定光泽测量角度/仪器，并记录颜色标准、光源、观察角度和允差。');
  if(!d.useEnvironment)gap('DG-CMF-ENVIRONMENT-UNKNOWN','使用环境未知，无法确定耐候、耐汗液、化学品或磨耗验证范围。','定义温湿度、UV、汗液/清洁剂接触和磨耗场景。');
  if(!d.cmfCompatibilityEvidence)gap('DG-CMF-COMPATIBILITY-UNKNOWN','没有材料与表面处理相容性的可追溯依据。','使用具体牌号的供应商资料，并用当前涂层/纹理体系样件确认附着与外观。');
  if(!d.cmfSamplePlan||!d.cmfDurabilityPlan)gap('DG-CMF-VALIDATION-PLAN-UNKNOWN','缺少颜色/光泽样件计划或耐久验证计划，不能形成工程放行结论。','定义样板与整机样件数量、批次、判据以及耐久前后复测。');
  if(d.cmfKnowledgeStatus!=='REVIEWED'||!d.cmfSource||!d.cmfSourceVersion||!d.cmfApplicability)gap('DG-CMF-KNOWLEDGE-UNREVIEWED','CMF 依据尚未完成来源、版本/日期、适用条件和审核状态登记；未审核知识不能用于工程放行。','保存供应商原始来源、版本或日期、适用条件、单位、例外和审核人状态。');
  return f;}
 generateCmfMatrix(p={}){const d=p.design||{},rows=p.bom?.length?p.bom:(d.material||d.materialGrade?[{part_id:'MAIN',part_name:'当前评审零件',material_specified:d.materialGrade||d.material}]:[]);return rows.map(r=>({part_id:r.part_id,part_name:r.part_name,material_family:r.material_family||d.materialFamily||'待指定',material_grade:r.material_grade||r.material_specified||d.materialGrade||'待指定',substrate:r.substrate||d.substrate||'待指定',finish_process:r.finish||d.finish||'待与供应商确认',color_code:r.color||d.color||'待选色样',gloss_range:r.gloss||d.gloss||'待定义',gloss_measurement_angle_deg:r.glossMeasurementAngleDeg??d.glossMeasurementAngleDeg??null,use_environment:r.useEnvironment||d.useEnvironment||'待定义',compatibility_evidence:r.cmfCompatibilityEvidence||d.cmfCompatibilityEvidence||null,sample_plan:r.cmfSamplePlan||d.cmfSamplePlan||null,durability_plan:r.cmfDurabilityPlan||d.cmfDurabilityPlan||null,knowledge_source:d.cmfSource||null,knowledge_version_or_date:d.cmfSourceVersion||null,applicability:d.cmfApplicability||null,units:d.cmfUnits||null,exceptions:d.cmfExceptions||null,review_status:d.cmfKnowledgeStatus||'UNREVIEWED',status:'DRAFT_UNVERIFIED',origin:'USER_INPUT_OR_MISSING',verified:false,release_authority:'HUMAN_RELEASE_REQUIRED'}));}
}
module.exports=CMFAgent;
