const C=require('../backend/contracts');
class RequirementAgent {
 constructor(rules=[]){this.agent_id='A01';this.rules=rules;}
 evaluate(p){const findings=[],d=p.design||{},requirements=p.requirements||[];
 if(!requirements.length)findings.push(C.gap('DG-REQ-MISSING','尚未建立可追溯的需求基线。',{agent_id:'A01'}));
 const battery=requirements.find(r=>/电池|battery/i.test(r.text)&&/可更换|快拆|removable|quick.release/i.test(r.text));
 if(battery){
 const method=d.batteryAttachment;
 if(method==='permanent_bond')findings.push({issue_id:'DG-REQ-002',agent_id:'A01',category:'Requirements',finding:`电池固定方式被明确填写为永久粘接，与需求 ${battery.req_id} 的可更换要求冲突。`,severity:'CRITICAL',record_type:'DERIVED_RULE',evidence_refs:[battery.req_id],requirement_id:battery.req_id,impact:'可能无法按需求拆换电池。',recommendation:'修改固定方式并提供拆换验证记录。',confidence:1,status:'OPEN'});
 else if(!['screws','latch','removable_connector'].includes(method))findings.push(C.gap('DG-REQ-BATTERY-CONFIRM','请结构化确认电池固定方式；自由文本中的否定、历史方案和胶粘对象不足以自动判定。',{agent_id:'A01',requirement_id:battery.req_id,evidence_refs:[battery.req_id]}));
 }
 for(const r of requirements)if(!r.verification_method||!r.acceptance_criteria)findings.push(C.gap('DG-REQ-PLAN-'+r.req_id,`需求 ${r.req_id} 缺少验证方法或明确的通过判据。`,{agent_id:'A01',requirement_id:r.req_id,evidence_refs:[r.req_id]}));
 return findings;
 }
}
module.exports=RequirementAgent;
