const C=require('../backend/contracts');
class QualityAgent{
 constructor(v){this.verifier=v;this.agent_id='A05';}
 evaluate(p){return (p.requirements||[]).filter(r=>/IP\d{2}|跌落|冲击|drop|密封/i.test(r.text)).flatMap(r=>{const v=(p.verifications||[]).find(v=>v.req_id===r.req_id&&v.revision===p.design.active_revision&&v.status==='PASS'&&v.evidence_id);return v?[]:[C.gap('DG-QUA-'+r.req_id,`需求 ${r.req_id} 尚缺当前版本的验证结果与证据；提及密封圈或缓冲结构不能替代试验。`,{agent_id:'A05',category:'Quality/FMEA',evidence_refs:[r.req_id],requirement_id:r.req_id,recommendation:'记录验证方法、试验条件、通过判据、实际结果并关联试验报告文件。'})];});}
}
module.exports=QualityAgent;
