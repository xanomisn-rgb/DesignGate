const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {canonicalize,sha256,CANONICALIZATION_VERSION,telemetrySigningInput}=require('../backend/crypto/canonical_json');

test('canonical JSON retains nested objects and hashes semantic key-order variants identically',()=>{
  const first={z:[{b:2,a:1}],a:{y:'yes',x:true}};
  const second={a:{x:true,y:'yes'},z:[{a:1,b:2}]};
  assert.equal(canonicalize(first),'{"a":{"x":true,"y":"yes"},"z":[{"a":1,"b":2}]}');
  assert.equal(sha256(first),sha256(second));
  assert.notEqual(sha256(first),sha256({...second,z:[{a:1,b:3}]}));
  assert.throws(()=>canonicalize({bad:Infinity}),/finite/);
});

test('canonical contract publishes a versioned golden-vector fixture and fixed telemetry signing input',()=>{
  const fixture=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures','canonical_vectors.json'),'utf8'));
  assert.equal(CANONICALIZATION_VERSION,fixture.canonicalization_version);
  for(const vector of fixture.vectors){
    assert.equal(canonicalize(vector.input),vector.canonical,vector.id);
    assert.equal(sha256(vector.input),vector.sha256,vector.id);
  }
  const signing=telemetrySigningInput({device_id:'SIM-01',project_id:'P-1',revision:'Rev-A',test_id:'T-1',sequence:7,metric:'force',value:3.5,unit:'N',source_timestamp:'2026-09-09T00:00:00.000Z',idempotency_key:'telemetry-7'});
  assert.equal(signing.version,'DG-TELEMETRY-SIGNATURE-v1');
  assert.equal(signing.text,'DG-TELEMETRY-SIGNATURE-v1\nSIM-01\nP-1\nRev-A\nT-1\n7\nforce\n3.5\nN\n2026-09-09T00:00:00.000Z\ntelemetry-7');
});

test('telemetry signing rejects incomplete and line-injected canonical fields',()=>{
 const base={device_id:'SIM-01',project_id:'P-1',revision:'Rev-A',test_id:'T-1',sequence:7,metric:'force',value:3.5,unit:'N',source_timestamp:'2026-09-09T00:00:00.000Z',idempotency_key:'telemetry-7'};
 assert.throws(()=>telemetrySigningInput({...base,value:Infinity}),/invalid value/);
 assert.throws(()=>telemetrySigningInput({...base,device_id:'SIM-01\nforged'}),/line break/);
});
