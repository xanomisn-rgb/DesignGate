const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const Bus=require('../backend/integrations/integration_event_bus');
const LabGateway=require('../backend/integrations/lab_device_gateway');

test('append-only integration events are idempotent and hash-chain linked',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-events-'));
  try {
    const bus=new Bus(dir);
    const event={event_type:'LAB_TELEMETRY_RECEIVED',project_id:'DG-LAB',revision:'B',source:'SIMULATED_DEVICE',source_id:'ESP32-1',idempotency_key:'seq-1',occurred_at:'2026-09-09T01:00:00.000Z',payload:{test_id:'T-1',metric:'surface_temperature',value:52.6,unit:'degC'}};
    const first=bus.publish(event);
    assert.equal(first.status,'RECEIVED');
    assert.match(first.event_hash,/^[a-f0-9]{64}$/);
    const replay=bus.publish(event);
    assert.equal(replay.status,'DUPLICATE_REPLAY');
    assert.equal(bus.list('DG-LAB').length,1);
    assert.throws(()=>bus.publish({...event,payload:{...event.payload,value:46.8}}),/IDEMPOTENCY_CONFLICT/);
  } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});

test('lab telemetry verifies HMAC and never lets a device submit PASS directly',()=>{
  const payload={device_id:'SIM-ESP32',project_id:'DG-LAB',revision:'B',test_id:'T-1',sequence:1,metric:'surface_temperature',value:52.6,unit:'degC',source_timestamp:'2026-09-09T01:00:00.000Z',idempotency_key:'lab-1'};
  const gateway=new LabGateway({deviceSecrets:{'SIM-ESP32':'test-secret'},testResolver:()=>({metric:'surface_temperature',unit:'degC',operator:'<=',threshold:48})});
  payload.signature=gateway.sign(payload,'test-secret');
  const result=gateway.ingest(payload);
  assert.equal(result.verification.status,'FAIL');
  assert.equal(result.source,'SIMULATED_DEVICE');
  assert.equal(result.event.payload.signature_algorithm,'HMAC-SHA256');
  assert.equal(result.event.payload.signature_input_version,'DG-TELEMETRY-SIGNATURE-v1');
  assert.equal(Object.hasOwn(result.event.payload,'secret'),false);
  assert.throws(()=>gateway.ingest({...payload,status:'PASS'}),/forbidden telemetry property/);
});
