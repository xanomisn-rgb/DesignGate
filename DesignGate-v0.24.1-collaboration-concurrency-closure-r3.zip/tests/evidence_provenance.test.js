const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const EvidenceProvenanceService=require('../backend/evidence/evidence_provenance_service');

function service(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-provenance-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return new EvidenceProvenanceService({directory:dir});}
function input(extra={}){return {evidence_id:'EVD-001',project_id:'DG-P0',revision:'B',source_kind:'CAD_ANALYSIS',source_id:'CAD-UPLOAD-001',file_sha256:'a'.repeat(64),payload:{solid_count:1},verification_plan_id:'VP-001',verification_plan_hash:'b'.repeat(64),...extra};}

test('valid current evidence has independently evaluated integrity and provenance',t=>{
 const evidence=service(t).createManifest(input());
 assert.equal(evidence.integrity_status,'VERIFIED');
 assert.equal(evidence.provenance_status,'BOUND');
 assert.equal(evidence.manifest.schema_version,'1.0');
});

test('a complete payload without source identity is integrity verified but provenance incomplete',t=>{
 const evidence=service(t).createManifest(input({source_id:null}));
 assert.equal(evidence.integrity_status,'VERIFIED');
 assert.equal(evidence.provenance_status,'INCOMPLETE');
});

test('binding validates project, revision, verification plan, and manifest tampering independently',t=>{
 const proven=service(t),created=proven.createManifest(input()).manifest;
 assert.equal(proven.verifyEvidenceBinding({project_id:'DG-OTHER',revision:'B',evidence_id:'EVD-001'}).provenance_status,'MISMATCH');
 assert.equal(proven.verifyEvidenceBinding({project_id:'DG-P0',revision:'C',evidence_id:'EVD-001'}).provenance_status,'STALE');
 assert.equal(proven.verifyEvidenceBinding({project_id:'DG-P0',revision:'B',evidence_id:'EVD-001',verification_plan_hash:'c'.repeat(64)}).provenance_status,'STALE');
 assert.equal(proven.verifyManifest({...created,source_id:'tampered'}).integrity_status,'INVALID');
});

test('a corrupted stored manifest is never treated as current bound evidence',t=>{
 const proven=service(t);proven.createManifest(input());
 const file=proven.store.file,row=JSON.parse(fs.readFileSync(file,'utf8').trim());row.source_id='tampered';fs.writeFileSync(file,JSON.stringify(row)+'\n');
 const result=proven.verifyEvidenceBinding({project_id:'DG-P0',revision:'B',evidence_id:'EVD-001'});
 assert.equal(result.valid,false);assert.equal(result.reason_code,'EVIDENCE_INTEGRITY_INVALID');assert.equal(result.integrity_status,'INVALID');
});
