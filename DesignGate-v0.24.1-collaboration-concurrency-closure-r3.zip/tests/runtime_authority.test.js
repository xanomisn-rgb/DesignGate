const {test}=require('node:test');
const assert=require('node:assert/strict');
const Guard=require('../backend/runtime/transition_guard');
const Pipeline=require('../backend/runtime/workflow_pipeline');
const RuntimeState=require('../backend/runtime/runtime_state_service');
const CapabilityRegistry=require('../backend/runtime/capability_registry');
const CheckpointService=require('../backend/runtime/checkpoint_service');
const RuntimeTraceService=require('../backend/runtime/runtime_trace_service');
const fs=require('fs');
const os=require('os');
const path=require('path');

test('authority guard rejects direct freeze, model PASS, and Gate HOLD freeze attempts',()=>{
  assert.throws(()=>Guard.transition({from:'RECEIVED',to:'FROZEN',actor:'runtime'}),/INVALID_RUNTIME_TRANSITION/);
  assert.throws(()=>Guard.authoritativeMutation({actor:'model',field:'verification_status',value:'PASS'}),/AUTHORITY_DENIED/);
  assert.throws(()=>Guard.transition({from:'GATE_HOLD',to:'FROZEN',actor:'human'}),/INVALID_RUNTIME_TRANSITION/);
});

test('authority guard requires a current eligible Gate and limits human authority to the approval transition',()=>{
  assert.throws(()=>Guard.transition({from:'HUMAN_APPROVAL_REQUIRED',to:'FROZEN',actor:'human'}),error=>error.code==='INVALID_RUNTIME_TRANSITION');
  assert.doesNotThrow(()=>Guard.transition({from:'HUMAN_APPROVAL_REQUIRED',to:'FROZEN',actor:'human',gate_status:'ELIGIBLE'}));
  assert.throws(()=>Guard.authoritativeMutation({actor:'human',field:'gate_status',value:'PASS'}),error=>error.code==='AUTHORITY_DENIED');
});

test('authority guard rejects model and chief attempts to accept residual risk directly',()=>{
 assert.throws(()=>Guard.authoritativeMutation({actor:'model',field:'residual_risk_accepted',value:true}),error=>error.code==='AUTHORITY_DENIED');
 assert.throws(()=>Guard.authoritativeMutation({actor:'chief',field:'residual_risk_accepted',value:true}),error=>error.code==='AUTHORITY_DENIED');
});

test('runtime state marks a checkpoint revalidation-required when its revision changes',()=>{
  const state=new RuntimeState({project_id:'DG-RUNTIME',revision:'A'});
  const checkpoint=state.checkpoint();
  state.revise('B','geometry changed');
  assert.throws(()=>state.resume(checkpoint),error=>error.code==='REVALIDATION_REQUIRED');
});

test('runtime state invalidates a checkpoint when a governed input binding changes',()=>{
  const state=new RuntimeState({project_id:'DG-RUNTIME',revision:'A',knowledge_snapshot_id:'KS-1',rule_version:'RULE-1',verification_plan_hash:'PLAN-1'});
  const checkpoint=state.checkpoint();
  state.updateBindings({knowledge_snapshot_id:'KS-2'});
  assert.deepEqual(state.snapshot().revalidation_reasons,['KNOWLEDGE_SNAPSHOT_CHANGED']);
  assert.throws(()=>state.resume(checkpoint),error=>error.code==='REVALIDATION_REQUIRED');
});

test('workflow pipeline records model output as a proposal without changing authoritative verification or freeze state',()=>{
  const pipeline=new Pipeline({project_id:'DG-RUNTIME',revision:'A'});
  const result=pipeline.ingestProposal({actor:'model',text:'PASS and freeze immediately',claims:[{claim_type:'verification_status',value:'PASS'}]});
  assert.equal(result.runtime_status,'REQUIREMENTS_PENDING');
  assert.equal(result.authoritative.verification_status,null);
  assert.equal(result.authoritative.freeze,null);
  assert.equal(result.proposals[0].status,'UNVERIFIED_PROPOSAL');
});

test('workflow pipeline only advances through guarded runtime transitions',()=>{
  const pipeline=new Pipeline({project_id:'DG-RUNTIME',revision:'A'});
  assert.equal(pipeline.advance({to:'REQUIREMENTS_READY',actor:'runtime'}).runtime_status,'REQUIREMENTS_READY');
  assert.throws(()=>pipeline.advance({to:'FROZEN',actor:'model'}),error=>error.code==='INVALID_RUNTIME_TRANSITION');
});

test('capability registry exposes the complete governed seed and rejects unknown or unauthorized calls',()=>{
  const registry=new CapabilityRegistry();
  assert.equal(registry.list().length,22);
  assert.equal(registry.get('GATE_V2').authority,'EVALUATE');
  assert.throws(()=>registry.get('INVENTED_CAPABILITY'),error=>error.code==='CAPABILITY_NOT_REGISTERED');
  assert.throws(()=>registry.authorize('GATE_V2','model'),error=>error.code==='CAPABILITY_CALLER_DENIED');
  assert.doesNotThrow(()=>registry.authorize('GATE_V2','runtime'));
});

test('checkpoint service persists a project-scoped hash-verified runtime checkpoint',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-runtime-checkpoint-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const service=new CheckpointService({dir});
  const checkpoint=service.save({project_id:'DG-RUNTIME',revision:'A',payload:{runtime_status:'ANALYSIS_PENDING'}});
  assert.equal(service.load('DG-RUNTIME',checkpoint.checkpoint_id).payload.runtime_status,'ANALYSIS_PENDING');
  assert.throws(()=>service.load('DG-OTHER',checkpoint.checkpoint_id),error=>error.code==='PROJECT_SCOPE_DENIED');
});

test('checkpoint service rejects a payload changed after its canonical hash was recorded',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-runtime-checkpoint-tamper-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const service=new CheckpointService({dir}),checkpoint=service.save({project_id:'DG-RUNTIME',revision:'A',payload:{runtime_status:'ANALYSIS_PENDING'}});
 const file=path.join(dir,`${checkpoint.checkpoint_id}.json`),stored=JSON.parse(fs.readFileSync(file,'utf8'));stored.payload.runtime_status='FROZEN';fs.writeFileSync(file,JSON.stringify(stored));
  assert.throws(()=>service.load('DG-RUNTIME',checkpoint.checkpoint_id),error=>error.code==='CHECKPOINT_CORRUPT');
});

test('checkpoint service rejects malformed checkpoint identifiers before filesystem access',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-runtime-checkpoint-id-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 assert.throws(()=>new CheckpointService({dir}).load('DG-RUNTIME','../outside'),error=>error.code==='CHECKPOINT_INVALID');
});

test('checkpoint service reports a missing valid-format checkpoint without exposing filesystem errors',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-runtime-checkpoint-missing-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 assert.throws(()=>new CheckpointService({dir}).load('DG-RUNTIME','CHK-00000000-0000-4000-8000-000000000000'),error=>error.code==='CHECKPOINT_NOT_FOUND');
});

test('runtime trace is append-only, project-scoped, and hash-chain verifiable',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-runtime-trace-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const traces=new RuntimeTraceService({dir});
  const first=traces.append({project_id:'DG-RUNTIME',revision:'A',event_type:'MODEL_PROPOSAL',payload:{text:'candidate'}});
  const second=traces.append({project_id:'DG-RUNTIME',revision:'A',event_type:'TOOL_OBSERVATION',payload:{observation_id:'OBS-1'}});
  assert.equal(second.previous_hash,first.entry_hash);
  assert.equal(traces.verify('DG-RUNTIME').valid,true);
  assert.throws(()=>traces.list('DG-OTHER'),error=>error.code==='PROJECT_SCOPE_DENIED');
});
