const test = require('node:test');
const assert = require('node:assert/strict');
const childProcess = require('child_process');
const path = require('path');

test('LAN server launcher refuses a public bind unless the operator explicitly opts in', (t) => {
  if (process.platform !== 'win32') t.skip('PowerShell launcher is Windows-specific');
  const result = childProcess.spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts/start_collaboration_server.ps1', '-ServerHost', '0.0.0.0'], { cwd: path.join(__dirname, '..'), encoding: 'utf8' });
  assert.notEqual(result.status, 0);
  assert.match(`${result.stdout}\n${result.stderr}`, /LAN_BIND_REQUIRES_DESIGNGATE_ALLOW_LAN/);
});
