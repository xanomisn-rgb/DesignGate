const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),path=require('path'),os=require('os'),vm=require('vm');
const State=require('../backend/project_state_manager'),Agent=require('../backend/agent_runtime'),Tools=require('../backend/agent_tools');
const Patches=require('../backend/action_patch'),C=require('../backend/contracts'),Workflow=require('../backend/workflow_service');
const Knowledge=require('../backend/knowledge_service'),Citation=require('../backend/citation_verifier'),Rules=require('../backend/rule_engine'),Evidence=require('../backend/evidence_registry');
const {healthcheck}=require('../backend/diagnostics_service');
const plan={steps:['读取项目与长期约束','检查候选及冲突','协商后提交可审查结论'],reason:'推进设计'};
const call=(name,args={})=>({message:{tool_calls:[{id:'c-'+Math.random(),type:'function',function:{name,arguments:JSON.stringify(args)}}]}});
const end={summary:'本次分析完成，仍需验证',evidence_ids:['OBS-2'],limitations:['模型立场不是工程结论']};
const sample=()=>({project_id:'DG-COL',project_name:'合成项目',requirements:[{req_id:'REQ-1',text:'可维修',verification_method:'拆装',acceptance_criteria:'待定'}],design:{active_revision:'A',process:'CNC',material:'6061-T6',internalCornerRadius:.3},bom:[{part_id:'BOM-001',part_name:'外壳',material_specified:'ABS',quantity:1,unit_cost:20,quote_source:'历史报价',currency:'CNY'}],memory:{design_intent:{audience:'租房青年',forbid_sliders:true}},findings:[]});
function env(t,sequence,options={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-col-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const sm=new State(dir);sm.saveProject(sample(),0);let i=0;const requests=[];
 const runtime=new Agent(sm,async req=>{requests.push(req);const item=sequence[i++];if(!item)throw Error('unexpected request');return typeof item==='function'?item(req):item;},options);
 return {sm,runtime,requests,start:()=>runtime.start('DG-COL','比较外壳设计，保留制造与造型取舍')};
}
const proposal={title:'材料、内角与目标统一修改',reason:'候选设计，待验证',assumptions:['材料替换需打样'],design_patch:{internalCornerRadius:2},bom_patches:[{part_id:'BOM-001',spec:{material_specified:'PC',finish:'哑光'}}],design_intent:{aesthetic:'莫兰迪色系',target_price_max:99,currency:'CNY'}};
test('approved composite patch atomically updates BOM, intent, geometry and invalidates quote',async t=>{
 const e=env(t,[call('update_plan',plan),call('propose_change',proposal)]),before=e.sm.getProject('DG-COL');
 const r=await e.runtime.settled('DG-COL',e.start().run_id);assert.deepEqual(e.sm.getProject('DG-COL'),before);assert(r.draft.diff.some(d=>d.field==='unit_cost'&&d.new_value===null));
 e.runtime.approve('DG-COL',r.run_id,true);const p=e.sm.getProject('DG-COL');assert.equal(p.version,2);assert.equal(p.bom[0].material_specified,'PC');assert.equal(p.bom[0].unit_cost,null);assert.equal(p.bom[0].quote_source,null);assert.equal(p.memory.design_intent.aesthetic,'莫兰迪色系');assert.equal(p.memory.design_intent.forbid_sliders,true);assert.equal(p.design.internalCornerRadius,2);assert.equal(p.gate.status,'OPEN');assert.equal(p.last_review,null);assert.equal(p.agent_patch_screening.formal_review,false);assert.equal(p.agent_changes.length,1);
});
test('invalid BOM id causes no partial design or intent write',()=>{
 const p=sample(),before=structuredClone(p);assert.throws(()=>Patches.prepare(p,{...proposal,bom_patches:[{part_id:'MISSING',spec:{process:'CNC'}}]}),/不存在/);assert.deepEqual(p,before);
});
test('diff integrity rejects altered persisted proposal before application',()=>{
 const p=sample(),d={proposal:structuredClone(proposal)};d.diff_hash=C.hash(Patches.prepare(p,d.proposal).diff);d.proposal.design_patch.internalCornerRadius=5;assert.throws(()=>Patches.apply(p,d,'RUN-test'),/差异/);
});
test('empty change and duplicate BOM writes are rejected',()=>{
 assert.throws(()=>Patches.prepare(sample(),{design_patch:{internalCornerRadius:.3}}),/实际变更/);
 assert.throws(()=>Patches.prepare(sample(),{bom_patches:[proposal.bom_patches[0],proposal.bom_patches[0]]}),/重复/);
});
test('price intent requires currency without changing the original project',()=>{
 const p=sample(),before=structuredClone(p);assert.throws(()=>Patches.prepare(p,{design_intent:{target_price_max:99}}),/币种/);assert.deepEqual(p,before);
});
test('UI location alone cannot serve as analysis evidence for completion',async t=>{
 const e=env(t,[call('update_plan',plan),call('read_project'),call('show_reference',{kind:'bom',id:'BOM-001'}),call('finish_task',{...end,evidence_ids:['OBS-3']}),call('finish_task',end)]);
 const r=await e.runtime.settled('DG-COL',e.start().run_id);assert.equal(r.events[3].status,'FAILED');assert.equal(r.status,'COMPLETED');
});
test('design intent survives Revision and is included in a fresh runtime context',async t=>{
 const e=env(t,[call('update_plan',plan),call('read_project'),call('finish_task',end)]);new Workflow(e.sm).newRevision('DG-COL',{revision:'B',reason:'下一轮设计'},1);
 const result=await e.runtime.settled('DG-COL',e.start().run_id);assert.equal(result.status,'COMPLETED');assert(e.requests[0].messages.some(m=>m.content.includes('租房青年')));assert.equal(e.sm.getProject('DG-COL').memory.design_intent.forbid_sliders,true);
});
const negotiation={topic:'内角与制造成本冲突',evidence_ids:['OBS-2'],options:[{name:'小圆角',patch:{internalCornerRadius:.3}},{name:'大圆角',patch:{internalCornerRadius:2}}]};
const position=(role)=>call('submit_specialist_review',{position:role+' 的有限立场',response_to_previous:role==='A03'?'提出议题':'回应前一角色的工艺意见',preferred_option:role==='A02'?'小圆角':'大圆角',risks:['待确认刀具可达性'],unresolved:['需要供应商确认'],evidence_ids:['OBS-2']});
test('three real model calls exchange positions, retain dissent, consume shared budget and do not mutate',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('negotiate_tradeoff',negotiation),position('A03'),req=>{assert(req.messages[1].content.includes('A03 的有限立场'));assert(req.messages[1].content.includes('租房青年'));return position('A02');},req=>{assert(req.messages[1].content.includes('A02 的有限立场'));return position('A06');},call('finish_task',{...end,evidence_ids:['OBS-3']})]);
 const before=e.sm.getProject('DG-COL'),r=await e.runtime.settled('DG-COL',e.start().run_id);assert.equal(r.status,'COMPLETED');assert.equal(r.rounds,7);assert.equal(r.steps,4);assert.equal(r.events[2].output.transcript.length,3);assert.equal(r.events[2].output.transcript[1].preferred_option,'小圆角');assert.equal(r.events[2].output.applied,false);assert.deepEqual(e.sm.getProject('DG-COL'),before);
});
test('negotiation cannot cite fabricated observation ids',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('negotiate_tradeoff',{...negotiation,evidence_ids:['OBS-999']}),call('finish_task',end)]);const r=await e.runtime.settled('DG-COL',e.start().run_id);assert.equal(r.events[2].status,'FAILED');assert.equal(r.rounds,4);
});
test('specialist requests stop at the same request cap and retain partial transcript',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('negotiate_tradeoff',negotiation),position('A03')],{maxSteps:4});const r=await e.runtime.settled('DG-COL',e.start().run_id);assert.equal(r.status,'MODEL_REQUEST_LIMIT');assert.equal(r.stop_reason,'MODEL_REQUEST_LIMIT');assert.equal(r.rounds,4);assert.equal(r.events[2].partial_transcript.length,1);
});
test('cancellation aborts a specialist call with no project write',async t=>{
 let ready;const started=new Promise(r=>ready=r);
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('negotiate_tradeoff',negotiation),req=>new Promise((resolve,reject)=>{ready();req.signal.addEventListener('abort',()=>reject(Error('stop')),{once:true});})]);
 const run=e.start();await started;e.runtime.cancel('DG-COL',run.run_id);const r=await e.runtime.settled('DG-COL',run.run_id);assert.equal(r.status,'CANCELLED');assert.equal(e.sm.getProject('DG-COL').version,1);
});
test('all three legacy consumers read only the injected knowledge bus',()=>{
 const calls=[],bus={executionRules:()=>{calls.push('executable');return [];},legacy:k=>{calls.push(k);return [];},records:[]};new Rules(bus).evaluateChecks({process:'CNC'});new Citation(bus);new Evidence(bus);assert.deepEqual(calls,['executable','materials','standards','rules','materials','standards']);
 for(const f of ['rule_engine.js','citation_verifier.js','evidence_registry.js'])assert(!fs.readFileSync(path.join(__dirname,'../backend',f),'utf8').includes('readFileSync'));
});
test('legacy records and attempted B1 evidence registration remain unreviewed',()=>{
 const kb=new Knowledge();assert(kb.legacy('materials').every(r=>r.evidence_level==='UNREVIEWED'&&Object.keys(r.properties).length===0));const reg=new Evidence(kb);reg.registerEvidence({evidence_id:'fake',evidence_level:'B1',verified:true});assert.equal(reg.getEvidence('fake').verified,false);assert.equal(reg.getEvidence('fake').evidence_level,'UNREVIEWED');
});
test('quarantine promotion requires versioned PDF and human field review for B1',()=>{
 const kb=new Knowledge(),r=kb.get('MAT-T65');r.evidence_target='B1';const out=kb.assessPromotion(r);assert.equal(out.status,'BLOCKED');assert(out.missing.includes('versioned_manufacturer_pdf_with_sha256'));assert(out.missing.includes('human_field_review'));assert.equal(out.promoted,false);
});
test('reference tool validates actual project scope and never accepts arbitrary file ids',async()=>{
 const p=sample();assert.equal((await Tools.execute('show_reference',{kind:'bom',id:'BOM-001'},{project:p})).reference.id,'BOM-001');await assert.rejects(Tools.execute('show_reference',{kind:'file',id:'/etc/passwd'},{project:p,files:{}}));await assert.rejects(Tools.execute('show_reference',{kind:'bom',id:'other'},{project:p}));
});
test('healthcheck leaves absent services honest without making network requests',async()=>{
 let requests=0;const r=await healthcheck({env:{DESIGNGATE_MODE:'production'},fetchImpl:async()=>{requests++;}});assert.equal(requests,0);assert(r.results.every(r=>r.status==='CONTRACT_PENDING'));assert.equal(r.business_integration_verified,false);
});
test('healthcheck uses only GET with no credentials, data or redirects',async()=>{
 const r=await healthcheck({env:{INAGENT_HEALTH_URL:'https://gateway.test/health'},fetchImpl:async(url,opts)=>{assert.equal(url,'https://gateway.test/health');assert.equal(opts.method,'GET');assert.equal(opts.redirect,'error');assert(!opts.body&&!opts.headers.Authorization);return {ok:true,status:200};}});assert.equal(r.results[0].status,'HTTP_REACHABLE');assert.equal(r.results[0].business_integration_verified,false);
});
test('health errors redact endpoint credentials and reject unsafe configuration',async()=>{
 let n=0;const r=await healthcheck({env:{INAGENT_HEALTH_URL:'https://user:secret@gateway.test',LMS_HEALTH_URL:'https://gateway.test/health'},fetchImpl:async()=>{n++;throw Error('secret');}});assert.equal(n,1);assert.equal(r.results[0].status,'CONFIG_ERROR');assert.equal(r.results[1].status,'UNAVAILABLE');assert(!JSON.stringify(r).includes('secret'));
});
test('health timeout aborts the transport',async()=>{
 const r=await healthcheck({timeoutMs:5,env:{INAGENT_HEALTH_URL:'https://gateway.test/health'},fetchImpl:async(url,{signal})=>new Promise((res,rej)=>signal.addEventListener('abort',()=>rej(Error('abort'))))});assert.equal(r.results[0].status,'UNAVAILABLE');assert(r.results[0].detail.includes('超时'));
});
test('patch and negotiation UI escape values and present explicit uncertainty',()=>{
 const ctx=vm.createContext({console,structuredClone});for(const file of ['components.js','agent_collaboration.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../src',file),'utf8'),ctx);
 ctx.r={revision:'A',draft:{proposal:{...proposal,title:'<img onerror=bad()>'},base_version:1,diff:[{entity:'bom',id:'BOM-001',field:'material',old_value:'ABS',new_value:'<script>bad</script>'}]},events:[{tool:'negotiate_tradeoff',status:'FAILED',arguments:{topic:'取舍'},partial_transcript:[],error:'未完成'}]};
 const html=vm.runInContext('renderPatchCard(r)+renderNegotiations(r)',ctx);assert(!html.includes('<script>'));assert(html.includes('&lt;script&gt;'));assert(html.includes('旧验证绑定清除'));assert(html.includes('未完成'));
});
