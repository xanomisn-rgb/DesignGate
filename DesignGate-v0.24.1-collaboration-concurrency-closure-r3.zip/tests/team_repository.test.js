const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const TeamProjectRepository = require('../backend/repositories/team_project_repository');

test('TeamProjectRepository exposes scoped project and entity-version reads without exposing SQLite details', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-repository-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const repository = new TeamProjectRepository({ store });

  repository.createProject({ project_id: 'DG-TEAM-REPO', project_name: 'Shared Lamp' }, { actor_id: 'USER-A' });
  assert.equal(repository.getProject('DG-TEAM-REPO', { actor_id: 'USER-A' }).project_name, 'Shared Lamp');
  assert.equal(repository.getCurrentVersion('DG-TEAM-REPO', { actor_id: 'USER-A' }), 1);
  assert.equal(repository.getEntityVersion('DG-TEAM-REPO', 'BOM_ITEM', 'P-03', { actor_id: 'USER-A' }), 0);
  assert.throws(() => repository.getProject('DG-TEAM-REPO', { actor_id: 'USER-B' }), /PROJECT_SCOPE_DENIED/);
});
