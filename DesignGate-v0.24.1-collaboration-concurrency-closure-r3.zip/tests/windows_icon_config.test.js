const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('Windows package configuration uses the checked-in DesignGate icon asset',()=>{
 const root=path.join(__dirname,'..');
 const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
 assert.equal(pkg.build.win.icon,'src/assets/DesignGate.ico');
 const icon=path.join(root,pkg.build.win.icon);
 assert.equal(fs.existsSync(icon),true);
 assert.ok(fs.statSync(icon).size>0);
});
