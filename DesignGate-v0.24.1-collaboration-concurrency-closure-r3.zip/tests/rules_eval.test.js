const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),os=require('os'),path=require('path');
const K=require('../backend/knowledge_service'),R=require('../backend/rule_engine'),Check=require('../backend/check_engine'),C=require('../backend/contracts');
const {score,compare}=require('../eval/metrics'),{run}=require('../eval/run');
const dataset=require('../eval/cases.json'),key=require('../eval/answer_key.json');
const d={process:'注塑',material:'ABS',manufacturingSupplier:'Protolabs',nominalWall:2,ribThickness:1.4,textureCode:'PM-T2',draftAngle:3};
test('screen and knowledge reference share exact rule, bounds, sources and revision',()=>{
 const k=new K(),r=new R(k).evaluateChecks(d).find(c=>c.check_id==='DFM-injection-RIB'),direct=k.check('REF-RIB',.7,'ratio',{process:'注塑',supplier:'Protolabs'});
 assert.equal(r.status,'FAIL');assert.equal(r.rule_results[0].reference_status,direct.status);assert.deepEqual(r.rule_results[0].reference,direct.reference);assert.deepEqual(r.rule_results[0].sources,direct.sources);assert.equal(r.rule_version,direct.rule_version);assert.equal(direct.rule_id,'DFM-RIB');
});
test('editing data reference changes both tools without editing evaluator code',()=>{
 const k=new K();k.records.find(r=>r.id==='REF-RIB').reference.max=.8;
 assert.equal(new R(k).evaluateChecks(d).find(c=>c.check_id==='DFM-injection-RIB').status,'PASS');assert.equal(k.check('REF-RIB',.7,'ratio',{process:'注塑',supplier:'Protolabs'}).status,'WITHIN_REFERENCE');
});
test('missing supplier cannot be auto-filled to obtain a PASS',()=>{
 const p={...d};delete p.manufacturingSupplier;const r=new R().evaluateChecks(p);assert.equal(r.find(c=>c.check_id==='DFM-injection-RIB').status,'UNKNOWN');
});
test('texture selection recomputes the same provider draft range',()=>{
 const r=new R();assert.equal(r.evaluateChecks({...d,textureCode:'PM-T1'}).find(c=>c.check_id==='DFM-injection-DRAFT').status,'PASS');assert.equal(r.evaluateChecks(d).find(c=>c.check_id==='DFM-injection-DRAFT').status,'FAIL');
});
test('unsupported supplier, material and unverified CNC threshold cannot pass',()=>{
 const r=new R();assert.equal(r.evaluateChecks({...d,manufacturingSupplier:'Other'}).find(c=>c.check_id==='DFM-injection-WALL').status,'UNKNOWN');assert.equal(r.evaluateChecks({...d,material:'PC+ABS'}).find(c=>c.check_id==='DFM-injection-WALL').status,'UNKNOWN');assert.equal(r.evaluateChecks({process:'CNC',internalCornerRadius:20})[0].status,'UNKNOWN');
});
test('all old numeric cutoffs are suspended and active records have audit metadata',()=>{
 const rules=new K().executionRules();assert.equal(rules.filter(r=>r.status==='SUSPENDED_UNVERIFIED').length,7);for(const r of rules.filter(r=>r.status==='ACTIVE_REFERENCE'))assert(r.review.reviewer&&r.review.reviewed_on&&r.source_ids.length&&r.condition.supplier);const code=fs.readFileSync(path.join(__dirname,'../backend/rule_engine.js'),'utf8');assert(!/1\.25|0\.60|0\.025|1\.5/.test(code));
});
test('reference data and applicability fields both participate in check fingerprint',()=>{
 const k=new K(),check=new Check(k),p={design:{active_revision:'A',...d},requirements:[],bom:[]};const before=check.evaluate(p).checks.find(c=>c.check_id==='DFM-injection-RIB');k.records.find(r=>r.id==='REF-RIB').reference.max=.8;const after=check.evaluate(p).checks.find(c=>c.check_id==='DFM-injection-RIB');assert.notEqual(before.input_fingerprint,after.input_fingerprint);assert(after.input_fields.includes('manufacturingSupplier'));assert.equal(after.rule_version,'0.13.0-alpha');
});
test('a stale review cannot freeze after knowledge changes even if previously eligible',()=>{
 const k=new K(),p={project_id:'DG-OLD',version:1,design:{active_revision:'A'},last_review:{knowledge_fingerprint:k.fingerprint(),gate:{freeze_eligible:true}}};
 k.records.find(r=>r.id==='REF-RIB').reference.max=.8;
 const Workflow=require('../backend/workflow_service');const w=new Workflow({getProject:()=>structuredClone(p)},k);
 assert.throws(()=>w.freeze('DG-OLD',{approved_by:'Test',reason:'test'}),/知识规则已更新/);
});
test('evaluation set is labelled synthetic and has separate answer-key coverage',()=>{
 assert.equal(dataset.cases.length,40);assert.equal(key.cases.length,40);assert.equal(dataset.origin,'AUTHORED_SYNTHETIC');for(const c of dataset.cases){assert(key.cases.some(k=>k.case_id===c.id));assert(!JSON.stringify(c).includes('expected_issue_ids'));}
});
function sampleRun(){return {status:'COLLECTED_AWAITING_HUMAN_REVIEW',mode:'INJECTED_TEST_TRANSPORT',dataset_hash:C.hash(dataset),cases:[{case_id:'E17',status:'COMPLETED',record:{summary:'未知'}},{case_id:'E18',status:'FAILED',record:{}}]};}
function annotations(r){return {run_hash:C.hash(r),cases:r.cases.map(c=>({case_id:c.case_id,response_hash:C.hash(c),reviewed:true,reviewer:'Synthetic test reviewer',reviewed_at:'2026-09-06',detected_issue_ids:[],identified_unknown_ids:[],release_claim:false,claims:[]}))};}
test('metric denominators distinguish high-risk omissions and false release claims',()=>{
 const r=sampleRun(),a=annotations(r);a.cases[0].release_claim=true;const s=score(dataset,key,r,a);assert.equal(s.metrics.high_risk_miss_rate.value,1);assert.equal(s.metrics.false_release_claim_rate.value,.5);assert.equal(s.metrics.issue_recall.value,0);assert.equal(s.metrics.citation_support_rate.value,null);assert.equal(s.counts.execution_errors,1);
});
test('unreviewed outputs remain pending, never silently become successes',()=>{
 const r=sampleRun(),a=annotations(r);a.cases[0].reviewed=false;const s=score(dataset,key,r,a);assert.equal(s.counts.human_reviewed,1);assert.deepEqual(s.counts.pending,['E17']);assert.equal(s.metrics.false_release_claim_rate.denominator,1);
});
test('stale annotations and offline plans cannot produce a model quality score',()=>{
 const r=sampleRun(),a=annotations(r);r.cases[0].record.summary='changed';assert.throws(()=>score(dataset,key,r,a),/绑定/);assert.throws(()=>score(dataset,key,{status:'NOT_RUN',cases:[]},{}),/没有/);
});
test('comparison rejects different subsets or incomplete annotations',()=>{
 const r=sampleRun(),s=score(dataset,key,r,annotations(r));assert.equal(compare(s,s).metrics.issue_recall.delta,0);assert.throws(()=>compare(s,{...s,case_ids:['E17']}));assert.throws(()=>compare(s,{...s,counts:{...s.counts,pending:['E17']}}));
});
test('dry run makes no calls, while missing credentials block live execution',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-evaltest-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));let n=0;const result=await run({dataset,output:path.join(dir,'plan.json'),model:async()=>n++});assert.equal(n,0);assert.equal(result.status,'NOT_RUN');await assert.rejects(run({dataset,output:path.join(dir,'live.json'),live:true,env:{}}),/需配置/);
});
test('runner exercises actual Agent and never sends answer labels or approves proposals',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-evaltest-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));let i=0;
 const calls=[['update_plan',{steps:['读取项目','检查条件','整理结论'],reason:'执行'}],['read_project',{}],['finish_task',{summary:'缺少验证',evidence_ids:['OBS-2'],limitations:['合成用例']}]];
 const r=await run({dataset,output:path.join(dir,'run.json'),live:true,limit:1,model:async req=>{assert(!JSON.stringify(req).includes('expected_issue_ids'));const [name,args]=calls[i++];return {message:{tool_calls:[{id:'c'+i,type:'function',function:{name,arguments:JSON.stringify(args)}}]}};}});
 assert.equal(r.mode,'INJECTED_TEST_TRANSPORT');assert.equal(r.cases[0].status,'COMPLETED');assert.equal(r.cases[0].project_changed,false);assert(fs.existsSync(path.join(dir,'run.json.annotations.json')));
});
