const {test}=require('node:test');
const assert=require('node:assert/strict');
const ProductAgent=require('../agents/product_agent');
const CMFAgent=require('../agents/cmf_agent');
const C=require('../backend/contracts');

test('whole-product envelope is never reused as the local grip section',()=>{
  const findings=new ProductAgent().evaluate({
    product:{category:'手持电子产品'},
    design:{dimensions:'160 x 72 x 9 mm'}
  });
  assert(findings.some(f=>f.issue_id==='DG-ERG-GRIP-UNKNOWN'));
  assert(!findings.some(f=>f.issue_id==='DG-ERG-PROTOTYPE'));
});

test('ergonomics contract keeps envelope grip load task and population as separate fields',()=>{
  const d=C.design({
    envelopeDimensions:'160 x 72 x 9 mm',gripSection:'42 x 24 mm',weightG:220,
    cogCoordinatesMm:'80, 34, 5',cogReference:'rear-lower-left datum',
    gripPosture:'power grip',operationForceN:3.5,operationDurationS:900,
    targetPopulation:'adult service technicians',populationSource:'recruiting brief v2'
  });
  assert.equal(d.envelopeDimensions,'160 x 72 x 9 mm');
  assert.equal(d.gripSection,'42 x 24 mm');
  assert.equal(d.weightG,220);
  assert.equal(d.operationDurationS,900);
  assert.equal(d.populationSource,'recruiting brief v2');
});

test('grip estimate states inputs units formula and does not hide missing task evidence',()=>{
  const findings=new ProductAgent().evaluate({
    product:{category:'handheld electronics'},design:{gripSection:'42 x 24 mm'}
  });
  const estimate=findings.find(f=>f.issue_id==='DG-ERG-GRIP-ESTIMATE');
  assert.match(estimate.finding,/42.*24.*mm/);
  assert.match(estimate.finding,/Ramanujan|π/);
  assert.equal(estimate.status,'NEED_HUMAN_REVIEW');
  const taskGap=findings.find(f=>f.issue_id==='DG-ERG-TASK-UNKNOWN');
  assert.match(taskGap.finding,/重量.*重心.*姿态.*操作力.*时长.*目标人群.*来源/);
  assert.match(taskGap.recommendation,/样机.*试握/);
});

test('legacy dimensions migrate to envelope while local grip remains explicitly unknown',()=>{
  const d=C.design({dimensions:'160 x 72 x 9 mm'});
  assert.equal(d.dimensions,'160 x 72 x 9 mm');
  assert.equal(d.envelopeDimensions,'160 x 72 x 9 mm');
  assert.equal(d.gripSection,null);
  assert.equal(d.ergonomicsMigration,'LEGACY_ENVELOPE_ONLY');
});

test('CMF contract preserves conditional specification and evidence fields',()=>{
  const d=C.design({materialFamily:'PC+ABS',materialGrade:'Bayblend T65 XF',substrate:'injection molded housing',finish:'VDI texture',color:'RAL 9005',gloss:'10 GU',glossMeasurementAngleDeg:60,useEnvironment:'indoor handheld',cmfCompatibilityEvidence:'supplier processing guide',cmfSamplePlan:'3 plaques and 5 housings',cmfDurabilityPlan:'abrasion and chemical exposure',cmfKnowledgeStatus:'REVIEWED',cmfSource:'supplier TDS',cmfSourceVersion:'2025-01',cmfApplicability:'injection molding',cmfExceptions:'paint system separately qualified'});
  assert.equal(d.materialGrade,'Bayblend T65 XF');
  assert.equal(d.glossMeasurementAngleDeg,60);
  assert.equal(d.cmfKnowledgeStatus,'REVIEWED');
  assert.equal(d.cmfExceptions,'paint system separately qualified');
});

test('CMF review separates generic material grade measurement conditions and verification plans',()=>{
  const findings=new CMFAgent().evaluate({design:{material:'ABS',finish:'paint',color:'black',gloss:'10 GU'}});
  assert(findings.some(f=>f.issue_id==='DG-CMF-MATERIAL-GRADE-UNKNOWN'));
  assert(findings.some(f=>f.issue_id==='DG-CMF-MEASUREMENT-CONDITION-UNKNOWN'));
  assert(findings.some(f=>f.issue_id==='DG-CMF-ENVIRONMENT-UNKNOWN'));
  assert(findings.some(f=>f.issue_id==='DG-CMF-VALIDATION-PLAN-UNKNOWN'));
});

test('reviewed CMF knowledge remains traceable but cannot become an automatic release',()=>{
  const matrix=new CMFAgent().generateCmfMatrix({design:{materialFamily:'PC+ABS',materialGrade:'Grade X',substrate:'molded plaque',finish:'paint',color:'black',gloss:'10 GU',glossMeasurementAngleDeg:60,useEnvironment:'indoor',cmfCompatibilityEvidence:'coupon report R1',cmfSamplePlan:'3 coupons',cmfDurabilityPlan:'rub test',cmfKnowledgeStatus:'REVIEWED',cmfSource:'supplier guide',cmfSourceVersion:'2026-01',cmfApplicability:'Grade X molded parts',cmfUnits:'mm, GU',cmfExceptions:'none'}});
  assert.equal(matrix[0].review_status,'REVIEWED');
  assert.equal(matrix[0].verified,false);
  assert.equal(matrix[0].release_authority,'HUMAN_RELEASE_REQUIRED');
  assert.equal(matrix[0].units,'mm, GU');
});

test('assembly service contract keeps fasteners tools access steps and irreversible joins distinct',()=>{
  const d=C.design({fastenerType:'M2 Phillips screw',serviceTool:'PH00 driver',servicePart:'battery',serviceAccess:'rear cover',disassemblySteps:'remove 4 screws; lift cover; disconnect battery',irreversibleJoints:'speaker grille heat stake',assemblyServiceConflicts:'heat stake blocks grille replacement'});
  assert.equal(d.fastenerType,'M2 Phillips screw');
  assert.equal(d.serviceTool,'PH00 driver');
  assert.equal(d.disassemblySteps,'remove 4 screws; lift cover; disconnect battery');
  assert.equal(d.irreversibleJoints,'speaker grille heat stake');
});

test('missing assembly service inputs are a data gap rather than a discovered defect',()=>{
  const findings=new ProductAgent().evaluate({product:{category:'手持电子产品'},design:{gripSection:'40 x 25 mm'},bom:[{part_id:'BAT',part_name:'battery'}]});
  const gap=findings.find(f=>f.issue_id==='DG-SERVICE-INFO-UNKNOWN');
  assert.equal(gap.record_type,'DATA_GAP');
  assert.equal(gap.severity,'INFO');
  assert.match(gap.finding,/紧固件.*工具.*可达性.*拆解步骤.*不可逆/);
});

test('an explicitly recorded assembly service conflict is a defect with user provenance',()=>{
  const findings=new ProductAgent().evaluate({product:{category:'handheld electronics'},design:{gripSection:'40 x 25 mm',fastenerType:'heat stakes',serviceTool:'n/a',servicePart:'speaker grille',serviceAccess:'inside rear housing',disassemblySteps:'open housing; destructively remove stakes',irreversibleJoints:'speaker grille heat stakes',assemblyServiceConflicts:'heat stakes prevent replacement without damage'}});
  const issue=findings.find(f=>f.issue_id==='DG-SERVICE-CONFLICT');
  assert.equal(issue.record_type,'USER_DECLARED_CONFLICT');
  assert.equal(issue.severity,'HIGH');
  assert.equal(issue.status,'OPEN');
  assert.match(issue.finding,/heat stakes prevent replacement without damage/);
});
