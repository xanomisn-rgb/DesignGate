const {test}=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');

const MqttLabConnector=require('../backend/integrations/mqtt_lab_connector');
const LabGateway=require('../backend/integrations/lab_device_gateway');

function telemetry(gateway,overrides={},secret='mock-secret'){
  const value={device_id:'MOCK-ESP32-01',project_id:'DG-MQTT',revision:'A',test_id:'T-TEMP',sequence:1,metric:'temperature',value:20,unit:'degC',source_timestamp:'2026-09-09T02:00:00.000Z',idempotency_key:'mqtt-1',...overrides};
  return {...value,signature:gateway.sign(value,secret)};
}

function connectedClient(){
  const client=new EventEmitter();
  client.subscribe=(topic,options,callback)=>setImmediate(()=>callback(null,[{topic,qos:1}]));
  client.end=(force,callback)=>callback?.();
  return client;
}

test('MQTT connector accepts an authenticated mock ESP32 message, but derives rather than accepts a test result',async()=>{
  const gateway=new LabGateway({deviceSecrets:{'MOCK-ESP32-01':{secret:'mock-secret',source:'MOCK'}},testResolver:()=>({metric:'temperature',unit:'degC',operator:'<=',threshold:25})});
  const client=connectedClient(), connector=new MqttLabConnector({gateway,brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:()=>{}});
  const ready=connector.start(); setImmediate(()=>client.emit('connect')); await ready;
  const accepted=[]; connector.on('accepted',row=>accepted.push(row));
  client.emit('message','lab/telemetry',Buffer.from(JSON.stringify(telemetry(gateway))));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(accepted.length,1);
  assert.equal(accepted[0].source,'MOCK');
  assert.equal(accepted[0].verification.status,'PASS');
  await connector.stop();
});

test('MQTT connector rejects bad broker authentication with a stable code',async()=>{
  const client=connectedClient(), connector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,timeoutMs:50,logger:()=>{}});
  const starting=connector.start(); setImmediate(()=>client.emit('error',{returnCode:4,message:'Bad user name or password'}));
  await assert.rejects(starting,error=>error.code==='MQTT_AUTHENTICATION_FAILED'&&error.returnCode===4);
});

test('forged telemetry signature is rejected, logged, and never produces an accepted result',async()=>{
  const warnings=[], gateway=new LabGateway({deviceSecrets:{'MOCK-ESP32-01':{secret:'mock-secret',source:'MOCK'}},testResolver:()=>({metric:'temperature',unit:'degC',operator:'<=',threshold:25})});
  const client=connectedClient(), connector=new MqttLabConnector({gateway,brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:entry=>warnings.push(entry)});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;
  const forged=telemetry(gateway,{value:99});forged.signature='0'.repeat(64);
  client.emit('message','lab/telemetry',Buffer.from(JSON.stringify(forged)));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(warnings.at(-1).code,'HMAC_SIGNATURE_MISMATCH');
  assert.equal(connector.receivedCount,1);assert.equal(connector.acceptedCount,0);
  await connector.stop();
});

test('unknown device or project binding is reported as unauthorized before it can create a test result',async()=>{
  const warnings=[], gateway=new LabGateway({deviceSecrets:{'MOCK-ESP32-01':{secret:'mock-secret',source:'MOCK',project_ids:['DG-MQTT']}},testResolver:()=>({metric:'temperature',unit:'degC',operator:'<=',threshold:25})});
  const client=connectedClient(), connector=new MqttLabConnector({gateway,brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:entry=>warnings.push(entry)});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;
  client.emit('message','lab/telemetry',Buffer.from(JSON.stringify(telemetry(gateway,{project_id:'DG-OTHER'}))));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(warnings.at(-1).code,'UNAUTHORIZED');assert.equal(connector.acceptedCount,0);
  await connector.stop();
});

test('MQTT connector covers connection rejection, subscription rejection, timeout, malformed payload and topic isolation',async()=>{
  const generic=new EventEmitter();generic.end=(force,callback)=>callback?.();
  const genericConnector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>generic,timeoutMs:30,logger:()=>{}});
  const genericStart=genericConnector.start();setImmediate(()=>generic.emit('error',Error('network reset')));
  await assert.rejects(genericStart,error=>error.code==='MQTT_CONNECTION_FAILED');

  const subscribeFail=connectedClient();subscribeFail.subscribe=(topic,options,callback)=>setImmediate(()=>callback(Error('subscription denied')));
  const subscribeConnector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>subscribeFail,logger:()=>{}});
  const subscriptionStart=subscribeConnector.start();setImmediate(()=>subscribeFail.emit('connect'));
  await assert.rejects(subscriptionStart,error=>error.code==='MQTT_CONNECTION_FAILED');

  const idle=new EventEmitter();idle.end=(force,callback)=>callback?.();
  const timeoutConnector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>idle,timeoutMs:5,logger:()=>{}});
  await assert.rejects(timeoutConnector.start(),error=>error.code==='MQTT_CONNECTION_TIMEOUT');

  const warnings=[], client=connectedClient(), connector=new MqttLabConnector({gateway:{ingest:()=>{throw Error('gateway failure');}},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:entry=>warnings.push(entry)});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;
  assert.equal(await connector.start(),connector);
  client.emit('message','other/topic',Buffer.from('{}'));
  client.emit('message','lab/telemetry',Buffer.from('{not-json'));
  client.emit('message','lab/telemetry',Buffer.from('{}'));
  assert.deepEqual(warnings.map(row=>row.code),['MQTT_TOPIC_REJECTED','MQTT_PAYLOAD_INVALID','MQTT_TELEMETRY_REJECTED']);
  await connector.stop();await timeoutConnector.stop();
});

test('MQTT connector sends accepted telemetry through the workflow-bound gateway when configured',async()=>{
  const client=connectedClient(), calls=[];
  const gateway={ingest:()=>null,ingestToWorkflow:(payload,workflow)=>{calls.push({payload,workflow});return {source:'MOCK',verification:{status:'PASS'}};}};
  const workflow={get:()=>null};const connector=new MqttLabConnector({gateway,workflow,brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:()=>{}});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;
  client.emit('message','lab/telemetry',Buffer.from(JSON.stringify({device_id:'MOCK-ESP32-01'})));
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(calls.length,1);assert.equal(calls[0].workflow,workflow);await connector.stop();
});

test('MQTT error normalization distinguishes every broker authentication form from transport failures',()=>{
  const {MqttIntegrationError,toIntegrationError}=MqttLabConnector;
  const original=new MqttIntegrationError('MQTT_CONNECTION_TIMEOUT','timeout');assert.equal(toIntegrationError(original),original);
  assert.equal(toIntegrationError({code:'HMAC_SIGNATURE_MISMATCH'}).code,'HMAC_SIGNATURE_MISMATCH');
  assert.equal(toIntegrationError({code:'UNAUTHORIZED'}).code,'UNAUTHORIZED');
  for(const error of [{returnCode:4},{code:4},{returnCode:5},{code:5},{message:'Bad user name or password'}])assert.equal(toIntegrationError(error).code,'MQTT_AUTHENTICATION_FAILED');
  assert.equal(toIntegrationError('socket closed').code,'MQTT_CONNECTION_FAILED');
  assert.throws(()=>new MqttLabConnector(),/requires LabDeviceGateway/);
  assert.throws(()=>new MqttLabConnector({gateway:{ingest:()=>null}}),/broker URL is required/);
  assert.throws(()=>new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:123}),/broker URL is required/);
  const defaultConnector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883'});return defaultConnector.stop();
});

test('MQTT rejection keeps null payload diagnostics safe and supports direct diagnostic emission defaults',async()=>{
  const warnings=[], client=connectedClient(), connector=new MqttLabConnector({gateway:{ingest:()=>{throw Error('signature parser failure');}},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:entry=>warnings.push(entry)});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;
  client.emit('message','lab/telemetry',Buffer.from('null'));
  const direct=connector.reject('DIRECT_DIAGNOSTIC','direct');
  assert.equal(warnings[0].code,'HMAC_SIGNATURE_MISMATCH');assert.equal(warnings[0].device_id,undefined);assert.equal(direct.status,'REJECTED');await connector.stop();
});

test('MQTT rejection preserves a non-Error gateway failure message',async()=>{
  const warnings=[], client=connectedClient(), connector=new MqttLabConnector({gateway:{ingest:()=>{throw 'raw gateway failure';}},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:entry=>warnings.push(entry)});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;client.emit('message','lab/telemetry',Buffer.from('{}'));
  assert.equal(warnings[0].code,'MQTT_TELEMETRY_REJECTED');assert.equal(warnings[0].message,'raw gateway failure');await connector.stop();
});

test('MQTT start handles a throwing client factory, redundant post-connect error and a client without end',async()=>{
  const throwing=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>{throw Error('factory failure');},logger:()=>{}});
  await assert.rejects(throwing.start(),error=>error.code==='MQTT_CONNECTION_FAILED');
  const client=connectedClient(), connector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>client,logger:()=>{}});
  const ready=connector.start();setImmediate(()=>client.emit('connect'));await ready;client.emit('error',Error('late broker notification'));assert.equal(await connector.start(),connector);await connector.stop();
  const noEnd=new EventEmitter();const noEndConnector=new MqttLabConnector({gateway:{ingest:()=>null},brokerUrl:'mqtt://127.0.0.1:18883',connect:()=>noEnd,logger:()=>{}});
  const failed=noEndConnector.start();setImmediate(()=>noEnd.emit('error',Error('no end implementation')));await assert.rejects(failed,error=>error.code==='MQTT_CONNECTION_FAILED');
});

test('LabGateway preserves all telemetry rejection paths and server-bound workflow records',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-mqtt-gateway-'));const Bus=require('../backend/integrations/integration_event_bus');
  try {
    const plan={metric:'temperature',unit:'degC',operator:'<=',threshold:25,plan_item_id:'PLAN-T',failure_mode_ids:['FM-T']};
    const gateway=new LabGateway({deviceSecrets:{'MOCK-ESP32-01':{secret:'mock-secret',source:'MOCK',project_ids:['DG-MQTT']},'SIM-01':'sim-secret','REAL-01':{secret:'real-secret',key_id:'key-1'}},testResolver:input=>input.metric==='no-plan'?null:input.metric==='wrong-unit'?{...plan,unit:'kPa'}:plan,eventBus:new Bus(dir)});
    assert.throws(()=>gateway.sign({},''),/secret/);
    assert.throws(()=>gateway.ingest({status:'PASS'}),/forbidden/);
    assert.throws(()=>gateway.ingest({}),/missing device_id/);
    const base=telemetry(gateway);assert.throws(()=>gateway.ingest({...base,value:Infinity}),/invalid telemetry/);
    assert.throws(()=>gateway.ingest({...base,device_id:'UNKNOWN'}),/unknown device/);
    assert.throws(()=>gateway.ingest({...base,project_id:'DG-OTHER',signature:gateway.sign({...base,project_id:'DG-OTHER'},'mock-secret')}),error=>error.code==='UNAUTHORIZED');
    assert.throws(()=>gateway.ingest({...base,signature:'aa'}),error=>error.code==='HMAC_SIGNATURE_MISMATCH');
    const noPlan={...base,metric:'no-plan'};noPlan.signature=gateway.sign(noPlan,'mock-secret');assert.throws(()=>gateway.ingest(noPlan),/does not match/);
    const wrongUnit={...base,metric:'wrong-unit'};wrongUnit.signature=gateway.sign(wrongUnit,'mock-secret');assert.throws(()=>gateway.ingest(wrongUnit),/does not match/);
    const sim={...base,device_id:'SIM-01',idempotency_key:'sim-1'};sim.signature=gateway.sign(sim,'sim-secret');assert.equal(gateway.ingest(sim).source,'SIMULATED_DEVICE');
    const real={...base,device_id:'REAL-01',idempotency_key:'real-1'};real.signature=gateway.sign(real,'real-secret');assert.equal(gateway.ingest(real).source,'DEVICE_TELEMETRY_NOT_LIVE_VERIFIED');
    for(const [operator,value] of [['>=',30],['===',25]]){const row={...base,idempotency_key:`op-${operator}`,value};row.signature=gateway.sign(row,'mock-secret');gateway.testResolver=()=>({...plan,operator,threshold:value});assert.equal(gateway.ingest(row).verification.status,'PASS');}
    gateway.testResolver=()=>({...plan,operator:'??'});const unsupported={...base,idempotency_key:'bad-operator'};unsupported.signature=gateway.sign(unsupported,'mock-secret');assert.throws(()=>gateway.ingest(unsupported),/unsupported verification operator/);
    gateway.testResolver=()=>plan;
    const failing={...base,idempotency_key:'derived-fail'};failing.signature=gateway.sign(failing,'mock-secret');gateway.testResolver=()=>({...plan,threshold:1});assert.equal(gateway.ingest(failing).verification.status,'FAIL');gateway.testResolver=()=>plan;
    assert.throws(()=>gateway.ingestToWorkflow(base,{}),/workflow service/);
    let project={design:{active_revision:'A'},version:3};const calls=[];const workflow={get:()=>project,addEvidence:(projectId,file,version)=>{calls.push({projectId,file,version,contents:fs.readFileSync(file,'utf8')});return {evidence:{evidence_id:'EVD-T'}};},recordDfmeaTest:(projectId,input,version)=>{calls.push({projectId,input,version});return {dfmea_test_records:[{record_id:'TESTREC-T'}]};}};
    const record={...base,idempotency_key:'workflow-1',retest_of:'FAILED-T'};record.signature=gateway.sign(record,'mock-secret');const result=gateway.ingestToWorkflow(record,workflow);assert.equal(result.workflow_status,'RECORDED_THROUGH_WORKFLOW');assert.equal(result.test_record_id,'TESTREC-T');assert.equal(calls[1].input.status,'PASS');assert.equal(calls[1].input.retest_of,'FAILED-T');assert.equal(fs.existsSync(path.dirname(calls[0].file)),false);
    const recordWithoutRetest={...base,idempotency_key:'workflow-2'};recordWithoutRetest.signature=gateway.sign(recordWithoutRetest,'mock-secret');gateway.ingestToWorkflow(recordWithoutRetest,workflow);assert.equal(calls.at(-1).input.retest_of,undefined);
    const failedRecord={...base,idempotency_key:'workflow-fail'};failedRecord.signature=gateway.sign(failedRecord,'mock-secret');gateway.testResolver=()=>({...plan,threshold:1});gateway.ingestToWorkflow(failedRecord,workflow);assert.equal(calls.at(-1).input.status,'FAILED');gateway.testResolver=()=>plan;
    assert.equal(gateway.ingestToWorkflow(record,workflow).workflow_status,'NO_DUPLICATE_SIDE_EFFECT');
    project={design:{active_revision:'B'},version:4};const stale={...base,idempotency_key:'workflow-stale'};stale.signature=gateway.sign(stale,'mock-secret');assert.throws(()=>gateway.ingestToWorkflow(stale,workflow),/not current/);
    project={design:{active_revision:'A'},version:4};gateway.testResolver=()=>({metric:'temperature',unit:'degC',operator:'<=',threshold:25});const unbound={...base,idempotency_key:'workflow-unbound'};unbound.signature=gateway.sign(unbound,'mock-secret');assert.throws(()=>gateway.ingestToWorkflow(unbound,workflow),/binding/);
  } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});

test('live Mosquitto accepts a signed MQTT.js mock-device message when explicitly configured',{
  skip:!process.env.DG_MQTT_TEST_URL||!process.env.DG_MQTT_TEST_USERNAME||!process.env.DG_MQTT_TEST_PASSWORD||!process.env.DG_MQTT_TEST_SECRET
},async t=>{
  const mqtt=require('mqtt');
  const secret=process.env.DG_MQTT_TEST_SECRET;
  const gateway=new LabGateway({deviceSecrets:{'MOCK-ESP32-01':{secret,source:'MOCK',project_ids:['DG-MQTT']}},testResolver:()=>({metric:'temperature',unit:'degC',operator:'<=',threshold:25})});
  const warnings=[];const connector=new MqttLabConnector({gateway,brokerUrl:process.env.DG_MQTT_TEST_URL,username:process.env.DG_MQTT_TEST_USERNAME,password:process.env.DG_MQTT_TEST_PASSWORD,timeoutMs:3000,logger:entry=>warnings.push(entry)});
  t.after(()=>connector.stop());
  await connector.start();
  const received=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error(`live MQTT message timed out: ${JSON.stringify(warnings)}`)),3000);connector.once('accepted',result=>{clearTimeout(timer);resolve(result);});});
  const payload=telemetry(gateway,{idempotency_key:'live-mqtt-1'},secret);
  const publisher=mqtt.connect(process.env.DG_MQTT_TEST_URL,{protocolVersion:4,username:process.env.DG_MQTT_TEST_USERNAME,password:process.env.DG_MQTT_TEST_PASSWORD,clientId:`designgate-mqtt-test-${process.pid}`,clean:true,reconnectPeriod:0});
  await new Promise((resolve,reject)=>{publisher.once('error',reject);publisher.once('connect',()=>publisher.publish('lab/telemetry',JSON.stringify(payload),{qos:1},error=>error?reject(error):resolve()));});
  publisher.end(true);
  const result=await received;assert.equal(result.source,'MOCK');assert.equal(result.verification.status,'PASS');
});
