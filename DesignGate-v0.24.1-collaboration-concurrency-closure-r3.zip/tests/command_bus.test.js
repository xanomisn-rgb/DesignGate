const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

async function request(base, pathname, options = {}) {
  const response = await fetch(`${base}${pathname}`, options);
  return { status: response.status, body: response.status === 204 ? null : await response.json() };
}

test('authenticated project commands use session identity instead of an actor_id supplied by the client', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-command-bus-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple' });
  identity.register({ user_id: 'USER-B', username: 'bruno', password: 'correct horse battery staple' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = async username => (await request(base, '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password: 'correct horse battery staple' }) })).body.token;
  const tokenA = await login('alice');
  const tokenB = await login('bruno');
  const auth = token => ({ authorization: `Bearer ${token}`, 'content-type': 'application/json' });

  assert.equal((await request(base, '/api/projects', { method: 'POST', headers: auth(tokenA), body: JSON.stringify({ project_id: 'DG-COMMAND-001', project_name: 'Shared Lamp' }) })).status, 201);
  assert.equal((await request(base, '/api/projects/DG-COMMAND-001/members', { method: 'POST', headers: auth(tokenA), body: JSON.stringify({ user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }) })).status, 201);
  const command = await request(base, '/api/projects/DG-COMMAND-001/commands', { method: 'POST', headers: auth(tokenB), body: JSON.stringify({ command_id: 'CMD-1', idempotency_key: 'idem-1', project_id: 'DG-COMMAND-001', actor_id: 'USER-A', command_type: 'UPDATE_BOM_ITEM', base_project_version: 1, entity_type: 'BOM_ITEM', entity_id: 'P-03', base_entity_version: 0, payload: { part_name: 'Housing', material: 'PC+ABS' } }) });

  assert.equal(command.status, 200);
  assert.equal(store.db.prepare('SELECT actor_id FROM collaboration_events WHERE command_id = ?').get('CMD-1').actor_id, 'USER-B');
});
