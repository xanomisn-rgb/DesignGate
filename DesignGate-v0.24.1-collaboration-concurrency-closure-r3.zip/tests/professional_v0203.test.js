const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs'),os=require('os'),path=require('path');
const State=require('../backend/project_state_manager');
const Agent=require('../backend/agent_runtime');
const Client=require('../connectors/agent_model_client');
const Orchestrator=require('../backend/orchestrator');
const Workflow=require('../backend/workflow_service');
const EvidenceGraph=require('../backend/evidence_graph');

const call=(name,args,usage=undefined)=>({message:{tool_calls:[{id:'call-'+Math.random().toString(16).slice(2),type:'function',function:{name,arguments:JSON.stringify(args)}}]},...(usage?{usage}:{} )});
const plan={steps:['读取项目','执行检查','总结'],reason:'专项回归'};
const finish={summary:'完成',evidence_ids:['OBS-2'],limitations:['No external production release was performed.'],claims:[],unknowns:[],decision:'ANALYSIS_COMPLETE'};

function agentEnv(t,replies,options={}){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0203-agent-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const sm=new State(dir);sm.saveProject({project_id:'DG-LONG',project_name:'long',design:{active_revision:'A'},requirements:[],bom:[],findings:[],gate:{current_stage:'Gate 1',status:'OPEN'}},0);
  const queue=[...replies],requests=[];
  const runtime=new Agent(sm,async req=>{requests.push(req);const next=queue.shift();if(typeof next==='function')return next(req);if(!next)throw Error('unexpected model request');return next;},options);
  return {dir,sm,runtime,requests};
}

function riskDefinition({severity=8,occurrence=3,detection=3}={}){
  return {items:[{item_id:'I-1',function:'retain part',failure_modes:[{failure_mode_id:'FM-1',effect:'part separates',cause:'joint weak',severity,occurrence,detection,controls:['fixture']}]}],requirement_links:[{failure_mode_id:'FM-1',requirement_id:'REQ-1'}]};
}
async function businessProject(t,id='DG-BIZ',risk=riskDefinition()){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0203-biz-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const orchestrator=new Orchestrator(null,{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
  await orchestrator.runReviewPipeline({projectId:id,stage:'Gate 2',requirements:[{req_id:'REQ-1',text:'Joint shall retain part',verification_method:'physical test',acceptance_criteria:'No separation'}],designParams:{process:'CNC',material:'6061',internalCornerRadius:2},dfmea:risk});
  return {dir,orchestrator,workflow};
}
function writeEvidence(dir,name='test.txt',content='measured test evidence') {const f=path.join(dir,name);fs.writeFileSync(f,content);return f;}

// A. No default cumulative token hard stop.
test('default Agent run continues and completes after reported cumulative usage exceeds legacy 180000 tokens',async t=>{
  const e=agentEnv(t,[call('update_plan',plan,{total_tokens:100000}),call('read_project',{}, {total_tokens:100000}),call('finish_task',finish,{total_tokens:100000})]);
  const id=e.runtime.start('DG-LONG','long task').run_id;const result=await e.runtime.settled('DG-LONG',id);
  assert.equal(result.status,'COMPLETED');assert(result.reported_tokens>180000);assert.equal(e.requests.length,3);
});

test('shared specialist/negotiation accounting does not stop merely because legacy 180000 token total is exceeded',async t=>{
  const e=agentEnv(t,[]);const run=e.runtime.start('DG-LONG','specialist budget test');e.runtime.cancel('DG-LONG',run.run_id);await e.runtime.settled('DG-LONG',run.run_id);
  const r=e.runtime.load('DG-LONG',run.run_id);r.status='RUNNING';r.reported_tokens=190000;e.runtime.save(r);
  const controller=new AbortController();let calls=0;e.runtime.model=async()=>{calls++;return {message:{content:'ok'},usage:{total_tokens:50000}};};
  await e.runtime.specialistRequest(r,controller,{messages:[{role:'user',content:'x'}],tools:[]});
  assert.equal(calls,1);assert(r.reported_tokens>180000);
});

// B. Output limit and truncation recovery.
test('model transport omits max_tokens by default and safely regenerates a truncated tool call before returning it',async()=>{
  const bodies=[];let n=0;const client=new Client(()=>({baseUrl:'https://example.test/v1',model:'m',apiKey:'k',modelRequestTimeoutMs:5000}),async(_url,opts)=>{bodies.push(JSON.parse(opts.body));n++;return {ok:true,json:async()=>n===1?{choices:[{finish_reason:'length',message:{tool_calls:[{id:'bad',type:'function',function:{name:'read_project',arguments:'{"bro'}}]}}]}:{choices:[{finish_reason:'tool_calls',message:{tool_calls:[{id:'good',type:'function',function:{name:'read_project',arguments:'{}'}}]}}],usage:{total_tokens:9}}};});
  const response=await client.call({messages:[{role:'user',content:'read'}],tools:[{type:'function',function:{name:'read_project',parameters:{type:'object'}}}]});
  assert.equal(Object.hasOwn(bodies[0],'max_tokens'),false);assert.equal(n,2);assert.equal(response.message.tool_calls[0].function.arguments,'{}');assert.equal(response.telemetry.length_recoveries,1);
});

test('explicit model max output config is actually sent and plain text length truncation is continued in a bounded way',async()=>{
  const bodies=[];let n=0;const client=new Client(()=>({baseUrl:'https://example.test/v1',model:'m',apiKey:'k',maxOutputTokens:4096,maxLengthRecoveryAttempts:2}),async(_url,opts)=>{bodies.push(JSON.parse(opts.body));n++;return {ok:true,json:async()=>n===1?{choices:[{finish_reason:'length',message:{content:'Part A'}}]}:{choices:[{finish_reason:'stop',message:{content:' Part B'}}],usage:{total_tokens:8}}};});
  const response=await client.call({messages:[{role:'user',content:'write'}],tools:[]});
  assert.equal(bodies[0].max_tokens,4096);assert.equal(response.message.content,'Part A Part B');assert.equal(n,2);
});

// C. Runtime controls report distinct reasons and persist resumable state.
test('run timeout is distinct from token budget and leaves resumable state',async t=>{
  const waiting=async({signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));
  const e=agentEnv(t,[waiting],{maxDurationMs:20});const id=e.runtime.start('DG-LONG','timeout').run_id;const r=await e.runtime.settled('DG-LONG',id);
  assert.equal(r.status,'RUN_TIMEOUT');assert.equal(r.stop_reason,'RUN_DURATION_LIMIT');assert.equal(r.resumable,true);
});

test('repeated no-progress calls stop with NO_PROGRESS rather than generic budget exceeded',async t=>{
  const same=call('read_project',{});const e=agentEnv(t,[call('update_plan',plan),same,same,same],{maxToolSteps:20,maxModelRequests:20});const id=e.runtime.start('DG-LONG','loop').run_id;const r=await e.runtime.settled('DG-LONG',id);
  assert(['NO_PROGRESS','FAILED'].includes(r.status));assert.notEqual(r.status,'BUDGET_EXCEEDED');
});

// D/E. Immutable test execution records and plan separation through business APIs.
test('design change invalidates old execution and resubmitting old DFMEA JSON cannot restore verification',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-BASE');let p=orchestrator.stateManager.getProject('DG-BASE');
  p=workflow.setDfmeaVerificationPlan('DG-BASE',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'physical test',acceptance_criteria:'No separation'}]},p.version);
  const evidence=workflow.addEvidence('DG-BASE',writeEvidence(dir),p.version).evidence;p=orchestrator.stateManager.getProject('DG-BASE');
  p=workflow.recordDfmeaTest('DG-BASE',{test_id:'T-1',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',actual_result:'No separation',reviewer:'R1',completed_at:'2026-09-09T01:00:00.000Z',evidence_id:evidence.evidence_id},p.version);
  let review=await orchestrator.runReviewPipeline({projectId:'DG-BASE',stage:'Gate 3'});assert.equal(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'VERIFIED');
  const oldUpload={...riskDefinition(),verification_tests:[{test_id:'T-1',status:'PASS',failure_mode_ids:['FM-1'],actual_result:'No separation',reviewer:'R1',completed_at:'2026-09-09T01:00:00.000Z',evidence_id:evidence.evidence_id,baseline_fingerprint:'client-old'}]};
  await orchestrator.runReviewPipeline({projectId:'DG-BASE',stage:'Gate 3',designParams:{internalCornerRadius:4}});
  review=await orchestrator.runReviewPipeline({projectId:'DG-BASE',stage:'Gate 3',dfmea:oldUpload});
  assert.notEqual(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'VERIFIED');
  assert.equal(orchestrator.stateManager.getProject('DG-BASE').dfmea_test_records.length,1);
});

test('adding a retest never changes risk-definition baseline or verification-plan version',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-RETEST');let p=orchestrator.stateManager.getProject('DG-RETEST');
  p=workflow.setDfmeaVerificationPlan('DG-RETEST',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);
  const riskHash=p.dfmea_baseline_hash,planVersion=p.dfmea_verification_plan.version;const ev=workflow.addEvidence('DG-RETEST',writeEvidence(dir,'r.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-RETEST');
  p=workflow.recordDfmeaTest('DG-RETEST',{test_id:'T-F',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'FAILED',actual_result:'Separated',reviewer:'R',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  p=workflow.recordDfmeaTest('DG-RETEST',{test_id:'T-R',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',retest_of:'T-F',actual_result:'No separation',reviewer:'R2',completed_at:'2026-09-09T02:00:00Z',evidence_id:ev.evidence_id},p.version);
  assert.equal(p.dfmea_baseline_hash,riskHash);assert.equal(p.dfmea_verification_plan.version,planVersion);
});

test('unrelated PASS, including repeated submission, cannot clear an earlier FAILED execution',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-UNREL');let p=orchestrator.stateManager.getProject('DG-UNREL');
  p=workflow.setDfmeaVerificationPlan('DG-UNREL',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-UNREL',writeEvidence(dir,'u.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-UNREL');
  p=workflow.recordDfmeaTest('DG-UNREL',{test_id:'T-F',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'FAILED',actual_result:'Separated',reviewer:'R',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  p=workflow.recordDfmeaTest('DG-UNREL',{test_id:'T-P',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',actual_result:'No separation',reviewer:'R2',completed_at:'2026-09-09T02:00:00Z',evidence_id:ev.evidence_id},p.version);
  assert.throws(()=>workflow.recordDfmeaTest('DG-UNREL',{test_id:'T-P',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',actual_result:'No separation',reviewer:'R2',completed_at:'2026-09-09T02:00:00Z',evidence_id:ev.evidence_id},p.version),/already|已存在|不可覆盖/i);
  const review=await orchestrator.runReviewPipeline({projectId:'DG-UNREL',stage:'Gate 3'});assert.equal(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'RISK_REOPENED');
});

test('qualified linked retest closes the original failure and restores the DFMEA professional check',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-CLOSE');let p=orchestrator.stateManager.getProject('DG-CLOSE');
  p=workflow.setDfmeaVerificationPlan('DG-CLOSE',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-CLOSE',writeEvidence(dir,'c.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-CLOSE');
  p=workflow.recordDfmeaTest('DG-CLOSE',{test_id:'T-F',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'FAILED',actual_result:'Separated',reviewer:'R',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  p=workflow.recordDfmeaTest('DG-CLOSE',{test_id:'T-R',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',retest_of:'T-F',actual_result:'No separation',reviewer:'R2',completed_at:'2026-09-09T02:00:00Z',evidence_id:ev.evidence_id},p.version);
  const review=await orchestrator.runReviewPipeline({projectId:'DG-CLOSE',stage:'Gate 3'});assert.equal(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'VERIFIED');assert.equal(review.checks.find(x=>x.check_id==='PROF-DFMEA').status,'PASS');
});

// F. Residual risk acceptance is separate from test PASS.
test('high residual risk remains Gate-blocking after PASS until an applicable acceptance record is added',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-HIGH',riskDefinition({severity:10,occurrence:10,detection:10}));let p=orchestrator.stateManager.getProject('DG-HIGH');
  p=workflow.setDfmeaVerificationPlan('DG-HIGH',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-HIGH',writeEvidence(dir,'h.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-HIGH');
  p=workflow.recordDfmeaTest('DG-HIGH',{test_id:'T-P',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',actual_result:'No separation',reviewer:'R',completed_at:'2026-09-09T02:00:00Z',evidence_id:ev.evidence_id},p.version);
  let review=await orchestrator.runReviewPipeline({projectId:'DG-HIGH',stage:'Gate 3'});assert(review.professional_capabilities.dfmea.result.residual_risk_acceptance_gaps.includes('FM-1'));assert.notEqual(review.checks.find(x=>x.check_id==='PROF-DFMEA').status,'PASS');
  p=orchestrator.stateManager.getProject('DG-HIGH');p=workflow.acceptResidualRisk('DG-HIGH',{failure_mode_id:'FM-1',reason:'Controlled use under supervised validation',responsible_person:'Chief Reviewer',conditions:'Local design freeze only',follow_up_actions:['Production release requires independent sign-off']},p.version);
  review=await orchestrator.runReviewPipeline({projectId:'DG-HIGH',stage:'Gate 3'});assert.equal(review.professional_capabilities.dfmea.result.residual_risk_acceptance_gaps.length,0);assert.equal(review.checks.find(x=>x.check_id==='PROF-DFMEA').status,'PASS');
});

// G. Capability isolation and evidence support validity.
test('invalid ergonomics input is isolated and does not erase completed DFMEA result',async t=>{
  const {orchestrator}=await businessProject(t,'DG-ISO');const p=orchestrator.stateManager.getProject('DG-ISO');p.professional_applicability={ergonomics:'APPLICABLE',dfmea:'APPLICABLE',cmf:'NOT_APPLICABLE'};p.product={category:'handheld'};p.design={...p.design,weightG:100,cogOffsetMm:10,gripSection:'0x20',targetPopulation:'adult',populationSource:'brief',gripPosture:'neutral',operationForceN:1,operationDurationS:10};orchestrator.stateManager.saveProject(p,p.version);
  const review=await orchestrator.runReviewPipeline({projectId:'DG-ISO',stage:'Gate 3'});assert(review.professional_capabilities.ergonomics.status==='NOT_EVALUATED_RUNTIME_ERROR');assert(review.professional_capabilities.dfmea);
});

test('failed, planned, stale or invalid test records never appear as current valid evidence support paths',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-GRAPH');let p=orchestrator.stateManager.getProject('DG-GRAPH');p=workflow.setDfmeaVerificationPlan('DG-GRAPH',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-GRAPH',writeEvidence(dir,'g.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-GRAPH');p=workflow.recordDfmeaTest('DG-GRAPH',{test_id:'T-F',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'FAILED',actual_result:'Separated',reviewer:'R',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  const graph=EvidenceGraph.fromProject(p,{projectsDir:orchestrator.stateManager.projectsDir}).snapshot();assert(!graph.edges.some(e=>e.from==='TEST:T-F'&&e.relation==='VERIFIES'&&e.data?.valid_support===true));assert(graph.edges.some(e=>e.from==='TEST:T-F'&&e.data?.historical_trace===true));
});

test('legacy migration preserves original test status/history instead of converting it to a passing current record',async t=>{
  const {orchestrator,workflow}=await businessProject(t,'DG-MIG');let p=orchestrator.stateManager.getProject('DG-MIG');p.dfmea.verification_tests=[{test_id:'LEG-1',status:'FAILED',failure_mode_ids:['FM-1'],revision:'A',actual_result:'Separated',reviewer:'Old',completed_at:'2026-09-01T00:00:00Z'}];orchestrator.stateManager.saveProject(p,p.version);
  const migrated=workflow.migrateProject('DG-MIG');assert.equal(migrated.dfmea_test_records.find(x=>x.test_id==='LEG-1').source_status,'FAILED');assert.equal(migrated.dfmea_test_records.find(x=>x.test_id==='LEG-1').status,'FAILED');
});

const RuntimeConfig=require('../backend/runtime_config');

test('legacy runtime config migrates historical 180000 hard default to disabled null budget while preserving explicit opt-in budgets',()=>{
  const migrated=RuntimeConfig.normalize({maxTokens:180000});
  assert.equal(migrated.cumulativeTokenBudgetEnabled,false);assert.equal(migrated.cumulativeTokenBudget,null);
  const voluntary=RuntimeConfig.normalize({cumulativeTokenBudgetEnabled:true,cumulativeTokenBudget:250000});
  assert.equal(voluntary.cumulativeTokenBudgetEnabled,true);assert.equal(voluntary.cumulativeTokenBudget,250000);
  assert.throws(()=>RuntimeConfig.normalize({cumulativeTokenBudgetEnabled:true,cumulativeTokenBudget:Infinity}),/正整数|预算/i);
});

test('user cancellation keeps checkpoint and the same run can resume to completion without resetting cumulative usage',async t=>{
  let waitingStarted;const started=new Promise(r=>waitingStarted=r);
  const waiting=({signal})=>new Promise((resolve,reject)=>{waitingStarted();signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true});});
  const e=agentEnv(t,[waiting,call('update_plan',plan,{total_tokens:50}),call('read_project',{}, {total_tokens:50}),call('finish_task',finish,{total_tokens:50})]);
  const id=e.runtime.start('DG-LONG','cancel-resume').run_id;await started;e.runtime.cancel('DG-LONG',id);let r=await e.runtime.settled('DG-LONG',id);
  assert.equal(r.status,'CANCELLED');assert.equal(r.stop_reason,'USER_CANCELLED');const usedBefore=r.reported_tokens;
  e.runtime.resume('DG-LONG',id);r=await e.runtime.settled('DG-LONG',id);assert.equal(r.status,'COMPLETED');assert(r.reported_tokens>=usedBefore);assert.equal(r.run_id,id);
});

test('a timed-out run can resume from its checkpoint after runtime duration is reconfigured',async t=>{
  let first=true;const waiting=({signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));
  const e=agentEnv(t,[req=>{if(first){first=false;return waiting(req);}return call('update_plan',plan);},call('update_plan',plan),call('read_project',{}),call('finish_task',finish)],{maxDurationMs:20});
  const id=e.runtime.start('DG-LONG','timeout-resume').run_id;let r=await e.runtime.settled('DG-LONG',id);assert.equal(r.status,'RUN_TIMEOUT');
  e.runtime.configure({maxDurationMs:2000,maxToolSteps:20,maxModelRequests:20});e.runtime.resume('DG-LONG',id);r=await e.runtime.settled('DG-LONG',id);assert.equal(r.status,'COMPLETED');assert.equal(r.run_id,id);
});

test('changing verification acceptance criteria creates plan v2, keeps raw old records immutable, and reevaluates old results/failures',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-PLANV');let p=orchestrator.stateManager.getProject('DG-PLANV');
  p=workflow.setDfmeaVerificationPlan('DG-PLANV',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-PLANV',writeEvidence(dir,'pv.txt'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-PLANV');
  p=workflow.recordDfmeaTest('DG-PLANV',{test_id:'PV-F',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'FAILED',actual_result:'Separated',reviewer:'R1',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  const rawBefore=structuredClone(p.dfmea_test_records[0]);p=workflow.setDfmeaVerificationPlan('DG-PLANV',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No movement over 500 N'}],change_reason:'Tightened load criterion'},p.version);
  assert.equal(p.dfmea_verification_plan.version,2);assert.equal(p.dfmea_verification_plan_history.length,1);assert.deepEqual(p.dfmea_test_records[0],rawBefore);
  const review=await orchestrator.runReviewPipeline({projectId:'DG-PLANV',stage:'Gate 3'});assert.equal(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'RISK_REOPENED');
});

test('tampering a registered evidence file invalidates current support even if registration timestamps remain',async t=>{
  const {dir,orchestrator,workflow}=await businessProject(t,'DG-TAMPER');let p=orchestrator.stateManager.getProject('DG-TAMPER');
  p=workflow.setDfmeaVerificationPlan('DG-TAMPER',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-1'],method:'test',acceptance_criteria:'No separation'}]},p.version);const ev=workflow.addEvidence('DG-TAMPER',writeEvidence(dir,'tamper.txt','original'),p.version).evidence;p=orchestrator.stateManager.getProject('DG-TAMPER');
  p=workflow.recordDfmeaTest('DG-TAMPER',{test_id:'TP-1',plan_item_id:'VP-1',failure_mode_ids:['FM-1'],status:'PASS',actual_result:'No separation',reviewer:'R',completed_at:'2026-09-09T01:00:00Z',evidence_id:ev.evidence_id},p.version);
  fs.writeFileSync(path.join(orchestrator.stateManager.projectsDir,'evidence','DG-TAMPER',ev.sha256),'tampered');
  const graph=EvidenceGraph.fromProject(orchestrator.stateManager.getProject('DG-TAMPER'),{projectsDir:orchestrator.stateManager.projectsDir}).snapshot();
  assert(!graph.edges.some(e=>e.from==='TEST:TP-1'&&e.relation==='VERIFIES'&&e.data?.valid_support===true));
  assert.throws(()=>workflow.freeze('DG-TAMPER',{review_id:'none',approved_by:'X',reason:'test'},orchestrator.stateManager.getProject('DG-TAMPER').version),/哈希|证据|冻结/i);
});
