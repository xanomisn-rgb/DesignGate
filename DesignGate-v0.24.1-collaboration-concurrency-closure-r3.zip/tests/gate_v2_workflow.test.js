const test=require('node:test');
const assert=require('node:assert/strict');
const {evaluateFormalGateV2}=require('../backend/gate/gate_v2');

function context(extra={}){return {stage:'Gate 3',revision:'B',project:{project_id:'DG-GATE',design:{active_revision:'B'},basis_hash:'basis-B',requirements:[{req_id:'REQ-1'}],verifications:[]},checks:[{check_id:'REQUIREMENT_BASELINE',status:'PASS',required_for_gate:1},{check_id:'VERIFY-REQ-1',status:'PASS',required_for_gate:3},{check_id:'PROF-DFMEA',status:'PASS',required_for_gate:3}],evidence_context:[{evidence_id:'EVD-1',integrity_status:'VERIFIED',provenance_status:'BOUND',current_revision_valid:true}],knowledge:{release:'K-1',fingerprint:'f'.repeat(64)},...extra};}

test('formal Gate v2 accepts only current bound evidence and emits every check family',()=>{
 const gate=evaluateFormalGateV2(context());
 assert.equal(gate.gate_engine_version,'v2');assert.equal(gate.decision,'PASS');assert.equal(gate.checks.length,10);assert.equal(gate.freeze_eligible,true);
});
test('formal Gate v2 fails closed and returns all blockers for missing provenance and an open critical risk',()=>{
 const gate=evaluateFormalGateV2(context({evidence_context:[{evidence_id:'EVD-1',integrity_status:'VERIFIED',provenance_status:'INCOMPLETE',current_revision_valid:false}],checks:[{check_id:'REQUIREMENT_BASELINE',status:'PASS',required_for_gate:1},{check_id:'VERIFY-REQ-1',status:'UNKNOWN',required_for_gate:3},{check_id:'PROF-DFMEA',status:'FAIL',required_for_gate:3,issue_ids:['DFMEA-FM-1']}]}));
 assert.equal(gate.decision,'REVISE');assert(gate.all_blockers.some(x=>x.check_id==='GATEV2-EVIDENCE_PROVENANCE_CHECK'));assert(gate.all_blockers.some(x=>x.check_id==='GATEV2-CRITICAL_RISK_CHECK'));assert.equal(gate.freeze_eligible,false);
});
