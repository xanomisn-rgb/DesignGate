const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto');
const State=require('../backend/project_state_manager'),Agent=require('../backend/agent_runtime'),Tools=require('../backend/agent_tools');
const Boundary=require('../backend/role_boundary'),Negotiation=require('../backend/negotiation_service'),Workflow=require('../backend/workflow_service');
const Assets=require('../backend/engineering_assets'),{projectContext}=require('../backend/context_projection');
const call=(name,args={})=>({message:{tool_calls:[{id:'call-'+name,type:'function',function:{name,arguments:JSON.stringify(args)}}]}});
const sample=()=>({project_id:'DG-ACTIONS',project_name:'合成测试项目',design:{active_revision:'A',process:'CNC',material:'6061',internalCornerRadius:1},requirements:[],bom:[{part_id:'BOM-1',part_name:'外壳',quantity:1,unit_cost:null}],evidence:[],findings:[]});
async function pending(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-actions-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const sm=new State(dir);sm.saveProject(sample(),0);
 const answers=[call('update_plan',{steps:['读取项目','检查工程','提出变更'],reason:'测试'}),call('propose_change',{title:'内角调整',reason:'待验证',assumptions:[],design_patch:{internalCornerRadius:2}})];
 const runtime=new Agent(sm,async()=>answers.shift());const run=runtime.start('DG-ACTIONS','保持轻盈轮廓');await runtime.settled('DG-ACTIONS',run.run_id);return {sm,runtime,id:run.run_id};}
test('remembered rejection persists verbatim, retains design and survives Revision',async t=>{
 const {sm,runtime,id}=await pending(t),before=sm.getProject('DG-ACTIONS');runtime.approve('DG-ACTIONS',id,false,{reason:'不要加粗悬臂',remember:true});
 const p=sm.getProject('DG-ACTIONS');assert.deepEqual(p.design,before.design);assert.equal(p.memory.design_intent.rejection_constraints[0].text,'不要加粗悬臂');
 new Workflow(sm).newRevision('DG-ACTIONS',{revision:'B',reason:'下一轮'},p.version);
 assert.equal(sm.getProject('DG-ACTIONS').memory.design_intent.rejection_constraints[0].source_run,id);
});
test('one-run rejection does not silently change project memory',async t=>{
 const {sm,runtime,id}=await pending(t),before=sm.getProject('DG-ACTIONS');runtime.approve('DG-ACTIONS',id,false,{reason:'本次不采用'});
 assert.deepEqual(sm.getProject('DG-ACTIONS'),before);assert.equal(runtime.get('DG-ACTIONS',id).draft.rejection.remembered,false);
});
test('invalid feedback and stale remembered rejection cannot write',async t=>{
 const {sm,runtime,id}=await pending(t);assert.throws(()=>runtime.approve('DG-ACTIONS',id,false,{remember:true}),/理由/);
 const p=sm.getProject('DG-ACTIONS');sm.saveProject(p,p.version);assert.throws(()=>runtime.approve('DG-ACTIONS',id,false,{reason:'保持轮廓',remember:true}),/VERSION_CONFLICT/);
 assert(!sm.getProject('DG-ACTIONS').memory);
});
test('crash after remembering rejection recovers without replaying write',async t=>{
 const {sm,runtime,id}=await pending(t),save=runtime.save.bind(runtime);runtime.save=()=>{throw Error('simulated crash');};
 assert.throws(()=>runtime.approve('DG-ACTIONS',id,false,{reason:'约束',remember:true}),/crash/);runtime.save=save;
 const restored=new Agent(sm,async()=>{}).get('DG-ACTIONS',id);assert.equal(restored.draft.status,'REJECTED');assert.equal(sm.getProject('DG-ACTIONS').version,2);
});
test('geometry projection strips coordinate arrays without altering source',async()=>{
 const p=sample();p.version=1;p.design.cad_geometry={display_mesh:{positions:Array(90000).fill(4),source_sha256:'a'.repeat(64),unit:'mm'}};
 const r=await Tools.execute('read_project',{}, {project:p});assert.equal(r.design.cad_geometry.display_mesh.triangle_count,10000);
 assert(!JSON.stringify(r).includes('positions'));assert.equal(p.design.cad_geometry.display_mesh.positions.length,90000);
});
test('A02 cannot execute manufacturing tools even by directly forged call',()=>{
 assert.throws(()=>Boundary.execute('A02','read_cad_summary',{},{}),/ROLE_TOOL_DENIED/);
 assert.throws(()=>Boundary.execute('A06','screen_role_design',{},{}),/ROLE_TOOL_DENIED/);
});
test('role knowledge access is checked at execution, not only in prompt',()=>{
 const kb=new (require('../backend/knowledge_service'))(),record=kb.records.find(r=>r.kind==='process_reference');
 assert.throws(()=>Boundary.execute('A02','read_role_knowledge',{record_id:record.id},{validate:Tools.validate}),/ROLE_KNOWLEDGE_DENIED/);
 assert.equal(Boundary.execute('A03','read_role_knowledge',{record_id:record.id},{validate:Tools.validate}).id,record.id);
});
test('role context isolates CAD and previous role memories',()=>{
 const p=sample();p.design.cad_geometry={secret_geometry:1};
 const r=Boundary.context('A02',p,[],[{role:'A03',position:'private'},{role:'A02',position:'own'}]);assert(!r.project.design.cad_geometry);assert.equal(r.role_memory.length,1);assert.equal(r.role_memory[0].position,'own');
});
test('specialist tools execute with attributable results and cannot leak payload to next role',async()=>{
 const p=sample();p.version=1;p.design.cad_geometry={secret_geometry:1};let n=0;
 const result=await Negotiation.negotiate({topic:'取舍',evidence_ids:['OBS-1'],options:[{name:'A',patch:{}},{name:'B',patch:{internalCornerRadius:2}}]},
 {project:p,observations:[{id:'OBS-1',tool:'screen_design',output:{counts:{failed:0}}}],screen:Tools.screen,validate:Tools.validate,onProgress:()=>{},request:async req=>{
   n++;if(n===1)return call('read_cad_summary');
   if(n===3)assert(!req.messages[1].content.includes('secret_geometry'));
   return call('submit_specialist_review',{position:'有界立场',response_to_previous:'回应',preferred_option:'A',risks:['待验证'],unresolved:['待供应商确认'],evidence_ids:n===2?['ROLE-A03-1']:['OBS-1']});
 }});assert.equal(result.transcript[0].tool_events[0].tool,'read_cad_summary');assert.equal(result.transcript[0].tool_events[0].output.fresh_measurement,false);assert.equal(n,4);
});
test('record package preserves null prices, has valid checksums, and never claims release',()=>{
 const p=sample();p.version=1;const files=Assets.buildAssets(p,[],1),manifest=JSON.parse(files['MANIFEST.json']);
 assert.equal(JSON.parse(files['02_BOM_Revision.json']).bom[0].unit_cost,null);assert.equal(manifest.external_release,false);
 for(const entry of manifest.entries)assert.equal(crypto.createHash('sha256').update(files[entry.name]).digest('hex'),entry.sha256);
 assert.equal(JSON.parse(files['03_Parameter_Plan.json']).status,'NO_SUPPORTED_APPROVED_PARAMETERS');
 assert.equal(Assets.zipAssets(files).subarray(0,2).toString(),'PK');
});
test('stale / cross-project asset requests fail closed',()=>{
 const p=sample();p.version=1;assert.throws(()=>Assets.buildAssets(p,[],2),/VERSION_CONFLICT/);
 assert.throws(()=>Assets.buildAssets(p,[{project_id:'DG-OTHER'}],1),/Cross-project/);
});
test('CAD plan exports only current supported approved numeric changes',()=>{
 const p=sample();p.design.internalCornerRadius=2;p.agent_changes=[{revision:'A',draft_id:'D',diff:[{entity:'design',field:'internalCornerRadius',old_value:1,new_value:2}]}];
 assert.equal(Assets.parameterPlan(p).changes[0].unit,'mm');p.design.internalCornerRadius=3;assert.throws(()=>Assets.parameterPlan(p),/changed/);
});
