const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const WebSocket = require('ws');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

function once(socket) {
  return new Promise((resolve, reject) => {
    socket.once('message', bytes => resolve(JSON.parse(bytes.toString('utf8'))));
    socket.once('error', reject);
  });
}

test('authorized project WebSocket receives a compact command event rather than a project snapshot', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-websocket-sync-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple' });
  store.createProject({ project_id: 'DG-WS-001', project_name: 'Shared Lamp' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const login = await fetch(`http://127.0.0.1:${server.address().port}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const socket = new WebSocket(`ws://127.0.0.1:${server.address().port}/api/projects/DG-WS-001/events`, { headers: { authorization: `Bearer ${login.token}` } });
  t.after(() => socket.close());
  const connected = await once(socket);
  assert.equal(connected.type, 'CONNECTED');
  const eventPromise = once(socket);
  await fetch(`http://127.0.0.1:${server.address().port}/api/projects/DG-WS-001/commands`, { method: 'POST', headers: { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' }, body: JSON.stringify({ command_id: 'CMD-WS-1', idempotency_key: 'idem-ws-1', project_id: 'DG-WS-001', command_type: 'UPDATE_BOM_ITEM', base_project_version: 1, entity_type: 'BOM_ITEM', entity_id: 'P-03', base_entity_version: 0, payload: { part_name: 'Housing' } }) });
  const event = await eventPromise;
  assert.equal(event.type, 'BOM_ITEM_UPDATED');
  assert.equal(event.entity_id, 'P-03');
  assert.equal(Object.hasOwn(event, 'project'), false);

  const memberEventPromise = Promise.race([
    once(socket),
    new Promise((_, reject) => setTimeout(() => reject(new Error('MEMBER_EVENT_TIMEOUT')), 1000))
  ]);
  await fetch(`http://127.0.0.1:${server.address().port}/api/projects/DG-WS-001/members`, { method: 'POST', headers: { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' }, body: JSON.stringify({ user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }) });
  const memberEvent = await memberEventPromise;
  assert.equal(memberEvent.type, 'MEMBER_ADDED');
  assert.equal(memberEvent.entity_id, 'USER-B');
});
