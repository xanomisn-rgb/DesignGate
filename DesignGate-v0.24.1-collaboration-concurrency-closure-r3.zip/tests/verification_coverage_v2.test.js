const {test}=require('node:test');
const assert=require('node:assert/strict');
const {computeCoverage}=require('../backend/verification/coverage');

test('verification coverage distinguishes absent plan, planned coverage, execution, and current valid PASS',()=>{
 const report=computeCoverage({requirements:[{req_id:'REQ-1'},{req_id:'REQ-2'}],plans:[{plan_item_id:'P-1',requirement_ids:['REQ-1']}],tests:[{test_id:'T-1',plan_item_id:'P-1',status:'PASS',current_valid:true}]});
 assert.equal(report.by_requirement['REQ-1'].status,'CURRENT_VALIDATED');
 assert.equal(report.by_requirement['REQ-2'].status,'NO_VERIFICATION_PLAN');
 assert.equal(report.summary.current_validated,1);
 assert.equal(report.summary.no_verification_plan,1);
});
