const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');

test('owner transfer is atomic and the last project owner cannot leave', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-owner-transfer-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-OWNER-001', project_name: 'Shared Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-OWNER-001', { user_id: 'USER-B', role_id: 'TEACHER_REVIEWER' }, { user_id: 'USER-A' });

  store.transferOwner('DG-OWNER-001', 'USER-B', { user_id: 'USER-A' });
  assert.equal(store.getMembership('DG-OWNER-001', 'USER-B').role_id, 'PROJECT_OWNER');
  assert.equal(store.getMembership('DG-OWNER-001', 'USER-A').role_id, 'TEACHER_REVIEWER');
  assert.throws(() => store.leaveProject('DG-OWNER-001', { user_id: 'USER-B' }), /LAST_OWNER_CANNOT_LEAVE/);
});
