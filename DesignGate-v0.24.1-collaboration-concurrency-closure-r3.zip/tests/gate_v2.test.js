const {test}=require('node:test');
const assert=require('node:assert/strict');
const {closureValid,evaluateGateV2}=require('../backend/gate/gate_v2');

test('Gate v2 rejects a closure basis that names no test or evaluation record',()=>{
 assert.equal(closureValid({status:'PASS',closure_basis:{revision:'B',baseline_hash:'base',test_ids:[],evidence_ids:['EVD-2'],rule_version:'DG-1'}},'B'),false);
});

test('Gate v2 rejects non-string execution references in an otherwise complete closure basis',()=>{
 assert.equal(closureValid({status:'PASS',closure_basis:{revision:'B',baseline_hash:'base',test_ids:[null],evidence_ids:['EVD-2'],rule_version:'DG-1'}},'B'),false);
});

test('Gate v2 rejects non-string evidence references in an otherwise complete closure basis',()=>{
 assert.equal(closureValid({status:'PASS',closure_basis:{revision:'B',baseline_hash:'base',test_ids:['T-2'],evidence_ids:[null],rule_version:'DG-1'}},'B','base'),false);
});

test('Gate v2 rejects a closure basis when the current Revision is empty',()=>{
 assert.equal(closureValid({status:'PASS',closure_basis:{revision:'',baseline_hash:'base',test_ids:['T-2'],evidence_ids:['EVD-2'],rule_version:'DG-1'}},'','base'),false);
});

test('Gate v2 does not close an issue with a PASS bound to an older baseline',()=>{
 const result=evaluateGateV2({stage:'Gate 3',revision:'B',baseline_hash:'current-base',prior_issues:[{issue_id:'RISK-1',status:'OPEN'}],checks:[{check_id:'PROF-DFMEA',status:'PASS',required_for_gate:3,issue_ids:['RISK-1'],closure_basis:{revision:'B',baseline_hash:'old-base',test_ids:['T-2'],evidence_ids:['EVD-2'],rule_version:'DG-1'}}]});
 assert.equal(result.decision,'HOLD');assert.equal(result.issues[0].status,'OPEN');assert.equal(result.blocking_reasons[0].reason,'PASS_WITHOUT_CURRENT_CLOSURE_BASIS');
});

test('Gate v2 only closes its mapped issue with current closure evidence and otherwise lists every blocker',()=>{
 const prior=[{issue_id:'PROF-DFMEA-INCOMPLETE',status:'OPEN'},{issue_id:'UNRELATED-RISK',status:'OPEN'}];
 const incomplete=evaluateGateV2({stage:'Gate 3',revision:'B',baseline_hash:'base',prior_issues:prior,checks:[{check_id:'PROF-DFMEA',status:'PASS',required_for_gate:3,issue_ids:['PROF-DFMEA-INCOMPLETE'],closure_basis:{revision:'B',baseline_hash:'base',test_ids:['T-2'],evidence_ids:[],rule_version:'DG-1'}}]});
 assert.equal(incomplete.decision,'HOLD');
 assert.equal(incomplete.issues.find(row=>row.issue_id==='PROF-DFMEA-INCOMPLETE').status,'OPEN');
 assert.ok(incomplete.blocking_reasons.some(row=>row.issue_id==='UNRELATED-RISK'));
 const resolved=evaluateGateV2({stage:'Gate 3',revision:'B',baseline_hash:'base',prior_issues:prior,checks:[{check_id:'PROF-DFMEA',status:'PASS',required_for_gate:3,issue_ids:['PROF-DFMEA-INCOMPLETE'],closure_basis:{revision:'B',baseline_hash:'base',test_ids:['T-2'],evidence_ids:['EVD-2'],rule_version:'DG-1'}},{check_id:'OTHER',status:'PASS',required_for_gate:3,issue_ids:['UNRELATED-RISK'],closure_basis:{revision:'B',baseline_hash:'base',evaluation_ids:['EVAL-3'],evidence_ids:['EVD-3'],rule_version:'DG-1'}}]});
 assert.equal(resolved.decision,'PASS');
 assert.equal(resolved.issues.every(row=>row.status==='CLOSED'),true);
});
