const {test}=require('node:test');
const assert=require('node:assert/strict');
const {parseRequirements}=require('../backend/requirements/requirement_parser');
const {normalizeRequirements}=require('../backend/requirements/requirement_normalizer');
const {assessTestability}=require('../backend/requirements/testability');
const {detectRequirementConflicts}=require('../backend/requirements/conflict_detector');
const {buildTraceability}=require('../backend/requirements/traceability');

test('requirements retain source facts, normalize units and report ambiguity without silently making a hard gate',()=>{
 const parsed=parseRequirements([{req_id:'REQ-1',text:'Wall thickness shall be 2 mm.',priority:'HIGH',source_pointer:'brief:4'},{req_id:'REQ-2',text:'The enclosure should feel premium.',source_pointer:'brief:5'}]);
 const normalized=normalizeRequirements(parsed.requirements);
 assert.equal(normalized.requirements[0].normalized_constraint.comparator,'=');
 assert.equal(normalized.requirements[0].normalized_constraint.value,2);
 assert.equal(normalized.requirements[0].normalized_constraint.unit,'mm');
 assert.equal(normalized.requirements[0].hard_gate,false);
 const testability=assessTestability(normalized.requirements);
 assert.equal(testability.by_requirement['REQ-1'].status,'TESTABLE');
 assert.equal(testability.by_requirement['REQ-2'].status,'AMBIGUOUS_REQUIRES_REVIEW');
});

test('requirement conflicts and traceability retain all links and report dangling references',()=>{
 const requirements=[{requirement_id:'REQ-1',text:'Wall thickness shall be 2 mm.',normalized_constraint:{field:'wall_thickness',comparator:'=',value:2,unit:'mm'}},{requirement_id:'REQ-2',text:'Wall thickness shall be 3 mm.',normalized_constraint:{field:'wall_thickness',comparator:'=',value:3,unit:'mm'}}];
 const conflicts=detectRequirementConflicts(requirements);
 assert.equal(conflicts[0].status,'UNRESOLVED_REQUIRES_REVIEW');
 const trace=buildTraceability({requirements,decisions:[{decision_id:'DEC-1',requirement_ids:['REQ-1']}],risks:[{risk_id:'RISK-1',requirement_id:'REQ-1'}],plans:[{plan_item_id:'PLAN-1',requirement_ids:['REQ-1'],risk_ids:['RISK-1']}],tests:[{test_id:'TEST-1',plan_item_id:'PLAN-1',evidence_id:'EVD-1'}],evidence:[{evidence_id:'EVD-1'}]});
 assert.equal(trace.dangling_references.length,0);
 assert.ok(trace.edges.some(edge=>edge.from==='REQ:REQ-1'&&edge.to==='DEC:DEC-1'));
 assert.ok(trace.edges.some(edge=>edge.from==='EVD:EVD-1'&&edge.to==='TEST:TEST-1'));
});
