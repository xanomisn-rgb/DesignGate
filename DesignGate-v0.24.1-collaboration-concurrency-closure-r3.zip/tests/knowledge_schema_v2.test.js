const {test}=require('node:test');
const assert=require('node:assert/strict');
const {migrateKnowledgeV2}=require('../backend/knowledge/knowledge_migrator_v2');
const {detectConflicts}=require('../backend/knowledge/knowledge_conflict_service');
const {buildRetrievalTrace}=require('../backend/knowledge/retrieval_trace');

const source={id:'SRC-1',publisher:'Example',title:'Controlled source',url:'https://example.invalid/source',locator:'p. 1',checked_on:'2026-09-09'};
const record={id:'MAT-1',title:'Material 1',kind:'material',domain:'materials',claim:'Screening-only value.',scope:{supplier:'Maker',grade:'M1',process:'injection_molding'},limitations:['Not a release decision.'],source_ids:['SRC-1'],properties:[{property:'HDT',value:102,unit:'degC',condition:'1.80 MPa',method:'ISO 75'}]};

test('knowledge v2 migration is non-destructive, idempotent, preserves IDs and reports identity conflicts',()=>{
  const input={curated_records:[record],expansion_records:[{...record,title:'Material 1 revised'}],sources:[source],quarantine:[{id:'Q-1',title:'Historical note',status:'HISTORICAL_REVIEW_REQUIRED',reason:'review'}]};
  const first=migrateKnowledgeV2(input),second=migrateKnowledgeV2(input);
  assert.deepEqual(second,first);
  assert.equal(first.records[0].knowledge_id,'MAT-1');
  assert.equal(first.records[0].engineering_release,false);
  assert.equal(first.records[0].hard_gate,false);
  assert.equal(first.quarantine[0].knowledge_id,'Q-1');
  assert.equal(first.migration_report.identity_conflicts.length,1);
  assert.equal(first.migration_report.identity_conflicts[0].status,'IDENTITY_CONFLICT');
  assert.equal(first.records[0].migration_variants.length,1);
});

test('knowledge conflict identity keeps conditioned measurements distinct and retrieval trace excludes quarantine',()=>{
  const a={...record,id:'MAT-A',claim:{property:'HDT',value:102,unit:'degC',conditions:'1.80 MPa',test_method:'ISO 75'},entity:{manufacturer:'Maker',model:'M1'}};
  const b={...a,id:'MAT-B',claim:{property:'HDT',value:122,unit:'degC',conditions:'0.45 MPa',test_method:'ISO 75'}};
  const conflicts=detectConflicts([a,b]);
  assert.equal(conflicts.filter(row=>row.conflict_type==='SOURCE_CONFLICT').length,0);
  const trace=buildRetrievalTrace({query:'hdt',records:[a,b],sources:[source],quarantine:[{knowledge_id:'Q-1',title:'quarantine'}]});
  assert.deepEqual(trace.returned_knowledge_ids,['MAT-A','MAT-B']);
  assert.equal(trace.quarantine_excluded_ids[0],'Q-1');
  assert.match(trace.trace_id,/^KTRACE-/);
});

test('unstructured narrative statements are not fabricated into a shared engineering-claim conflict',()=>{
 const a={...record,id:'REF-A',claim:'Narrative guidance A',entity:{manufacturer:'Maker',model:null,material_family:null}};
 const b={...record,id:'REF-B',claim:'Narrative guidance B',entity:{manufacturer:'Maker',model:null,material_family:null}};
 assert.equal(detectConflicts([a,b]).filter(row=>row.conflict_type==='SOURCE_CONFLICT').length,0);
});
