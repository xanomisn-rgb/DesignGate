const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('different requirement and BOM entities can commit from the same project snapshot', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-parallel-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const commands = new CommandService({ store });
  store.createProject({ project_id: 'DG-TEAM-003', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-TEAM-003', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }, { user_id: 'USER-A' });

  const requirement = commands.execute({
    command_id: 'CMD-REQ-003', idempotency_key: 'idem-req-003', project_id: 'DG-TEAM-003',
    command_type: 'UPDATE_REQUIREMENT', base_project_version: 1, entity_type: 'REQUIREMENT', entity_id: 'REQ-003', base_entity_version: 0,
    payload: { req_id: 'REQ-003', text: 'Lamp shall support outdoor rain protection' }
  }, { user_id: 'USER-A' });
  const bom = commands.execute({
    command_id: 'CMD-BOM-003', idempotency_key: 'idem-bom-003', project_id: 'DG-TEAM-003',
    command_type: 'UPDATE_BOM_ITEM', base_project_version: 1, entity_type: 'BOM_ITEM', entity_id: 'P-03', base_entity_version: 0,
    payload: { part_id: 'P-03', part_name: 'Housing', material: 'PC+ABS' }
  }, { user_id: 'USER-B' });

  assert.equal(requirement.status, 'APPLIED');
  assert.equal(bom.status, 'APPLIED');
  const project = store.getProjectForActor('DG-TEAM-003', 'USER-A');
  assert.equal(project.requirements[0].req_id, 'REQ-003');
  assert.equal(project.bom[0].part_id, 'P-03');
  assert.equal(project.version, 4);
});
