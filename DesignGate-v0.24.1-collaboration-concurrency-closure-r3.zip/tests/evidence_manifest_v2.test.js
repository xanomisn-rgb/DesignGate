const {test}=require('node:test');
const assert=require('node:assert/strict');
const os=require('os');
const fs=require('fs');
const path=require('path');
const State=require('../backend/project_state_manager');
const Workflow=require('../backend/workflow_service');
const {createRevisionManifest,diffManifests}=require('../backend/evidence/manifest_service');

test('revision manifest preserves evidence history but makes carry-forward an explicit pending decision',()=>{
 const prior=createRevisionManifest({project_id:'P-1',revision:'A',evidence:[{evidence_id:'EVD-1',sha256:'a'.repeat(64),filename:'report.pdf',verification_scope:'FILE_INTEGRITY_ONLY'}]});
 const current=createRevisionManifest({project_id:'P-1',revision:'B',prior_manifest:prior,evidence:[]});
 assert.equal(current.entries[0].applicability,'HISTORICAL_PENDING_CARRY_FORWARD_REVIEW');
 assert.equal(current.entries[0].current_valid_support,false);
 assert.equal(diffManifests(prior,current).carry_forward_review_required.length,1);
});

test('new revision keeps design inputs while invalidating current approval and verification state',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-revision-'));const state=new State(dir),workflow=new Workflow(state);
 state.saveProject({project_id:'DG-REV',project_name:'P',design:{active_revision:'A',material:'ABS',process:'injection_molding',internalCornerRadius:2,cad_geometry:{volume:1}},requirements:[],bom:[],findings:[],gate:{current_stage:'Gate 1',status:'OPEN'}},0);
 const revised=workflow.newRevision('DG-REV',{revision:'B',reason:'controlled geometry change'},state.getProject('DG-REV').version);
 assert.equal(revised.design.active_revision,'B');
 assert.equal(revised.design.internalCornerRadius,2);
 assert.equal(revised.design.cad_geometry,undefined);
 assert.deepEqual(revised.design_snapshots[0].design.cad_geometry,{volume:1});
 assert.equal(revised.verifications.length,0);
 assert.equal(revised.evidence_manifest.revision,'B');
});
