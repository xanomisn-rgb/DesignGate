const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createTrainingSession,submitTrainingAttempt,reviewTrainingAttempt,listPublicTrainingTasks}=require('../training/training_kernel');

test('training exposes exactly four public task templates without answer or Gold payloads',()=>{
 const tasks=listPublicTrainingTasks();
 assert.equal(tasks.length,4);
 assert.deepEqual(tasks.map(task=>task.task_id),['PUBLIC-DFMEA-INTRO-1','PUBLIC-CAD-EVIDENCE-1','PUBLIC-RETEST-TRACE-1','PUBLIC-GATE-BOUNDARY-1']);
 assert(tasks.every(task=>Object.hasOwn(task,'answer_key')===false&&Object.hasOwn(task,'gold')===false));
});

test('training session rejects an unregistered task identifier',()=>{
 assert.throws(()=>createTrainingSession({session_id:'SESSION-X',learner_id:'LEARNER-X',project_id:'PROJECT-TRAIN-X',task_id:'GOLD-OR-INVENTED',engineering_state:{},started_at:'2026-09-10T00:00:00.000Z'}),/public training task/i);
});

test('training attempt is isolated from the supplied engineering state and never auto-approves a design',()=>{
 const engineeringState={project_id:'PROJECT-TRAIN-1',revision:'A',gate:{decision:'HOLD'},requirements:[{req_id:'REQ-1'}]};
 const before=structuredClone(engineeringState);
 const session=createTrainingSession({session_id:'SESSION-1',learner_id:'LEARNER-1',project_id:'PROJECT-TRAIN-1',task_id:'PUBLIC-DFMEA-INTRO-1',engineering_state:engineeringState,started_at:'2026-09-10T00:00:00.000Z'});
 const attempt=submitTrainingAttempt({session,attempt_id:'ATTEMPT-1',observed_actions:[{type:'SUBMITTED_DRAFT'}],submitted_at:'2026-09-10T00:01:00.000Z'});
 assert.deepEqual(engineeringState,before);
 assert.equal(session.engineering_state_snapshot.gate.decision,'HOLD');
 assert.equal(attempt.status,'PENDING_INSTRUCTOR_REVIEW');
 assert.equal(Object.hasOwn(attempt,'gate_decision'),false);
 assert.equal(Object.hasOwn(attempt,'freeze_eligible'),false);
});

test('training attempt rejects a tampered engineering snapshot',()=>{
 const session=createTrainingSession({session_id:'SESSION-2',learner_id:'LEARNER-2',project_id:'PROJECT-TRAIN-2',task_id:'PUBLIC-DFMEA-INTRO-1',engineering_state:{revision:'A'},started_at:'2026-09-10T00:00:00.000Z'});
 session.engineering_state_snapshot.revision='B';
 assert.throws(()=>submitTrainingAttempt({session,attempt_id:'ATTEMPT-2',observed_actions:[],submitted_at:'2026-09-10T00:01:00.000Z'}),/snapshot integrity/i);
});

test('named instructor review records only a training outcome, never an engineering PASS',()=>{
 const session=createTrainingSession({session_id:'SESSION-3',learner_id:'LEARNER-3',project_id:'PROJECT-TRAIN-3',task_id:'PUBLIC-DFMEA-INTRO-1',engineering_state:{revision:'A'},started_at:'2026-09-10T00:00:00.000Z'});
 const attempt=submitTrainingAttempt({session,attempt_id:'ATTEMPT-3',observed_actions:[],submitted_at:'2026-09-10T00:01:00.000Z'});
 const review=reviewTrainingAttempt({attempt,reviewer_id:'INSTRUCTOR-1',outcome:'SATISFACTORY',rationale:'Observed a complete trace.',reviewed_at:'2026-09-10T00:02:00.000Z'});
 assert.equal(review.status,'TRAINING_REVIEWED');
 assert.equal(review.outcome,'SATISFACTORY');
 assert.equal(review.authority,'TRAINING_ONLY_NOT_ENGINEERING_APPROVAL');
 assert.equal(Object.hasOwn(review,'gate_decision'),false);
 assert.throws(()=>reviewTrainingAttempt({attempt,reviewer_id:'INSTRUCTOR-1',outcome:'PASS',rationale:'wrong semantic',reviewed_at:'2026-09-10T00:02:00.000Z'}),/outcome/i);
});
