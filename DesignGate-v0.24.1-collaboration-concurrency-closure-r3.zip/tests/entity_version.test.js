const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('a stale update to the same BOM entity is rejected rather than overwriting the current value', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-entity-version-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const commands = new CommandService({ store });
  store.createProject({ project_id: 'DG-TEAM-002', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-TEAM-002', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }, { user_id: 'USER-A' });

  commands.execute({
    command_id: 'CMD-ADD-P05', idempotency_key: 'idem-add-p05', project_id: 'DG-TEAM-002',
    command_type: 'UPDATE_BOM_ITEM', base_project_version: 1, entity_type: 'BOM_ITEM', entity_id: 'P-05', base_entity_version: 0,
    payload: { part_id: 'P-05', part_name: 'Lens', material: 'PC+ABS' }
  }, { user_id: 'USER-A' });

  const first = commands.execute({
    command_id: 'CMD-A-P05', idempotency_key: 'idem-a-p05', project_id: 'DG-TEAM-002',
    command_type: 'UPDATE_BOM_ITEM', base_project_version: 2, entity_type: 'BOM_ITEM', entity_id: 'P-05', base_entity_version: 1,
    payload: { material: 'PC+ABS FR' }
  }, { user_id: 'USER-A' });
  assert.equal(first.entity_version, 2);

  assert.throws(() => commands.execute({
    command_id: 'CMD-B-P05', idempotency_key: 'idem-b-p05', project_id: 'DG-TEAM-002',
    command_type: 'UPDATE_BOM_ITEM', base_project_version: 2, entity_type: 'BOM_ITEM', entity_id: 'P-05', base_entity_version: 1,
    payload: { material: 'PMMA' }
  }, { user_id: 'USER-B' }), error => error.code === 'ENTITY_VERSION_CONFLICT'
    && error.current_version === 2
    && error.expected_version === 1
    && error.current_snapshot.material === 'PC+ABS FR'
    && error.conflicting_fields.includes('material')
    && error.updated_by === 'USER-A'
    && !Number.isNaN(Date.parse(error.updated_at)));
});
