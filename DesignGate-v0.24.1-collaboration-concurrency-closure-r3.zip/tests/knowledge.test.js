const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs'),os=require('os'),path=require('path');
const Knowledge=require('../backend/knowledge_service');
const Tools=require('../backend/agent_tools');
const Citation=require('../backend/citation_verifier');
const Evidence=require('../backend/evidence_registry');
const Agent=require('../backend/agent_runtime');
const State=require('../backend/project_state_manager');
const kb=new Knowledge();
test('curated catalog remains valid while the governed expansion adds searchable records',()=>{
 assert(kb.records.length>kb.data.records.length);assert(kb.sources.length>=10);
 assert(kb.records.some(record=>record.id==='CELL-EVE-21700-50E'));
 assert(kb.records.some(record=>record.id==='STD-IEC 60529:1989+A1:1999+A2:2013'));
 assert.equal(new Set(kb.sources.map(s=>s.id)).size,kb.sources.length);
 for(const s of kb.sources){assert.equal(new URL(s.url).protocol,'https:');assert(s.locator);assert.match(s.checked_on,/^\d{4}-\d{2}-\d{2}$/);}
 for(const r of kb.data.records){assert(r.scope);assert(r.limitations.length);for(const p of r.properties||[]){assert(p.condition&&p.method&&p.unit);assert.equal(p.status,'TYPICAL_NOT_SPECIFICATION');}}
});
const queries=[['ABS 外壳注塑壁厚怎么选','REF-WALL-ABS'],['聚碳酸酯壁厚','REF-WALL-PC'],['聚甲醛注塑壁厚','REF-WALL-POM'],['加强筋太厚会缩痕吗','REF-RIB'],['PM-T2 纹理拔模角','REF-PM-T2'],['CNC 内角刀具可达性','REF-CNC'],['钣金折弯开裂','REF-BEND'],['6063 阳极氧化外观','MAT-AL-6063'],['TPU 90A 粉末柔性','MAT-SLS-TPU90'],['T65 XF 密度','MAT-T65']];
test('ten authored Chinese retrieval cases return expected card in top four',()=>{
 for(const [query,id] of queries)assert(kb.search(query).hits.some(h=>h.id===id),query);
});
test('unsupported topics honestly return no results and exclude legacy archive',()=>{
 const r=kb.search('脑电植入器寿命认证');assert.equal(r.total_matches,0);assert.equal(r.legacy_included,false);assert.equal(r.engineering_release,false);
});
test('material and process filters reject unrelated reference families',()=>{
 const r=kb.search('壁厚',{material:'聚碳酸酯',process:'注塑'});assert.deepEqual(r.hits.map(h=>h.id),['REF-WALL-PC']);
 assert.equal(kb.search('壁厚',{process:'cnc'}).total_matches,0);
});
test('longer grade names do not inherit base-grade material cards',()=>{
 for(const q of ['T65 XFA','T65 XF RE','T65 XF BBS910'])assert(!kb.search(q).hits.some(h=>h.id==='MAT-T65'),q);
 assert.throws(()=>kb.get('../../materials.json'),/未知/);
});
test('correct density conversion and distinct HDT load conditions survive full read',()=>{
 const r=kb.get('MAT-T65'),d=r.properties.find(p=>p.property==='density');assert.equal(d.value,1.13);assert.equal(d.raw_value/1000,d.value);
 const h=r.properties.filter(p=>p.property==='HDT');assert.deepEqual(h.map(p=>[p.value,p.condition]),[[102,'1.80 MPa'],[122,'0.45 MPa']]);
 assert(r.properties.find(p=>p.property==='flammability').condition.includes('0.85'));assert.equal(r.engineering_release,false);
});
test('unreviewed legacy material values are quarantined and not returned as evidence',()=>{
 for(const grade of ['MG47','2405','6061-T6','LSR 2670','58610']){const r=new Citation().verifyMaterialGrade(grade);assert.deepEqual(r.properties,{});assert.equal(r.tds_status,'LEGACY_UNREVIEWED');}
 assert.equal(new Evidence().getEvidence('MAT-PCABS-001').verified,false);
});
const context={process:'注塑',material:'ABS',supplier:'Protolabs'};
test('reference bounds retain explicit inch conversion and inclusive endpoints',()=>{
 const r=kb.get('REF-WALL-ABS').reference;assert.equal(r.min,1.143);assert.equal(r.max,3.556);
 for(const n of [r.min,2,r.max])assert.equal(kb.check('REF-WALL-ABS',n,'mm',context).status,'WITHIN_REFERENCE');
 for(const n of [1,4])assert.equal(kb.check('REF-WALL-ABS',n,'mm',context).status,'OUTSIDE_REFERENCE');
});
test('reference checks refuse unknown supplier, incompatible material, process or units',()=>{
 assert.equal(kb.check('REF-WALL-ABS',2,'mm',{process:'注塑',material:'ABS'}).status,'NEED_CONTEXT');
 assert.equal(kb.check('REF-WALL-ABS',2,'mm',{...context,material:'PC+ABS'}).status,'NOT_APPLICABLE');
 assert.equal(kb.check('REF-WALL-ABS',2,'mm',{...context,process:'cnc'}).status,'NOT_APPLICABLE');
 assert.equal(kb.check('REF-WALL-ABS',.1,'in',context).status,'UNIT_MISMATCH');
 assert.equal(kb.check('MAT-T65',102,'degC',{}).status,'NOT_EXECUTABLE');
});
test('texture-dependent reference demands the exact supplier texture code',()=>{
 const ctx={process:'injection_molding',supplier:'Protolabs'};
 assert.equal(kb.check('REF-PM-T2',5,'deg',ctx).status,'NEED_CONTEXT');
 assert.equal(kb.check('REF-PM-T2',5,'deg',{...ctx,texture:'PM-T1'}).status,'NOT_APPLICABLE');
 assert.equal(kb.check('REF-PM-T2',5,'deg',{...ctx,texture:'PM-T2'}).status,'WITHIN_REFERENCE');
});
test('knowledge tools reject non-finite values, extra arguments and file paths',async()=>{
 for(const value of [NaN,Infinity,-1])assert.throws(()=>Tools.validateCall('check_knowledge_reference',{record_id:'REF-RIB',value,unit:'ratio',context:{}}));
 assert.throws(()=>Tools.validateCall('read_knowledge',{record_id:'MAT-T65',file:'/etc/passwd'}));
 await assert.rejects(Tools.execute('read_knowledge',{record_id:'../materials.json'},{project:{}}));
});
test('actual Agent loop searches, reads and checks knowledge without changing saved project',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-kb-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const sm=new State(dir);sm.saveProject({project_id:'DG-KB',project_name:'知识集成测试',design:{active_revision:'A',process:'注塑',material:'ABS',nominalWall:2},requirements:[],bom:[]},0);
 const before=sm.getProject('DG-KB');
 const steps=[['update_plan',{steps:['定位壁厚资料','读取原厂条件','核对参考并说明限制'],reason:'验证资料接入'}],['search_knowledge',{query:'ABS 壁厚'}],['read_knowledge',{record_id:'REF-WALL-ABS'}],['check_knowledge_reference',{record_id:'REF-WALL-ABS',value:2,unit:'mm',context}],['finish_task',{summary:'假设采用 Protolabs 工艺，2 mm 落在 REF-WALL-ABS 建议范围；不代表工程放行。',evidence_ids:['OBS-4'],limitations:['供应商选择为本测试假设。']}]];
 let i=0;const runtime=new Agent(sm,async()=>{const [name,args]=steps[i++];return {message:{role:'assistant',tool_calls:[{id:'k'+i,type:'function',function:{name,arguments:JSON.stringify(args)}}]}};});
 const run=runtime.start('DG-KB','假设使用 Protolabs，核对 ABS 2 mm 壁厚');const result=await runtime.settled('DG-KB',run.run_id);
 assert.equal(result.status,'COMPLETED');assert.equal(result.events[3].output.status,'WITHIN_REFERENCE');assert.deepEqual(sm.getProject('DG-KB'),before);
 assert(result.events[2].output.sources[0].url.startsWith('https://www.protolabs.com/'));
});
