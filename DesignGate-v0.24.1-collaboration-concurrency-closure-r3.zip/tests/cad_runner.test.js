const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const {CadAnalysisRunner,assertSchema}=require('../backend/integrations/cad_analysis_runner');

test('CAD runner executes the existing OCP B-Rep analyzer through a bounded Node spawn',async()=>{
 const runner=new CadAnalysisRunner({timeout_ms:30000});
 const health=await runner.discoverBackend();assert.equal(health.backend,'OCP');assert.equal(health.pinned_ocp_version,'8.0.1.0.0');
 if(!health.available)return assert.equal(health.status,'OCP_ENVIRONMENT_UNAVAILABLE');
 const result=await runner.analyze({input_path:path.join(__dirname,'../samples/brep/plate_1_3mm.step'),params:{pull_direction:[0,0,1]}});
 assert.equal(result.analysis_status,'BREP_ANALYZED_PARTIAL');assert.equal(result.analyzer_backend,'OCP');assert.equal(result.file_sha256,'3a6a64ccfcc3ec7c0df7b57205d4f4fab1a12379011c67d5872e72f6368600a9');assert.equal(result.solid_count,1);
 assert.equal(result.thickness_oracle.global_mathematical_proof,false);assert.equal(result.undercut_oracle.global_mathematical_proof,false);
 assert.equal(result.assembly_analysis.status,'ASSEMBLY_NOT_APPLICABLE_REQUIRES_MULTIPLE_SOLIDS');
});

test('CAD runner rejects missing input before spawning a backend',async()=>{
 await assert.rejects(()=>new CadAnalysisRunner().analyze({input_path:path.join(__dirname,'missing.step')}),/CAD_INPUT_MISSING/);
});

test('CAD runner rejects negative topology counts in an otherwise shaped analyzer response',()=>{
 const output={schema_version:'1.0',analyzer_backend:'OCP',file_sha256:'a'.repeat(64),solid_count:-1,face_count:6,bounding_box:null,measurements:{},capabilities:[],limitations:[],sampling:{},analysis_status:'BREP_ANALYZED_PARTIAL'};
 assert.throws(()=>assertSchema(output),/CAD_OUTPUT_SCHEMA_INVALID/);
});

test('CAD runner rejects a non-JSON analyzer response',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-runner-invalid-json-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const input=path.join(dir,'part.step'),script=path.join(dir,'invalid.py');fs.writeFileSync(input,'ISO-10303-21;');fs.writeFileSync(script,"print('not json')");
 const runner=new CadAnalysisRunner({script_path:script});runner.discoverBackend=async()=>({available:true,python_bin:'python'});
 await assert.rejects(()=>runner.analyze({input_path:input}),/CAD_OUTPUT_INVALID_JSON/);
});

test('CAD runner propagates a nonzero analyzer exit as a failed analysis',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-runner-nonzero-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const input=path.join(dir,'part.step'),script=path.join(dir,'fail.py');fs.writeFileSync(input,'ISO-10303-21;');fs.writeFileSync(script,'import sys; sys.exit(7)');
 const runner=new CadAnalysisRunner({script_path:script});runner.discoverBackend=async()=>({available:true,python_bin:'python'});
 await assert.rejects(()=>runner.analyze({input_path:input}),/CAD_RUNNER_NONZERO_EXIT:7/);
});

test('CAD runner terminates an analyzer that exceeds its execution budget',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-runner-timeout-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const input=path.join(dir,'part.step'),script=path.join(dir,'slow.py');fs.writeFileSync(input,'ISO-10303-21;');fs.writeFileSync(script,'import time; time.sleep(2)');
 const runner=new CadAnalysisRunner({script_path:script,timeout_ms:25});runner.discoverBackend=async()=>({available:true,python_bin:'python'});
 await assert.rejects(()=>runner.analyze({input_path:input}),/CAD_RUNNER_TIMEOUT/);
});

test('CAD runner reports unavailable when every Python/OCP candidate fails discovery',async()=>{
 const runner=new CadAnalysisRunner();runner.candidates=()=>['definitely-not-a-python-executable'];
 const health=await runner.discoverBackend();
 assert.equal(health.available,false);assert.equal(health.status,'OCP_ENVIRONMENT_UNAVAILABLE');assert.equal(health.python_bin,null);
});

test('CAD runner refuses analysis when the discovered backend is unavailable',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-runner-unavailable-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const input=path.join(dir,'part.step');fs.writeFileSync(input,'ISO-10303-21;');
 const runner=new CadAnalysisRunner();runner.discoverBackend=async()=>({available:false,status:'OCP_VERSION_MISMATCH'});
 await assert.rejects(()=>runner.analyze({input_path:input}),/OCP_VERSION_MISMATCH/);
});

test('CAD runner rejects a structurally valid response bound to a different STEP hash',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-runner-hash-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const input=path.join(dir,'part.step'),script=path.join(dir,'wrong-hash.py');fs.writeFileSync(input,'ISO-10303-21;');
 const output={schema_version:'1.0',analyzer_backend:'OCP',file_sha256:'b'.repeat(64),solid_count:1,face_count:6,bounding_box:null,measurements:{},capabilities:[],limitations:[],sampling:{},analysis_status:'BREP_ANALYZED_PARTIAL'};fs.writeFileSync(script,`print(${JSON.stringify(JSON.stringify(output))})`);
 const runner=new CadAnalysisRunner({script_path:script});runner.discoverBackend=async()=>({available:true,python_bin:'python'});
 await assert.rejects(()=>runner.analyze({input_path:input}),/CAD_OUTPUT_FILE_HASH_MISMATCH/);
});
