const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

test('formal domain services do not import the local ProjectStateManager implementation', () => {
  const root = path.resolve(__dirname, '../..');
  for (const relative of ['backend/workflow_service.js', 'backend/agent_runtime.js', 'backend/orchestrator.js', 'backend/gate/gate_v2.js', 'backend/evidence/evidence_provenance_service.js']) {
    const source = fs.readFileSync(path.join(root, relative), 'utf8');
    assert.doesNotMatch(source, /require\(['"][^'"]*project_state_manager['"]\)/, relative);
  }
});
