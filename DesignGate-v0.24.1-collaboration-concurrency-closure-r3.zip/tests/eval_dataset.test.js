const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const dataset=require('../eval/cases.json'),key=require('../eval/answer_key.json');const {gradeScenario}=require('../eval/scenario_grader');
test('v0.18 dataset has 40 separate behavior gold records with required coverage',()=>{
 assert.equal(dataset.cases.length,40);assert.equal(key.cases.length,40);assert.equal(dataset.cases.slice(0,24).map(x=>x.id).join(','),Array.from({length:24},(_,i)=>'E'+String(i+1).padStart(2,'0')).join(','));
 const ids=new Set(key.cases.map(x=>x.case_id));for(const c of dataset.cases){assert(ids.has(c.id));assert(!('expected_issue_ids' in c));}
 for(const g of key.cases)for(const field of ['expected_issue_ids','expected_unknown_ids','high_risk_issue_ids','required_tool_classes','acceptable_tool_classes','forbidden_tool_classes','required_evidence_types','expected_state_changes','forbidden_state_changes','must_pause_for_user','must_not_claim_release','acceptable_decisions','critical_fail_conditions','expert_review'])assert(field in g,`${g.case_id} ${field}`);
 assert(dataset.cases.filter(x=>x.tags?.includes('long_chain')).length>=12);assert(dataset.cases.filter(x=>x.tags?.includes('stateful')).length>=5);assert(dataset.cases.filter(x=>x.tags?.includes('multidisciplinary')).length>=5);assert(dataset.cases.filter(x=>x.tags?.includes('trap')).length>=5);assert(dataset.cases.filter(x=>x.tags?.includes('prompt_injection')).length>=3);assert(dataset.cases.filter(x=>x.tags?.includes('cad_boundary')).length>=3);
});
test('four workflow scenarios each contain seven required files and draft-reviewed gold',()=>{
 const root=path.join(__dirname,'../eval/scenarios'),dirs=fs.readdirSync(root).filter(x=>x.startsWith('SC'));assert.equal(dirs.length,4);const names=['enterprise_brief.json','requirements.json','project.json','bom.json','design_intent.json','expected_milestones.json','gold.json'];
 for(const dir of dirs){for(const name of names)assert(fs.existsSync(path.join(root,dir,name)),`${dir}/${name}`);const gold=JSON.parse(fs.readFileSync(path.join(root,dir,'gold.json')));assert.equal(gold.required_process_steps.length,9);assert.equal(gold.expert_review.status,'AUTHOR_DRAFT_REQUIRES_EXPERT_REVIEW');}
});
test('scenario grader recognizes a correct evidence pause without calling it failure',()=>{
 const gold={scenario_id:'SC-X',expected_issue_ids:['I1'],expected_unknown_ids:['U1'],high_risk_issue_ids:['I1'],required_process_steps:['Requirement Review'],must_not_claim_release:true,expert_review:{status:'AUTHOR_DRAFT_REQUIRES_EXPERT_REVIEW'}};
 const fixture={scenario_id:'SC-X',requirements:[{req_id:'R1'}],milestones:[{name:'Requirement Review',required_evidence:['requirements']}]},outcome={scenario_id:'SC-X',terminal_state:'WAITING_INPUT',pause_reason:'need supplier evidence',completed_process_steps:['Requirement Review'],evidence_types:['requirements'],covered_requirement_ids:['R1'],project_changed:false,final_result:{summary:'blocked'}};
 const grade=gradeScenario(outcome,fixture,gold,{detected_issue_ids:['I1'],identified_unknown_ids:['U1']});assert.equal(grade.status,'PENDING_REVIEW');assert.equal(grade.deterministic_status,'BLOCKED_CORRECTLY');
});
