const {test}=require('node:test');
const assert=require('node:assert/strict');

test('professional capability contract rejects unsupported statuses and normalizes evidence fields',()=>{
  const {createCapabilityResult}=require('../backend/capability_contract');
  const result=createCapabilityResult({
    capability:'ergonomics.grip_assessment', status:'EVALUATED', method:'anthropometric_percentile_model',
    result:{fit:'COMPATIBLE'}, confidence:0.87, evidence_ids:['EVD-01'], source_ids:['SRC-01'], revision:'B.2'
  });
  assert.equal(result.status,'EVALUATED');
  assert.deepEqual(result.inputs,{});
  assert.throws(()=>createCapabilityResult({capability:'cmf.compatibility',status:'APPROVED_FOR_PRODUCTION'}),/capability status/i);
});

test('ergonomics service calculates a transparent static wrist moment and names its limitation',()=>{
  const ErgonomicsService=require('../backend/ergonomics_service');
  const result=new ErgonomicsService().assessGrip({
    mass_kg:0.65, cog_offset_mm:85, grip_section_mm:{width:42,depth:24},
    target_population:{percentile:'P50',sex:'mixed'}, posture:'power_grip', operation_force_n:3, duration_s:300
  },{revision:'B.2',evidence_ids:['EVD-ERG-01']});
  assert.equal(result.status,'EVALUATED');
  assert.equal(result.method,'static_wrist_moment_screen');
  assert.equal(result.result.static_wrist_moment_nm,0.542);
  assert.match(result.limitations.join(' '),/biomechanical/i);
});

test('CMF compatibility service never approves an unknown material-finish-environment combination',()=>{
  const CMFService=require('../backend/cmf_service');
  const result=new CMFService().evaluateCompatibility({
    material:'PC+ABS', process:'injection_molding', finish:'uv_coating', environment:'alcohol_wipe'
  },{revision:'B.2'});
  assert.equal(result.status,'PARTIALLY_EVALUATED');
  assert.equal(result.result.compatibility,'UNKNOWN_REQUIRES_TEST');
  assert.equal(result.result.production_release,'HUMAN_APPROVAL_REQUIRED');
});

test('FMEA risk engine identifies a verification gap for an uncovered failure mode',()=>{
  const FMEAService=require('../backend/fmea_service');
  const result=new FMEAService().evaluate({
    items:[{item_id:'seal',function:'prevent ingress',failure_modes:[{failure_mode_id:'FM-LEAK',effect:'water ingress',cause:'low gasket compression',severity:9,occurrence:3,detection:6,controls:['gasket compression']}]}],
    requirement_links:[{requirement_id:'REQ-IP67',failure_mode_id:'FM-LEAK'}], verification_tests:[]
  },{revision:'B.2'});
  assert.equal(result.status,'PARTIALLY_EVALUATED');
  assert.equal(result.result.failure_modes[0].rpn,162);
  assert.deepEqual(result.result.verification_gaps,['FM-LEAK']);
});

test('evidence graph preserves traceability from user evidence through requirement to decision',()=>{
  const EvidenceGraph=require('../backend/evidence_graph');
  const graph=new EvidenceGraph();
  graph.addNode({id:'USR-1',type:'USER_EVIDENCE',data:{source:'field interview'}});
  graph.addNode({id:'REQ-ONE-HAND',type:'REQUIREMENT',data:{text:'Button must be operable one-handed'}});
  graph.addNode({id:'DEC-01',type:'DECISION',data:{selected_concept:'C03'}});
  graph.addEdge({from:'USR-1',to:'REQ-ONE-HAND',relation:'SUPPORTS'});
  graph.addEdge({from:'REQ-ONE-HAND',to:'DEC-01',relation:'INFORMS'});
  assert.deepEqual(graph.trace('DEC-01').node_ids,['DEC-01','REQ-ONE-HAND','USR-1']);
});
