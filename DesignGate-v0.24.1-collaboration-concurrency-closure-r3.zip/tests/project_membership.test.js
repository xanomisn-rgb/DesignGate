const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');

test('a team project has an owner membership and remains invisible to non-members', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-members-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });

  store.createProject({ project_id: 'DG-TEAM-001', project_name: 'Portable Outdoor Power Lamp' }, { user_id: 'USER-A' });

  assert.equal(store.getMembership('DG-TEAM-001', 'USER-A').role_id, 'PROJECT_OWNER');
  assert.deepEqual(store.listProjectIds('USER-A'), ['DG-TEAM-001']);
  assert.deepEqual(store.listProjectIds('USER-B'), []);
  assert.throws(() => store.getProjectForActor('DG-TEAM-001', 'USER-B'), /PROJECT_SCOPE_DENIED/);
});
