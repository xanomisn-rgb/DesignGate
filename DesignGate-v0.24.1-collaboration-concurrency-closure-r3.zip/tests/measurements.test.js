const {test}=require('node:test'),assert=require('node:assert/strict');
const Tools=require('../backend/agent_tools'),Boundary=require('../backend/role_boundary');
const {projectContext}=require('../backend/context_projection'),Assets=require('../backend/engineering_assets');
const {observation}=require('../backend/measurement_observation');
function geometry(){return {source_sha256:'a'.repeat(64),surface_measurements:{status:'SAMPLED_BREP_ONLY',source_sha256:'a'.repeat(64),
 coverage:{global_minimum_proven:false},samples:Array.from({length:100},(_,i)=>({sample_id:'S'+i,face_id:i+1,normal_chord_mm:1.3+i}))}};}
test('model context uses bounded source-linked samples and retains original',()=>{
 const g=geometry(),r=projectContext(g);assert.equal(r.surface_measurements.samples.length,6);
 assert.equal(r.surface_measurements.samples[0].normal_chord_mm,1.3);assert.equal(g.surface_measurements.samples.length,100);
 assert.equal(r.surface_measurements.samples_truncated,true);
});
test('hypothetical screen does not claim old CAD is the patched geometry',()=>{
 const p={project_id:'DG-MEASURE',version:1,design:{active_revision:'A',cad_geometry:geometry()},requirements:[],bom:[]};
 const r=Tools.screen(p,{nominalWall:2});assert.equal(r.geometry_observation.status,'ORIGINAL_GEOMETRY_NOT_PATCH_VALIDATED');
 assert.equal(r.geometry_observation.formal_gate_pass,false);assert.equal(p.design.nominalWall,undefined);
});
test('mismatched geometry hash suppresses measurement observations',()=>{
 const g=geometry();g.source_sha256='wrong';assert.equal(observation(g).status,'GEOMETRY_SOURCE_MISMATCH');
});
test('measurement bound to an older revision is explicitly stale',()=>{
 const g=geometry();g.measurement_revision='A';g.surface_measurements.measurement_revision='A';
 assert.equal(observation(g,false,{revision:'B'}).status,'GEOMETRY_REVISION_MISMATCH');
});
test('measurement without a revision cannot satisfy a revision-bound observation',()=>{
 const g=geometry();
 const r=observation(g,false,{revision:'B'});
 assert.equal(r.status,'GEOMETRY_REVISION_UNBOUND');
 assert.equal(r.expected_revision,'B');
});
test('only A03 can invoke a fresh selected-CAD callback',async()=>{
 let calls=0;const context={validate:Tools.validate,measureSelectedCAD:async()=>{calls++;return {cad_analysis:geometry()};}};
 assert.throws(()=>Boundary.execute('A02','measure_selected_cad',{},context),/ROLE_TOOL_DENIED/);
 assert.throws(()=>Boundary.execute('A06','measure_selected_cad',{},context),/ROLE_TOOL_DENIED/);
 const r=await Boundary.execute('A03','measure_selected_cad',{},context);assert.equal(calls,1);
 assert.equal(r.result.cad_analysis.source_sha256,'a'.repeat(64));
});
test('CAD tool cannot introduce a path and missing callback fails closed',()=>{
 const context={validate:Tools.validate,measureSelectedCAD:()=>assert.fail('must not execute')};
 assert.throws(()=>Boundary.execute('A03','measure_selected_cad',{path:'/unselected.step'},context));
 assert.throws(()=>Boundary.execute('A03','measure_selected_cad',{}, {validate:Tools.validate}),/UNAVAILABLE/);
});
test('failed fresh CAD measurement remains an error',async()=>{
 await assert.rejects(()=>Boundary.execute('A03','measure_selected_cad',{}, {validate:Tools.validate,measureSelectedCAD:async()=>{throw Error('file missing');}}),/file missing/);
});
test('export includes complete samples while model projection stays bounded',()=>{
 const p={project_id:'DG-MEASURE',version:1,design:{active_revision:'A',cad_geometry:geometry()}};
 const f=Assets.buildAssets(p,[],1);assert.equal(JSON.parse(f['06_BRep_Surface_Samples.json']).measurement.samples.length,100);
 assert(JSON.parse(f['MANIFEST.json']).entries.some(e=>e.name==='06_BRep_Surface_Samples.json'));
});
test('overlay distinguishes measured raw values from explicitly unmeasured faces',async()=>{
 const {overlayData}=await import('../src/measurement_overlay.mjs'),hash='b'.repeat(64);
 const g={source_sha256:hash,display_mesh:{source_sha256:hash,positions:Array(18).fill(0),face_ids:[1,2]},surface_measurements:{source_sha256:hash,
  coverage:{face_coverage:[{face_id:1,state:'MEASURED'},{face_id:2,state:'UNMEASURED',reason:'FACE_LIMIT_EXCEEDED'}]},
  samples:[{sample_id:'F1',face_id:1,point_mm:[0,0,0],normal_chord_mm:1.2,signed_draft_deg:2}]}};
 const o=overlayData(g);assert.equal(o.faces.get(1).measurement_state,'MEASURED');assert.equal(o.faces.get(1).engineering_status,'NOT_EVALUATED');
 assert.equal(o.faces.get(2).measurement_state,'UNMEASURED');assert.notDeepEqual(o.faces.get(1).colour,o.faces.get(2).colour);
});
test('CAD face reference fails closed when requested revision is absent',async()=>{
 const {faceReference}=await import('../src/measurement_overlay.mjs'),hash='c'.repeat(64);
 const g={source_sha256:hash,display_mesh:{source_sha256:hash,positions:Array(9).fill(0),face_ids:[1]},
  surface_measurements:{source_sha256:hash,coverage:{face_coverage:[{face_id:1,state:'MEASURED'}]},
   samples:[{sample_id:'F1',face_id:1,point_mm:[0,0,0],normal_chord_mm:1.2}]}};
 assert.equal(faceReference(g,hash,1,'B'),null);
});
test('legacy face samples are partial measurements, never implicit threshold passes',async()=>{
 const {overlayData}=await import('../src/measurement_overlay.mjs'),hash='d'.repeat(64);
 const g={source_sha256:hash,display_mesh:{source_sha256:hash,positions:Array(9).fill(0),face_ids:[1]},
  surface_measurements:{source_sha256:hash,samples:[{sample_id:'F1',face_id:1,point_mm:[0,0,0],signed_draft_deg:4}]}};
 const face=overlayData(g).faces.get(1);
 assert.equal(face.measurement_state,'PARTIALLY_MEASURED');
 assert.equal(face.engineering_status,'NOT_EVALUATED');
});
test('face label explicitly distinguishes unmeasured coverage from raw values',async()=>{
 const {faceDisplayLabel}=await import('../src/measurement_overlay.mjs');
 assert.match(faceDisplayLabel({id:7,measurement_state:'UNMEASURED',unmeasured_reason:'TIME_LIMIT_REACHED'}),/UNMEASURED.*TIME_LIMIT_REACHED/);
 assert.match(faceDisplayLabel({id:8,measurement_state:'MEASURED',minimum:1.25,occluded:2,engineering_status:'NOT_EVALUATED'}),/1\.25°.*NOT_EVALUATED/);
});
test('overlay rejects surface samples from a different geometry revision',async()=>{
 const {overlayData}=await import('../src/measurement_overlay.mjs'),hash='e'.repeat(64),g={source_sha256:hash,measurement_revision:'B',
  display_mesh:{source_sha256:hash,positions:Array(9).fill(0),face_ids:[1]},
  surface_measurements:{source_sha256:hash,measurement_revision:'A',samples:[]}};
 assert.equal(overlayData(g),null);
});
test('observation rejects internally inconsistent geometry and sample revisions',()=>{
 const g=geometry();g.measurement_revision='B';g.surface_measurements.measurement_revision='A';
 assert.equal(observation(g).status,'GEOMETRY_REVISION_MISMATCH');
});
