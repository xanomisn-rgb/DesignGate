const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),path=require('path'),os=require('os'),vm=require('vm');
const {createRequire}=require('module');
const main=path.join(__dirname,'../main.js');
function bootstrap(t,fetchImpl){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-ipc-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const handlers=new Map();
 const electron={app:{requestSingleInstanceLock:()=>true,getPath:()=>dir,whenReady:()=>({then:()=>{}}),on:()=>{},quit:()=>{}},ipcMain:{handle:(name,handler)=>handlers.set(name,handler)},safeStorage:{isEncryptionAvailable:()=>false}};
 const local=createRequire(main),Client=local('./connectors/agent_model_client');
 class TestTransport extends Client{constructor(getConfig){super(getConfig,fetchImpl);}}
 const ctx=vm.createContext({require:name=>name==='electron'?electron:name==='./connectors/agent_model_client'?TestTransport:local(name),__dirname:path.dirname(main),console:{warn:()=>{},error:()=>{}},process,fetch:fetchImpl,AbortController,URL,setTimeout,clearTimeout,Buffer});
 vm.runInContext(fs.readFileSync(main,'utf8'),ctx);
 return {ctx,handlers,invoke:(name,...args)=>handlers.get('designGate:'+name)({},...args)};
}
function response(name,args){return {ok:true,json:async()=>({choices:[{message:{tool_calls:[{id:'call-'+name,type:'function',function:{name,arguments:JSON.stringify(args)}}]}}]})};}
test('desktop IPC starts native model tool cycle and returns durable run to renderer',async t=>{
 const queue=[response('update_plan',{steps:['读取项目','检查需求','总结结果'],reason:'按目标执行'}),response('inspect_requirements',{}),response('finish_task',{summary:'当前项目尚无需求基线。',evidence_ids:['OBS-2'],limitations:['尚无测试证据。']})];
 const e=bootstrap(t,async()=>queue.shift());e.invoke('saveProject',{project_id:'DG-IPC',project_name:'集成测试'});
 await assert.rejects(()=>e.invoke('agent',{action:'start',projectId:'DG-IPC',input:{goal:'检查资料'}}),/API Key/);
 e.invoke('saveConfig',{baseUrl:'https://example.test/v1',model:'tool-model',apiKey:'TEST-ONLY-NOT-A-CREDENTIAL'});
 assert(!('apiKey'in e.invoke('getConfig')));
 const r=await e.invoke('agent',{action:'start',projectId:'DG-IPC',input:{goal:'检查缺少的工程资料'}});
 e.ctx.id=r.run_id;await vm.runInContext("agentRuntime.settled('DG-IPC',id)",e.ctx);
 const final=await e.invoke('agent',{action:'get',projectId:'DG-IPC',runId:r.run_id});assert.equal(final.status,'COMPLETED');assert(final.events[1].output.baseline_missing);
 assert(!JSON.stringify(final).includes('TEST-ONLY-NOT-A-CREDENTIAL'));assert.equal(e.invoke('getProject','DG-IPC').version,1);
});
test('desktop IPC prevents mutation while active and stop reaches transport abort',async t=>{
 const e=bootstrap(t,async(url,{signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('cancel')),{once:true})));
 e.invoke('saveProject',{project_id:'DG-IPC'});e.invoke('saveConfig',{baseUrl:'https://example.test/v1',model:'test',apiKey:'test'});
 const r=await e.invoke('agent',{action:'start',projectId:'DG-IPC',input:{goal:'检查设计'}});
 await assert.rejects(()=>e.invoke('workspace',{action:'profile',projectId:'DG-IPC',input:{project_name:'unexpected'}}),/停止任务/);
 await assert.rejects(()=>e.invoke('runPipeline',{projectId:'DG-IPC'}),/停止任务/);
 await e.invoke('agent',{action:'cancel',projectId:'DG-IPC',runId:r.run_id});e.ctx.id=r.run_id;await vm.runInContext("agentRuntime.settled('DG-IPC',id)",e.ctx);
 assert.equal((await e.invoke('agent',{action:'get',projectId:'DG-IPC',runId:r.run_id})).status,'CANCELLED');
});
test('Agent panel renders task states and safely escapes model proposal text',()=>{
 const ctx=vm.createContext({console,setTimeout,clearTimeout,structuredClone,crypto:require('crypto').webcrypto});
 for(const file of ['components.js','agent_collaboration.js','agent_panel.js','app.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../src',file),'utf8'),ctx);
 vm.runInContext(`ui.project={project_id:'DG-UI',design:{active_revision:'A'}};ui.view='advisor';agentPanelState('DG-UI').run={run_id:'RUN-x',status:'WAITING_APPROVAL',steps:3,rounds:3,revision:'A',goal:'检查',plan:['读取'],events:[],draft:{proposal:{title:'<script>bad()</script>',reason:'候选方案',assumptions:['待验证'],design_patch:{material:'PC'}}}}`,ctx);
 const html=vm.runInContext('viewShell(ui)',ctx);assert(html.includes('审查后合并提案'));assert(html.includes('拒绝 / 保留原状'));assert(!html.includes('<script>bad()'));assert(html.includes('&lt;script&gt;'));
 vm.runInContext("agentPanelState('DG-UI').run.status='RUNNING'",ctx);assert(vm.runInContext('viewAgentPanel(ui)',ctx).includes('停止任务'));
});
