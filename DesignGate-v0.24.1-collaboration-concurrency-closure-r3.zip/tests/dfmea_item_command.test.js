const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('DFMEA item command creates a current risk definition and versioned verification plan', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-dfmea-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-DFMEA-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const result = commands.execute({ command_id: 'CMD-DFMEA-001', idempotency_key: 'idem-dfmea-001', project_id: 'DG-DFMEA-001', command_type: 'DFMEA_ITEM_CREATE', entity_type: 'DFMEA_ITEM', entity_id: 'DFI-001', base_project_version: 1, base_entity_version: 0, payload: { function: 'Retain battery', failure_modes: [{ failure_mode_id: 'FM-001', effect: 'Battery release', cause: 'Latch fracture', severity: 9, occurrence: 3, detection: 4 }], verification_plan_item: { plan_item_id: 'VP-001', failure_mode_ids: ['FM-001'], method: 'Latch cycle test', acceptance_criteria: 'No fracture in 100 cycles' } } }, { user_id: 'USER-A' });
  assert.equal(result.event_type, 'DFMEA_ITEM_CREATED');
  const state = store.getProjectForActor('DG-DFMEA-001', 'USER-A');
  assert.equal(state.dfmea.items[0].item_id, 'DFI-001');
  assert.equal(state.dfmea_verification_plan.items[0].plan_item_id, 'VP-001');
  assert.equal(state.dfmea_baseline_hash.length, 64);
});
