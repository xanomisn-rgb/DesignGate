const test=require('node:test');
const assert=require('node:assert/strict');
const {loadOpenApi}=require('../backend/http/openapi_contract');
const {REQUIRED}=require('../backend/http/routes/cad_routes');
test('checked-in OpenAPI contract parses and matches the implemented integration routes',()=>{
 const contract=loadOpenApi();assert.deepEqual(contract.paths.sort(),['/api/integrations/cad/upload','/api/integrations/health']);assert.deepEqual(contract.required.sort(),[...REQUIRED,'file'].sort());for(const status of [202,400,401,403,409,413,422,429,503])assert(contract.statuses.includes(status));assert.equal(contract.hasSecurity,true);
});
