const {test}=require('node:test');
const assert=require('node:assert/strict');
const Knowledge=require('../backend/knowledge_service');
const Tools=require('../backend/agent_tools');
const Boundary=require('../backend/role_boundary');

test('knowledge expansion exposes an exact EVE cell and a deterministic 2S2P calculation',()=>{
  const kb=new Knowledge();
  const hit=kb.search('EVE 50E 21700', {kind:'battery_cell',manufacturer:'EVE Energy',exact_model:'INR21700/50E'});
  assert.equal(hit.status,'OK');
  assert.equal(hit.hits[0].id,'CELL-EVE-21700-50E');
  const result=kb.calculateBatteryPack({manufacturer:'EVE Energy',exact_model:'INR21700/50E',ns:2,np:2});
  assert.equal(result.status,'CALCULATED');
  assert.equal(result.nominal_voltage_v,7.3);
  assert.equal(result.capacity_ah,10);
  assert.equal(result.energy_wh,73);
  assert.equal(result.current.status,'THEORETICAL_CELL_LIMIT_ONLY');
});

test('exact battery aliases rank the registered model and generic cell claims remain data gaps',()=>{
  const kb=new Knowledge();
  for(const [query,manufacturer,model,id] of [
    ['Molicel P45B','Molicel','INR-21700-P45B','CELL-MOLICEL-P45B'],
    ['Molicel P50B','Molicel','INR-21700-P50B','CELL-MOLICEL-P50B'],
    ['Molicel M65A','Molicel','INR-21700-M65A','CELL-MOLICEL-M65A']
  ]) {
    const found=kb.search(query,{kind:'battery_cell',manufacturer,exact_model:model});
    assert.equal(found.hits[0].id,id,query);
  }
  const generic=kb.search('21700 5000mAh',{kind:'battery_cell'});
  assert.equal(generic.status,'DATA_GAP');
  assert.deepEqual(generic.data_gaps,['manufacturer','exact_model']);
  assert.equal(kb.calculateBatteryPack({ns:2,np:2}).status,'DATA_GAP');
});

test('battery current remains theoretical until every system limiter is supplied',()=>{
  const kb=new Knowledge();
  const calculated=kb.calculateBatteryPack({manufacturer:'EVE Energy',exact_model:'INR21700/50E',ns:2,np:2,bms_limit_a:28,busbar_limit_a:31,wire_limit_a:25,connector_limit_a:24,fuse_limit_a:30,thermal_limit_a:20});
  assert.equal(calculated.current.status,'SYSTEM_LIMIT_IDENTIFIED');
  assert.equal(calculated.current.continuous_a,20);
  assert.equal(calculated.cycle_condition,'25 °C, manufacturer standard cycle');
  assert.equal(calculated.engineering_release,false);
});

test('standards are indexes and quarantine stays excluded from current evidence',()=>{
  const kb=new Knowledge();
  const standard=kb.get('STD-IEC 60529:1989+A1:1999+A2:2013');
  assert.equal(standard.kind,'standard_index');
  assert.equal(standard.verification_status,'INDEX_ONLY');
  assert.equal(standard.hard_gate,false);
  assert.equal(kb.check(standard.id,1,'mm',{}).status,'NOT_EXECUTABLE');
  const historic=kb.get('Q-HOSTAFORM-C9021-HIST');
  assert.equal(historic.authority,'QUARANTINE_DO_NOT_PROMOTE');
  assert.equal(historic.engineering_release,false);
});

test('agent tools expose governed filters and a read-only battery calculation',async()=>{
  Tools.validateCall('search_knowledge',{query:'EVE 50E',kind:'battery_cell',manufacturer:'EVE Energy',exact_model:'INR21700/50E'});
  await assert.rejects(Tools.execute('calculate_battery_pack',{manufacturer:'EVE Energy',exact_model:'INR21700/50E',ns:2.5,np:2},{project:{}}),/positive integer/);
  const result=await Tools.execute('calculate_battery_pack',{manufacturer:'EVE Energy',exact_model:'INR21700/50E',ns:2,np:2},{project:{}});
  assert.equal(result.status,'CALCULATED');
  assert.equal(result.engineering_release,false);
});

test('specialist boundaries can read only their governed knowledge kinds',()=>{
  const project={project_id:'DG-KNOWLEDGE',version:1,design:{active_revision:'A'},requirements:[]};
  const quality=Boundary.context('A05',project,[]);
  assert(quality.knowledge_index.some(record=>record.kind==='standard_index'));
  const method=Boundary.execute('A05','read_role_knowledge',{record_id:'REF-FMEA-AIAG-VDA'},{project,candidates:[],validate:Tools.validate});
  assert.equal(method.kind,'method_reference');
  assert.throws(()=>Boundary.execute('A02','read_role_knowledge',{record_id:'CELL-EVE-21700-50E'},{project,candidates:[],validate:Tools.validate}),/ROLE_KNOWLEDGE_DENIED/);
});
