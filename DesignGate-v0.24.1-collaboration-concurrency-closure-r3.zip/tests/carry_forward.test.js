const {test}=require('node:test');const assert=require('node:assert/strict');
const {decideCarryForward}=require('../backend/evidence/carry_forward_service');
test('revision carry-forward fails closed without reviewed applicability proof',()=>{
 const result=decideCarryForward({evidence_id:'EVD-1',from_revision:'A',to_revision:'B',changed_design_fields:['material'],impacted_requirement_ids:['REQ-1'],impacted_failure_mode_ids:['FM-1']});
 assert.equal(result.status,'RETEST_REQUIRED');assert.equal(result.evidence_id,'EVD-1');
 assert.throws(()=>decideCarryForward({evidence_id:'EVD-1',from_revision:'A',to_revision:'A'}),/different/);
});
