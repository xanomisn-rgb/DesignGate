const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

function command(type, version, payload) {
  return { command_id: `CMD-TASK-${type}-${version}`, idempotency_key: `idem-task-${type}-${version}`, project_id: 'DG-TASK-001', command_type: type, entity_type: 'TASK', entity_id: 'TASK-001', base_project_version: 1, base_entity_version: version, payload };
}

test('task commands retain attribution, require a project member assignee, and never close engineering risks', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-task-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-TASK-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-TASK-001', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }, { user_id: 'USER-A' });

  const created = commands.execute(command('TASK_CREATE', 0, { title: 'Resolve finding F-018', target: { entity_type: 'FINDING', entity_id: 'F-018' }, assignee_id: 'USER-B', priority: 'HIGH' }), { user_id: 'USER-A' });
  assert.equal(created.event_type, 'TASK_CREATED');
  const assigned = commands.execute(command('TASK_ASSIGN', 1, { assignee_id: 'USER-A' }), { user_id: 'USER-B' });
  assert.equal(assigned.event_type, 'TASK_ASSIGNED');
  const updated = commands.execute(command('TASK_UPDATE', 2, { status: 'DONE', completion_note: 'Evidence requested; no risk closure asserted.' }), { user_id: 'USER-A' });
  assert.equal(updated.event_type, 'TASK_UPDATED');
  const task = store.getProjectForActor('DG-TASK-001', 'USER-A').tasks[0];
  assert.equal(task.assignee_id, 'USER-A');
  assert.equal(task.status, 'DONE');
  assert.equal(Object.hasOwn(task, 'risk_closed'), false);
  const invalid = command('TASK_ASSIGN', 3, { assignee_id: 'USER-NOT-A-MEMBER' });
  invalid.command_id = 'CMD-TASK-invalid'; invalid.idempotency_key = 'idem-task-invalid';
  assert.throws(() => commands.execute(invalid, { user_id: 'USER-A' }), /TASK_ASSIGNEE_NOT_MEMBER/);
});
