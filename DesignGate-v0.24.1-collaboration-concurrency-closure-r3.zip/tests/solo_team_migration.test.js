const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const childProcess = require('child_process');
const { buildMigrationPlan } = require('../backend/collaboration/solo_team_migration');
const { executeMigration } = require('../backend/collaboration/solo_team_migration');
const TeamStore = require('../backend/collaboration/team_store');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');

test('Solo-to-Team preflight discovers bound local artifacts and reports missing references without changing the Solo project', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-solo-team-plan-'));
  const cadPath = path.join(directory, 'fixture.step');
  fs.writeFileSync(cadPath, 'ISO-10303-21;');
  const solo = {
    project_id: 'DG-SOLO-1',
    project_name: 'Solo fixture',
    design: { active_revision: 'B', cad_path: cadPath },
    requirements: [{ req_id: 'REQ-1', text: 'fixture requirement' }],
    bom: [{ part_id: 'PART-1', part_name: 'fixture part' }],
    evidence: [{ evidence_id: 'EVD-1', file_path: path.join(directory, 'missing.csv') }],
    dfmea: { items: [{ failure_mode_id: 'FM-1' }] },
    dfmea_test_records: [{ test_id: 'T-1' }]
  };
  const before = structuredClone(solo);

  const plan = buildMigrationPlan({ soloProject: solo, target_project_id: 'DG-TEAM-1' });

  assert.equal(plan.status, 'READY_WITH_WARNINGS');
  assert.equal(plan.source_project_id, 'DG-SOLO-1');
  assert.equal(plan.target_project_id, 'DG-TEAM-1');
  assert.equal(plan.counts.requirements, 1);
  assert.equal(plan.counts.bom, 1);
  assert.equal(plan.counts.artifacts, 1);
  assert.equal(plan.counts.missing_artifacts, 1);
  assert.equal(plan.artifacts[0].sha256, crypto.createHash('sha256').update('ISO-10303-21;').digest('hex'));
  assert.equal(plan.artifacts[0].revision_id, 'B');
  assert.deepEqual(solo, before);
});

test('confirmed Solo-to-Team import creates immutable artifact bindings while keeping historical tests revalidation-required', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-solo-team-import-'));
  const cadPath = path.join(directory, 'fixture.step');
  const evidencePath = path.join(directory, 'result.csv');
  fs.writeFileSync(cadPath, 'ISO-10303-21;');
  fs.writeFileSync(evidencePath, 'force_n,10');
  const solo = {
    project_id: 'DG-SOLO-2', project_name: 'Migrated fixture', design: { active_revision: 'B', cad_path: cadPath },
    requirements: [{ req_id: 'REQ-1', text: 'fixture requirement' }], bom: [{ part_id: 'PART-1', part_name: 'fixture part' }],
    evidence: [{ evidence_id: 'EVD-1', file_path: evidencePath, purpose: 'legacy result' }],
    dfmea: { items: [{ failure_mode_id: 'FM-1' }] }, dfmea_test_records: [{ test_id: 'T-1', status: 'FAILED' }]
  };
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  const artifactStore = new LocalImmutableArtifactStore({ directory: path.join(directory, 'artifacts') });
  const plan = buildMigrationPlan({ soloProject: solo, target_project_id: 'DG-TEAM-2' });

  const report = executeMigration({ plan, soloProject: solo, store, artifactStore, actor: { user_id: 'OWNER-1' } });
  const imported = store.getProjectForActor('DG-TEAM-2', 'OWNER-1');

  assert.equal(report.status, 'SUCCESS');
  assert.equal(report.artifact_count, 2);
  assert.equal(imported.design.cad_artifact_revision, 'B');
  assert.equal(imported.evidence[0].artifact_id.startsWith('ART-'), true);
  assert.equal(imported.evidence[0].status, 'HISTORICAL_REQUIRES_REVALIDATION');
  assert.equal(Object.hasOwn(imported.evidence[0], 'migration_source_path'), false);
  assert.equal(imported.dfmea_test_records[0].status, 'FAILED');
  assert.equal(imported.dfmea_test_records[0].migration_status, 'LEGACY_IMPORTED_REQUIRES_REVALIDATION');
  for (const artifact of store.listArtifacts('DG-TEAM-2')) assert.equal(artifactStore.verifyHash(artifactStore.getMetadata(artifact.artifact_id)), true);
  store.close();
});

test('migration CLI performs an explicit non-mutating preflight by default', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-solo-team-cli-'));
  const projectPath = path.join(directory, 'solo.json');
  fs.writeFileSync(projectPath, JSON.stringify({ project_id: 'DG-SOLO-3', project_name: 'CLI fixture', design: { active_revision: 'A' }, requirements: [] }));
  const result = childProcess.spawnSync(process.execPath, ['tools/migrate_solo_to_team.js', '--project', projectPath, '--target', 'DG-TEAM-3'], { cwd: path.join(__dirname, '..'), encoding: 'utf8' });

  assert.equal(result.status, 0, result.stderr);
  const output = JSON.parse(result.stdout);
  assert.equal(output.status, 'READY');
  assert.equal(output.execution, 'NOT_EXECUTED_CONFIRMATION_REQUIRED');
});
