const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');

test('immutable artifact store never overwrites an earlier file with the same filename', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-artifacts-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const store = new LocalImmutableArtifactStore({ directory });
  const first = store.put({ project_id: 'DG-ART-001', revision_id: 'A', artifact_type: 'CAD', original_filename: 'lamp.step', bytes: Buffer.from('STEP-A'), created_by: 'USER-A' });
  const second = store.put({ project_id: 'DG-ART-001', revision_id: 'B', artifact_type: 'CAD', original_filename: 'lamp.step', bytes: Buffer.from('STEP-B'), created_by: 'USER-A' });

  assert.notEqual(first.artifact_id, second.artifact_id);
  assert.notEqual(first.storage_key, second.storage_key);
  assert.equal(fs.readFileSync(store.pathFor(first.storage_key), 'utf8'), 'STEP-A');
  assert.equal(fs.readFileSync(store.pathFor(second.storage_key), 'utf8'), 'STEP-B');
  assert.equal(first.immutable, true);
});
