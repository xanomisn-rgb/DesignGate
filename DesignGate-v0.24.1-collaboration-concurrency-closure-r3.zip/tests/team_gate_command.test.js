const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');

test('Team Gate recalculation ignores a client PASS claim and holds an incomplete DFMEA project', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-gate-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-GATE-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-DFI-GATE', idempotency_key: 'idem-dfi-gate', project_id: 'DG-GATE-001', command_type: 'DFMEA_ITEM_CREATE', entity_type: 'DFMEA_ITEM', entity_id: 'DFI-GATE', base_project_version: 1, base_entity_version: 0, payload: { function: 'Retain battery', failure_modes: [{ failure_mode_id: 'FM-GATE', effect: 'Battery release', cause: 'Latch fracture', severity: 9, occurrence: 3, detection: 4 }], verification_plan_item: { plan_item_id: 'VP-GATE', failure_mode_ids: ['FM-GATE'], method: 'Latch cycle', acceptance_criteria: 'No fracture' } } }, { user_id: 'USER-A' });
  const result = commands.execute({ command_id: 'CMD-GATE-001', idempotency_key: 'idem-gate-001', project_id: 'DG-GATE-001', command_type: 'GATE_RECALCULATE_REQUEST', entity_type: 'GATE', entity_id: 'GATE-3', base_project_version: 2, base_entity_version: 0, payload: { stage: 'Gate 3', claimed_status: 'PASS' } }, { user_id: 'USER-A' });
  assert.equal(result.event_type, 'GATE_RECALCULATED');
  const gate = store.getProjectForActor('DG-GATE-001', 'USER-A').gate;
  assert.notEqual(gate.status, 'PASS');
  assert.equal(gate.client_claimed_status, undefined);
  assert.ok(gate.blocking_reasons.length > 0);
});

test('Team Gate recalculation recognizes a current evidence artifact only after the immutable store verifies its bytes', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-gate-evidence-'));
  const store = new TeamStore({ directory: path.join(directory, 'db') });
  const artifacts = new LocalImmutableArtifactStore({ directory: path.join(directory, 'artifacts') });
  const commands = new CommandService({ store, artifactVerifier: artifact => {
    const metadata = artifacts.getMetadata(artifact.artifact_id);
    return Boolean(metadata && artifacts.verifyHash(metadata));
  } });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-GATE-EVIDENCE', project_name: 'Lamp' }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-REQ-E', idempotency_key: 'idem-req-e', project_id: 'DG-GATE-EVIDENCE', command_type: 'UPDATE_REQUIREMENT', entity_type: 'REQUIREMENT', entity_id: 'REQ-E', base_project_version: 1, base_entity_version: 0, payload: { text: 'The latch shall retain the battery.' } }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-DFI-E', idempotency_key: 'idem-dfi-e', project_id: 'DG-GATE-EVIDENCE', command_type: 'DFMEA_ITEM_CREATE', entity_type: 'DFMEA_ITEM', entity_id: 'DFI-E', base_project_version: 2, base_entity_version: 0, payload: { function: 'Retain battery', failure_modes: [{ failure_mode_id: 'FM-E', effect: 'Battery release', cause: 'Latch fracture', severity: 8, occurrence: 3, detection: 4 }], verification_plan_item: { plan_item_id: 'VP-E', failure_mode_ids: ['FM-E'], method: 'Latch cycle', acceptance_criteria: 'No fracture' } } }, { user_id: 'USER-A' });
  const artifact = artifacts.put({ project_id: 'DG-GATE-EVIDENCE', revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'latch.csv', bytes: Buffer.from('cycles,result\n100,PASS\n'), created_by: 'USER-A' });
  store.registerArtifact(artifact);
  commands.execute({ command_id: 'CMD-EVD-E', idempotency_key: 'idem-evd-e', project_id: 'DG-GATE-EVIDENCE', command_type: 'EVIDENCE_ADD', entity_type: 'EVIDENCE', entity_id: 'EVD-E', base_project_version: 3, base_entity_version: 0, payload: { artifact_id: artifact.artifact_id, sha256: artifact.sha256, purpose: 'Latch cycle evidence', requirement_ids: ['REQ-E'] } }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-GATE-E', idempotency_key: 'idem-gate-e', project_id: 'DG-GATE-EVIDENCE', command_type: 'GATE_RECALCULATE_REQUEST', entity_type: 'GATE', entity_id: 'GATE-3-E', base_project_version: 4, base_entity_version: 0, payload: { stage: 'Gate 3' } }, { user_id: 'USER-A' });
  const checks = store.getProjectForActor('DG-GATE-EVIDENCE', 'USER-A').gate.gate_record.checks;
  assert.equal(checks.find(check => check.check_id === 'GATEV2-EVIDENCE_INTEGRITY_CHECK').status, 'PASS');
  assert.equal(checks.find(check => check.check_id === 'GATEV2-EVIDENCE_PROVENANCE_CHECK').status, 'PASS');
});
