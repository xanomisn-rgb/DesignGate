const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const crypto=require('crypto');
const Orchestrator=require('../backend/orchestrator');
const Workflow=require('../backend/workflow_service');
const Bus=require('../backend/integrations/integration_event_bus');
const {CadAdapter}=require('../backend/integrations/cad_adapter');

test('CAD observation flows through evidence and v2 Gate, then becomes historical on a new revision',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-flow-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const orchestrator=new Orchestrator(null,{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
 await orchestrator.runReviewPipeline({projectId:'DG-FLOW',stage:'Gate 2',requirements:[{req_id:'REQ-1',text:'Part shall survive use',verification_method:'test',acceptance_criteria:'no break'}],designParams:{material:'6061',process:'CNC',finish:'anodized',color:'black',gloss:'matte'}});
 let project=orchestrator.stateManager.getProject('DG-FLOW');project=workflow.newRevision('DG-FLOW',{revision:'B',reason:'CAD controlled revision'},project.version);
 const file=path.join(dir,'part.step');fs.writeFileSync(file,'ISO-10303-21;mock');const fileSha=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 const adapter=new CadAdapter({stateManager:orchestrator.stateManager,workflowService:workflow,eventBus:new Bus(path.join(dir,'events')),runner:{analyze:async()=>({analysis_status:'BREP_ANALYZED_PARTIAL',analysis_success:true,file_sha256:fileSha,solid_count:1,face_count:6,bounding_box:{unit:'mm'},measurements:{},analyzer_backend:'OCP',analyzer_version:'8.0.1.0.0',limitations:['SAMPLED_NOT_GLOBAL_PROOF']})}});
 const upload=await adapter.upload({project_id:'DG-FLOW',revision:'B',source_system:'MOCK_CAD',idempotency_key:'cad-b',file_path:file,authorization:{authorized:true}});assert(upload.evidence_reference.manifest_id);
 let review=await orchestrator.runReviewPipeline({projectId:'DG-FLOW',stage:'Gate 3'});assert.equal(review.gate.gate_engine_version,'v2');assert(review.gate.all_blockers.some(row=>row.check_id==='GATEV2-INTEGRATION_SOURCE_CHECK'));
 project=orchestrator.stateManager.getProject('DG-FLOW');const evidence=project.evidence[0];workflow.verify('DG-FLOW',{req_id:'SYS-CAD',status:'PASS',observed_result:'Human review of bounded CAD observation',reviewer:'Reviewer',evidence_id:evidence.evidence_id},project.version);
 project=orchestrator.stateManager.getProject('DG-FLOW');assert.match(project.cad_observations[0].status,/^CLOSED/);
 project=workflow.newRevision('DG-FLOW',{revision:'C',reason:'geometry changed'},project.version);review=await orchestrator.runReviewPipeline({projectId:'DG-FLOW',stage:'Gate 3'});
 assert(review.evidence_context.some(row=>row.evidence_id===evidence.evidence_id&&row.provenance_status==='STALE'));assert.notEqual(review.gate.decision,'PASS');
});
