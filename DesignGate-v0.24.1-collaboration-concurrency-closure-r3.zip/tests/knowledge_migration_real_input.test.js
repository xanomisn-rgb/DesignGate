const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');const path=require('path');
const {migrateKnowledgeV2}=require('../backend/knowledge/knowledge_migrator_v2');
test('knowledge v2 migrates the supplied governed knowledge inputs without losing source references',()=>{
 const root=path.join(__dirname,'..','knowledge'),json=file=>JSON.parse(fs.readFileSync(path.join(root,file),'utf8'));
 const curated=json('curated/records.json'),expanded=json('expansion/records.upsert.json');
 const result=migrateKnowledgeV2({curated_records:curated.records,expansion_records:expanded.records,sources:[...json('curated/sources.json'),...json('expansion/sources.upsert.json')],standards:json('expansion/standards.upsert.json'),battery_cells:json('expansion/battery_cells.json'),battery_rules:json('expansion/battery_pack_rules.json'),quarantine:json('expansion/quarantine.review_required.json')});
 const sourceIds=new Set(result.sources.map(row=>row.source_id));
 assert.ok(result.records.length>0);assert.equal(result.records.every(row=>row.source_ids.every(id=>sourceIds.has(id))),true);
 assert.equal(result.quarantine.every(row=>row.do_not_promote===true),true);
});
