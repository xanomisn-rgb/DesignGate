const {test}=require('node:test');
const assert=require('node:assert/strict');
const FMEAService=require('../backend/fmea_service');
const fs=require('fs'),os=require('os'),path=require('path');
const State=require('../backend/project_state_manager'),Workflow=require('../backend/workflow_service'),EvidenceGraph=require('../backend/evidence_graph');
const ErgonomicsService=require('../backend/ergonomics_service');
const CMFService=require('../backend/cmf_service');
const Orchestrator=require('../backend/orchestrator'),C=require('../backend/contracts');

function model(test={}){return {items:[{item_id:'seal',function:'prevent ingress',failure_modes:[{failure_mode_id:'FM-LEAK',effect:'water ingress',cause:'gasket compression',severity:9,occurrence:3,detection:6,controls:['compression control']}]}],requirement_links:[{requirement_id:'REQ-IP67',failure_mode_id:'FM-LEAK'}],verification_tests:[test]};}

test('DFMEA only accepts explicit evidenced PASS as VERIFIED',()=>{
  for(const status of ['PLANNED','RUNNING','UNKNOWN','FAIL','FAILED',undefined]){
    const r=new FMEAService().evaluate(model({test_id:'TC-01',status,failure_mode_ids:['FM-LEAK']}),{revision:'A'});
    assert.notEqual(r.result.failure_modes[0].verification_status,'VERIFIED',status);
  }
});

test('applicable DFMEA with a reopened critical risk produces a failing Gate check',()=>{
  const {toGateArtifacts}=require('../backend/professional_gate');
  const artifacts=toGateArtifacts({dfmea:{capability:'quality.dfmea',status:'PARTIALLY_EVALUATED',result:{risk_reopened:['FM-LEAK'],failure_modes:[{failure_mode_id:'FM-LEAK',severity:10,rpn:1000,verification_status:'RISK_REOPENED'}]} }},{dfmea:'APPLICABLE'});
  assert.equal(artifacts.checks[0].status,'FAIL');
  assert.equal(artifacts.findings[0].severity,'CRITICAL');
});

test('decision preserves validated requirement IDs for the evidence graph',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0201-decision-'));const state=new State(dir),workflow=new Workflow(state);
  state.saveProject({project_id:'DG-D1',project_name:'x',design:{active_revision:'A'},requirements:[{req_id:'REQ-1',text:'one-hand use'}],bom:[],findings:[],version:0});
  const project=workflow.decision('DG-D1',{problem:'button location',alternatives:['left','right'],selected_option:'left',reason:'reach',requirement_ids:['REQ-1']});
  const graph=EvidenceGraph.fromProject(project).snapshot();
  assert.deepEqual(project.decisions[0].requirement_ids,['REQ-1']);
  assert(graph.edges.some(edge=>edge.from==='REQ:REQ-1'&&edge.to.startsWith('DEC:')));
});

test('ergonomics accepts zero moment arm and zero external operation force without invented risk bands',()=>{
  const result=new ErgonomicsService().assessGrip({mass_kg:.65,cog_offset_mm:0,grip_section_mm:{width:42,depth:24},target_population:{source:'brief'},posture:'neutral',operation_force_n:0,duration_s:300});
  assert.equal(result.status,'EVALUATED');
  assert.equal(result.result.static_wrist_moment_nm,0);
  assert.equal(result.result.moment_torque_risk,'NOT_CLASSIFIED_NO_APPLICABLE_REFERENCE');
});

test('unreviewed CMF rule IDs are not emitted as project evidence or a conclusive compatibility claim',()=>{
  const result=new CMFService().evaluateCompatibility({material:'PC+ABS',process:'injection_molding',finish:'molded_texture',environment:'indoor'});
  assert.equal(result.status,'PARTIALLY_EVALUATED');
  assert.equal(result.result.compatibility,'REFERENCE_ONLY_REQUIRES_REVIEW');
  assert.deepEqual(result.evidence_ids,[]);
});

test('a current failed severity-10 DFMEA test recorded through business APIs blocks Gate 3 and local freeze',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0201-risk-'));const orchestrator=new Orchestrator(null,{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
  const dfmea=model();dfmea.items[0].failure_modes[0].severity=10;dfmea.items[0].failure_modes[0].occurrence=10;dfmea.items[0].failure_modes[0].detection=10;delete dfmea.verification_tests;
  await orchestrator.runReviewPipeline({projectId:'DG-RISK',stage:'Gate 2',requirements:[{req_id:'REQ-IP67',text:'Ingress protection',verification_method:'test',acceptance_criteria:'pass'}],designParams:{process:'CNC',material:'6061-T6'},dfmea});
  let p=workflow.get('DG-RISK');p=workflow.setDfmeaVerificationPlan('DG-RISK',{items:[{plan_item_id:'VP-IP67',failure_mode_ids:['FM-LEAK'],method:'physical test',acceptance_criteria:'No ingress'}]},p.version);
  const file=path.join(dir,'failed-test.txt');fs.writeFileSync(file,'water ingress observed');const ev=workflow.addEvidence('DG-RISK',file,p.version).evidence;p=workflow.get('DG-RISK');
  p=workflow.recordDfmeaTest('DG-RISK',{test_id:'TC-IP67',plan_item_id:'VP-IP67',status:'FAILED',actual_result:'Water ingress observed',reviewer:'Reviewer',completed_at:'2026-09-08T12:00:00Z',evidence_id:ev.evidence_id},p.version);
  const result=await orchestrator.runReviewPipeline({projectId:'DG-RISK',stage:'Gate 3'});
  assert.equal(result.checks.find(check=>check.check_id==='PROF-DFMEA').status,'FAIL');assert.notEqual(result.gate.decision,'PASS');assert.equal(result.gate.freeze_eligible,false);
});

test('DFMEA definition changes and Revision changes invalidate applicability without mutating immutable test status',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0201-baseline-'));const orchestrator=new Orchestrator(null,{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
  const first=model();delete first.verification_tests;await orchestrator.runReviewPipeline({projectId:'DG-BASE',requirements:[{req_id:'REQ-IP67',text:'seal',verification_method:'test',acceptance_criteria:'pass'}],designParams:{process:'CNC',material:'6061'},dfmea:first});let p=workflow.get('DG-BASE');
  p=workflow.setDfmeaVerificationPlan('DG-BASE',{items:[{plan_item_id:'VP-1',failure_mode_ids:['FM-LEAK'],method:'test',acceptance_criteria:'No ingress'}]},p.version);const file=path.join(dir,'old-pass.txt');fs.writeFileSync(file,'No ingress');const ev=workflow.addEvidence('DG-BASE',file,p.version).evidence;p=workflow.get('DG-BASE');p=workflow.recordDfmeaTest('DG-BASE',{test_id:'TC-OLD',plan_item_id:'VP-1',status:'PASS',actual_result:'No ingress',reviewer:'R',completed_at:'2026-09-08T12:00:00Z',evidence_id:ev.evidence_id},p.version);const oldRecord=structuredClone(p.dfmea_test_records[0]),beforeHash=p.dfmea_baseline_hash;
  const changed=structuredClone(first);changed.items[0].failure_modes[0].cause='housing flatness';await orchestrator.runReviewPipeline({projectId:'DG-BASE',dfmea:changed});p=workflow.get('DG-BASE');assert.notEqual(p.dfmea_baseline_hash,beforeHash);assert.equal(p.dfmea_test_records[0].status,'PASS');let review=await orchestrator.runReviewPipeline({projectId:'DG-BASE',stage:'Gate 3'});assert.notEqual(review.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'VERIFIED');
  p=workflow.get('DG-BASE');const revised=workflow.newRevision('DG-BASE',{revision:'B',reason:'geometry revision'},p.version);assert.equal(revised.dfmea_test_records[0].status,oldRecord.status);assert.notEqual(revised.dfmea_design_hash,oldRecord.design_baseline_hash);
});

test('normal business flow traces registered evidence through requirement, decision, risk, test and current Revision',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v0201-trace-')),orchestrator=new Orchestrator(null,{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
  const dfmea=model();delete dfmea.verification_tests;await orchestrator.runReviewPipeline({projectId:'DG-TRACE',requirements:[{req_id:'REQ-IP67',text:'Ingress protection',verification_method:'test',acceptance_criteria:'No ingress'}],designParams:{process:'CNC',material:'6061'},dfmea});let p=workflow.get('DG-TRACE');
  p=workflow.setDfmeaVerificationPlan('DG-TRACE',{items:[{plan_item_id:'VP-SEAL',failure_mode_ids:['FM-LEAK'],method:'physical test',acceptance_criteria:'No ingress'}]},p.version);const report=path.join(dir,'seal-test.txt');fs.writeFileSync(report,'actual local test report');const evidence=workflow.addEvidence('DG-TRACE',report,p.version).evidence;p=workflow.get('DG-TRACE');p=workflow.decision('DG-TRACE',{problem:'seal architecture',alternatives:['gasket','adhesive'],selected_option:'gasket',reason:'service',requirement_ids:['REQ-IP67']},p.version);p=workflow.recordDfmeaTest('DG-TRACE',{test_id:'TC-SEAL',plan_item_id:'VP-SEAL',status:'PASS',actual_result:'No ingress observed',reviewer:'Reviewer',completed_at:'2026-09-08T13:00:00Z',evidence_id:evidence.evidence_id},p.version);
  // Severity 9 requires explicit local residual-risk acceptance under current DesignGate policy.
  p=workflow.acceptResidualRisk('DG-TRACE',{failure_mode_id:'FM-LEAK',reason:'Verified locally for design freeze',responsible_person:'Reviewer',conditions:'Local design freeze only',follow_up_actions:['Independent production sign-off required']},p.version);
  const result=await orchestrator.runReviewPipeline({projectId:'DG-TRACE',stage:'Gate 3'});assert.equal(result.professional_capabilities.dfmea.result.failure_modes[0].verification_status,'VERIFIED');const edges=result.evidence_graph.edges;assert(edges.some(edge=>edge.from.startsWith('EVD:')&&edge.to==='TEST:TC-SEAL'&&edge.relation==='REGISTERED_FOR'&&edge.data.valid_support===true));assert(edges.some(edge=>edge.from==='REQ:REQ-IP67'&&edge.to.startsWith('DEC:')&&edge.relation==='INFORMS'));assert(edges.some(edge=>edge.from==='TEST:TC-SEAL'&&edge.to==='RISK:A:FM-LEAK'&&edge.relation==='VERIFIES'&&edge.data.valid_support===true));
});
