const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

function command(type, version, payload, suffix = version) {
  return { command_id: `CMD-RISK-${type}-${suffix}`, idempotency_key: `idem-risk-${type}-${suffix}`, project_id: 'DG-RISK-001', command_type: type, entity_type: 'RISK_ACCEPTANCE', entity_id: 'RACC-001', base_project_version: 1, base_entity_version: version, payload };
}

test('residual risk acceptance needs a human reviewer decision and stays revision/version bound', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-risk-acceptance-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-RISK-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-RISK-001', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }, { user_id: 'USER-A' });
  store.addMember('DG-RISK-001', { user_id: 'TEACHER-01', role_id: 'TEACHER_REVIEWER' }, { user_id: 'USER-A' });
  const requested = commands.execute(command('RISK_ACCEPTANCE_REQUEST', 0, { risk_id: 'FM-018', risk_version: 3, reason: 'Residual pinch risk is documented.', residual_risk: 'MEDIUM', evidence_set_hash: 'a'.repeat(64) }), { user_id: 'USER-A' });
  assert.equal(requested.event_type, 'RISK_ACCEPTANCE_REQUESTED');
  assert.throws(() => commands.execute(command('RISK_ACCEPTANCE_DECIDE', 1, { decision: 'ACCEPTED', reason: 'not authorized' }, 'student'), { user_id: 'USER-B' }), error => error.code === 'PERMISSION_DENIED');
  const decided = commands.execute(command('RISK_ACCEPTANCE_DECIDE', 1, { decision: 'ACCEPTED', reason: 'Reviewed with documented controls.' }, 'teacher'), { user_id: 'TEACHER-01' });
  assert.equal(decided.event_type, 'RISK_ACCEPTANCE_DECIDED');
  const row = store.getProjectForActor('DG-RISK-001', 'USER-A').risk_acceptance_requests[0];
  assert.equal(row.status, 'ACCEPTED');
  assert.equal(row.decided_by, 'TEACHER-01');
  assert.equal(row.revision_id, 'A');
});
