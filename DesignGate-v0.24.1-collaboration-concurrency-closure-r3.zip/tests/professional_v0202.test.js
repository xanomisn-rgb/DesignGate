const {test}=require('node:test');const assert=require('node:assert/strict');const FMEA=require('../backend/fmea_service');
const base={items:[{item_id:'I',failure_modes:[{failure_mode_id:'FM',effect:'e',cause:'c',severity:8,occurrence:3,detection:3}]}],requirement_links:[{failure_mode_id:'FM',requirement_id:'REQ'}]};
test('invalid completion date, unknown requirement and unlinked PASS cannot verify DFMEA',()=>{
 const model={...base,verification_tests:[{test_id:'T2',status:'PASS',failure_mode_ids:['FM'],revision:'A',baseline_fingerprint:'B',evidence_id:'E',actual_result:'ok',acceptance_criteria:'ok',reviewer:'r',completed_at:'not-a-date'}]};
 const result=new FMEA().evaluate(model,{revision:'A',baseline_fingerprint:'B',valid_evidence_ids:['E'],valid_requirement_ids:[]});
 assert.notEqual(result.result.failure_modes[0].verification_status,'VERIFIED');assert(result.result.invalid_links.length);
});
