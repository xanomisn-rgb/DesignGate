const { test } = require('node:test');
const assert = require('node:assert/strict');
const TeamClient = require('../src/team_client');

test('TeamClient keeps the session in memory and authenticates Team API reads', async () => {
  const requests = [];
  const fetchImpl = async (url, options = {}) => {
    requests.push({ url, options });
    const body = url.endsWith('/api/auth/login')
      ? { token: 'memory-only-session', user: { user_id: 'designer-1', display_name: 'Designer' } }
      : { projects: [{ project_id: 'DG-TEAM-1', project_name: 'Team project' }] };
    return { ok: true, status: 200, json: async () => body };
  };
  const client = new TeamClient({ baseUrl: 'http://127.0.0.1:43124', fetchImpl });

  await client.login({ username: 'designer', password: 'correct-password' });
  const projects = await client.listProjects();

  assert.deepEqual(projects, [{ project_id: 'DG-TEAM-1', project_name: 'Team project' }]);
  assert.equal(requests[0].url, 'http://127.0.0.1:43124/api/auth/login');
  assert.equal(requests[0].options.headers['content-type'], 'application/json');
  assert.equal(requests[1].options.headers.authorization, 'Bearer memory-only-session');
  assert.equal(client.sessionToken, 'memory-only-session');
});

test('TeamClient sends collaboration mutations only through the server command route', async () => {
  let request;
  const client = new TeamClient({
    baseUrl: 'http://127.0.0.1:43124',
    fetchImpl: async (url, options) => {
      request = { url, options };
      return { ok: true, status: 200, json: async () => ({ status: 'APPLIED', event_id: 'evt-1' }) };
    }
  });
  client.sessionToken = 'server-session';

  const result = await client.applyCommand('DG-TEAM-1', {
    command_id: 'cmd-1', command_type: 'COMMENT_CREATE', project_id: 'DG-TEAM-1', payload: { body: 'Please review.' }
  });

  assert.equal(result.status, 'APPLIED');
  assert.equal(request.url, 'http://127.0.0.1:43124/api/projects/DG-TEAM-1/commands');
  assert.equal(request.options.method, 'POST');
  assert.equal(request.options.headers.authorization, 'Bearer server-session');
  assert.deepEqual(JSON.parse(request.options.body).payload, { body: 'Please review.' });
});

test('TeamClient reads members from the authenticated project-scoped endpoint', async () => {
  let request;
  const client = new TeamClient({
    baseUrl: 'http://127.0.0.1:43124',
    fetchImpl: async (url, options) => {
      request = { url, options };
      return { ok: true, status: 200, json: async () => ({ members: [{ user_id: 'reviewer-1', role_id: 'reviewer' }] }) };
    }
  });
  client.sessionToken = 'project-scoped-session';

  const members = await client.listMembers('DG-TEAM-1');

  assert.deepEqual(members, [{ user_id: 'reviewer-1', role_id: 'reviewer' }]);
  assert.equal(request.url, 'http://127.0.0.1:43124/api/projects/DG-TEAM-1/members');
  assert.equal(request.options.headers.authorization, 'Bearer project-scoped-session');
});

test('TeamClient sends presence status through the authenticated project heartbeat endpoint', async () => {
  let request;
  const client = new TeamClient({ baseUrl: 'http://127.0.0.1:43124', fetchImpl: async (url, options) => {
    request = { url, options };
    return { ok: true, status: 200, json: async () => ({ presence: { user_id: 'designer-1', status: 'ONLINE' } }) };
  } });
  client.sessionToken = 'presence-session';

  const presence = await client.heartbeat('DG-TEAM-1', 'ONLINE');

  assert.equal(presence.status, 'ONLINE');
  assert.equal(request.url, 'http://127.0.0.1:43124/api/projects/DG-TEAM-1/presence');
  assert.equal(request.options.method, 'POST');
  assert.deepEqual(JSON.parse(request.options.body), { status: 'ONLINE' });
});

test('TeamClient uploads a selected artifact as authenticated multipart data rather than a client-created registry record', async () => {
  let request;
  const client = new TeamClient({ baseUrl: 'http://127.0.0.1:43124', fetchImpl: async (url, options) => {
    request = { url, options };
    return { ok: true, status: 201, json: async () => ({ artifact: { artifact_id: 'ART-1', sha256: 'a'.repeat(64) } }) };
  } });
  client.sessionToken = 'upload-session';

  const artifact = await client.uploadArtifact('DG-TEAM-1', { revision_id: 'A', artifact_type: 'EVIDENCE', file: new Blob(['measured,value\n1,PASS\n'], { type: 'text/csv' }), filename: 'result.csv' });

  assert.equal(artifact.artifact_id, 'ART-1');
  assert.equal(request.url, 'http://127.0.0.1:43124/api/projects/DG-TEAM-1/artifacts');
  assert.equal(request.options.method, 'POST');
  assert.equal(request.options.headers.authorization, 'Bearer upload-session');
  assert.equal(request.options.headers['content-type'], undefined);
  assert.equal(request.options.body.get('revision_id'), 'A');
  assert.equal(request.options.body.get('artifact_type'), 'EVIDENCE');
  assert.equal(request.options.body.get('file').name, 'result.csv');
});

test('TeamClient delegates authenticated project event subscription to the Electron transport without URL tokens', () => {
  let subscribed, removed, received;
  const client = new TeamClient({
    baseUrl: 'http://127.0.0.1:43124',
    fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({}) }),
    eventTransport: {
      subscribe: (options, onEvent) => { subscribed = options; onEvent({ type: 'PRESENCE_UPDATED' }); return 'sub-1'; },
      unsubscribe: id => { removed = id; }
    }
  });
  client.sessionToken = 'opaque-session';

  const unsubscribe = client.subscribeEvents('DG-TEAM-1', event => { received = event; });
  unsubscribe();

  assert.deepEqual(subscribed, { baseUrl: 'http://127.0.0.1:43124', projectId: 'DG-TEAM-1', token: 'opaque-session' });
  assert.deepEqual(received, { type: 'PRESENCE_UPDATED' });
  assert.equal(removed, 'sub-1');
});
