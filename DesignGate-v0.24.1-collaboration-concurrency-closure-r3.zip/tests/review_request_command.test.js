const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('a review request is revision-bound and does not become an approval or freeze', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-review-request-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-REVIEW-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const result = commands.execute({
    command_id: 'CMD-REVIEW-001', idempotency_key: 'idem-review-001', project_id: 'DG-REVIEW-001',
    command_type: 'REVIEW_REQUEST_CREATE', entity_type: 'REVIEW_REQUEST', entity_id: 'REVREQ-001', base_project_version: 1, base_entity_version: 0,
    payload: { requested_role: 'TEACHER_REVIEWER', scope: 'Gate 3 readiness', reason: 'Please review current evidence.' }
  }, { user_id: 'USER-A' });
  assert.equal(result.event_type, 'REVIEW_REQUEST_CREATED');
  const state = store.getProjectForActor('DG-REVIEW-001', 'USER-A');
  assert.equal(state.review_requests[0].revision_id, 'A');
  assert.equal(state.review_requests[0].status, 'OPEN');
  assert.equal(state.approval, undefined);
  assert.equal(state.freeze, undefined);
});
