const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const Agent=require('../backend/agent_runtime'),State=require('../backend/project_state_manager'),Tools=require('../backend/agent_tools'),Handover=require('../backend/handover_service');
const call=(name,args)=>({message:{tool_calls:[{id:'call-'+name,type:'function',function:{name,arguments:JSON.stringify(args)}}]}});
const plan=()=>call('update_plan',{steps:['读取约束','修正方案','审查提案'],reason:'回归测试'});
const propose=(n)=>call('propose_change',{title:'候选 '+n,reason:'合成测试',assumptions:[],design_patch:{ribThickness:n}});
function setup(t,replies){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-retry-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const sm=new State(dir);sm.saveProject({project_id:'DG-RETRY',project_name:'合成测试',design:{active_revision:'A',process:'注塑',material:'ABS',manufacturingSupplier:'Protolabs',nominalWall:2,ribThickness:1},requirements:[],bom:[],findings:[]},0);const runtime=new Agent(sm,async()=>{const r=replies.shift();if(!r)throw Error('Unexpected model request');return r;});return {sm,runtime};}
test('critic rejection is corrected in the same bounded task before approval',async t=>{
 const {sm,runtime}=setup(t,[plan(),propose(1.8),propose(1.1)]);const id=runtime.start('DG-RETRY','优化筋厚').run_id;const r=await runtime.settled('DG-RETRY',id);
 assert.equal(r.status,'WAITING_APPROVAL');assert.equal(r.critique_failures,1);assert.equal(r.draft.proposal.design_patch.ribThickness,1.1);
 assert.equal(r.events[1].output.status,'CRITIQUE_REJECTED');assert.equal(sm.getProject('DG-RETRY').design.ribThickness,1);
});
test('three rejected candidates pause without applying or offering an unsafe draft',async t=>{
 const {sm,runtime}=setup(t,[plan(),propose(1.8),propose(1.9),propose(2)]);const id=runtime.start('DG-RETRY','优化筋厚').run_id;const r=await runtime.settled('DG-RETRY',id);
 assert.equal(r.status,'WAITING_INPUT');assert.equal(r.critique_failures,3);assert(!r.draft);assert.equal(sm.getProject('DG-RETRY').version,1);
 assert.equal(new Agent(sm,async()=>{}).get('DG-RETRY',id).critique_failures,3);
});
function frozen(){return {project_id:'DG-HANDOVER',project_name:'合成验收项目',version:3,design:{active_revision:'A'},basis_hash:'basis',last_review:{review_id:'R',basis_hash:'basis',gate:{freeze_eligible:true}},freeze:{freeze_id:'F',authority:'LOCAL_DESKTOP_APPROVAL',revision:'A',review_id:'R',basis_hash:'basis'}};}
test('handover enforces current local freeze and version',()=>{
 const p=frozen();assert.equal(Handover.snapshot(p,[],3).project.freeze.freeze_id,'F');
 assert.throws(()=>Handover.snapshot(p,[],2),/VERSION/);p.freeze.revision='B';assert.throws(()=>Handover.snapshot(p,[],3),/FREEZE/);
 delete p.freeze;assert.throws(()=>Handover.snapshot(p,[],3),/FREEZE/);
});
test('handover rejects foreign audit runs',()=>assert.throws(()=>Handover.snapshot(frozen(),[{project_id:'OTHER'}],3),/SCOPE/));
const geometry=()=>({source_sha256:'a'.repeat(64),display_mesh:{source_sha256:'a'.repeat(64),positions:Array(36).fill(0),face_ids:[1,2,3,4]},surface_measurements:{source_sha256:'a'.repeat(64),samples:[.8,2,4,90].map((a,i)=>({face_id:i+1,point_mm:[i,0,0],signed_draft_deg:a}))}});
test('heatmap exposes raw angle bands without implying pass when no threshold exists',async()=>{
 const {overlayData}=await import('../src/measurement_overlay.mjs');const r=overlayData(geometry());
 assert.deepEqual(r.faces.get(1).raw_range.absolute_signed_draft_deg,[.8,.8]);
 assert.deepEqual(r.faces.get(3).raw_range.absolute_signed_draft_deg,[4,4]);assert.equal(r.faces.get(4).minimum,null);
 assert.equal(r.faces.get(1).engineering_status,'NOT_EVALUATED');assert.equal(r.faces.get(3).engineering_status,'NOT_EVALUATED');
 assert.equal(r.colours.length,36);
});
test('heatmap and agent references reject wrong source hashes',async()=>{
 const {overlayData}=await import('../src/measurement_overlay.mjs');const g=geometry();g.display_mesh.source_sha256='wrong';assert.equal(overlayData(g),null);
 await assert.rejects(()=>Tools.execute('show_reference',{kind:'cad_face',id:'1',source_sha256:'wrong'},{project:{project_id:'DG-H',version:1,design:{cad_geometry:geometry()}}}),/MISMATCH/);
});
test('agent face references require a measured face of saved geometry',async()=>{
 const p={project_id:'DG-H',version:1,design:{cad_geometry:geometry()}};
 const r=await Tools.execute('show_reference',{kind:'cad_face',id:'1',source_sha256:'a'.repeat(64)},{project:p});assert.equal(r.reference.kind,'cad_face');
 await assert.rejects(()=>Tools.execute('show_reference',{kind:'cad_face',id:'9',source_sha256:'a'.repeat(64)},{project:p}),/UNKNOWN/);
});
test('CAD references are selected from source-bound measured objects by opaque handle',async()=>{
 const g=geometry();g.measurement_revision='A';g.surface_measurements.measurement_revision='A';g.surface_measurements.observation_id='MEAS-1';
 const p={project_id:'DG-H',version:1,design:{active_revision:'A',cad_geometry:g}};
 const listed=await Tools.execute('list_cad_references',{}, {project:p});
 assert.equal(listed.references.length,4);
 assert(listed.references.every(x=>x.handle&&x.source_sha256==='a'.repeat(64)&&x.revision==='A'&&x.observation_id==='MEAS-1'));
 const shown=await Tools.execute('show_cad_reference',{handle:listed.references[0].handle},{project:p});
 assert.equal(shown.reference.handle,listed.references[0].handle);
});
