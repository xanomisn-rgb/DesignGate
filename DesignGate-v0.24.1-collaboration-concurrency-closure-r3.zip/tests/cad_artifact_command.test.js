const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('CAD_ARTIFACT_REGISTER only binds an immutable artifact matching the current revision', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-cad-command-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const commands = new CommandService({ store });
  store.createProject({ project_id: 'DG-CAD-CMD', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.registerArtifact({ artifact_id: 'ART-STEP-A', project_id: 'DG-CAD-CMD', revision_id: 'A', artifact_type: 'CAD', sha256: 'a'.repeat(64), immutable: true, created_by: 'USER-A' });

  const result = commands.execute({ command_id: 'CMD-CAD-A', idempotency_key: 'idem-cad-a', project_id: 'DG-CAD-CMD', command_type: 'CAD_ARTIFACT_REGISTER', base_project_version: 1, entity_type: 'CAD_ARTIFACT', entity_id: 'ART-STEP-A', base_entity_version: 0, payload: { artifact_id: 'ART-STEP-A', sha256: 'a'.repeat(64) } }, { user_id: 'USER-A' });
  assert.equal(result.event_type, 'CAD_ARTIFACT_CREATED');
  assert.equal(store.getProjectForActor('DG-CAD-CMD', 'USER-A').design.cad_artifact_id, 'ART-STEP-A');
  assert.throws(() => commands.execute({ command_id: 'CMD-CAD-BAD', idempotency_key: 'idem-cad-bad', project_id: 'DG-CAD-CMD', command_type: 'CAD_ARTIFACT_REGISTER', base_project_version: 2, entity_type: 'CAD_ARTIFACT', entity_id: 'ART-STEP-A', base_entity_version: 1, payload: { artifact_id: 'ART-STEP-A', sha256: 'b'.repeat(64) } }, { user_id: 'USER-A' }), /ARTIFACT_HASH_MISMATCH/);
});
