const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

function command(type, entity_id, payload) {
  return { command_id: `CMD-${entity_id}`, idempotency_key: `idem-${entity_id}`, project_id: 'DG-DFMEA-TEST', command_type: type, entity_type: 'TEST_RECORD', entity_id, base_project_version: 1, base_entity_version: 0, payload };
}

test('DFMEA test history appends FAIL and only permits a later PASS as an explicit retest', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-dfmea-test-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-DFMEA-TEST', project_name: 'Lamp' }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-DFI', idempotency_key: 'idem-dfi', project_id: 'DG-DFMEA-TEST', command_type: 'DFMEA_ITEM_CREATE', entity_type: 'DFMEA_ITEM', entity_id: 'DFI-001', base_project_version: 1, base_entity_version: 0, payload: { function: 'Retain battery', failure_modes: [{ failure_mode_id: 'FM-001', effect: 'Battery release', cause: 'Latch fracture', severity: 9, occurrence: 3, detection: 4 }], verification_plan_item: { plan_item_id: 'VP-001', failure_mode_ids: ['FM-001'], method: 'Latch cycle test', acceptance_criteria: 'No fracture in 100 cycles' } } }, { user_id: 'USER-A' });
  store.registerArtifact({ artifact_id: 'ART-TEST-001', project_id: 'DG-DFMEA-TEST', revision_id: 'A', artifact_type: 'EVIDENCE', sha256: 'a'.repeat(64), immutable: true, created_by: 'USER-A' });
  commands.execute({ command_id: 'CMD-EVD', idempotency_key: 'idem-evd', project_id: 'DG-DFMEA-TEST', command_type: 'EVIDENCE_ADD', entity_type: 'EVIDENCE', entity_id: 'EVD-001', base_project_version: 2, base_entity_version: 0, payload: { artifact_id: 'ART-TEST-001', sha256: 'a'.repeat(64), purpose: 'Latch-cycle evidence' } }, { user_id: 'USER-A' });
  const failed = commands.execute(command('TEST_RECORD_CREATE', 'TEST-FAIL-001', { plan_item_id: 'VP-001', failure_mode_ids: ['FM-001'], status: 'FAIL', actual_result: 'Latch fractured at cycle 30.', reviewer: 'Engineer A', completed_at: '2026-09-14T08:00:00.000Z', evidence_id: 'EVD-001' }), { user_id: 'USER-A' });
  assert.equal(failed.event_type, 'TEST_RECORDED');
  const unlinkedPass = command('TEST_RECORD_CREATE', 'TEST-PASS-UNLINKED', { plan_item_id: 'VP-001', failure_mode_ids: ['FM-001'], status: 'PASS', actual_result: 'New test passed.', reviewer: 'Engineer A', completed_at: '2026-09-14T10:00:00.000Z', evidence_id: 'EVD-001' });
  assert.throws(() => commands.execute(unlinkedPass, { user_id: 'USER-A' }), /PASS_REQUIRES_RETEST_OF_FAILED_TEST/);
  const retest = commands.execute(command('TEST_RETEST_CREATE', 'TEST-RETEST-001', { plan_item_id: 'VP-001', failure_mode_ids: ['FM-001'], status: 'PASS', actual_result: 'Updated latch passed 100 cycles.', reviewer: 'Engineer A', completed_at: '2026-09-14T11:00:00.000Z', evidence_id: 'EVD-001', retest_of: 'TEST-FAIL-001' }), { user_id: 'USER-A' });
  assert.equal(retest.event_type, 'TEST_RETEST_RECORDED');
  const records = store.getProjectForActor('DG-DFMEA-TEST', 'USER-A').dfmea_test_records;
  assert.deepEqual(records.map(record => [record.test_id, record.status, record.retest_of]), [['TEST-FAIL-001', 'FAILED', null], ['TEST-RETEST-001', 'PASS', 'TEST-FAIL-001']]);
});

test('a configured artifact verifier rejects DFMEA test evidence whose immutable bytes no longer verify', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-dfmea-byte-check-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store, artifactVerifier: () => false });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-DFMEA-TEST', project_name: 'Lamp' }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-DFI-BYTE', idempotency_key: 'idem-dfi-byte', project_id: 'DG-DFMEA-TEST', command_type: 'DFMEA_ITEM_CREATE', entity_type: 'DFMEA_ITEM', entity_id: 'DFI-BYTE-001', base_project_version: 1, base_entity_version: 0, payload: { function: 'Retain battery', failure_modes: [{ failure_mode_id: 'FM-BYTE-001', effect: 'Battery release', cause: 'Latch fracture', severity: 9, occurrence: 3, detection: 4 }], verification_plan_item: { plan_item_id: 'VP-BYTE-001', failure_mode_ids: ['FM-BYTE-001'], method: 'Latch cycle test', acceptance_criteria: 'No fracture in 100 cycles' } } }, { user_id: 'USER-A' });
  store.registerArtifact({ artifact_id: 'ART-BYTE-001', project_id: 'DG-DFMEA-TEST', revision_id: 'A', artifact_type: 'EVIDENCE', sha256: 'b'.repeat(64), immutable: true, created_by: 'USER-A' });
  commands.execute({ command_id: 'CMD-EVD-BYTE', idempotency_key: 'idem-evd-byte', project_id: 'DG-DFMEA-TEST', command_type: 'EVIDENCE_ADD', entity_type: 'EVIDENCE', entity_id: 'EVD-BYTE-001', base_project_version: 2, base_entity_version: 0, payload: { artifact_id: 'ART-BYTE-001', sha256: 'b'.repeat(64), purpose: 'Latch-cycle evidence' } }, { user_id: 'USER-A' });
  assert.throws(() => commands.execute(command('TEST_RECORD_CREATE', 'TEST-BYTE-FAIL', { plan_item_id: 'VP-BYTE-001', failure_mode_ids: ['FM-BYTE-001'], status: 'FAIL', actual_result: 'Latch fractured.', reviewer: 'Engineer A', completed_at: '2026-09-14T08:00:00.000Z', evidence_id: 'EVD-BYTE-001' }), { user_id: 'USER-A' }), error => error.code === 'TEST_EVIDENCE_ARTIFACT_INTEGRITY_INVALID');
});
