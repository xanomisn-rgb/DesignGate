const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

test('Team collaboration launch configuration declares scoped storage and a non-secret session variable', () => {
  const root = path.join(__dirname, '..');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const env = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
  assert.match(pkg.scripts['collaboration:server'] || '', /tools[\\/]collaboration_server\.js/);
  for (const key of ['DESIGNGATE_MODE=team', 'DESIGNGATE_SERVER_HOST=', 'DESIGNGATE_SERVER_PORT=', 'DESIGNGATE_COLLABORATION_DIR=', 'DESIGNGATE_ARTIFACT_DIR=', 'DESIGNGATE_SESSION_SECRET=']) assert.match(env, new RegExp(`^${key}`, 'm'));
  assert.doesNotMatch(env, /DGS_[A-Za-z0-9]/);
});
