const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');const os=require('os');const path=require('path');
const Bus=require('../backend/integrations/integration_event_bus');

test('integration event replay verifies payload and chain integrity and exposes a project index',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-replay-'));try{const bus=new Bus(dir);const base={event_type:'LAB_TELEMETRY_RECEIVED',project_id:'DG-R',revision:'A',source:'SIMULATED_DEVICE',source_id:'SIM-1',occurred_at:'2026-09-09T00:00:00.000Z'};
  bus.publish({...base,idempotency_key:'1',payload:{value:1}});bus.publish({...base,idempotency_key:'2',payload:{value:2}});
  assert.equal(bus.index('DG-R').event_count,2);assert.equal(bus.verifyReplay('DG-R').status,'VALID');
  const file=path.join(dir,'integration-events.jsonl');const rows=fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse);rows[1].payload.value=9;fs.writeFileSync(file,rows.map(JSON.stringify).join('\n')+'\n');
  assert.equal(bus.verifyReplay('DG-R').status,'INVALID');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('same idempotency key with a changed payload fails closed without appending an event',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-replay-conflict-'));try{const bus=new Bus(dir),base={event_type:'LAB_TELEMETRY_RECEIVED',project_id:'DG-R',revision:'A',source:'SIMULATED_DEVICE',source_id:'SIM-1',occurred_at:'2026-09-09T00:00:00.000Z',idempotency_key:'same-key'};
  bus.publish({...base,payload:{value:1}});
  assert.throws(()=>bus.publish({...base,payload:{value:2}}),/IDEMPOTENCY_CONFLICT/);
  assert.equal(bus.list('DG-R').length,1);
  assert.equal(bus.verifyReplay('DG-R').status,'VALID');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
