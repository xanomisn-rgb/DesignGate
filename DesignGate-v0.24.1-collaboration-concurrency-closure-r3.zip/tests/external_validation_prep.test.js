const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('external validation kit is explicitly preparation-only and binds independent review inputs',()=>{
 const root=path.join(__dirname,'..');
 const protocol=fs.readFileSync(path.join(root,'docs','v0.23','BATCH8_EXTERNAL_VALIDATION_PROTOCOL.md'),'utf8');
 const template=JSON.parse(fs.readFileSync(path.join(root,'docs','v0.23','external-validation-template.json'),'utf8'));
 assert.match(protocol,/independent/i);
 assert.match(protocol,/200/);
 assert.match(protocol,/production approval/i);
 assert.equal(template.status,'PREPARATION_ONLY_NOT_EXECUTED');
 assert.deepEqual(template.results,[]);
 assert.deepEqual(template.required_run_bindings.sort(),['code_artifact_hash','knowledge_snapshot_hash','model_identity','runtime_config_hash','tool_registry_hash']);
});
