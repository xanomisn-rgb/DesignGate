const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const crypto=require('crypto');
const State=require('../backend/project_state_manager');
const Workflow=require('../backend/workflow_service');
const Bus=require('../backend/integrations/integration_event_bus');
const {CadAdapter}=require('../backend/integrations/cad_adapter');
const {CadAnalysisRunner}=require('../backend/integrations/cad_analysis_runner');

function seed(dir){const state=new State(dir);state.saveProject({project_id:'DG-CAD',project_name:'cad',gate_engine_version:'v2',design:{active_revision:'B'},requirements:[],bom:[],findings:[],gate:{current_stage:'Gate 1',status:'OPEN'},evidence:[]},0);return state;}
test('CAD adapter emits append-only events and creates Workflow-bound evidence without changing a gate',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-adapter-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const state=seed(dir),workflow=new Workflow(state),bus=new Bus(path.join(dir,'events'));const file=path.join(dir,'part.step');fs.writeFileSync(file,'ISO-10303-21;');
 const adapter=new CadAdapter({stateManager:state,workflowService:workflow,eventBus:bus,runner:{analyze:async()=>({analysis_status:'BREP_ANALYZED_PARTIAL',analysis_success:true,file_sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),solid_count:2,face_count:12,bounding_box:null,measurements:{},assembly_analysis:{status:'ASSEMBLY_PAIR_ANALYZED',pairs:[{part_a_id:'SOLID-1',part_b_id:'SOLID-2',pair_status:'SEPARATED_CLEARANCE'}]},analyzer_backend:'OCP',analyzer_version:'8.0.1.0.0',limitations:['SAMPLED']})}});
 const result=await adapter.upload({project_id:'DG-CAD',revision:'B',source_system:'MOCK_CAD',idempotency_key:'upload-1',file_path:file,authorization:{authorized:true}});
 assert.equal(result.status,'ACCEPTED');assert(result.evidence_reference.manifest_id);assert.equal(bus.list('DG-CAD').map(x=>x.event_type).join(','),'CAD_REVISION_UPLOADED,CAD_ANALYSIS_STARTED,CAD_ANALYSIS_COMPLETE,EVIDENCE_CREATED');
 const project=state.getProject('DG-CAD');assert.equal(project.gate.status,'OPEN');assert.equal(project.evidence[0].provenance_status,'BOUND');
 assert.equal(project.cad_observations[0].analysis_summary.assembly_analysis.pairs[0].pair_status,'SEPARATED_CLEARANCE');
 const replay=await adapter.upload({project_id:'DG-CAD',revision:'B',source_system:'MOCK_CAD',idempotency_key:'upload-1',file_path:file,authorization:{authorized:true}});assert.equal(replay.status,'DUPLICATE_REPLAY');
});
test('CAD adapter rejects an old revision and never silently promotes it to current evidence',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-old-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const state=seed(dir),file=path.join(dir,'part.step');fs.writeFileSync(file,'x');const adapter=new CadAdapter({stateManager:state,workflowService:new Workflow(state),eventBus:new Bus(path.join(dir,'events')),runner:{analyze:async()=>{throw Error('not called');}}});
 await assert.rejects(()=>adapter.upload({project_id:'DG-CAD',revision:'A',source_system:'MOCK_CAD',idempotency_key:'old',file_path:file,authorization:{authorized:true}}),/REJECT_OLD_REVISION/);
});
test('actual STEP analysis is stored as revision-bound CAD evidence, never a Gate decision',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-cad-actual-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const state=seed(dir),workflow=new Workflow(state),runner=new CadAnalysisRunner({timeout_ms:30000});
 const health=await runner.discoverBackend();if(!health.available)return t.skip('OCP environment unavailable');
 const adapter=new CadAdapter({stateManager:state,workflowService:workflow,eventBus:new Bus(path.join(dir,'events')),runner});
 const result=await adapter.upload({project_id:'DG-CAD',revision:'B',source_system:'LOCAL_OCP',idempotency_key:'actual-step',file_path:path.join(__dirname,'../samples/brep/plate_1_3mm.step'),authorization:{authorized:true}});
 const project=state.getProject('DG-CAD');assert.equal(result.status,'ACCEPTED');assert.equal(project.cad_observations[0].analysis_summary.thickness_oracle.global_mathematical_proof,false);assert.equal(project.cad_observations[0].status,'NEEDS_HUMAN_REVIEW');assert.equal(project.gate.status,'OPEN');
});
