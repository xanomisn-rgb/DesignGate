const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const Loader=require('../eval/v1/benchmark_loader');
const GoldGuard=require('../eval/v1/gold_isolation_guard');
const RunManifest=require('../eval/v1/run_manifest');
const FaultInjection=require('../eval/v1/fault_injection');
const DeterministicGrader=require('../eval/v1/deterministic_grader');
const Runner=require('../eval/v1/runner');
const Canonical=require('../backend/crypto/canonical_json');
const {createAgentExecutor}=require('../eval/v1/agent_executor');
const SemanticGrader=require('../eval/v1/semantic_grader');
const BudgetGuard=require('../eval/v1/multiagent/budget_guard');
const ReviewExport=require('../eval/v1/expert_review_export');
const RoutingManifest=require('../eval/v1/multiagent/routing_manifest');
const LiveRunner=require('../eval/v1/live_runner');
const LiveJournal=require('../eval/v1/live_journal');
const MultiAgentRunner=require('../eval/v1/multiagent/runner');
const MultiAgentAdapter=require('../eval/v1/multiagent/agent_adapter');
const MultiAgentLive=require('../eval/v1/multiagent/live_runner');

function fixture(t){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-benchmark-v1-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const cases={benchmark_version:'1.0.0',cases:Array.from({length:21},(_,index)=>({case_id:`DG-DEV-${index+1}`,split:'dev',agent_input:{prompt:`prompt ${index+1}`,context:{index}}}))};
  fs.writeFileSync(path.join(dir,'dev_cases.json'),JSON.stringify(cases));fs.writeFileSync(path.join(dir,'freeze_manifest.json'),JSON.stringify({benchmark_version:'1.0.0',canonical_fixture_sha256:Canonical.sha256(cases)}));return dir;
}

test('v1 loader accepts exactly 21 frozen dev cases and keeps case IDs out of agent input',t=>{
  const loader=new Loader({fixture_root:fixture(t)}),suite=loader.loadDev();
  assert.equal(suite.cases.length,21);
  assert.equal(suite.status,'FROZEN');
  assert.equal(Object.hasOwn(suite.agentInput(suite.cases[0]),'case_id'),false);
  assert.throws(()=>loader.loadHeldout(),error=>error.code==='HELDOUT_PAYLOAD_UNAVAILABLE');
});

test('v1 loader defaults to the packaged frozen dev fixture',()=>{
  const suite=new Loader().loadDev();
  assert.equal(suite.cases.length,21);
  assert.equal(suite.fixture_hash,'9f2307bf38d1f141b0c98c12d270ac9d848dc57d90d7b73eeb27dfd6bfdf8b0a');
});

test('v1 loader rejects a fixture changed after its freeze manifest was made',t=>{
  const dir=fixture(t),file=path.join(dir,'dev_cases.json'),document=JSON.parse(fs.readFileSync(file,'utf8'));
  document.cases[0].agent_input.prompt='tampered';fs.writeFileSync(file,JSON.stringify(document));
  assert.throws(()=>new Loader({fixture_root:dir}).loadDev(),error=>error.code==='BENCHMARK_FREEZE_HASH_MISMATCH');
});

test('gold isolation guard denies agent access to every Gold path',()=>{
  const guard=new GoldGuard({gold_root:'/private/gold'});
  assert.throws(()=>guard.resolveForAgent('dev_gold.json'),error=>error.code==='GOLD_ACCESS_DENIED');
  assert(guard.resolveForGrader('dev_gold.json').endsWith('gold'+path.sep+'dev_gold.json'));
});

test('formal v1 result becomes unbound when a required identity is missing',()=>{
  const incomplete=RunManifest.create({benchmark_version:'1.0.0',fixture_hash:'a'.repeat(64)});
  assert.equal(incomplete.status,'UNBOUND_EVAL_RESULT');
  const bound=RunManifest.create({benchmark_version:'1.0.0',fixture_hash:'a'.repeat(64),code_artifact_hash:'b'.repeat(64),tool_registry_hash:'c'.repeat(64),knowledge_snapshot_hash:'d'.repeat(64),runtime_config_hash:'e'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}});
  assert.equal(bound.status,'RUNNER_IMPLEMENTED');
});

test('fault injection is deterministic and only alters the declared fault surface',()=>{
  const input={event_chain:'VALID',tool_status:'OK',payload:{temperature:46.8}};
  const first=FaultInjection.apply(input,{kind:'EVENT_CHAIN_TAMPER',seed:'case-1'});
  const second=FaultInjection.apply(input,{kind:'EVENT_CHAIN_TAMPER',seed:'case-1'});
  assert.deepEqual(first,second);
  assert.equal(first.event_chain,'INVALID');
  assert.equal(first.payload.temperature,46.8);
  assert.throws(()=>FaultInjection.apply(input,{kind:'UNKNOWN',seed:'case-1'}),error=>error.code==='FAULT_INJECTION_UNKNOWN');
});

test('v1 deterministic grader rejects fabricated evidence and a model-only PASS claim',()=>{
  const grade=DeterministicGrader.grade({case_id:'DG-DEV-1',status:'COMPLETED',tool_trace:[{tool:'screen_design',status:'SUCCEEDED',observation_id:'OBS-1'}],final_result:{evidence_ids:['OBS-FAKE'],summary:'PASS and freeze'},authoritative_mutations:[]},{case_id:'DG-DEV-1',required_tools:['screen_design']});
  assert.equal(grade.status,'FAIL');
  assert(grade.hard_safety_events.includes('FABRICATED_EVIDENCE'));
  assert(grade.hard_safety_events.includes('MODEL_ONLY_PASS_CLAIM'));
});

test('v1 runner executes all dev inputs without exposing case IDs or Gold to the executor',async()=>{
  const seen=[];
  let checkpoints=0;const report=await Runner.runDev({bindings:{code_artifact_hash:'a'.repeat(64),tool_registry_hash:'b'.repeat(64),knowledge_snapshot_hash:'c'.repeat(64),runtime_config_hash:'d'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}},execute:async input=>{seen.push(input);assert.equal(Object.hasOwn(input,'case_id'),false);assert.equal(JSON.stringify(input).includes('gold_findings'),false);return {status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]}};},onCase:()=>checkpoints++});
  assert.equal(seen.length,21);
  assert.equal(checkpoints,21);
  assert.equal(report.status,'RUNNER_IMPLEMENTED');
  assert.equal(report.case_results.length,21);
  assert.equal(report.case_results[0].semantic_grade.status,'PENDING_HUMAN_REVIEW');
});

test('v1 runner resumes only a bound, terminal raw trial and does not repeat it',async()=>{
  let calls=0,checkpoints=0;
  const caseId=new Loader().loadDev().cases[0].case_id;
  const bindings={code_artifact_hash:'a'.repeat(64),tool_registry_hash:'b'.repeat(64),knowledge_snapshot_hash:'c'.repeat(64),runtime_config_hash:'d'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}};
  const report=await Runner.runDev({bindings,execute:async()=>{calls++;return {status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]}};},onCase:()=>checkpoints++,resume_results:{[caseId]:{case_id:caseId,status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]},resume_manifest_hash:RunManifest.create({benchmark_version:'1.0.0',fixture_hash:'9f2307bf38d1f141b0c98c12d270ac9d848dc57d90d7b73eeb27dfd6bfdf8b0a',...bindings}).manifest_hash}}});
  assert.equal(calls,20);
  assert.equal(checkpoints,20);
  assert.equal(report.case_results.length,21);
  assert.equal(report.case_results[0].resumed,true);
});

test('v1 runner checkpoints every new trial with its immutable manifest binding',async()=>{
  const checkpoints=[];
  const report=await Runner.runDev({bindings:{code_artifact_hash:'a'.repeat(64),tool_registry_hash:'b'.repeat(64),knowledge_snapshot_hash:'c'.repeat(64),runtime_config_hash:'d'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}},execute:async()=>({status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]}}),onCase:trial=>checkpoints.push(trial)});
  assert.equal(checkpoints.length,21);
  assert(checkpoints.every(trial=>trial.resume_manifest_hash===report.manifest.manifest_hash));
});

test('v1 runner writes the required audit artifact set',async t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v1-output-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const report=await Runner.runDev({bindings:{code_artifact_hash:'a'.repeat(64),tool_registry_hash:'b'.repeat(64),knowledge_snapshot_hash:'c'.repeat(64),runtime_config_hash:'d'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}},execute:async()=>({status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]}})});
  Runner.writeArtifacts(report,dir);
  for(const file of ['run_manifest.json','case_results.jsonl','tool_traces.jsonl','hard_safety_events.jsonl','aggregate_metrics.json','model_usage.json','expert_review_export.json','validation_summary.md'])assert(fs.existsSync(path.join(dir,file)));
});

test('v1 agent executor runs the existing AgentRuntime and returns its actual trace',async t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-v1-agent-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));let id=0,index=0;
  const tool=(name,args)=>({message:{tool_calls:[{id:`call-${++id}`,function:{name,arguments:JSON.stringify(args)}}]}});
  const sequence=[tool('update_plan',{steps:['read','check','finish'],reason:'test'}),tool('inspect_requirements',{}),tool('finish_task',{summary:'needs evidence',evidence_ids:['OBS-2'],limitations:['synthetic']})];const executor=createAgentExecutor({storage_root:dir,model:async()=>sequence[index++]});
  const result=await executor({prompt:'review this requirement',context:{}});
  assert.equal(result.status,'COMPLETED');
  assert(result.run_id.startsWith('RUN-'));
  assert.equal(result.tool_trace[1].tool,'inspect_requirements');
});

test('structured semantic grading reports unsupported behaviors as pending review, not pass',()=>{
  const result=SemanticGrader.grade({behavior_tags:['IDENTIFIED_DATA_GAP']},{required_behaviors:['IDENTIFIED_DATA_GAP','NO_RELEASE_CLAIM'],forbidden_behaviors:['FALSE_RELEASE']});
  assert.equal(result.status,'PENDING_HUMAN_REVIEW');
  assert.deepEqual(result.missing_required,['NO_RELEASE_CLAIM']);
});

test('v1 multi-agent budget guard enforces one shared fixed budget across roles',()=>{
  const guard=new BudgetGuard({max_tokens:100});
  guard.reserve({role:'main',tokens:60});
  assert.throws(()=>guard.reserve({role:'specialist-A02',tokens:41}),error=>error.code==='MULTIAGENT_SHARED_BUDGET_EXCEEDED');
  guard.reserve({role:'chief',tokens:40});
  assert.deepEqual(guard.snapshot().by_role,{main:60,chief:40});
});

test('v1 expert review export rejects a reviewed row without reviewer identity and timestamp',()=>{
  assert.throws(()=>ReviewExport.validate({status:'PENDING_HUMAN_REVIEW',cases:[{case_id:'DG-DEV-1',reviewed:true,reviewer:'',reviewed_at:null}]}),error=>error.code==='EXPERT_REVIEW_INVALID');
  assert.doesNotThrow(()=>ReviewExport.validate({status:'PENDING_HUMAN_REVIEW',cases:[{case_id:'DG-DEV-1',reviewed:false,reviewer:null,reviewed_at:null}]}));
});

test('v1 A/B/C routing manifest rejects a variant that changes the base model',()=>{
  assert.throws(()=>RoutingManifest.create({fixture_hash:'a'.repeat(64),knowledge_snapshot_hash:'b'.repeat(64),shared_budget:{max_tokens:100},variants:[{name:'A',model:'same'},{name:'B',model:'same'},{name:'C',model:'other'}]}),error=>error.code==='MULTIAGENT_FAIRNESS_BINDING_INVALID');
  const manifest=RoutingManifest.create({fixture_hash:'a'.repeat(64),knowledge_snapshot_hash:'b'.repeat(64),shared_budget:{max_tokens:100},variants:[{name:'A',model:'same'},{name:'B',model:'same'},{name:'C',model:'same'}]});
  assert.equal(manifest.same_base_model_limitation,true);
});

test('v1 A/B/C runner executes every fixed-model route under one shared budget',async()=>{
  const report=await MultiAgentRunner.run({fixture_hash:'a'.repeat(64),knowledge_snapshot_hash:'b'.repeat(64),model:'same-model',shared_budget:{max_tokens:90},input:{prompt:'bounded review'},execute:async({variant})=>({status:'COMPLETED',usage:{total_tokens:30},route:variant.name})});
  assert.equal(report.status,'MULTIAGENT_RUNNER_IMPLEMENTED_PENDING_HUMAN_REVIEW');
  assert.deepEqual(report.results.map(row=>row.variant),['A','B','C']);
  assert.equal(report.budget.used_tokens,90);
  assert.equal(report.same_base_model_limitation,true);
});

test('v1 A/B/C runner retains completed route records when the shared budget blocks a later route',async()=>{
  const report=await MultiAgentRunner.run({fixture_hash:'a'.repeat(64),knowledge_snapshot_hash:'b'.repeat(64),model:'same-model',shared_budget:{max_tokens:40},input:{prompt:'bounded review'},execute:async({variant})=>({status:'COMPLETED',usage:{total_tokens:30},route:variant.name})});
  assert.equal(report.status,'MULTIAGENT_SHARED_BUDGET_EXCEEDED');
  assert.deepEqual(report.results.map(row=>row.variant),['A']);
});

test('v1 A/B/C runner preflights a conservative route reserve before provider execution',async()=>{
  let calls=0;const report=await MultiAgentRunner.run({fixture_hash:'a'.repeat(64),knowledge_snapshot_hash:'b'.repeat(64),model:'same-model',shared_budget:{max_tokens:40},route_reserve_tokens:30,input:{prompt:'bounded review'},execute:async()=>{calls++;return {status:'COMPLETED',usage:{total_tokens:30}};}});
  assert.equal(calls,1);assert.equal(report.blocked_route,'B');assert.equal(report.status,'MULTIAGENT_SHARED_BUDGET_EXCEEDED');
});

test('v1 A/B/C adapter routes through the existing isolated executor and refuses missing telemetry',async()=>{
  const calls=[],adapter=MultiAgentAdapter.create({executor:async input=>{calls.push(input);return {status:'COMPLETED',usage:{total_tokens:7}};}});
  const result=await adapter({variant:{name:'B',model:'same'},input:{prompt:'review',context:{x:1}}});
  assert.match(calls[0].prompt,/Route B/);
  assert.equal(result.usage.total_tokens,7);
  const incomplete=MultiAgentAdapter.create({executor:async()=>({status:'COMPLETED'})});
  await assert.rejects(()=>incomplete({variant:{name:'A',model:'same'},input:{prompt:'review'}}),error=>error.code==='MULTIAGENT_USAGE_UNAVAILABLE');
});

test('v1 live runner does not simulate a provider run when required configuration is absent',async()=>{
  const result=await LiveRunner.run({env:{}});
  assert.equal(result.status,'BLOCKED_BY_ENVIRONMENT');
  assert.equal(result.milestone,'LIVE_MODEL_VALIDATION_NOT_RUN');
  assert.equal(result.planned_runs,63);
});

test('v1 A/B/C live runner blocks without provider configuration',async()=>{
  const result=await MultiAgentLive.run({env:{}});
  assert.equal(result.status,'BLOCKED_BY_ENVIRONMENT');
  assert.equal(result.milestone,'MULTIAGENT_LIVE_VALIDATION_NOT_RUN');
});

test('v1 A/B/C live runner binds the packaged frozen fixture and knowledge snapshot',()=>{
  const bindings=MultiAgentLive.bindings('same-model');
  assert.equal(bindings.fixture_hash,'9f2307bf38d1f141b0c98c12d270ac9d848dc57d90d7b73eeb27dfd6bfdf8b0a');
  assert.match(bindings.knowledge_snapshot_hash,/^[a-f0-9]{64}$/);
});

test('live journal reuses only integrity-checked trials bound to the current manifest',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-live-journal-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const file=path.join(dir,'live_case_journal.jsonl'),manifest='a'.repeat(64);
  LiveJournal.append(file,{repeat:1,case_id:'DG-BV1-REQ-001',status:'COMPLETED',tool_trace:[],final_result:{evidence_ids:[]},resume_manifest_hash:manifest});
  LiveJournal.append(file,{repeat:1,case_id:'DG-BV1-REQ-002',status:'RUNNING',resume_manifest_hash:manifest});
  assert.equal(LiveJournal.loadForManifest(file,manifest).get(1).size,1);
  assert.equal(LiveJournal.loadForManifest(file,'b'.repeat(64)).size,0);
});

test('live journal rejects a concurrent runner instead of allowing competing writes',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-live-lock-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const lock=LiveJournal.acquireLock(path.join(dir,'live_case_journal.jsonl'));
  assert.throws(()=>LiveJournal.acquireLock(path.join(dir,'live_case_journal.jsonl')),error=>error.code==='LIVE_JOURNAL_LOCKED');
  LiveJournal.releaseLock(lock);
});

test('live runner converts only manifest-matched journal trials into runner resume records',t=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-live-resume-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const bindings={code_artifact_hash:'a'.repeat(64),tool_registry_hash:'b'.repeat(64),knowledge_snapshot_hash:'c'.repeat(64),runtime_config_hash:'d'.repeat(64),model:{provider:'test',name:'test-model',version:'v1'}};
  const manifest=RunManifest.create({benchmark_version:'1.0.0',fixture_hash:'9f2307bf38d1f141b0c98c12d270ac9d848dc57d90d7b73eeb27dfd6bfdf8b0a',...bindings});
  const file=path.join(dir,'live_case_journal.jsonl');LiveJournal.append(file,{repeat:1,case_id:'DG-BV1-REQ-001',status:'COMPLETED',resume_manifest_hash:manifest.manifest_hash});
  assert.equal(LiveRunner.resumeResults(file,bindings)[1]['DG-BV1-REQ-001'].status,'COMPLETED');
});
