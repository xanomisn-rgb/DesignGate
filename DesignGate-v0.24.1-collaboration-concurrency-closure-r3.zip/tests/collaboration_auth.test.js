const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');

test('local development user can log in and receives an expiring opaque session', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-collab-auth-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));

  const identity = new IdentityService({ directory, sessionSecret: 'test-session-secret' });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple', display_name: 'Alice' });

  const session = identity.login({ username: 'alice', password: 'correct horse battery staple' });
  assert.equal(session.user.user_id, 'USER-A');
  assert.equal(session.user.username, 'alice');
  assert.match(session.token, /^DGS_/);
  assert.ok(Date.parse(session.expires_at) > Date.now());
  assert.equal(identity.authenticate(session.token).user_id, 'USER-A');
});
