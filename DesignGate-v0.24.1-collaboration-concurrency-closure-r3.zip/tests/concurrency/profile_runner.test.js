const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { runProfiles } = require('../../tools/concurrency/run_profiles');

test('profile runner executes each isolated external-process profile and writes one aggregate manifest', async (t) => {
  const outputDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-profile-report-'));
  t.after(() => fs.rmSync(outputDirectory, { recursive: true, force: true }));
  const aggregate = await runProfiles({ outputDirectory, profiles: [{ profile: 'TEST-A', clientCount: 2, commandsPerClient: 1 }, { profile: 'TEST-B', clientCount: 1, commandsPerClient: 2 }] });

  assert.equal(aggregate.status, 'PASSED');
  assert.equal(aggregate.runs.length, 2);
  assert.deepEqual(aggregate.runs.map(run => run.metrics.command_count), [2, 2]);
  assert.ok(fs.existsSync(aggregate.manifest_path));
});
