const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { runExternalLoadProfile } = require('../../tools/concurrency/load_runner');

test('external-process load runner writes an isolated metrics report and validates committed state', async (t) => {
  const outputDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-load-report-'));
  t.after(() => fs.rmSync(outputDirectory, { recursive: true, force: true }));
  const report = await runExternalLoadProfile({ profile: 'TEST', clientCount: 3, commandsPerClient: 2, outputDirectory });

  assert.equal(report.status, 'PASSED');
  assert.equal(report.metrics.command_count, 6);
  assert.equal(report.metrics.success_count, 6);
  assert.equal(report.metrics.unexpected_5xx_count, 0);
  assert.ok(Number.isFinite(report.metrics.runner_resources.cpu_user_ms));
  assert.ok(Number.isFinite(report.metrics.runner_resources.rss_bytes_end));
  assert.ok(Number.isFinite(report.metrics.command_latency_ms.p95));
  assert.ok(Number.isFinite(report.metrics.throughput_commands_per_second));
  assert.equal(report.invariants.valid, true);
  assert.ok(fs.existsSync(report.report_path));
  assert.deepEqual(JSON.parse(fs.readFileSync(report.report_path, 'utf8')).metrics, report.metrics);
});
