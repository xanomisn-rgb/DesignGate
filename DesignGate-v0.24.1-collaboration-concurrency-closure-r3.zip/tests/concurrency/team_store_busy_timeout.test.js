const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../../backend/collaboration/team_store');

test('TeamStore configures a bounded SQLite busy timeout for brief write-lock contention', (t) => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-sqlite-busy-timeout-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  assert.ok(store.db.prepare('PRAGMA busy_timeout').get().timeout >= 5_000);
});
