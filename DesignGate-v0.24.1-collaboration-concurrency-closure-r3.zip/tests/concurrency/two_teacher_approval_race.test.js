const test = require('node:test');
const assert = require('node:assert/strict');
const FinalFreezeService = require('../../backend/collaboration/final_freeze_service');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('two teachers may retain independent current approvals only when each binds to the same current project state', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 3 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const teacherA = fixture.clients[1];
  const teacherB = fixture.clients[2];
  const project = await owner.createProject({ project_id: 'DG-TWO-TEACHERS', project_name: 'Independent teacher approval fixture' });
  await owner.addMember(project.project_id, { user_id: teacherA.user_id, role_id: 'TEACHER_REVIEWER' });
  await owner.addMember(project.project_id, { user_id: teacherB.user_id, role_id: 'TEACHER_REVIEWER' });

  const artifact = fixture.artifactStore.put({ project_id: project.project_id, revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'review.csv', bytes: Buffer.from('result,PASS\n'), created_by: owner.user_id });
  fixture.store.registerArtifact(artifact);
  const prepared = await owner.project(project.project_id);
  prepared.evidence = [{ evidence_id: 'EVD-TWO-TEACHERS', artifact_id: artifact.artifact_id, artifact_sha256: artifact.sha256, project_id: project.project_id, revision_id: 'A', status: 'CURRENT' }];
  prepared.dfmea = null;
  prepared.dfmea_test_records = [];
  prepared.dfmea_verification_plan = null;
  prepared.risk_acceptances = [];
  prepared.gate = { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'A', decision: 'PASS', freeze_eligible: true } };
  fixture.store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(prepared), project.project_id);

  const barrier = createBarrier(2);
  const responses = await Promise.all([
    [teacherA, 'APR-TEACHER-A'],
    [teacherB, 'APR-TEACHER-B']
  ].map(([teacher, approvalId]) => (async () => {
    await barrier.ready();
    return teacher.command(project.project_id, {
      command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: approvalId,
      payload: { decision: 'APPROVED', reason: 'Independent teacher review.' }, idempotency_key: approvalId
    }, { allowError: true });
  })()));

  assert.deepEqual(responses.map(response => response.status).sort((a, b) => a - b), [200, 200]);
  const current = await owner.project(project.project_id);
  const approvals = current.approvals.filter(approval => approval.status === 'CURRENT');
  assert.equal(approvals.length, 2);
  assert.deepEqual(new Set(approvals.map(approval => approval.actor_id)), new Set([teacherA.user_id, teacherB.user_id]));
  const finalFreeze = new FinalFreezeService({ store: fixture.store, artifactVerifier: artifactRow => fixture.artifactStore.verifyHash(fixture.artifactStore.getMetadata(artifactRow.artifact_id)) });
  const bindings = finalFreeze.revalidate({ project_id: project.project_id, state: current });
  for (const approval of approvals) assert.doesNotThrow(() => finalFreeze.validateApproval({ approval, bindings }));
});
