const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { spawn } = require('child_process');
const { createNetworkFixture } = require('../../tools/concurrency/harness');

function runExternalClient(input) {
  const worker = path.join(__dirname, '../../tools/concurrency/http_command_worker.js');
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [worker], {
      env: { ...process.env, DG_CONCURRENCY_WORKER_INPUT: JSON.stringify(input) },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.once('error', reject);
    child.once('close', code => {
      if (code !== 0) return reject(Error(`EXTERNAL_CLIENT_EXIT_${code}:${stderr || stdout}`));
      try { resolve(JSON.parse(stdout)); } catch (error) { reject(Error(`EXTERNAL_CLIENT_INVALID_JSON:${error.message}:${stdout}`)); }
    });
  });
}

test('twenty independent Node processes authenticate and race one HTTP entity without a lost update', async (t) => {
  const fixture = await createNetworkFixture();
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-EXTERNAL-RACE', project_name: 'External process race fixture' });
  const results = await Promise.all(Array.from({ length: 20 }, (_, index) => runExternalClient({
    base: fixture.base,
    username: 'user0',
    password: 'concurrency-test-password',
    project_id: project.project_id,
    command: {
      command_id: `CMD-EXTERNAL-${index}`,
      idempotency_key: `IDEMP-EXTERNAL-${index}`,
      base_project_version: 1,
      base_entity_version: 0,
      entity_type: 'BOM_ITEM',
      entity_id: 'BOM-EXTERNAL-RACE',
      command_type: 'UPDATE_BOM_ITEM',
      payload: { part_id: 'BOM-EXTERNAL-RACE', part_name: `External candidate ${index}`, quantity: 1 }
    }
  })));

  assert.equal(results.filter(result => result.status === 200).length, 1);
  assert.equal(results.filter(result => result.status === 409 && result.body.code === 'ENTITY_VERSION_CONFLICT').length, 19);
  const current = await owner.project(project.project_id);
  assert.equal(current.bom.length, 1);
  assert.equal(fixture.store.entityVersion(project.project_id, 'BOM_ITEM', 'BOM-EXTERNAL-RACE'), 1);
  assert.equal(fixture.store.listEvents(project.project_id).filter(event => event.entity_id === 'BOM-EXTERNAL-RACE').length, 1);
});
