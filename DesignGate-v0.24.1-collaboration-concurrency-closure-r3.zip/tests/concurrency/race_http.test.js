const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('20 authenticated HTTP writers to one BOM entity yield one commit and nineteen entity-version conflicts', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 20 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-RACE-A1', project_name: 'Race fixture' });
  await fixture.addCollaborators(project.project_id);
  const seeded = await owner.command(project.project_id, {
    command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-P03',
    payload: { part_id: 'BOM-P03', part_name: 'Initial housing', quantity: 1 }, idempotency_key: 'SEED-BOM-P03'
  });
  const barrier = createBarrier(20);
  const responses = await Promise.all(fixture.clients.map((client, index) => (async () => {
    await barrier.ready();
    return client.command(project.project_id, {
      command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-P03',
      payload: { part_id: 'BOM-P03', part_name: `Housing ${index}`, quantity: index + 1 },
      base_entity_version: seeded.body.entity_version,
      idempotency_key: `RACE-A1-${index}`
    }, { allowError: true });
  })()));
  const applied = responses.filter(row => row.status === 200);
  const conflicts = responses.filter(row => row.status === 409 && row.body.code === 'ENTITY_VERSION_CONFLICT');
  const current = await owner.project(project.project_id);

  assert.equal(applied.length, 1);
  assert.equal(conflicts.length, 19);
  assert.equal(fixture.store.entityVersion(project.project_id, 'BOM_ITEM', 'BOM-P03'), seeded.body.entity_version + 1);
  assert.equal(current.bom.filter(item => item.part_id === 'BOM-P03').length, 1);
});

test('20 identical HTTP idempotency submissions produce one domain event and deterministic replays', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 20 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-RACE-A4', project_name: 'Idempotency fixture' });
  await fixture.addCollaborators(project.project_id);
  const barrier = createBarrier(20);
  const command = { command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-IDEM', payload: { part_id: 'BOM-IDEM', part_name: 'Shared housing', quantity: 1 }, base_entity_version: 0, idempotency_key: 'IDEM-RACE-A4' };
  const responses = await Promise.all(fixture.clients.map(client => (async () => { await barrier.ready(); return client.command(project.project_id, command, { allowError: true }); })()));
  const events = fixture.store.listEvents(project.project_id, { after: 0, limit: 1000 }).filter(event => event.idempotency_key === 'IDEM-RACE-A4');

  assert.equal(responses.filter(row => row.status === 200).length, 20);
  assert.equal(events.length, 1);
  assert.equal(fixture.store.entityVersion(project.project_id, 'BOM_ITEM', 'BOM-IDEM'), 1);
  assert.equal(responses.filter(row => row.body.status === 'APPLIED').length, 1);
  assert.equal(responses.filter(row => row.body.status === 'DUPLICATE_REPLAY').length, 19);
});

test('same idempotency key with different HTTP payloads permits one command and rejects the conflicting replay', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 2 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-RACE-A5', project_name: 'Idempotency conflict fixture' });
  await fixture.addCollaborators(project.project_id);
  const barrier = createBarrier(2);
  const responses = await Promise.all(fixture.clients.map((client, index) => (async () => {
    await barrier.ready();
    return client.command(project.project_id, {
      command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-DIFF', base_entity_version: 0,
      payload: { part_id: 'BOM-DIFF', part_name: `Payload ${index}`, quantity: index + 1 }, idempotency_key: 'IDEM-RACE-A5'
    }, { allowError: true });
  })()));
  const events = fixture.store.listEvents(project.project_id, { after: 0, limit: 1000 }).filter(event => event.idempotency_key === 'IDEM-RACE-A5');

  assert.equal(responses.filter(row => row.status === 200).length, 1);
  assert.equal(responses.filter(row => row.status === 409 && row.body.code === 'IDEMPOTENCY_CONFLICT').length, 1);
  assert.equal(events.length, 1);
});

test('20 authenticated HTTP writers to distinct BOM entities all commit without false entity conflicts', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 20 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-RACE-A2', project_name: 'Parallel entity fixture' });
  await fixture.addCollaborators(project.project_id);
  const barrier = createBarrier(20);
  const responses = await Promise.all(fixture.clients.map((client, index) => (async () => {
    await barrier.ready();
    return client.command(project.project_id, {
      command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: `BOM-${index}`,
      payload: { part_id: `BOM-${index}`, part_name: `Part ${index}`, quantity: index + 1 }, base_entity_version: 0, idempotency_key: `RACE-A2-${index}`
    }, { allowError: true });
  })()));
  const current = await owner.project(project.project_id);

  assert.equal(responses.filter(row => row.status === 200).length, 20);
  assert.equal(responses.filter(row => row.status === 409).length, 0);
  assert.equal(current.bom.length, 20);
  assert.equal(fixture.store.listEvents(project.project_id, { after: 0, limit: 1000 }).filter(event => event.event_type === 'BOM_ITEM_UPDATED').length, 20);
});
