const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('two concurrent final-freeze requests create one record and reject the loser as a conflict, never a server error', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 2 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const teacher = fixture.clients[1];
  const project = await owner.createProject({ project_id: 'DG-DOUBLE-FRZ', project_name: 'Double freeze HTTP status fixture' });
  await owner.addMember(project.project_id, { user_id: teacher.user_id, role_id: 'TEACHER_REVIEWER' });

  const artifact = fixture.artifactStore.put({ project_id: project.project_id, revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'result.csv', bytes: Buffer.from('result,PASS\n'), created_by: owner.user_id });
  fixture.store.registerArtifact(artifact);
  const prepared = await owner.project(project.project_id);
  prepared.evidence = [{ evidence_id: 'EVD-DOUBLE-FRZ', artifact_id: artifact.artifact_id, artifact_sha256: artifact.sha256, project_id: project.project_id, revision_id: 'A', status: 'CURRENT' }];
  prepared.dfmea = null;
  prepared.dfmea_test_records = [];
  prepared.dfmea_verification_plan = null;
  prepared.risk_acceptances = [];
  prepared.gate = { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'A', decision: 'PASS', freeze_eligible: true } };
  fixture.store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(prepared), project.project_id);

  const approval = await teacher.command(project.project_id, {
    command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-DOUBLE-FRZ',
    payload: { decision: 'APPROVED', reason: 'Current bounded review completed.' }, idempotency_key: 'APR-DOUBLE-FRZ'
  });
  assert.equal(approval.status, 200);

  const barrier = createBarrier(2);
  const [first, second] = await Promise.all(['FRZ-DOUBLE-A', 'FRZ-DOUBLE-B'].map((freezeId) => (async () => {
    await barrier.ready();
    return teacher.command(project.project_id, {
      command_type: 'FINAL_FREEZE_APPROVE', entity_type: 'FINAL_FREEZE', entity_id: freezeId,
      payload: { reason: 'Concurrent final-freeze request.' }, idempotency_key: freezeId
    }, { allowError: true });
  })()));

  assert.deepEqual([first.status, second.status].sort((a, b) => a - b), [200, 409]);
  const loser = first.status === 409 ? first : second;
  assert.equal(loser.body.code, 'FROZEN_REVISION');
  const current = await owner.project(project.project_id);
  assert.equal(current.freeze_records.length, 1);
  assert.equal(current.freeze.freeze_id, first.status === 200 ? 'FRZ-DOUBLE-A' : 'FRZ-DOUBLE-B');
});
