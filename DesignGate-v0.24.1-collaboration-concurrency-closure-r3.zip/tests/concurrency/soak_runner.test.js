const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { runExternalLoadProfile } = require('../../tools/concurrency/load_runner');

test('multi-round external-process soak workload retains one server state and validates all committed waves', async (t) => {
  const outputDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-soak-report-'));
  t.after(() => fs.rmSync(outputDirectory, { recursive: true, force: true }));
  const report = await runExternalLoadProfile({ profile: 'SOAK_TEST', clientCount: 2, commandsPerClient: 2, rounds: 3, outputDirectory });

  assert.equal(report.status, 'PASSED');
  assert.equal(report.execution.rounds, 3);
  assert.equal(report.metrics.command_count, 12);
  assert.equal(report.metrics.success_count, 12);
  assert.equal(report.invariants.event_count, 13);
  assert.equal(report.invariants.valid, true);
});
