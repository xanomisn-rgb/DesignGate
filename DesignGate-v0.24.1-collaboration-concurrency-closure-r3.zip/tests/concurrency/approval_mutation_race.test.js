const test = require('node:test');
const assert = require('node:assert/strict');
const FinalFreezeService = require('../../backend/collaboration/final_freeze_service');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('concurrent teacher approval and engineering mutation never leaves an old-state approval current', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 2 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const teacher = fixture.clients[1];
  const project = await owner.createProject({ project_id: 'DG-APR-RACE', project_name: 'Approval race fixture' });
  await owner.addMember(project.project_id, { user_id: teacher.user_id, role_id: 'TEACHER_REVIEWER' });
  const artifact = fixture.artifactStore.put({ project_id: project.project_id, revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'result.csv', bytes: Buffer.from('result,PASS\n'), created_by: owner.user_id });
  fixture.store.registerArtifact(artifact);
  const prepared = await owner.project(project.project_id);
  prepared.evidence = [{ evidence_id: 'EVD-APR-RACE', artifact_id: artifact.artifact_id, artifact_sha256: artifact.sha256, project_id: project.project_id, revision_id: 'A', status: 'CURRENT' }];
  prepared.dfmea = null; prepared.dfmea_test_records = []; prepared.dfmea_verification_plan = null; prepared.risk_acceptances = [];
  prepared.gate = { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'A', decision: 'PASS', freeze_eligible: true } };
  fixture.store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(prepared), project.project_id);
  const barrier = createBarrier(2);
  const [approval, mutation] = await Promise.all([
    (async () => { await barrier.ready(); return teacher.command(project.project_id, { command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-RACE', payload: { decision: 'APPROVED', reason: 'Concurrent review.' }, idempotency_key: 'APR-RACE' }, { allowError: true }); })(),
    (async () => { await barrier.ready(); return owner.command(project.project_id, { command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-APR-RACE', payload: { part_id: 'BOM-APR-RACE', part_name: 'Changed housing', quantity: 1 }, idempotency_key: 'BOM-APR-RACE' }, { allowError: true }); })()
  ]);
  const current = await owner.project(project.project_id);
  const record = current.approvals?.[0];

  assert.equal(approval.status, 200);
  assert.equal(mutation.status, 200);
  assert.ok(['CURRENT', 'STALE'].includes(record.status));
  if (record.status === 'CURRENT') {
    const bindings = new FinalFreezeService({ store: fixture.store, artifactVerifier: value => fixture.artifactStore.verifyHash(fixture.artifactStore.getMetadata(value.artifact_id)) }).revalidate({ project_id: project.project_id, state: current });
    assert.doesNotThrow(() => new FinalFreezeService({ store: fixture.store }).validateApproval({ approval: record, bindings }));
  }
});
