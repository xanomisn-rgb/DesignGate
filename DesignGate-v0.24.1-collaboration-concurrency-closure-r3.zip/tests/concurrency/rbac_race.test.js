const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('concurrent viewer write attempts are all denied and create no domain events beside the authorized command', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 20 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-RBAC-RACE', project_name: 'RBAC race fixture' });
  await fixture.addCollaborators(project.project_id, 'VIEWER');
  const barrier = createBarrier(20);
  const responses = await Promise.all(fixture.clients.map((client, index) => (async () => {
    await barrier.ready();
    return client.command(project.project_id, {
      command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: `BOM-RBAC-${index}`,
      payload: { part_id: `BOM-RBAC-${index}`, part_name: `RBAC ${index}`, quantity: 1 }, idempotency_key: `RBAC-RACE-${index}`
    }, { allowError: true });
  })()));
  const events = fixture.store.listEvents(project.project_id, { after: 0, limit: 1000 });

  assert.equal(responses.filter(row => row.status === 200).length, 1);
  assert.equal(responses.filter(row => row.status === 403 && row.body.code === 'PERMISSION_DENIED').length, 19);
  assert.equal(events.filter(event => event.event_type === 'BOM_ITEM_UPDATED').length, 1);
});
