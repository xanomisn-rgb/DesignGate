const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('20 authenticated concurrent same-filename CAD uploads create distinct immutable artifacts with matching bytes', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 20 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-ART-RACE', project_name: 'Artifact race fixture' });
  await fixture.addCollaborators(project.project_id);
  const barrier = createBarrier(20);
  const payloads = Array.from({ length: 20 }, (_, index) => Buffer.from(`ISO-10303-21;ARTIFACT-${index}`));
  const uploads = await Promise.all(fixture.clients.map((client, index) => (async () => {
    await barrier.ready();
    return client.uploadArtifact(project.project_id, { revision_id: 'A', artifact_type: 'CAD', filename: 'housing.step', bytes: payloads[index] });
  })()));
  const artifacts = fixture.store.listArtifacts(project.project_id);

  assert.equal(uploads.filter(row => row.status === 201).length, 20);
  assert.equal(artifacts.length, 20);
  assert.equal(new Set(artifacts.map(item => item.artifact_id)).size, 20);
  for (let index = 0; index < artifacts.length; index += 1) {
    const metadata = fixture.artifactStore.getMetadata(artifacts[index].artifact_id);
    assert.equal(fixture.artifactStore.verifyHash(metadata), true);
    assert.equal(artifacts.some(item => item.sha256 === crypto.createHash('sha256').update(payloads[index]).digest('hex')), true);
  }
});
