const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture, createBarrier } = require('../../tools/concurrency/harness');

test('concurrent final freeze and engineering mutation never commit a mutation into the frozen revision', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 2 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const teacher = fixture.clients[1];
  const project = await owner.createProject({ project_id: 'DG-FRZ-RACE', project_name: 'Freeze race fixture' });
  await owner.addMember(project.project_id, { user_id: teacher.user_id, role_id: 'TEACHER_REVIEWER' });
  const artifact = fixture.artifactStore.put({ project_id: project.project_id, revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'result.csv', bytes: Buffer.from('result,PASS\n'), created_by: owner.user_id });
  fixture.store.registerArtifact(artifact);
  const prepared = await owner.project(project.project_id);
  prepared.evidence = [{ evidence_id: 'EVD-FRZ-RACE', artifact_id: artifact.artifact_id, artifact_sha256: artifact.sha256, project_id: project.project_id, revision_id: 'A', status: 'CURRENT' }];
  prepared.dfmea = null; prepared.dfmea_test_records = []; prepared.dfmea_verification_plan = null; prepared.risk_acceptances = [];
  prepared.gate = { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'A', decision: 'PASS', freeze_eligible: true } };
  fixture.store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(prepared), project.project_id);
  const approval = await teacher.command(project.project_id, { command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-FRZ-RACE', payload: { decision: 'APPROVED', reason: 'Current local bounded state reviewed.' }, idempotency_key: 'APR-FRZ-RACE' });
  assert.equal(approval.status, 200);
  const barrier = createBarrier(2);
  const [freeze, mutation] = await Promise.all([
    (async () => { await barrier.ready(); return teacher.command(project.project_id, { command_type: 'FINAL_FREEZE_APPROVE', entity_type: 'FINAL_FREEZE', entity_id: 'FRZ-RACE', payload: { reason: 'Race freeze request.' }, idempotency_key: 'FRZ-RACE' }, { allowError: true }); })(),
    (async () => { await barrier.ready(); return owner.command(project.project_id, { command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-FRZ-RACE', payload: { part_id: 'BOM-FRZ-RACE', part_name: 'Mutation candidate', quantity: 1 }, idempotency_key: 'BOM-FRZ-RACE' }, { allowError: true }); })()
  ]);
  const current = await owner.project(project.project_id);
  const changed = current.bom.some(item => item.part_id === 'BOM-FRZ-RACE');

  assert.equal(Boolean(current.freeze) && changed, false);
  if (current.freeze) {
    assert.equal(freeze.status, 200);
    assert.notEqual(mutation.status, 200);
    assert.equal(current.freeze_records.length, 1);
  } else {
    assert.equal(mutation.status, 200);
    assert.notEqual(freeze.status, 200);
  }
});
