const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture } = require('../../tools/concurrency/harness');
const { validateProjectConcurrencyInvariants } = require('../../tools/concurrency/invariants');

test('concurrency invariant validator accepts a real HTTP-committed project event chain', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 1 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-INVARIANT-1', project_name: 'Invariant fixture' });
  await owner.command(project.project_id, { command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-1', payload: { part_id: 'BOM-1', part_name: 'Part', quantity: 1 }, idempotency_key: 'INV-1' });

  const report = validateProjectConcurrencyInvariants({ store: fixture.store, artifactStore: fixture.artifactStore, project_id: project.project_id });

  assert.deepEqual(report.violations, []);
  assert.equal(report.event_count, 2);
});
