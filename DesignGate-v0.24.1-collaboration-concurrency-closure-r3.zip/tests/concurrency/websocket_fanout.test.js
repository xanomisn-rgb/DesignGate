const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture } = require('../../tools/concurrency/harness');

test('50 authenticated WebSocket observers receive each of 100 committed HTTP events in monotonic sequence', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 1 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-WS-FANOUT', project_name: 'WebSocket fanout fixture' });
  const observers = await Promise.all(Array.from({ length: 50 }, () => owner.subscribe(project.project_id)));
  t.after(() => Promise.all(observers.map(observer => observer.close())));
  for (let index = 0; index < 100; index += 1) {
    await owner.command(project.project_id, {
      command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: `BOM-WS-${index}`,
      payload: { part_id: `BOM-WS-${index}`, part_name: `Fanout ${index}`, quantity: 1 }, idempotency_key: `WS-FANOUT-${index}`
    });
  }
  await Promise.all(observers.map(observer => observer.waitFor(100, 10_000)));
  for (const observer of observers) {
    assert.equal(observer.events.length, 100);
    assert.deepEqual(observer.events.map(event => event.event_seq), Array.from({ length: 100 }, (_, index) => index + 2));
    assert.equal(new Set(observer.events.map(event => event.event_id)).size, 100);
  }
});

test('50 WebSocket observers retain one ordered event stream while 100 distinct HTTP entities are written concurrently', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 1 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-WS-CONCURRENT', project_name: 'WebSocket concurrent writer fixture' });
  const observers = await Promise.all(Array.from({ length: 50 }, () => owner.subscribe(project.project_id)));
  t.after(() => Promise.all(observers.map(observer => observer.close())));
  const responses = await Promise.all(Array.from({ length: 100 }, (_, index) => owner.command(project.project_id, {
    command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: `BOM-WS-CONCURRENT-${index}`,
    payload: { part_id: `BOM-WS-CONCURRENT-${index}`, part_name: `Concurrent fanout ${index}`, quantity: 1 }, idempotency_key: `WS-CONCURRENT-${index}`
  }, { allowError: true })));
  assert.equal(responses.filter(response => response.status === 200).length, 100);
  await Promise.all(observers.map(observer => observer.waitFor(100, 10_000)));
  for (const observer of observers) {
    assert.equal(observer.events.length, 100);
    assert.deepEqual(observer.events.map(event => event.event_seq), Array.from({ length: 100 }, (_, index) => index + 2));
    assert.equal(new Set(observer.events.map(event => event.event_id)).size, 100);
  }
});

test('a disconnected observer catches up concurrent committed events over HTTP before resuming its WebSocket stream', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 1 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const project = await owner.createProject({ project_id: 'DG-WS-CATCHUP-CONCURRENT', project_name: 'WebSocket concurrent catch-up fixture' });
  const disconnected = await owner.subscribe(project.project_id);
  await disconnected.close();
  const responses = await Promise.all(Array.from({ length: 100 }, (_, index) => owner.command(project.project_id, {
    command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: `BOM-WS-CATCH-${index}`,
    payload: { part_id: `BOM-WS-CATCH-${index}`, part_name: `Catch-up ${index}`, quantity: 1 }, idempotency_key: `WS-CATCH-${index}`
  }, { allowError: true })));
  assert.equal(responses.filter(response => response.status === 200).length, 100);

  const login = await fetch(`${fixture.base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'user0', password: 'concurrency-test-password' }) });
  const token = (await login.json()).token;
  const catchup = await fetch(`${fixture.base}/api/projects/${project.project_id}/events?after=1&limit=100`, { headers: { authorization: `Bearer ${token}` } });
  const catchupBody = await catchup.json();
  assert.equal(catchup.status, 200);
  assert.deepEqual(catchupBody.events.map(event => event.event_seq), Array.from({ length: 100 }, (_, index) => index + 2));

  const resumed = await owner.subscribe(project.project_id);
  t.after(() => resumed.close());
  const finalWrite = await owner.command(project.project_id, {
    command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-WS-CATCH-FINAL',
    payload: { part_id: 'BOM-WS-CATCH-FINAL', part_name: 'Resumed stream event', quantity: 1 }, idempotency_key: 'WS-CATCH-FINAL'
  });
  assert.equal(finalWrite.status, 200);
  await resumed.waitFor(1, 10_000);
  assert.deepEqual(resumed.events.map(event => event.event_seq), [102]);
});
