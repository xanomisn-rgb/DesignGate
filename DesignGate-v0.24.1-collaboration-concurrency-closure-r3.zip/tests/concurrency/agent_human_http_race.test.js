const test = require('node:test');
const assert = require('node:assert/strict');
const { createNetworkFixture } = require('../../tools/concurrency/harness');

async function jsonRequest(base, pathname, token, body) {
  const response = await fetch(`${base}${pathname}`, { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: response.status, body: await response.json() };
}

async function login(base, username) {
  const response = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password: 'concurrency-test-password' }) });
  return (await response.json()).token;
}

test('only an Agent-run requester may complete it, and a human change forces the completed result to revalidation-required', async (t) => {
  const fixture = await createNetworkFixture({ userCount: 2 });
  t.after(async () => fixture.close());
  const owner = fixture.clients[0];
  const collaborator = fixture.clients[1];
  const project = await owner.createProject({ project_id: 'DG-AGENT-HUMAN-RACE', project_name: 'Agent human HTTP race fixture' });
  await owner.addMember(project.project_id, { user_id: collaborator.user_id, role_id: 'VIEWER' });
  const ownerToken = await login(fixture.base, 'user0');
  const collaboratorToken = await login(fixture.base, 'user1');
  const start = await jsonRequest(fixture.base, `/api/projects/${project.project_id}/agent-runs`, ownerToken, {
    project_id: project.project_id,
    revision_id: 'A',
    relevant_entity_versions: [{ entity_type: 'BOM_ITEM', entity_id: 'BOM-AGENT-HUMAN', version: 0 }],
    knowledge_snapshot_hash: 'a'.repeat(64), rule_version: 'rules-v1', tool_registry_hash: 'b'.repeat(64)
  });
  assert.equal(start.status, 201);
  const forbidden = await jsonRequest(fixture.base, `/api/projects/${project.project_id}/agent-runs/${start.body.run.run_id}/complete`, collaboratorToken, { result: { finding_ids: ['FIND-FORGED'] } });
  assert.equal(forbidden.status, 403);
  assert.equal(forbidden.body.code, 'AGENT_RUN_COMPLETION_FORBIDDEN');

  const mutation = await owner.command(project.project_id, {
    command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'BOM-AGENT-HUMAN',
    payload: { part_id: 'BOM-AGENT-HUMAN', part_name: 'Human engineering change', quantity: 1 }, idempotency_key: 'AGENT-HUMAN-MUTATION'
  });
  assert.equal(mutation.status, 200);
  const completion = await jsonRequest(fixture.base, `/api/projects/${project.project_id}/agent-runs/${start.body.run.run_id}/complete`, ownerToken, { result: { finding_ids: ['FIND-RECHECK'] } });
  assert.equal(completion.status, 200);
  assert.equal(completion.body.run.status, 'REVALIDATION_REQUIRED');
  assert.deepEqual(completion.body.run.changed_entities, [{ entity_type: 'BOM_ITEM', entity_id: 'BOM-AGENT-HUMAN', expected_version: 0, current_version: 1 }]);
});
