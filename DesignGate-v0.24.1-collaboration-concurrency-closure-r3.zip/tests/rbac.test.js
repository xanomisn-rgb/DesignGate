const test = require('node:test');
const assert = require('node:assert/strict');
const PermissionService = require('../backend/collaboration/permission_service');

test('student role cannot final-freeze while teacher reviewer can approve it', () => {
  const permissions = new PermissionService();
  assert.equal(permissions.allowed('STUDENT_STRUCTURE', 'APPROVE_FINAL_FREEZE'), false);
  assert.equal(permissions.allowed('TEACHER_REVIEWER', 'APPROVE_FINAL_FREEZE'), true);
  assert.throws(() => permissions.require('VIEWER', 'UPDATE_BOM_ITEM'), /PERMISSION_DENIED/);
});
