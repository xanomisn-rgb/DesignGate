const {test}=require('node:test'),assert=require('node:assert/strict');
const {critique}=require('../backend/proposal_critique');
const Gate=require('../backend/gate_engine');
const before={design:{},marker:'before'},after={design:{},marker:'after'};
function screen(a,b){return p=>({checks:p.marker==='before'?a:b,findings:[]});}
test('proposal critique blocks new failed checks without mutating either input',()=>{
 const input=structuredClone([before,after]);
 assert.equal(critique(before,after,screen([],[{check_id:'X',status:'FAIL'}])).status,'BLOCKED_REGRESSION');
 assert.deepEqual([before,after],input);
});
test('proposal critique blocks loss of covered knowledge',()=>{
 assert.equal(critique(before,after,screen([{check_id:'X',status:'PASS'}],[{check_id:'X',status:'UNKNOWN'}])).status,'BLOCKED_REGRESSION');
});
test('proposal critique blocks silent removal of passed checks',()=>{
 assert.equal(critique(before,after,screen([{check_id:'X',status:'PASS'}],[])).status,'BLOCKED_REGRESSION');
});
test('no detected regression is not engineering approval',()=>{
 const r=critique(before,after,screen([],[{check_id:'X',status:'UNKNOWN'}]));
 assert.equal(r.status,'NO_DETECTED_REGRESSION');assert.equal(r.engineering_approval,false);
});
test('gate rejects failed required check even when no Finding was emitted',()=>{
 const gate=new Gate().evaluateGate('Gate 2',[],{checks:[{check_id:'X',status:'FAIL',required_for_gate:2}]});
 assert.equal(gate.decision,'REVISE');assert.equal(gate.freeze_eligible,false);
});
test('gate ignores checks for a later stage for the current decision',()=>{
 const gate=new Gate().evaluateGate('Gate 1',[],{checks:[{check_id:'A',status:'PASS',required_for_gate:1},{check_id:'B',status:'FAIL',required_for_gate:3}]});
 assert.equal(gate.decision,'PASS');
});
