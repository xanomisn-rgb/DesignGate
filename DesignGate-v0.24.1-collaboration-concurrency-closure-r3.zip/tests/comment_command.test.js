const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

function command(command_type, entity_id, base_entity_version, payload) {
  return { command_id: `CMD-${entity_id}-${base_entity_version}`, idempotency_key: `idem-${entity_id}-${base_entity_version}`, project_id: 'DG-COMMENT-001', command_type, entity_type: 'COMMENT', entity_id, base_project_version: 1, base_entity_version, payload };
}

test('comment resolution appends an auditable resolution without overwriting the original comment', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-comment-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-COMMENT-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const created = commands.execute(command('COMMENT_CREATE', 'CMT-001', 0, { text: 'Please verify the corner radius.', anchor: { entity_type: 'BOM_ITEM', entity_id: 'P-01' } }), { user_id: 'USER-A' });
  assert.equal(created.event_type, 'COMMENT_CREATED');
  const resolved = commands.execute(command('COMMENT_RESOLVE', 'CMT-001', 1, { reason: 'Radius evidence added.' }), { user_id: 'USER-A' });
  assert.equal(resolved.event_type, 'COMMENT_RESOLVED');
  const state = store.getProjectForActor('DG-COMMENT-001', 'USER-A');
  assert.equal(state.comments[0].text, 'Please verify the corner radius.');
  assert.equal(state.comment_resolutions[0].comment_id, 'CMT-001');
  const stale = command('COMMENT_RESOLVE', 'CMT-001', 1, { reason: 'duplicate stale resolve' });
  stale.command_id = 'CMD-CMT-001-stale';
  stale.idempotency_key = 'idem-CMT-001-stale';
  assert.throws(() => commands.execute(stale, { user_id: 'USER-A' }), error => error.code === 'ENTITY_VERSION_CONFLICT');
});
