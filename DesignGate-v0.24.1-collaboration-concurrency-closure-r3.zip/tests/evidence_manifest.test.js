const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createManifest,verifyManifest}=require('../backend/evidence/evidence_manifest');
test('evidence manifest distinguishes file payload and tamper-evident manifest hashes',()=>{
 const manifest=createManifest({evidence_id:'EVD-1',project_id:'DG-1',revision:'A',source_kind:'CAD',source_id:'CAD-1',source_event_id:'IEV-1',file_sha256:'a'.repeat(64),payload:{measurement:2},integrity_status:'VALIDATED',provenance_status:'SOURCE_BOUND'});
 assert.match(manifest.payload_sha256,/^[a-f0-9]{64}$/);assert.match(manifest.manifest_hash,/^[a-f0-9]{64}$/);
 assert.equal(verifyManifest(manifest).status,'VALID');
 assert.equal(verifyManifest({...manifest,provenance_status:'TAMPERED'}).status,'INVALID');
});
