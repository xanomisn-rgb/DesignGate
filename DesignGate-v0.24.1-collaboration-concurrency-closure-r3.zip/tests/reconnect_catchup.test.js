const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

test('an authenticated client can catch up missed ordered project events after a disconnect', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-catchup-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple' });
  store.createProject({ project_id: 'DG-CATCHUP-001', project_name: 'Shared Lamp' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const headers = { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' };
  for (const [id, entity_id] of [['CMD-CATCH-1', 'P-01'], ['CMD-CATCH-2', 'P-02']]) await fetch(`${base}/api/projects/DG-CATCHUP-001/commands`, { method: 'POST', headers, body: JSON.stringify({ command_id: id, idempotency_key: id, project_id: 'DG-CATCHUP-001', command_type: 'UPDATE_BOM_ITEM', base_project_version: 1, entity_type: 'BOM_ITEM', entity_id, base_entity_version: 0, payload: { part_name: entity_id } }) });

  const response = await fetch(`${base}/api/projects/DG-CATCHUP-001/events?after=1`, { headers });
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.deepEqual(body.events.map(event => event.event_seq), [2, 3]);
  assert.equal(body.full_resync_required, false);
});
