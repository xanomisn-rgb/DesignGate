const test=require('node:test');
const assert=require('node:assert/strict');
const IntegrationServer=require('../backend/http/integration_server');

async function server(t,adapter,options={}){const instance=new IntegrationServer({adapter,apiKey:'key-1',projectAuthorizer:({project_id})=>project_id==='DG-HTTP',...options});await instance.listen();t.after(()=>instance.close());return `http://127.0.0.1:${instance.address().port}`;}
function form(fields={},contents='ISO-10303-21;'){const body=new FormData();for(const [key,value] of Object.entries(fields))body.append(key,value);body.append('file',new Blob([contents],{type:'application/step'}),'part.step');return body;}
test('loopback CAD HTTP endpoint authenticates, authorizes, and exposes adapter evidence references',async t=>{
 const calls=[];const base=await server(t,{upload:async input=>{calls.push(input);return {status:'ACCEPTED',event_id:'IEV-1',analysis_reference:{event_id:'IEV-1'},evidence_reference:{evidence_id:'EVD-1',manifest_id:'EVM-1'}};}});
 const unauthorized=await fetch(base+'/api/integrations/cad/upload',{method:'POST',body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'one'})});assert.equal(unauthorized.status,401);
 const denied=await fetch(base+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-OTHER',revision:'B',source_system:'MOCK',idempotency_key:'one'})});assert.equal(denied.status,403);
 const accepted=await fetch(base+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'one'})});assert.equal(accepted.status,202);assert.equal((await accepted.json()).evidence_reference.evidence_id,'EVD-1');assert.equal(calls.length,1);
});
test('loopback CAD HTTP maps adapter idempotency and analyzer availability failures',async t=>{
 const base=await server(t,{upload:async()=>{throw Error('IDEMPOTENCY_CONFLICT');}});const response=await fetch(base+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'one'})});assert.equal(response.status,409);
});
test('loopback CAD HTTP enforces upload limits and maps invalid STEP and unavailable analyzer errors',async t=>{
 const tooSmall=await server(t,{upload:async()=>({})},{maxUploadBytes:10});let response=await fetch(tooSmall+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'size'},'ISO-10303-21;too large')});assert.equal(response.status,413);
 const base=await server(t,{upload:async()=>{throw Error('OCP_ENVIRONMENT_UNAVAILABLE');}});response=await fetch(base+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'ocp'})});assert.equal(response.status,503);
 response=await fetch(base+'/api/integrations/cad/upload',{method:'POST',headers:{'X-DesignGate-Integration-Key':'key-1'},body:form({project_id:'DG-HTTP',revision:'B',source_system:'MOCK',idempotency_key:'empty'},'')});assert.equal(response.status,422);
});
