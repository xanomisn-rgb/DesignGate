const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

test('review request API routes through the authenticated command authority', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-review-api-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple' });
  store.createProject({ project_id: 'DG-REVIEW-API', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const response = await fetch(`${base}/api/projects/DG-REVIEW-API/review-request`, { method: 'POST', headers: { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' }, body: JSON.stringify({ command_id: 'CMD-REVIEW-API', idempotency_key: 'idem-review-api', project_id: 'DG-REVIEW-API', actor_id: 'ATTACKER', command_type: 'REVIEW_REQUEST_CREATE', entity_type: 'REVIEW_REQUEST', entity_id: 'REVREQ-API', base_project_version: 1, base_entity_version: 0, payload: { requested_role: 'TEACHER_REVIEWER', scope: 'Evidence review', reason: 'Needs a human decision.' } }) });
  const body = await response.json();
  assert.equal(response.status, 201);
  assert.equal(body.event_type, 'REVIEW_REQUEST_CREATED');
  assert.equal(store.db.prepare('SELECT actor_id FROM collaboration_events WHERE command_id = ?').get('CMD-REVIEW-API').actor_id, 'USER-A');
});
