const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

test('CollaborationServer exposes health and authenticates a Team session server-side', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-collaboration-server-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple', display_name: 'Alice' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0, version: '0.24.1-test' });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;

  const health = await fetch(`${base}/health`).then(response => response.json());
  assert.equal(health.status, 'OK');
  assert.equal(health.version, '0.24.1-test');
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const me = await fetch(`${base}/api/auth/me`, { headers: { authorization: `Bearer ${login.token}` } }).then(response => response.json());
  assert.equal(me.user.user_id, 'USER-A');
});
