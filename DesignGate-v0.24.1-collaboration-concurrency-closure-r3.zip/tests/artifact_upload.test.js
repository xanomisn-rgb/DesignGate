const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');
const CollaborationServer = require('../backend/collaboration/server');

test('authenticated Team artifact upload creates immutable server metadata', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-artifact-upload-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  const artifacts = new LocalImmutableArtifactStore({ directory: path.join(directory, 'artifacts') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple' });
  store.createProject({ project_id: 'DG-UPLOAD-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, artifactStore: artifacts, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(r => r.json());
  const data = new FormData(); data.set('revision_id', 'A'); data.set('artifact_type', 'CAD'); data.set('file', new Blob(['STEP DATA'], { type: 'model/step' }), 'lamp.step');
  const response = await fetch(`${base}/api/projects/DG-UPLOAD-001/artifacts`, { method: 'POST', headers: { authorization: `Bearer ${login.token}` }, body: data });
  const body = await response.json();
  assert.equal(response.status, 201);
  assert.equal(body.artifact.immutable, true);
  assert.equal(body.artifact.sha256.length, 64);
  assert.equal(store.getArtifact(body.artifact.artifact_id).project_id, 'DG-UPLOAD-001');

  const listed = await fetch(`${base}/api/projects/DG-UPLOAD-001/artifacts`, { headers: { authorization: `Bearer ${login.token}` } });
  const listedBody = await listed.json();
  assert.equal(listed.status, 200);
  assert.deepEqual(listedBody.artifacts.map(artifact => artifact.artifact_id), [body.artifact.artifact_id]);
  assert.equal(listedBody.artifacts[0].immutable, true);
});
