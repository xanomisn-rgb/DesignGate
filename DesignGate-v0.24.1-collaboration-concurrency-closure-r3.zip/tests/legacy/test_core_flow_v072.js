const assert = require("assert");
const fs = require("fs");
const path = require("path");
const RuleEngine = require("../backend/rule_engine");
const CitationVerifier = require("../backend/citation_verifier");
const GateEngine = require("../backend/gate_engine");
const RevisionDiffEngine = require("../backend/revision_diff_engine");
const ProjectStateManager = require("../backend/project_state_manager");
const EvidenceRegistry = require("../backend/evidence_registry");
const ApplicabilityEngine = require("../backend/applicability_engine");
const FileIntakeManager = require("../backend/file_intake_manager");
const DocumentParser = require("../tools/document_parser");
const BOMParser = require("../tools/bom_parser");
const CADGeometryTool = require("../tools/cad_geometry_tool");
const InAgentAdapter = require("../connectors/inagent_adapter");
const LMSAdapter = require("../connectors/lms_adapter");
const PLMAdapter = require("../connectors/plm_adapter");
const DesignGateOrchestrator = require("../backend/orchestrator");

console.log("=== DesignGate Core v0.7.0 Engineering Truth & Ground Truth Test Suite ===");

// TEST 01/28: Synthetic Fixture Isolation
const fixturePath = path.join(__dirname, "fixtures/DG-001-revA.json");
assert(fs.existsSync(fixturePath), "Fixture DG-001-revA.json must exist");
const fixture = JSON.parse(fs.readFileSync(fixturePath, "utf-8"));
assert(fixture.is_synthetic === true, "Fixture must be explicitly flagged as is_synthetic=true");
console.log("TEST 01/28 PASSED: Synthetic fixture isolated and verified.");

// TEST 02/28: Real Binary PDF DocumentParser with Page Source Pointer
const pdfPath = path.join(__dirname, "fixtures/Design_RevA.pdf");
const pdfRes = DocumentParser.parsePDF(pdfPath);
assert(pdfRes.success === true, "Real PDF parsing must succeed");
assert(pdfRes.total_pages === 2, "Must read 2 total pages from Design_RevA.pdf");
assert(pdfRes.extracted_dimensions_by_page.length >= 1, "Must extract dimension callouts from page 2");
const page2Dim = pdfRes.extracted_dimensions_by_page[0];
assert(page2Dim.page === 2, "Source Pointer must point to Page 2");
assert(page2Dim.dimensions.nominalWall === 2.0, "Must extract nominal wall 2.0mm");
assert(page2Dim.dimensions.localMaxWall === 4.5, "Must extract local max wall 4.5mm");
console.log("TEST 02/28 PASSED: Real Binary PDF DocumentParser extracted dimensions with Page 2 Source Pointer.");

// TEST 03/28: Real Binary XLSX BOMParser with Sheet & Row Source Pointer (No process guessing)
const xlsxPath = path.join(__dirname, "fixtures/BOM.xlsx");
const bomRes = BOMParser.parseXLSX(xlsxPath);
assert(bomRes.success === true, "Real XLSX parsing must succeed");
assert(bomRes.components.length === 5, "Must parse 5 components from BOM.xlsx");
const item1 = bomRes.components[0];
assert(item1.source_pointer.file === "BOM.xlsx", "Source pointer file must be BOM.xlsx");
assert(item1.source_pointer.sheet === "BOM", "Source pointer sheet must be BOM");
assert(item1.source_pointer.row === 2, "Source pointer row must be Row 2");
assert(item1.material_specified.includes("Bayblend T65 XF"), "Must identify material Bayblend T65 XF");

const emptyProcessBOM = BOMParser.parseBOMText("| 1 | 异形按键 | 硅胶 | |");
assert(emptyProcessBOM[0].process === null, "Missing process in BOM must remain null, never guessed as injection molding");
console.log("TEST 03/28 PASSED: Real Binary XLSX BOMParser extracted parts without default process guessing.");

// TEST 04/28: FileIntakeManager Integration Test (SHA-256 + Field Provenance)
const briefPath = path.join(__dirname, "fixtures/Brief.pdf");
const intakeRes = FileIntakeManager.processIntake({
  briefFile: briefPath,
  designFile: pdfPath,
  bomFile: xlsxPath
});
assert(intakeRes.files_processed.length === 3, "Intake must process all 3 files");
assert(intakeRes.files_processed[0].sha256.length === 64, "Must compute valid SHA-256 hash");
assert(intakeRes.requirements.length >= 2, "Must extract REQ-01 and REQ-02 from Brief.pdf");
assert(intakeRes.requirements[0].priority === null, "Brief requirement without explicit priority must have priority: null");
assert(intakeRes.bom.length === 5, "Must extract 5 BOM components from BOM.xlsx");
assert(intakeRes.field_provenance.localMaxWall, "Must register field provenance for localMaxWall");
assert(intakeRes.field_provenance.localMaxWall.page === 2, "Field provenance page must be 2");
console.log("TEST 04/28 PASSED: FileIntakeManager processed PDF & XLSX with SHA-256 and Field Provenance.");

// TEST 05/28: Negative Test (No Guessing on Incomplete Input)
const ruleEngine = new RuleEngine();
const nullFindings = ruleEngine.evaluateGeometry({ nominalWall: null, localMaxWall: null });
const unknownFinding = nullFindings.find(f => f.finding.includes("UNKNOWN"));
assert(unknownFinding, "When dimensions are null, RuleEngine must report UNKNOWN rather than guessing");
assert(!nullFindings.some(f => f.finding.includes("4.5mm")), "Must not invent 4.5mm thickness when not provided");
console.log("TEST 05/28 PASSED: Negative Test Passed: RuleEngine preserves UNKNOWN when input is incomplete.");

// TEST 06/28: FreeCAD CAD Geometry Tool Honest Behavior & STL Mesh Topology
const stlPath = path.join(__dirname, "fixtures/enclosure.stl");
const cadRealRes = CADGeometryTool.analyze({ cad_file: stlPath });
assert(cadRealRes.success === true, "Real 3D STL analysis must succeed");
assert(cadRealRes.bounding_box.length_mm === 165, "Must extract real bounding box length 165mm from 3D mesh");
assert(cadRealRes.bounding_box.width_mm === 78, "Must extract real bounding box width 78mm from 3D mesh");
assert(cadRealRes.bounding_box.height_mm === 26, "Must extract real bounding box height 26mm from 3D mesh");
assert(cadRealRes.draft_analysis.insufficient_draft_facets === 8, "Must detect 8 vertical 0.0 deg side wall facets");
assert(cadRealRes.undercut_analysis.has_undercuts === false, "Flat bottom rectangular box must NOT be flagged as undercut");

const emptyCadRes = CADGeometryTool.analyze({});
assert(emptyCadRes.success === false, "Must not fabricate dimensions on empty input");
console.log("TEST 06/28 PASSED: Real 3D Mesh Topology Engine verified with correct draft and undercut physics.");

// TEST 07/28: Applicability Engine Three-State & Thermoplastics Boundary
const injectionRule = {
  record_id: "DFM-001",
  applies_if: { process: ["Injection molding"], material_family: ["thermoplastics"] }
};
const unknownCheck = ApplicabilityEngine.isRuleApplicable(injectionRule, { material: "PC+ABS" });
assert(unknownCheck.status === "UNKNOWN_APPLICABILITY", "Missing process must yield UNKNOWN_APPLICABILITY");
assert(unknownCheck.applicable === false, "UNKNOWN_APPLICABILITY must set applicable = false");

const metalCheck = ApplicabilityEngine.isRuleApplicable(injectionRule, { process: "Injection molding", material: "铝合金 6061-T6" });
assert(metalCheck.status === "NOT_APPLICABLE", "Aluminum must not match thermoplastics rule");
assert(metalCheck.applicable === false, "Metal must not be applicable to plastic injection rule");

const validCheck = ApplicabilityEngine.isRuleApplicable(injectionRule, { process: "Injection molding", material: "Covestro Bayblend T65 XF (PC+ABS)" });
assert(validCheck.status === "APPLICABLE" && validCheck.applicable === true, "Valid thermoplastic injection molding must apply");
console.log("TEST 07/28 PASSED: Applicability Engine Three-State logic and Thermoplastics boundary verified.");

// TEST 08/28: Citation Verifier Exact Grade Matching & Hallucination Defense
const verifier = new CitationVerifier();
const validMat = verifier.verifyMaterialGrade("外壳选用 Covestro Bayblend T65 XF 合金");
assert(validMat.verified === true, "Exact grade Bayblend T65 XF must be verified in TDS database");
assert(validMat.evidence_level === "B1", "TDS evidence level must be B1");

const ipcCheck = verifier.verifyMaterialGrade("设备符合 IPC-A-610 电子组装标准");
assert(ipcCheck.verified === false, "IPC standard text must not be verified as material");
assert(!ipcCheck.is_generic_family, "IPC standard abbreviation must not be falsely flagged as generic material family");

const fakeStd = verifier.verifyStandardCitation("GB/T 99999-2099");
assert(fakeStd.verified === false, "Hallucination Test: Fictitious standard must be rejected");
console.log("TEST 08/28 PASSED: Citation Verifier matches exact grade and defends against token false positives.");

// TEST 09/28: Evidence Registry Authority Level vs Mandatory Law
const evdRegistry = new EvidenceRegistry();
const evdMat = evdRegistry.getEvidence("MAT-PCABS-001");
assert(evdMat && evdMat.authority_level === "MANUFACTURER_PRIMARY", "TDS must be authority_level MANUFACTURER_PRIMARY");
assert(evdMat.mandatory_requirement === false, "TDS must NOT be marked as mandatory statutory law");

const evdSeal = evdRegistry.getEvidence("SEAL-001");
assert(evdSeal && evdSeal.source_id === "SRC-SEAL-GUIDELINE", "Seal compression must be mapped to SRC-SEAL-GUIDELINE");
console.log("TEST 09/28 PASSED: Evidence Registry maps findings and distinguishes Authority Level from Mandatory Law.");

// TEST 10/28: Gate Engine Hard Gate Logic
const gateEngine = new GateEngine();
const gateRevise = gateEngine.evaluateGate("Gate 2: 详细工程与 DFM 冻结评审", [
  { issue_id: "I-01", severity: "CRITICAL", status: "OPEN", finding: "Battery glued shut" }
]);
assert(gateRevise.decision === "REVISE", "Unresolved CRITICAL must force REVISE");
assert(gateRevise.hard_gate_blocked === true, "Hard gate must be blocked");
console.log("TEST 10/28 PASSED: Gate Engine executes deterministic hard gate logic.");

// TEST 11/28: Revision Diff Engine True Closure Verification
const diffEngine = new RevisionDiffEngine();
const pastIssues = [
  { issue_id: "DG-MFG-001", finding: "螺柱肉厚过大", status: "OPEN" },
  { issue_id: "DG-REQ-002", finding: "电池封死", status: "OPEN" }
];
const currentIssues = [
  { issue_id: "DG-MFG-001", finding: "螺柱肉厚过大依然存在", status: "OPEN" }
];
const diffResult = diffEngine.computeDiff(pastIssues, currentIssues, "针对 DG-MFG-001 螺柱肉厚我们已优化。");
assert(diffResult.metrics.resolved_count === 1, "DG-REQ-002 absent in current findings must be resolved");
assert(diffResult.metrics.unresolved_count === 1, "DG-MFG-001 still detected by rules must remain UNRESOLVED even if text claims resolved");
console.log("TEST 11/28 PASSED: Revision Diff Engine enforces objective closure verification.");

// TEST 12/28: Connectors Dual-Mode & Production Fail-Closed
async function testConnectors() {
  const inagentMock = new InAgentAdapter({ mode: "mock" });
  const docRes = await inagentMock.parseDocument(null, "application/pdf", "Brief.pdf");
  assert(docRes.status === "PARSED_READY", "inAgent Parser mock capability must be ready");

  const inagentProd = new InAgentAdapter({ mode: "production", endpoint: "http://127.0.0.1:9999" });
  const failRes = await inagentProd.parseDocument("fake.pdf", "application/pdf", "fake.pdf");
  assert(failRes.status === "CONNECTION_FAILED", "Production mode must fail closed upon connection loss");

  const plmProd = new PLMAdapter({ mode: "production", endpoint: "http://127.0.0.1:9999" });
  const plmFail = await plmProd.createReviewRecord("DG-001", "A", [], "REVISE");
  assert(plmFail.status === "WRITE_FAILED", "PLM production mode must fail closed upon connection loss");
  console.log("TEST 12/28 PASSED: Connectors Dual-Mode verified with strict Fail-Closed production semantics.");
}

// TEST 13/28: Dual State Model (Engineering Gate vs Workflow Status)
async function testDualStateModel() {
  const orchestrator = new DesignGateOrchestrator(null);
  orchestrator.plmAdapter = new PLMAdapter({ mode: "production", endpoint: "http://127.0.0.1:9999" });

  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-001",
    demoMode: true,
    proposalText: "采用结构胶永久粘合封死电池仓。"
  });

  assert(res.gate.decision === "REVISE", "Engineering gate is evaluated independently");
  assert(res.workflow_status === "EXTERNAL_WRITE_FAILED", "Workflow status must flag external write failure");
  assert(res.archive_status === "FAILED", "Archive status must be FAILED");
  console.log("TEST 13/28 PASSED: Dual State Model cleanly separates Engineering Gate from Workflow Status.");
}

// TEST 14/28: Real End-to-End File-Driven Pipeline with Field Provenance
async function runEndToEndFileDriven() {
  await testConnectors();
  const orchestrator = new DesignGateOrchestrator(async () => "Mock Narrative Synthesis Layer");
  
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-001",
    revision: "A",
    stage: "Gate 2: 详细工程与 DFM 冻结评审",
    files: {
      briefFile: briefPath,
      designFile: pdfPath,
      bomFile: xlsxPath
    },
    proposalText: "送审方案采用结构胶永久粘合封死电池仓，螺柱肉厚达到 4.5mm。"
  });

  assert(res.gate.decision === "REVISE", "Gate 2 Decision must be REVISE");
  assert(res.findings.some(f => f.issue_id === "DG-REQ-002"), "Must identify battery conflict DG-REQ-002 from Brief.pdf");
  assert(res.findings.some(f => f.issue_id === "DG-MFG-001"), "Must identify thickness sink risk DG-MFG-001 from Design_RevA.pdf");
  
  const dfmFinding = res.findings.find(f => f.issue_id === "DG-MFG-001");
  assert(dfmFinding && dfmFinding.evidence_pointer, "DFM Finding must carry evidence_pointer");
  assert(dfmFinding.evidence_pointer.file === "Design_RevA.pdf", "Pointer file must be Design_RevA.pdf");
  assert(dfmFinding.evidence_pointer.page === 2, "Pointer page must be Page 2");
  assert(dfmFinding.evidence_pointer.field === "localMaxWall", "Pointer must capture field provenance for localMaxWall");
  console.log("TEST 14/28 PASSED: Real File-Driven End-to-End Orchestrator Pipeline verified with Field Provenance.");
}

// TEST 15/28: Normal Project Without Brief Must NOT Get IP67 / Battery Requirements
async function testNoPollution() {
  const orchestrator = new DesignGateOrchestrator(null);
  const newProjRes = await orchestrator.runReviewPipeline({
    projectId: "DG-999",
    proposalText: "普通桌面音箱外观设计，塑料机身。"
  });
  assert(!newProjRes.findings.some(f => f.issue_id === "DG-REQ-002"), "Ordinary project without brief must NOT get DG-REQ-002 battery conflict");
  console.log("TEST 15/28 PASSED: Normal project without brief is clean and unpolluted by Golden Demo requirements.");
}

// TEST 16/28: Component-Scoped Material Scoping (Does NOT Blindly Take BOM Row 1)
async function testMaterialScoping() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-999",
    files: { bomFile: xlsxPath },
    proposalText: "巡检仪送审。"
  });
  assert(res.material_verification.verified === true, "Must correctly identify Bayblend T65 XF from primary housing");
  console.log("TEST 16/28 PASSED: Material Scoping prioritizes primary housing component over arbitrary BOM rows.");
}

// TEST 17/28: Chief Reviewer Synthesizes Dynamically & Product Agent Avoids Visual Hallucinations
async function testAgentDynamism() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-888",
    stage: "Gate 1: 需求工程与范围评审",
    imageAttached: { fileName: "sketch.png", dataUrl: "data:image/png;base64,mock" },
    proposalText: "工业手持巡检终端，尺寸 165x78x26mm，直角造型。"
  });

  const rationale = res.chief_review.trade_off_rationale || "";
  assert(!rationale.includes("电池仓胶粘方案已被 A01 认定为阻断项"), "Chief Reviewer must NOT emit hardcoded battery text when issue is not present");

  const ergoFinding = res.findings.find(f => f.issue_id === "DG-ERG-001");
  assert(ergoFinding && ergoFinding.finding.includes("GB/T 10000-2023"), "Product Agent must consume GB/T 10000-2023 and output quantitative grip perimeter finding");
  console.log("TEST 17/28 PASSED: Chief Reviewer synthesizes dynamically and Product Agent executes GB/T 10000-2023 ergonomics calculations.");
}

// TEST 18/28: ProjectStateManager Path Traversal Defense & userData Support
function testProjectStateSecurity() {
  const customDir = path.join(__dirname, "../data/test_userdata_projects");
  const sm = new ProjectStateManager(customDir);
  
  const testProject = { project_id: "DG-TEST-STORAGE", project_name: "Test UserData Persistence" };
  sm.saveProject(testProject);
  const loaded = sm.getProject("DG-TEST-STORAGE");
  assert(loaded && loaded.project_id === "DG-TEST-STORAGE", "Must persist and reload from custom storageDir");

  assert.throws(() => {
    sm.saveProject({ project_id: "../../evil_path", project_name: "Exploit" });
  }, /Invalid Project ID/, "Must reject path traversal attacks in project_id");

  fs.rmSync(customDir, { recursive: true, force: true });
  console.log("TEST 18/28 PASSED: ProjectStateManager verified with path traversal defense and custom storageDir support.");
}

// TEST 19/28: Pipeline Result Schema & Renderer Safe Formatting (No TypeError)
async function testContractAndRenderer() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-001",
    demoMode: true,
    proposalText: "采用结构胶永久粘合封死电池仓。"
  });
  
  assert(res.project_id && res.revision && res.stage, "Pipeline result must contain core meta fields");
  assert(Array.isArray(res.findings), "findings must be an array");
  assert(res.gate && res.gate.decision, "gate must contain decision");
  assert(res.material_verification !== undefined, "material_verification must be present");

  const { material_verification, findings, gate } = res;
  let simulatedOutput = `Result: ${gate.decision}, Mat: ${material_verification?.verified ? "VERIFIED" : "UNKNOWN"}`;
  assert(!simulatedOutput.includes("undefined"), "Simulated renderer formatting must not produce undefined or error");
  console.log("TEST 19/28 PASSED: Pipeline Result satisfies unified contract, and renderer formatting is immune to TypeError.");
}

// TEST 20/28: Python Runner Health Check Verification
function testPythonRunnerHealth() {
  const { checkPythonHealth } = require("../tools/python_runner");
  const health = checkPythonHealth();
  assert(health.available === true, "Python runner must find valid python executable");
  assert(health.modules.pypdf === true, "Python environment must have pypdf installed");
  assert(health.modules.openpyxl === true, "Python environment must have openpyxl installed");
  console.log("TEST 20/28 PASSED: Python Runner health check verified (command: " + health.command + ", version: " + health.version + ").");
}

// =========================================================
// 新增 8 项专门的工程真实性与反例测试 (TEST 21 ~ TEST 28)
// =========================================================

// TEST 21/28: 手持设备未给尺寸时不得输出 78x26，A02 必须客观输出 UNKNOWN
async function testErgonomicsNegativeMissingDims() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-TEST-NO-DIMS",
    proposalText: "这是一款手持工业设备，未标注尺寸。"
  });
  const ergoInfo = res.findings.find(f => f.issue_id === "DG-ERG-INFO-01");
  assert(ergoInfo, "Missing dimensions on handheld product must yield DG-ERG-INFO-01 (UNKNOWN)");
  assert(!res.findings.some(f => f.issue_id === "DG-ERG-001"), "Must NOT emit DG-ERG-001 when dimensions are missing");
  console.log("TEST 21/28 PASSED: Handheld device without dimensions honestly outputs UNKNOWN rather than guessing 78x26.");
}

// TEST 22/28: 只输入品牌系列名称（如 Bayblend）不得通过 B1 验证
function testTradeNameOnlyRejection() {
  const cv = new CitationVerifier();
  const res = cv.verifyMaterialGrade("外壳选用 Bayblend 塑料");
  assert(res.verified === false, "Trade family name alone must NOT be B1 verified");
  assert(res.is_trade_family_only === true, "Must identify as trade family only");
  console.log("TEST 22/28 PASSED: Trade name alone (Bayblend) is rejected from B1 TDS verification without specific grade.");
}

// TEST 23/28: 普通长方体 STL 不得误判为需要侧抽芯倒扣
function testRectangularBoxNoUndercut() {
  const res = CADGeometryTool.analyze({ cad_file: stlPath });
  assert(res.undercut_analysis.has_undercuts === false, "Rectangular box must NOT have undercuts");
  assert(res.undercut_analysis.action_required === "Direct draw feasible", "Action must be Direct draw feasible");
  
  // 对照测试：具有倒勾特征的模型必须检出倒扣
  const clipPath = path.join(__dirname, "fixtures/undercut_clip.stl");
  const clipRes = CADGeometryTool.analyze({ cad_file: clipPath });
  assert(clipRes.undercut_analysis.has_undercuts === true, "Undercut clip must have undercuts");
  console.log("TEST 23/28 PASSED: Rectangular box is correctly recognized as no undercut, while re-entrant clip triggers undercut.");
}

// TEST 24/28: 仅含 CARTESIAN_POINT 的纯坐标点 STEP 文本不得冒充拔模达标
function testStepPointCloudHonesty() {
  const stepPath = path.join(__dirname, "fixtures/minimal_points.step");
  const res = CADGeometryTool.analyze({ cad_file: stepPath });
  assert(res.status === "PARTIAL_POINT_CLOUD_ONLY", "Must be status PARTIAL_POINT_CLOUD_ONLY");
  assert(res.draft_analysis.status === "NOT_EVALUATED_REQUIRES_BREP_TOPOLOGY", "Draft must NOT be marked ADEQUATE without surface normals");
  console.log("TEST 24/28 PASSED: Point-cloud STEP honestly returns NOT_EVALUATED for draft instead of fake ADEQUATE.");
}

// TEST 25/28: 室内蓝牙音箱在 Statement 中不得出现 IP67、快拆电池或 1.5m 跌落
async function testNoStatementPollution() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-SPEAKER",
    mode: "statement",
    designParams: { material: "ABS" },
    proposalText: "室内桌面蓝牙音箱外观设计，无防水要求。"
  });
  const stmt = res.specialized_artifacts?.award_statement;
  assert(stmt, "Statement must be generated");
  const compStr = JSON.stringify(stmt.standard_compliance);
  assert(!compStr.includes("IP67"), "Indoor speaker statement must NOT claim IP67");
  assert(!compStr.includes("自由跌落"), "Indoor speaker statement must NOT claim 1.5m drop test");
  assert(!JSON.stringify(stmt.key_innovations).includes("快拆电池"), "Indoor speaker statement must NOT claim quick release battery");
  console.log("TEST 25/28 PASSED: Statement artifacts are evidence-driven and clean from Golden Demo cross-project pollution.");
}

// TEST 26/28: 钣金冲压工艺 (R < 1t) 必须真正触发 SM-001 规则
function testMultiProcessSheetMetalRule() {
  const re = new RuleEngine();
  const smFindings = re.evaluateGeometry({
    process: "Sheet metal forming",
    sheetThickness: 1.0,
    insideRadius: 0.2
  });
  assert(smFindings.some(f => f.issue_id === "DG-SM-001"), "Must trigger DG-SM-001 bend radius violation");
  console.log("TEST 26/28 PASSED: Generic Multi-Process Rule Engine successfully evaluated SM-001 for sheet metal forming.");
}

// TEST 27/28: inAgent production 断线时必须记录失败且 workflow 状态为 EXTERNAL_WRITE_FAILED
async function testInAgentProductionFailClosed() {
  const orchestrator = new DesignGateOrchestrator(null);
  orchestrator.inagentAdapter = new InAgentAdapter({ mode: "production", endpoint: "http://127.0.0.1:9998" });

  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-TEST-RAG",
    inagentRAG: true
  });

  assert(res.external_receipts.inagent !== null, "external_receipts.inagent must exist");
  assert(res.external_receipts.inagent.status === "CONNECTION_FAILED", "inAgent receipt status must be CONNECTION_FAILED");
  assert(res.workflow_status === "EXTERNAL_WRITE_FAILED", "Workflow status must be EXTERNAL_WRITE_FAILED on inAgent production disconnection");
  console.log("TEST 27/28 PASSED: inAgent production connection loss triggers Fail-Closed workflow status.");
}

// TEST 28/28: 舒适尺寸 (45x20mm) 手持设备人机握持周长必须通过，不得触发 DG-ERG-001 超标
async function testErgonomicsComfortPass() {
  const orchestrator = new DesignGateOrchestrator(null);
  const res = await orchestrator.runReviewPipeline({
    projectId: "DG-COMFORT-TOOL",
    proposalText: "紧凑型手持测温仪，外壳尺寸 110x45x20mm，舒适便携。"
  });
  assert(!res.findings.some(f => f.issue_id === "DG-ERG-001"), "Comfortable grip (45x20mm ~ 107mm perimeter) must NOT be flagged as DG-ERG-001 ergonomic violation");
  console.log("TEST 28/28 PASSED: Comfortable dimension handheld device passes GB/T 10000-2023 ergonomics without false alarm.");
}

async function runAll() {
  await runEndToEndFileDriven();
  await testDualStateModel();
  await testNoPollution();
  await testMaterialScoping();
  await testAgentDynamism();
  testProjectStateSecurity();
  await testContractAndRenderer();
  testPythonRunnerHealth();

  // 运行新增的 8 项真实性与反例测试
  await testErgonomicsNegativeMissingDims();
  testTradeNameOnlyRejection();
  testRectangularBoxNoUndercut();
  testStepPointCloudHonesty();
  await testNoStatementPollution();
  testMultiProcessSheetMetalRule();
  await testInAgentProductionFailClosed();
  await testErgonomicsComfortPass();

  console.log("ALL 28 ENGINEERING TRUTH & STABILIZATION TESTS PASSED SUCCESSFULLY (28/28)!");
}

runAll();
