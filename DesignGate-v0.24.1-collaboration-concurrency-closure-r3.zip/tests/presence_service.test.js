const test = require('node:test');
const assert = require('node:assert/strict');
const PresenceService = require('../backend/collaboration/presence_service');

test('presence keeps only fresh project-scoped sessions and never writes to project state', () => {
  let now = 1_000;
  const presence = new PresenceService({ now: () => now, ttlMs: 100 });

  presence.heartbeat({ project_id: 'DG-TEAM-1', user_id: 'designer-1', status: 'ONLINE' });
  assert.deepEqual(presence.list('DG-TEAM-1'), [{ project_id: 'DG-TEAM-1', user_id: 'designer-1', status: 'ONLINE', last_seen_at: new Date(1_000).toISOString() }]);

  now = 1_101;
  assert.deepEqual(presence.list('DG-TEAM-1'), []);
  assert.throws(() => presence.heartbeat({ project_id: 'DG-TEAM-1', user_id: 'designer-1', status: 'BUSY' }), error => error.code === 'INVALID_PRESENCE_STATUS');
});
