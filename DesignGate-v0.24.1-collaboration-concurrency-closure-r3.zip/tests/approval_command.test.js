const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');
const LocalImmutableArtifactStore = require('../backend/collaboration/local_immutable_artifact_store');

test('only a teacher records a current-version-bound approval, which is not a freeze', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-approval-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-APPROVAL-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.addMember('DG-APPROVAL-001', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' }, { user_id: 'USER-A' });
  store.addMember('DG-APPROVAL-001', { user_id: 'TEACHER-01', role_id: 'TEACHER_REVIEWER' }, { user_id: 'USER-A' });
  const input = { decision: 'APPROVED', reason: 'Evidence and review scope are complete.', evidence_set_hash: 'a'.repeat(64), verification_state_hash: 'b'.repeat(64), dfmea_state_hash: 'c'.repeat(64), gate_state_hash: 'd'.repeat(64), risk_state_hash: 'e'.repeat(64) };
  const command = actor => ({ command_id: `CMD-APPROVAL-${actor}`, idempotency_key: `idem-approval-${actor}`, project_id: 'DG-APPROVAL-001', command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-001', base_project_version: 1, base_entity_version: 0, payload: input });
  assert.throws(() => commands.execute(command('student'), { user_id: 'USER-B' }), error => error.code === 'PERMISSION_DENIED');
  const result = commands.execute(command('teacher'), { user_id: 'TEACHER-01' });
  assert.equal(result.event_type, 'APPROVAL_RECORDED');
  const approval = store.getProjectForActor('DG-APPROVAL-001', 'USER-A').approvals[0];
  assert.equal(approval.actor_id, 'TEACHER-01');
  assert.equal(approval.revision_id, 'A');
  assert.equal(approval.status, 'CURRENT');
  assert.equal(approval.dfmea_state_hash, input.dfmea_state_hash);
  assert.equal(store.getProjectForActor('DG-APPROVAL-001', 'USER-A').freeze, undefined);
});

test('a design-relevant command marks a prior current approval stale instead of reusing it', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-approval-stale-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-APPROVAL-STALE', project_name: 'Lamp' }, { user_id: 'OWNER-01' });
  store.addMember('DG-APPROVAL-STALE', { user_id: 'TEACHER-01', role_id: 'TEACHER_REVIEWER' }, { user_id: 'OWNER-01' });
  commands.execute({ command_id: 'CMD-APR-stale', idempotency_key: 'idem-apr-stale', project_id: 'DG-APPROVAL-STALE', command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-STALE', base_project_version: 2, base_entity_version: 0, payload: { decision: 'APPROVED', reason: 'Current at review time.', evidence_set_hash: 'a'.repeat(64), verification_state_hash: 'b'.repeat(64), dfmea_state_hash: 'c'.repeat(64), gate_state_hash: 'd'.repeat(64), risk_state_hash: 'e'.repeat(64) } }, { user_id: 'TEACHER-01' });
  commands.execute({ command_id: 'CMD-BOM-stale', idempotency_key: 'idem-bom-stale', project_id: 'DG-APPROVAL-STALE', command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'P-03', base_project_version: 3, base_entity_version: 0, payload: { part_name: 'Housing', material: 'PC+ABS' } }, { user_id: 'OWNER-01' });
  assert.equal(store.getProjectForActor('DG-APPROVAL-STALE', 'OWNER-01').approvals[0].status, 'STALE');
});

test('a current Gate 3 approval derives its bindings server-side without operator-supplied hashes', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-approval-derived-'));
  const store = new TeamStore({ directory: path.join(directory, 'db') });
  const artifacts = new LocalImmutableArtifactStore({ directory: path.join(directory, 'artifacts') });
  const commands = new CommandService({ store, artifactVerifier: artifact => {
    const metadata = artifacts.getMetadata(artifact.artifact_id);
    return Boolean(metadata && artifacts.verifyHash(metadata));
  } });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-APPROVAL-DERIVED', project_name: 'Lamp' }, { user_id: 'OWNER-01' });
  store.addMember('DG-APPROVAL-DERIVED', { user_id: 'TEACHER-01', role_id: 'TEACHER_REVIEWER' }, { user_id: 'OWNER-01' });
  const artifact = artifacts.put({ project_id: 'DG-APPROVAL-DERIVED', revision_id: 'A', artifact_type: 'EVIDENCE', original_filename: 'result.csv', bytes: Buffer.from('result,PASS\n'), created_by: 'OWNER-01' });
  store.registerArtifact(artifact);
  const state = store.getProjectForActor('DG-APPROVAL-DERIVED', 'OWNER-01');
  state.evidence = [{ evidence_id: 'EVD-1', artifact_id: artifact.artifact_id, artifact_sha256: artifact.sha256, project_id: 'DG-APPROVAL-DERIVED', revision_id: 'A', status: 'CURRENT' }];
  state.dfmea = null; state.dfmea_test_records = []; state.dfmea_verification_plan = null; state.risk_acceptances = [];
  state.gate = { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'A', decision: 'PASS', freeze_eligible: true } };
  store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(state), 'DG-APPROVAL-DERIVED');
  commands.execute({ command_id: 'CMD-APR-DERIVED', idempotency_key: 'idem-apr-derived', project_id: 'DG-APPROVAL-DERIVED', command_type: 'APPROVAL_RECORD', entity_type: 'APPROVAL', entity_id: 'APR-DERIVED', base_project_version: 2, base_entity_version: 0, payload: { decision: 'APPROVED', reason: 'Teacher reviewed the current locally bounded record.' } }, { user_id: 'TEACHER-01' });
  const approval = store.getProjectForActor('DG-APPROVAL-DERIVED', 'OWNER-01').approvals[0];
  for (const field of ['evidence_set_hash', 'verification_state_hash', 'dfmea_state_hash', 'risk_state_hash', 'gate_state_hash']) assert.match(approval[field], /^[a-f0-9]{64}$/);
});
