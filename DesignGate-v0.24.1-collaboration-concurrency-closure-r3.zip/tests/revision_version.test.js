const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('REVISION_CREATE is an audited command that invalidates current verification state', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-team-revision-'));
  const store = new TeamStore({ directory });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const commands = new CommandService({ store });
  store.createProject({ project_id: 'DG-REV-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const project = store.getProjectForActor('DG-REV-001', 'USER-A');
  project.verifications = [{ req_id: 'REQ-1', status: 'PASS' }];
  store.db.prepare('UPDATE team_projects SET state_json = ? WHERE project_id = ?').run(JSON.stringify(project), 'DG-REV-001');

  const result = commands.execute({ command_id: 'CMD-REV-B', idempotency_key: 'idem-rev-b', project_id: 'DG-REV-001', command_type: 'REVISION_CREATE', base_project_version: 1, entity_type: 'REVISION', entity_id: 'B', base_entity_version: 0, payload: { revision: 'B', reason: 'Sealing geometry changed' } }, { user_id: 'USER-A' });
  const next = store.getProjectForActor('DG-REV-001', 'USER-A');
  assert.equal(result.event_type, 'REVISION_CREATED');
  assert.equal(next.design.active_revision, 'B');
  assert.deepEqual(next.verifications, []);
});
