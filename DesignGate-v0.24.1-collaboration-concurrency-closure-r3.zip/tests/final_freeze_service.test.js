const test = require('node:test');
const assert = require('node:assert/strict');
const FinalFreezeService = require('../backend/collaboration/final_freeze_service');

test('freeze-time revalidation rejects a current evidence artifact whose bytes no longer verify', () => {
  const service = new FinalFreezeService({
    store: { getArtifact: id => id === 'ART-E-1' ? { artifact_id: id, project_id: 'DG-FRZ-1', revision_id: 'C', sha256: 'a'.repeat(64), immutable: true } : null },
    artifactVerifier: () => false
  });
  const state = {
    version: 7,
    design: { active_revision: 'C' },
    evidence: [{ evidence_id: 'EVD-1', artifact_id: 'ART-E-1', artifact_sha256: 'a'.repeat(64), project_id: 'DG-FRZ-1', revision_id: 'C', status: 'CURRENT' }],
    dfmea_test_records: [], dfmea: null, dfmea_verification_plan: null, risk_acceptances: [],
    gate: { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { decision: 'PASS' }
    }
  };

  assert.throws(() => service.revalidate({ project_id: 'DG-FRZ-1', state }), error => error.code === 'ARTIFACT_INTEGRITY_INVALID');
});

test('freeze-time approval validation rejects an approval bound to an older evidence set', () => {
  const service = new FinalFreezeService({ store: { getArtifact: () => null } });
  const bindings = { revision_id: 'C', evidence_set_hash: 'a'.repeat(64), verification_state_hash: 'b'.repeat(64), dfmea_state_hash: 'c'.repeat(64), risk_state_hash: 'd'.repeat(64), gate_state_hash: 'e'.repeat(64) };
  const approval = { status: 'CURRENT', decision: 'APPROVED', revision_id: 'C', evidence_set_hash: 'f'.repeat(64), verification_state_hash: 'b'.repeat(64), risk_state_hash: 'd'.repeat(64), gate_state_hash: 'e'.repeat(64) };
  assert.throws(() => service.validateApproval({ approval, bindings }), error => error.code === 'STALE_APPROVAL');
});

test('freeze-time revalidation rejects an applicable DFMEA that no longer has a current valid execution', () => {
  const service = new FinalFreezeService({ store: { getArtifact: () => null } });
  const state = {
    project_id: 'DG-FRZ-DFMEA',
    design: { active_revision: 'C' },
    evidence: [],
    dfmea: {
      items: [{
        item_id: 'ITEM-1',
        function: 'retain pressure',
        failure_modes: [{ failure_mode_id: 'FM-1', effect: 'leak', cause: 'seal damage', severity: 8, occurrence: 3, detection: 3 }]
      }],
      requirement_links: []
    },
    dfmea_verification_plan: {
      plan_id: 'PLAN-1', version: 1,
      items: [{ plan_item_id: 'PLAN-ITEM-1', failure_mode_ids: ['FM-1'], method: 'pressure test', acceptance_criteria: 'no leak' }]
    },
    dfmea_test_records: [],
    risk_acceptances: [],
    dfmea_failure_dispositions: []
  };

  assert.throws(() => service.revalidate({ project_id: 'DG-FRZ-DFMEA', state }), error => error.code === 'FINAL_FREEZE_DFMEA_NOT_CLOSED');
});

test('freeze-time revalidation rejects a Gate 3 cache whose decision record belongs to another revision', () => {
  const service = new FinalFreezeService({ store: { getArtifact: () => null } });
  const state = {
    project_id: 'DG-FRZ-GATE', design: { active_revision: 'C' }, evidence: [],
    dfmea: null, dfmea_test_records: [], dfmea_verification_plan: null, risk_acceptances: [],
    gate: { current_stage: 'Gate 3', status: 'PASS', freeze_eligible: true, gate_record: { revision: 'B', decision: 'PASS', freeze_eligible: true } }
  };

  assert.throws(() => service.revalidate({ project_id: 'DG-FRZ-GATE', state }), error => error.code === 'FINAL_FREEZE_GATE_STALE');
});
