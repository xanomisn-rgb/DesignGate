const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');
const { WebSocket } = require('ws');

test('presence heartbeat is authenticated, project-scoped, and reports only the session user', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-presence-http-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple', display_name: 'Alice' });
  store.createProject({ project_id: 'DG-PRESENCE-1', project_name: 'Presence' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const headers = { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' };

  const written = await fetch(`${base}/api/projects/DG-PRESENCE-1/presence`, { method: 'POST', headers, body: JSON.stringify({ user_id: 'FORGED-USER', status: 'ONLINE' }) });
  assert.equal(written.status, 200);
  assert.equal((await written.json()).presence.user_id, 'USER-A');
  const listed = await fetch(`${base}/api/projects/DG-PRESENCE-1/presence`, { headers }).then(response => response.json());
  assert.deepEqual(listed.presence.map(row => row.user_id), ['USER-A']);
});

test('presence updates are delivered as minimal project-scoped WebSocket events', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-presence-ws-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  identity.register({ user_id: 'USER-A', username: 'alice', password: 'correct horse battery staple', display_name: 'Alice' });
  store.createProject({ project_id: 'DG-PRESENCE-2', project_name: 'Presence' }, { user_id: 'USER-A' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const port = server.address().port, base = `http://127.0.0.1:${port}`;
  const login = await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'alice', password: 'correct horse battery staple' }) }).then(response => response.json());
  const socket = new WebSocket(`ws://127.0.0.1:${port}/api/projects/DG-PRESENCE-2/events`, { headers: { authorization: `Bearer ${login.token}` } });
  t.after(() => socket.close());
  const nextMessage = () => new Promise(resolve => socket.once('message', payload => resolve(JSON.parse(payload))));
  const connected = await nextMessage();
  assert.equal(connected.type, 'CONNECTED');

  const presenceEvent = nextMessage();
  const heartbeat = await fetch(`${base}/api/projects/DG-PRESENCE-2/presence`, { method: 'POST', headers: { authorization: `Bearer ${login.token}`, 'content-type': 'application/json' }, body: JSON.stringify({ status: 'IDLE' }) });
  assert.equal(heartbeat.status, 200);
  const event = await presenceEvent;
  assert.deepEqual(event, { type: 'PRESENCE_UPDATED', project_id: 'DG-PRESENCE-2', presence: { project_id: 'DG-PRESENCE-2', user_id: 'USER-A', status: 'IDLE', last_seen_at: event.presence.last_seen_at } });
});
