const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const State=require('../backend/project_state_manager');
const Workflow=require('../backend/workflow_service');

function project(id){return {project_id:id,project_name:id,design:{active_revision:'A'},requirements:[],bom:[],findings:[],gate:{current_stage:'Gate 1',status:'OPEN'},evidence:[]};}
test('workflow registration persists a bound provenance manifest and rejects a fabricated evidence ID',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-workflow-prov-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const state=new State(dir),workflow=new Workflow(state);state.saveProject(project('DG-PROV'),0);
 const file=path.join(dir,'observation.txt');fs.writeFileSync(file,'observed data');
 const added=workflow.addEvidence('DG-PROV',file,1);
 assert.equal(added.evidence.integrity_status,'VERIFIED');assert.equal(added.evidence.provenance_status,'BOUND');assert(added.evidence.manifest_id);
 const current=workflow.currentEvidenceContext(state.getProject('DG-PROV'));
 assert.equal(current[0].current_revision_valid,true);
 assert.equal(workflow.evidenceProvenance.verifyEvidenceBinding({project_id:'DG-PROV',revision:'A',evidence_id:'EVD-LLM-INVENTED'}).reason_code,'EVIDENCE_MANIFEST_MISSING');
});

test('legacy evidence remains historical but cannot become v2 current evidence',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-workflow-legacy-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const state=new State(dir),workflow=new Workflow(state);const old=project('DG-LEGACY');old.evidence=[{evidence_id:'EVD-OLD',sha256:'a'.repeat(64),revision:'A'}];state.saveProject(old,0);
 const context=workflow.currentEvidenceContext(state.getProject('DG-LEGACY'))[0];
 assert.equal(context.provenance_status,'LEGACY_UNBOUND');assert.equal(context.current_revision_valid,false);
});
