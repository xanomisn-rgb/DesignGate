const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const IdentityService = require('../backend/collaboration/identity_service');
const TeamStore = require('../backend/collaboration/team_store');
const CollaborationServer = require('../backend/collaboration/server');

test('only an owner can change a member role, remove a member, or transfer ownership', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-member-api-'));
  const identity = new IdentityService({ directory: path.join(directory, 'identity'), sessionSecret: 'test-secret' });
  const store = new TeamStore({ directory: path.join(directory, 'database') });
  for (const [user_id, username] of [['USER-A', 'alice'], ['USER-B', 'bruno']]) identity.register({ user_id, username, password: 'correct horse battery staple' });
  const server = new CollaborationServer({ identity, store, host: '127.0.0.1', port: 0 });
  await server.start();
  t.after(async () => { await server.stop(); store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const login = async username => (await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password: 'correct horse battery staple' }) }).then(response => response.json())).token;
  const tokenA = await login('alice');
  const tokenB = await login('bruno');
  const request = (pathname, token, method, body) => fetch(`${base}${pathname}`, { method, headers: { authorization: `Bearer ${token}`, ...(body ? { 'content-type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}) });

  assert.equal((await request('/api/projects', tokenA, 'POST', { project_id: 'DG-MEMBER-API', project_name: 'Shared lamp' })).status, 201);
  assert.equal((await request('/api/projects/DG-MEMBER-API/members', tokenA, 'POST', { user_id: 'USER-B', role_id: 'STUDENT_STRUCTURE' })).status, 201);
  const changed = await request('/api/projects/DG-MEMBER-API/members/USER-B', tokenA, 'PATCH', { role_id: 'TEACHER_REVIEWER' });
  assert.equal(changed.status, 200);
  assert.equal((await changed.json()).member.role_id, 'TEACHER_REVIEWER');
  assert.equal((await request('/api/projects/DG-MEMBER-API/members/USER-B', tokenB, 'DELETE')).status, 403);
  assert.equal((await request('/api/projects/DG-MEMBER-API/ownership', tokenA, 'POST', { target_user_id: 'USER-B' })).status, 200);
  assert.equal(store.getMembership('DG-MEMBER-API', 'USER-B').role_id, 'PROJECT_OWNER');
  assert.equal((await request('/api/projects/DG-MEMBER-API/members/USER-B', tokenB, 'DELETE')).status, 400);
});
