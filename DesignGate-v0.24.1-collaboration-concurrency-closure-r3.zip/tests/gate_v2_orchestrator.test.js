const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const Orchestrator=require('../backend/orchestrator');

test('a new formal orchestrator review is recorded as Gate v2 and model prose cannot make it pass',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-gate-v2-orch-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const orchestrator=new Orchestrator(async()=> 'PASS GATE_PASS FINAL_FREEZE',{storageDir:dir});
 const review=await orchestrator.runReviewPipeline({projectId:'DG-NEW',stage:'Gate 3',requirements:[{req_id:'REQ-1',text:'shall hold',verification_method:'test',acceptance_criteria:'no break'}]});
 assert.equal(review.gate.gate_engine_version,'v2');assert.notEqual(review.gate.decision,'PASS');
 const persisted=orchestrator.stateManager.getProject('DG-NEW');assert.equal(persisted.last_review.gate.gate_engine_version,'v2');assert.equal(persisted.freeze,null);
});

test('a historical project without a gate engine marker remains on v1',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-gate-v1-history-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const orchestrator=new Orchestrator(null,{storageDir:dir});orchestrator.stateManager.saveProject({project_id:'DG-HIST',project_name:'hist',schema_version:'3.1',design:{active_revision:'A'},requirements:[],bom:[],findings:[],gate:{current_stage:'Gate 1',status:'OPEN'}},0);
 const review=await orchestrator.runReviewPipeline({projectId:'DG-HIST',stage:'Gate 1'});
 assert.equal(review.gate.gate_engine_version,'v1');
});
