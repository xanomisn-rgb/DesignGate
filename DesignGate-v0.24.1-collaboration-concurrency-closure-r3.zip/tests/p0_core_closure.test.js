const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const crypto=require('crypto');
const Orchestrator=require('../backend/orchestrator');
const Workflow=require('../backend/workflow_service');
const Bus=require('../backend/integrations/integration_event_bus');
const {CadAdapter}=require('../backend/integrations/cad_adapter');
const IntegrationServer=require('../backend/http/integration_server');

function good(){return {process:'CNC',material:'6061-T6',materialFamily:'aluminum',materialGrade:'6061-T6',substrate:'6061-T6',internalCornerRadius:2,finish:'anodized',color:'black',gloss:'matte',glossMeasurementAngleDeg:60,useEnvironment:'indoor',cmfCompatibilityEvidence:'local reviewed sample record',cmfSamplePlan:'record sample lot',cmfDurabilityPlan:'record pre/post condition',cmfKnowledgeStatus:'REVIEWED',cmfSource:'local source',cmfSourceVersion:'p0',cmfApplicability:'this sample condition',cmfUnits:'gloss deg',cmfExceptions:'none recorded'};}
test('P0 main chain is continuous and preserves the human approval boundary',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-p0-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const orchestrator=new Orchestrator(async()=> 'PASS GATE_PASS FINAL_FREEZE',{storageDir:dir}),workflow=new Workflow(orchestrator.stateManager);
 const first=await orchestrator.runReviewPipeline({projectId:'DG-P0',stage:'Gate 2',requirements:[{req_id:'REQ-1',text:'Housing shall survive use',verification_method:'test',acceptance_criteria:'no break'}],bom:[{part_id:'P1',part_name:'housing',material_specified:'6061-T6',quantity:1,unit_cost:1,currency:'CNY',quote_source:'local'}],designParams:good()});assert.notEqual(first.gate.decision,'PASS');assert.equal(orchestrator.stateManager.getProject('DG-P0').freeze,null);
 const expectedSha=crypto.createHash('sha256').update('ISO-10303-21;P0').digest('hex');const adapter=new CadAdapter({stateManager:orchestrator.stateManager,workflowService:workflow,eventBus:new Bus(path.join(dir,'events')),runner:{analyze:async()=>({analysis_status:'BREP_ANALYZED_PARTIAL',analysis_success:true,file_sha256:expectedSha,solid_count:1,face_count:6,bounding_box:{unit:'mm'},measurements:{},analyzer_backend:'OCP',analyzer_version:'8.0.1.0.0',limitations:['SAMPLED_NOT_GLOBAL_PROOF']})}});
 const server=new IntegrationServer({adapter,apiKey:'p0-key',projectAuthorizer:({project_id})=>project_id==='DG-P0'});await server.listen();t.after(()=>server.close());const form=new FormData();for(const [key,value] of Object.entries({project_id:'DG-P0',revision:'A',source_system:'MOCK_CAD',idempotency_key:'p0-upload'}))form.append(key,value);form.append('file',new Blob(['ISO-10303-21;P0']),'p0.step');const response=await fetch(`http://127.0.0.1:${server.address().port}/api/integrations/cad/upload`,{method:'POST',headers:{'X-DesignGate-Integration-Key':'p0-key'},body:form});assert.equal(response.status,202);const upload=await response.json();assert(upload.evidence_reference.manifest_id);
 let project=orchestrator.stateManager.getProject('DG-P0'),evidence=project.evidence[0];for(const req_id of ['REQ-1','SYS-MATERIAL','SYS-MANUFACTURING','SYS-CMF','SYS-CAD']){project=orchestrator.stateManager.getProject('DG-P0');workflow.verify('DG-P0',{req_id,status:'PASS',observed_result:'Current bounded observation and human verification record',reviewer:'Local reviewer',evidence_id:evidence.evidence_id},project.version);}
 const final=await orchestrator.runReviewPipeline({projectId:'DG-P0',stage:'Gate 3'});assert.equal(final.gate.gate_engine_version,'v2');assert.equal(final.gate.decision,'PASS',JSON.stringify(final.gate.all_blockers));assert.throws(()=>workflow.freeze('DG-P0',{review_id:final.review_id,approved_by:'',reason:''},orchestrator.stateManager.getProject('DG-P0').version),/审批人|审批意见/);assert.equal(orchestrator.stateManager.getProject('DG-P0').freeze,null);
});
