const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');

test('EVIDENCE_ADD appends immutable evidence only for a current-revision registered artifact', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-evidence-command-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-EVIDENCE-CMD', project_name: 'Lamp' }, { user_id: 'USER-A' });
  store.registerArtifact({ artifact_id: 'ART-EVIDENCE-A', project_id: 'DG-EVIDENCE-CMD', revision_id: 'A', artifact_type: 'EVIDENCE', sha256: 'e'.repeat(64), immutable: true, created_by: 'USER-A' });
  commands.execute({
    command_id: 'CMD-REQ-A', idempotency_key: 'idem-req-a', project_id: 'DG-EVIDENCE-CMD',
    command_type: 'UPDATE_REQUIREMENT', entity_type: 'REQUIREMENT', entity_id: 'REQ-A', base_project_version: 1, base_entity_version: 0,
    payload: { text: 'The lamp shall remain stable.' }
  }, { user_id: 'USER-A' });

  const result = commands.execute({
    command_id: 'CMD-EVIDENCE-A', idempotency_key: 'idem-evidence-a', project_id: 'DG-EVIDENCE-CMD',
    command_type: 'EVIDENCE_ADD', entity_type: 'EVIDENCE', entity_id: 'EVD-A', base_project_version: 2, base_entity_version: 0,
    payload: { artifact_id: 'ART-EVIDENCE-A', sha256: 'e'.repeat(64), purpose: 'verification observation', requirement_ids: ['REQ-A'] }
  }, { user_id: 'USER-A' });

  assert.equal(result.event_type, 'EVIDENCE_ADDED');
  const evidence = store.getProjectForActor('DG-EVIDENCE-CMD', 'USER-A').evidence;
  assert.deepEqual(evidence[0].requirement_ids, ['REQ-A']);
  assert.equal(evidence[0].artifact_id, 'ART-EVIDENCE-A');
  assert.equal(evidence[0].immutable, true);
  assert.throws(() => commands.execute({
    command_id: 'CMD-EVIDENCE-B', idempotency_key: 'idem-evidence-b', project_id: 'DG-EVIDENCE-CMD',
    command_type: 'EVIDENCE_ADD', entity_type: 'EVIDENCE', entity_id: 'EVD-B', base_project_version: 3, base_entity_version: 0,
    payload: { artifact_id: 'ART-EVIDENCE-A', sha256: 'f'.repeat(64), purpose: 'tampered hash' }
  }, { user_id: 'USER-A' }), /ARTIFACT_HASH_MISMATCH/);
});
