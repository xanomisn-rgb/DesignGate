const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const TeamStore = require('../backend/collaboration/team_store');
const CommandService = require('../backend/collaboration/command_service');
const AgentRunCoordinator = require('../backend/collaboration/agent_run_coordinator');

test('an Agent result is revalidation-required when a relevant entity changed during its run', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-agent-run-'));
  const store = new TeamStore({ directory });
  const commands = new CommandService({ store });
  const coordinator = new AgentRunCoordinator({ store });
  t.after(() => { store.close(); fs.rmSync(directory, { recursive: true, force: true }); });
  store.createProject({ project_id: 'DG-AGENT-001', project_name: 'Lamp' }, { user_id: 'USER-A' });
  const run = coordinator.start({ project_id: 'DG-AGENT-001', revision_id: 'A', relevant_entity_versions: [{ entity_type: 'BOM_ITEM', entity_id: 'P-03', version: 0 }], knowledge_snapshot_hash: 'a'.repeat(64), rule_version: 'rules-v1', tool_registry_hash: 'b'.repeat(64) }, { user_id: 'USER-A' });
  commands.execute({ command_id: 'CMD-BOM-AGENT', idempotency_key: 'idem-bom-agent', project_id: 'DG-AGENT-001', command_type: 'UPDATE_BOM_ITEM', entity_type: 'BOM_ITEM', entity_id: 'P-03', base_project_version: 1, base_entity_version: 0, payload: { part_name: 'Housing', material: 'PC+ABS' } }, { user_id: 'USER-A' });
  const completed = coordinator.complete(run.run_id, { finding_ids: ['FIND-018'] }, { user_id: 'USER-A' });
  assert.equal(completed.status, 'REVALIDATION_REQUIRED');
  assert.deepEqual(completed.changed_entities, [{ entity_type: 'BOM_ITEM', entity_id: 'P-03', expected_version: 0, current_version: 1 }]);
});
