const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const FileProjectRepository = require('../backend/repositories/file_project_repository');

test('FileProjectRepository preserves the existing local project version contract', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dg-file-repository-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const repository = new FileProjectRepository({ directory });
  repository.createProject({ project_id: 'DG-FILE-001', project_name: 'Solo Lamp' });

  const first = repository.getProject('DG-FILE-001');
  assert.equal(first.version, 1);
  first.project_name = 'Updated Solo Lamp';
  repository.saveProject(first, 1);
  assert.equal(repository.getCurrentVersion('DG-FILE-001'), 2);
  assert.throws(() => repository.saveProject(first, 1), /VERSION_CONFLICT/);
});
