const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs'),path=require('path'),os=require('os');
const State=require('../backend/project_state_manager');
const Agent=require('../backend/agent_runtime');
const Tools=require('../backend/agent_tools');
const Client=require('../connectors/agent_model_client');
const plan={steps:['读取项目需求和材料','执行规则检查并核对缺口','整理证据与下一步动作'],reason:'按目标执行'};
const finish=(ids=['OBS-2'])=>({summary:'依据工具记录整理缺口，尚需工程师验证。',evidence_ids:ids,limitations:['单零件规则范围有限。']});
function call(name,args={}){return {message:{role:'assistant',content:null,tool_calls:[{id:'call-'+Math.random(),type:'function',function:{name,arguments:JSON.stringify(args)}}]}};}
function env(t,sequence,options={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dg-agent-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const sm=new State(dir);sm.saveProject({project_id:'DG-AGENT',project_name:'合成测试项目',requirements:[{req_id:'REQ-01',text:'外壳可拆卸'}],design:{active_revision:'A',process:'CNC',material:'6061-T6',internalCornerRadius:.3},bom:[],findings:[]},0);
 let index=0;const requests=[];
 const model=async request=>{requests.push(request);const next=sequence[index++];if(!next)throw Error('unexpected model call');return typeof next==='function'?next(request):next;};
 const runtime=new Agent(sm,model,options);return {runtime,sm,dir,requests,start:goal=>runtime.start('DG-AGENT',goal||'检查我的方案并提出建议')};
}
test('model-selected tools execute actual checks and persist a cited result without changing project',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('finish_task',finish())]);const before=e.sm.getProject('DG-AGENT');
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 assert.equal(r.status,'COMPLETED');assert(r.events[1].output.findings.some(f=>f.issue_id==='DG-CHECK-cnc-CORNER'));assert.deepEqual(e.sm.getProject('DG-AGENT'),before);
 assert(e.requests[2].messages.some(m=>m.role==='tool'&&m.content.includes('OBS-2')));assert(!('messages'in r));
 const restarted=new Agent(e.sm,async()=>{});assert.equal(restarted.list('DG-AGENT')[0].status,'COMPLETED');
});
test('agent runtime records model tool requests as unverified governed proposals without authoritative mutation',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('finish_task',finish())]);
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 assert.equal(r.runtime_governance.state.project_id,'DG-AGENT');
 assert.equal(r.runtime_governance.authoritative.verification_status,null);
 assert.equal(r.runtime_governance.authoritative.freeze,null);
 assert.equal(r.runtime_governance.state.runtime_status,'ANALYSIS_PENDING');
 assert(r.runtime_governance.proposals.some(proposal=>proposal.status==='UNVERIFIED_PROPOSAL'));
 assert.equal(r.runtime_governance.trace.valid,true);
 assert.match(r.runtime_governance.checkpoint.checkpoint_id,/^CHK-/);
 assert.match(r.runtime_governance.checkpoint.payload_hash,/^[a-f0-9]{64}$/);
 assert(r.runtime_governance.proposals.some(proposal=>proposal.capability_id==='PLAN_UPDATE'));
});
test('finish schema repair is forced without conflicting replanning',async t=>{const e=env(t,[call('update_plan',plan),call('screen_design'),call('finish_task',{}),request=>{assert.equal(request.forcePlan,false);assert.equal(request.forceTool,'finish_task');return call('finish_task',finish());}]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'COMPLETED');assert.equal(r.events.filter(x=>x.tool==='finish_task').length,2);assert.match(r.events.find(x=>x.tool==='finish_task'&&x.status==='FAILED').error,/FINISH_SCHEMA_REPAIR_REQUIRED/);});
test('recovered format failures remain visible with structured recovery markers',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('finish_task',{}),call('finish_task',finish())]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 const failed=r.events.find(x=>x.tool==='finish_task'&&x.status==='FAILED'),recovered=r.events.at(-1);
 assert.equal(failed.error_class,'RECOVERABLE_FORMAT');
 assert.equal(failed.recovery_action,'REPAIR');
 assert.equal(failed.recovered_by,recovered.id);
 assert.deepEqual(recovered.recovered_failures,[failed.id]);
});
test('an identical failed tool call is stopped on the next attempt without consuming a third retry',async t=>{
 const bad={id:'REF-WALL-ABS'},e=env(t,[call('update_plan',plan),call('read_knowledge',bad),call('read_knowledge',bad),call('ask_user',{question:'请确认需要读取的知识编号。'})]);
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 assert.equal(r.status,'WAITING_INPUT');
 assert.equal(r.events[1].error_class,'RECOVERABLE_FORMAT');
 assert.equal(r.events[2].error_class,'NO_PROGRESS_LOOP');
 assert.equal(r.events.filter(x=>x.tool==='read_knowledge').length,2);
});
test('missing input pauses and continues after restart with the user answer',async t=>{
 const e=env(t,[call('update_plan',plan),call('inspect_requirements'),call('ask_user',{question:'可拆装的通过判据是什么？'})]);
 let r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'WAITING_INPUT');
 assert.throws(()=>e.runtime.resume('DG-AGENT',r.run_id,''),/回答/);
 let seen=false;const queue=[call('update_plan',{...plan,reason:'已收到判据'}),call('inspect_requirements'),call('finish_task',finish(['OBS-5']))];
 const restarted=new Agent(e.sm,async request=>{if(request.messages.some(m=>m.role==='user'&&m.content==='三分钟内使用普通螺丝刀拆装'))seen=true;return queue.shift();});
 restarted.resume('DG-AGENT',r.run_id,'三分钟内使用普通螺丝刀拆装');r=await restarted.settled('DG-AGENT',r.run_id);assert.equal(r.status,'COMPLETED');assert(seen);
});
test('draft approval applies only reviewed fields then resumed agent checks the changed project',async t=>{
 const e=env(t,[call('update_plan',plan),call('screen_design'),call('propose_change',{title:'内角半径试验',reason:'规则检出内角半径不足，提出候选值',assumptions:['2mm 是候选值，尚未实测'],design_patch:{internalCornerRadius:2}}),call('update_plan',{...plan,reason:'草案已批准，复查'}),call('screen_design'),call('finish_task',finish(['OBS-5']))]);
 let r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'WAITING_APPROVAL');assert.equal(e.sm.getProject('DG-AGENT').design.internalCornerRadius,.3);
 assert.throws(()=>e.runtime.resume('DG-AGENT',r.run_id),/草案/);
 e.runtime.approve('DG-AGENT',r.run_id,true);const p=e.sm.getProject('DG-AGENT');assert.equal(p.design.internalCornerRadius,2);assert.equal(p.gate.status,'OPEN');assert.equal(p.field_provenance.internalCornerRadius.measured,false);
 assert.throws(()=>e.runtime.approve('DG-AGENT',r.run_id,true),/没有/);
 e.runtime.resume('DG-AGENT',r.run_id);r=await e.runtime.settled('DG-AGENT',r.run_id);assert.equal(r.status,'COMPLETED');assert(r.events[4].output.findings.some(f=>f.issue_id==='DG-CHECK-cnc-CORNER'));
});
test('rejected proposal leaves project untouched',async t=>{
 const e=env(t,[call('update_plan',plan),call('propose_change',{title:'候选材料',reason:'比较',assumptions:['待核对'],design_patch:{material:'PC'}})]),before=e.sm.getProject('DG-AGENT');
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);e.runtime.approve('DG-AGENT',r.run_id,false);assert.deepEqual(e.sm.getProject('DG-AGENT'),before);
});
test('stale approval cannot overwrite a newer project version',async t=>{
 const e=env(t,[call('update_plan',plan),call('propose_change',{title:'候选',reason:'候选',assumptions:[],design_patch:{material:'PC'}})]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 const p=e.sm.getProject('DG-AGENT');p.project_name='已被用户更新';e.sm.saveProject(p,p.version);assert.throws(()=>e.runtime.approve('DG-AGENT',r.run_id,true),/VERSION_CONFLICT/);
});
test('arbitrary tools and prototype keys fail before execution',async t=>{
 let executed=0;const e=env(t,[call('update_plan',plan),call('shell',{cmd:'echo bad'}),call('screen_design',{patch:{freeze:true}}),call('read_project',{project_id:'DG-OTHER'})],{toolExecutor:async()=>{executed++;}});
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'FAILED');assert.equal(executed,0);
 assert.throws(()=>Tools.validateCall('screen_design',JSON.parse('{"patch":{"__proto__":{}}}')),/禁止/);
});
test('no ordinary assistant text can masquerade as executed actions',async t=>{
 const e=env(t,Array.from({length:3},()=>({message:{content:'已经修改并冻结'}})));const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'FAILED');assert.equal(r.events.length,0);assert(!e.sm.getProject('DG-AGENT').freeze);
});
test('fabricated observation references are rejected and repairable',async t=>{
 const e=env(t,[call('update_plan',plan),call('check_bom_cost'),call('finish_task',finish(['OBS-999'])),call('finish_task',finish())]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'COMPLETED');assert.equal(r.events[2].status,'FAILED');
});
test('step budget stops even a compliant looping model',async t=>{
 const e=env(t,[call('update_plan',plan),call('read_project')],{maxSteps:2});const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'TOOL_STEP_LIMIT');assert.equal(r.stop_reason,'TOOL_STEP_LIMIT');assert.equal(e.requests.length,2);
});
test('token estimate prevents sending an oversized request',async t=>{
 const e=env(t,[],{maxTokens:10});const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'TOKEN_BUDGET_EXCEEDED');assert.equal(r.stop_reason,'USER_TOKEN_BUDGET_PREFLIGHT');assert.equal(e.requests.length,0);
});
test('cancel aborts in-flight model request and persists cancelled state',async t=>{
 const waiting=async({signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));
 const e=env(t,[waiting]),r=e.start();e.runtime.cancel('DG-AGENT',r.run_id);const done=await e.runtime.settled('DG-AGENT',r.run_id);assert.equal(done.status,'CANCELLED');
});
test('one active task per project and cross-project read blocked',async t=>{
 const waiting=async({signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));const e=env(t,[waiting]);const r=e.start();assert.throws(()=>e.start(),/已有任务/);assert.throws(()=>e.runtime.get('DG-OTHER',r.run_id),/不属于/);e.runtime.cancel('DG-AGENT',r.run_id);await e.runtime.settled('DG-AGENT',r.run_id);
});
test('hypothetical candidate screening clears prior evidence binding',()=>{
 const p={version:1,requirements:[],design:{active_revision:'A',process:'CNC'},basis_hash:'OLD',verifications:[{req_id:'SYS-MATERIAL',status:'PASS',revision:'A',basis_hash:'OLD',evidence_id:'E'}]};const r=Tools.screen(p,{material:'PC'});assert.equal(r.checks.find(c=>c.check_id==='VERIFY-SYS-MATERIAL').status,'UNKNOWN');assert.equal(p.design.material,undefined);
});
test('selected-file tool cannot read a model-invented path and parses real scoped PDF',async()=>{
 assert.throws(()=>Tools.validateCall('read_selected_file',{kind:'designFile',path:'/etc/passwd'}));
 await assert.rejects(()=>Tools.execute('read_selected_file',{kind:'designFile'},{project:{}}),/未由用户/);
 const r=await Tools.execute('read_selected_file',{kind:'designFile'},{project:{},files:{designFile:path.join(__dirname,'fixtures/Design_RevA.pdf')}});assert(r.files_processed.length===1);assert.equal(r.field_provenance.nominalWall.page,2);
});
test('tool schemas omit unavailable file and CAD-handle actions',()=>{
 const names=Tools.schemas({files:{},project:{project_id:'DG-X',version:1,design:{active_revision:'A'}}}).map(x=>x.function.name);
 assert(!names.includes('read_selected_file'));
 assert(!names.includes('show_cad_reference'));
 assert(names.includes('list_cad_references'));
});
test('replanning is required before another analysis tool after four productive tools',async t=>{
 const e=env(t,[call('update_plan',plan),call('read_project'),call('inspect_requirements'),call('check_bom_cost'),call('screen_design'),call('read_project'),call('update_plan',{...plan,reason:'按工具结果重评'}),call('finish_task',finish())]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.events[5].status,'FAILED');assert.equal(r.status,'COMPLETED');assert(e.requests[5].forcePlan);
});
test('a valid finish may close the task when the rolling plan horizon ends',async t=>{
 const e=env(t,[call('update_plan',plan),call('read_project'),call('inspect_requirements'),call('check_bom_cost'),call('screen_design'),call('finish_task',finish())]);
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 assert.equal(r.status,'COMPLETED');
 assert.equal(r.events.at(-1).status,'SUCCEEDED');
});
test('crash checkpoint is recovered as interrupted instead of shown as running',async t=>{
 const e=env(t,[call('update_plan',plan),call('ask_user',{question:'目标用户是谁？'})]);let r=await e.runtime.settled('DG-AGENT',e.start().run_id);const raw=e.runtime.load('DG-AGENT',r.run_id);raw.status='RUNNING';e.runtime.save(raw);assert.equal(new Agent(e.sm,async()=>{}).get('DG-AGENT',r.run_id).status,'INTERRUPTED');
});
test('native model transport sends schemas, forced plan and supports usage',async()=>{
 let request;const client=new Client(()=>({baseUrl:'https://example.test/v1',model:'test-model',apiKey:'private-key'}),async(url,opts)=>{request=opts;return {ok:true,json:async()=>({...call('read_project'),choices:[{message:call('read_project').message}],usage:{total_tokens:20}})};});
 const response=await client.call({messages:[{role:'user',content:'goal'}],tools:Tools.schemas(),forcePlan:true});const body=JSON.parse(request.body);assert.equal(body.tool_choice.function.name,'update_plan');assert.deepEqual(body.tools,Tools.schemas());assert(!request.body.includes('private-key'));assert.equal(response.usage.total_tokens,20);
});
test('model transport reports request-body components and provider latency without pricing guesses',async()=>{
 const client=new Client(()=>({baseUrl:'https://example.test/v1',model:'test-model',apiKey:'private-key'}),async()=>({ok:true,json:async()=>({choices:[{message:call('read_project').message}],usage:{prompt_tokens:11,completion_tokens:3,total_tokens:14,prompt_cache_hit_tokens:5}})}));
 const response=await client.call({messages:[{role:'system',content:'rules'},{role:'user',content:'project'},{role:'tool',content:'observation',tool_call_id:'x'}],tools:Tools.schemas()});
 assert(response.telemetry.request_bytes.total>response.telemetry.request_bytes.system);
 assert(response.telemetry.request_bytes.tool_schemas>0);
 assert(response.telemetry.request_bytes.tool_observations>0);
 assert.equal(response.telemetry.cached_tokens,5);
 assert(Number.isFinite(response.telemetry.model_latency_ms));
 assert(!Object.hasOwn(response.telemetry,'cost'));
});
test('provider adapter normalizes only unambiguous finish_task protocol shape',async()=>{
 const legacy=call('finish_task',{summary:'已完成只读核对。',evidence_ids:['OBS-2'],limitations:'仍需人工复核。',claims:[{claim_id:'C1',claim_type:'CHECK',text:'工具记录支持该描述。',status:'supported',evidence_ids:['OBS-2'],confidence:'high'}]});
 const client=new Client(()=>({baseUrl:'https://example.test/v1',model:'test-model',apiKey:'private-key'}),async()=>({ok:true,json:async()=>({choices:[{message:legacy.message}],usage:{total_tokens:20}})}));
 const response=await client.call({messages:[],tools:Tools.schemas()});
 const args=JSON.parse(response.message.tool_calls[0].function.arguments);
 assert.deepEqual(args.limitations,['仍需人工复核。']);
 assert.equal(args.claims[0].status,'SUPPORTED');
 assert.equal(args.claims[0].confidence,'HIGH');
});
test('native model errors do not include provider response secrets',async()=>{
 const client=new Client(()=>({baseUrl:'https://example.test',apiKey:'private-key'}),async()=>({ok:false,status:401,text:async()=>'private-key'}));await assert.rejects(()=>client.call({messages:[],tools:[]}),e=>e.message.includes('401')&&!e.message.includes('private-key'));
});
test('provider transport retries a transient service error within a fixed bound',async()=>{
 let attempts=0;const client=new Client(()=>({baseUrl:'https://example.test',model:'test-model',apiKey:'private-key',maxProviderRetries:1}),async()=>++attempts===1?{ok:false,status:503}:{ok:true,json:async()=>({choices:[{message:call('read_project').message}],usage:{total_tokens:4}})});
 const response=await client.call({messages:[],tools:[]});
 assert.equal(attempts,2);
 assert.equal(response.telemetry.provider_attempts,2);
});
test('project changes during model request prevent stale completion',async t=>{
 let e;e=env(t,[call('update_plan',plan),call('read_project'),()=>{const p=e.sm.getProject('DG-AGENT');p.project_name='同时修改';e.sm.saveProject(p,p.version);return call('finish_task',finish());}]);
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'PROJECT_CHANGED');assert(!r.result);
});
test('reported provider usage above the historical default remains telemetry when no user token budget is enabled',async t=>{
 const response=call('update_plan',plan);response.usage={total_tokens:200000};const e=env(t,[response,call('read_project'),call('finish_task',finish(['OBS-2']))]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);assert.equal(r.status,'COMPLETED');assert(r.reported_tokens>180000);assert.equal(e.requests.length,3);
});
test('runtime persists model request telemetry separately from tool duration',async t=>{
 const first=call('update_plan',plan);first.telemetry={request_bytes:{total:321,system:10,tool_schemas:100,project_data:50,tool_observations:0,history_messages:0,format_repair:0},model_latency_ms:7,cached_tokens:2};
 const e=env(t,[first,call('screen_design'),call('finish_task',finish())]);const r=await e.runtime.settled('DG-AGENT',e.start().run_id);
 assert.equal(r.model_telemetry[0].request_bytes.total,321);
 assert.equal(r.cached_tokens,2);
 assert(r.events.every(event=>Number.isFinite(event.tool_duration_ms)));
});
test('approval recovery uses project commit marker and does not apply twice',async t=>{
 const e=env(t,[call('update_plan',plan),call('propose_change',{title:'候选',reason:'候选',assumptions:[],design_patch:{internalCornerRadius:2}})]);
 const r=await e.runtime.settled('DG-AGENT',e.start().run_id),before=e.runtime.load('DG-AGENT',r.run_id);e.runtime.approve('DG-AGENT',r.run_id,true);const version=e.sm.getProject('DG-AGENT').version;
 e.runtime.save(before);const recovered=new Agent(e.sm,async()=>{}).get('DG-AGENT',r.run_id);assert.equal(recovered.draft.status,'APPLIED');assert(recovered.approval_recovered);assert.equal(e.sm.getProject('DG-AGENT').version,version);
});
