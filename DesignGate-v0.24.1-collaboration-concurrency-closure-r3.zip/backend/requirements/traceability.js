function buildTraceability({requirements=[],decisions=[],risks=[],plans=[],tests=[],evidence=[]}={}){
 const nodes=new Map(),edges=[],dangling=[];const add=(id,type)=>nodes.set(id,{id,type});const edge=(from,to,relation,reference)=>{if(!nodes.has(from)||!nodes.has(to)){dangling.push({from,to,relation,reference,reason:'MISSING_OR_WRONG_TYPE_REFERENCE'});return;}edges.push({from,to,relation});};
 for(const row of requirements)add(`REQ:${row.requirement_id||row.req_id}`,'REQUIREMENT');for(const row of decisions)add(`DEC:${row.decision_id}`,'DECISION');for(const row of risks)add(`RISK:${row.risk_id||row.failure_mode_id}`,'RISK');for(const row of plans)add(`PLAN:${row.plan_item_id}`,'VERIFICATION_PLAN');for(const row of tests)add(`TEST:${row.test_id}`,'TEST_EXECUTION');for(const row of evidence)add(`EVD:${row.evidence_id}`,'EVIDENCE');
 for(const row of decisions)for(const requirementId of row.requirement_ids||[])edge(`REQ:${requirementId}`,`DEC:${row.decision_id}`,'INFORMS',{requirementId});
 for(const row of risks)if(row.requirement_id)edge(`REQ:${row.requirement_id}`,`RISK:${row.risk_id||row.failure_mode_id}`,'MITIGATED_BY',{requirementId:row.requirement_id});
 for(const row of plans){for(const requirementId of row.requirement_ids||[])edge(`REQ:${requirementId}`,`PLAN:${row.plan_item_id}`,'PLANNED_FOR',{requirementId});for(const riskId of row.risk_ids||[])edge(`RISK:${riskId}`,`PLAN:${row.plan_item_id}`,'PLANNED_FOR',{riskId});}
 for(const row of tests){if(row.plan_item_id)edge(`PLAN:${row.plan_item_id}`,`TEST:${row.test_id}`,'EXECUTED_AS',{planItemId:row.plan_item_id});if(row.evidence_id)edge(`EVD:${row.evidence_id}`,`TEST:${row.test_id}`,'EVIDENCES',{evidenceId:row.evidence_id});}
 return {nodes:[...nodes.values()].sort((a,b)=>a.id.localeCompare(b.id)),edges:edges.sort((a,b)=>`${a.from}|${a.to}`.localeCompare(`${b.from}|${b.to}`)),dangling_references:dangling,validity:'STRUCTURAL_TRACE_ONLY',engineering_release:false};
}
module.exports={buildTraceability};
