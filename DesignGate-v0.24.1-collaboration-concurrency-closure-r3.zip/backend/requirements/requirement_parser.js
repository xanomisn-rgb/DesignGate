function parseRequirements(rows=[]){
 if(!Array.isArray(rows))throw Error('requirements input must be an array');
 const requirements=[],diagnostics=[],seen=new Set();
 for(const [index,row] of rows.entries()){
  const requirementId=typeof row?.requirement_id==='string'?row.requirement_id.trim():typeof row?.req_id==='string'?row.req_id.trim():'';
  const text=typeof row?.text==='string'?row.text.trim():'';
  if(!requirementId||!text){diagnostics.push({index,status:'INVALID_REQUIREMENT',reason:'requirement_id and text are required'});continue;}
  if(seen.has(requirementId)){diagnostics.push({index,requirement_id:requirementId,status:'DUPLICATE_ID',reason:'Requirement IDs must be unique.'});continue;}
  seen.add(requirementId);requirements.push({requirement_id:requirementId,req_id:requirementId,text,priority:row.priority||'MEDIUM',verification_method:row.verification_method||null,acceptance_criteria:row.acceptance_criteria||null,source_pointer:row.source_pointer||null,source_text:row.source_text||text,source_type:row.source_type||'PROJECT_INPUT',parser_status:'PARSED_UNREVIEWED',hard_gate:false,engineering_release:false});
 }
 return {requirements,diagnostics,hard_gate:false,engineering_release:false};
}
module.exports={parseRequirements};
