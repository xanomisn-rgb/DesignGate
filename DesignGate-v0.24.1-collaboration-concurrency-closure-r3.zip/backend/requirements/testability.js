function assessOne(row={}){
 const id=row.requirement_id||row.req_id,hasConstraint=!!row.normalized_constraint,hasExplicit=typeof row.verification_method==='string'&&row.verification_method.trim()&&typeof row.acceptance_criteria==='string'&&row.acceptance_criteria.trim();
 if(hasConstraint||hasExplicit)return {requirement_id:id,status:'TESTABLE',basis:hasExplicit?'EXPLICIT_METHOD_AND_CRITERIA':'DETERMINISTIC_NORMALIZED_CONSTRAINT',blocking:false};
 return {requirement_id:id,status:'AMBIGUOUS_REQUIRES_REVIEW',basis:'No deterministic constraint or complete verification method/acceptance criteria.',blocking:false};
}
function assessTestability(rows=[]){const entries=rows.map(assessOne);return {by_requirement:Object.fromEntries(entries.map(row=>[row.requirement_id,row])),summary:{testable:entries.filter(row=>row.status==='TESTABLE').length,ambiguous:entries.filter(row=>row.status!=='TESTABLE').length},hard_gate:false,engineering_release:false};}
module.exports={assessOne,assessTestability};
