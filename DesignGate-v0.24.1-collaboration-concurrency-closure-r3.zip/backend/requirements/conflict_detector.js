const {sha256}=require('../crypto/canonical_json');
function detectRequirementConflicts(requirements=[]){
 const out=[],byField=new Map();
 for(const requirement of requirements){const constraint=requirement.normalized_constraint;if(!constraint||!constraint.field||!constraint.comparator)continue;const key=`${constraint.field}|${constraint.unit||''}|${constraint.comparator}`,prior=byField.get(key);if(prior&&prior.value!==constraint.value)out.push({conflict_id:`REQCON-${sha256({key,requirements:[prior.requirement_id,requirement.requirement_id||requirement.req_id]}).slice(0,20)}`,status:'UNRESOLVED_REQUIRES_REVIEW',requirement_ids:[prior.requirement_id,requirement.requirement_id||requirement.req_id].sort(),field:constraint.field,values:[prior.value,constraint.value],hard_gate:false,engineering_release:false});else if(!prior)byField.set(key,{requirement_id:requirement.requirement_id||requirement.req_id,value:constraint.value});
 }
 return out;
}
module.exports={detectRequirementConflicts};
