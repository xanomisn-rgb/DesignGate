function inferField(text){const lower=text.toLowerCase();if(/wall\s+thickness|壁厚/.test(lower))return 'wall_thickness';if(/draft|拔模/.test(lower))return 'draft_angle';if(/radius|圆角/.test(lower))return 'corner_radius';return null;}
function normalizeRequirement(row={}){
 const text=String(row.text||'').trim(),match=text.match(/\b(?:shall|must)\s+(?:be|equal(?:\s+to)?)\s+(-?\d+(?:\.\d+)?)\s*(mm|cm|m|°|deg|n|nm|mpa|%|kg|g)\b/i),field=inferField(text);
 const constraint=match&&field?{field,comparator:'=',value:Number(match[1]),unit:match[2].replace(/^deg$/i,'°').replace(/^n$/i,'N').replace(/^nm$/i,'Nm').replace(/^mpa$/i,'MPa')} : null;
 return {...structuredClone(row),normalized_constraint:constraint,normalization_status:constraint?'NORMALIZED_DETERMINISTIC':'NO_DETERMINISTIC_CONSTRAINT',hard_gate:false,engineering_release:false};
}
function normalizeRequirements(rows=[]){return {requirements:rows.map(normalizeRequirement),normalizer_version:'DG-REQ-NORMALIZER-v1',hard_gate:false,engineering_release:false};}
module.exports={normalizeRequirement,normalizeRequirements};
