/* Geometry stays in local artifacts; model context receives metadata only. */
function projectContext(value) {
 if (Array.isArray(value)) return value.map(projectContext);
 if (!value || typeof value !== 'object') return value;
 return Object.fromEntries(Object.entries(value).map(([key,v]) => [key,
   key==='surface_measurements' && v ? require('./measurement_observation').summarize(v) : key==='display_mesh' && v ? {omitted:true,source_sha256:v.source_sha256,
     triangle_count:Array.isArray(v.positions)?v.positions.length/9:null,
     unit:v.unit,engineering_evidence:false} : projectContext(v)]));
}
module.exports={projectContext};
