class AdvisorService{
 constructor(manager,modelCaller){this.sm=manager;this.modelCaller=modelCaller;this.sessions=new Map();}
 async consult(projectId,question,mode='chat'){
 const p=this.sm.getProject(projectId);if(!p)throw Error('请先创建项目');if(typeof question!=='string'||!question.trim()||question.length>12000)throw Error('请输入1–12000字的设计问题');
 const previous=this.sessions.get(projectId)||[];
 const context={project_name:p.project_name,product:p.product,design_intent:p.memory?.design_intent||{},requirements:p.requirements,design:p.design,findings:p.last_review?.findings||[],next_actions:p.last_review?.workspace?.next_actions||[],decisions:(p.decisions||[]).slice(-5),history:previous.slice(-6)};
 const answer=await this.modelCaller({task:'design_advice',mode,question,context});
 if(typeof answer!=='string'||!answer.trim())throw Error('模型未返回可用建议');
 this.sessions.set(projectId,[...previous,{role:'user',content:question},{role:'assistant',content:answer.slice(0,12000)}].slice(-8));
 return {project_id:projectId,status:'ADVISORY_ONLY',text:answer,limits:'模型建议未经工程验证；不修改需求、尺寸、Issue 或 Gate。对话仅在本次桌面会话保留，重要取舍请保存为决策。'};
 }
}
module.exports=AdvisorService;
