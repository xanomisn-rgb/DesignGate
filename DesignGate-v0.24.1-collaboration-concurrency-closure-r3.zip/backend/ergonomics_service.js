const {createCapabilityResult}=require('./capability_contract');

const GRAVITY_MPS2=9.81;
const required=['mass_kg','cog_offset_mm','grip_section_mm','target_population','posture','operation_force_n','duration_s'];
function missingInputs(input){return required.filter(key=>input[key]===undefined||input[key]===null||input[key]==='');}
function finitePositive(value){return Number.isFinite(value)&&value>0;}
function finiteNonNegative(value){return Number.isFinite(value)&&value>=0;}

class ErgonomicsService {
  assessGrip(input={},meta={}){
    const missing=missingInputs(input);
    if(missing.length) return createCapabilityResult({
      capability:'ergonomics.grip_assessment',status:'NOT_EVALUATED_MISSING_INPUT',method:'static_wrist_moment_screen',inputs:input,
      result:{missing_inputs:missing},confidence:0,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,
      limitations:['Supply the missing anthropometric, geometry, load and task inputs before screening.']
    });
    if(!finiteNonNegative(input.mass_kg)||!finiteNonNegative(input.cog_offset_mm)||!finiteNonNegative(input.operation_force_n)||!finitePositive(input.duration_s)||!input.grip_section_mm||!finitePositive(input.grip_section_mm.width)||!finitePositive(input.grip_section_mm.depth)||typeof input.posture!=='string'||!input.posture.trim()||!input.target_population||typeof input.target_population!=='object'||!Object.values(input.target_population).some(value=>typeof value==='string'&&value.trim())) throw Error('ergonomics inputs contain an invalid load, geometry, task or population record');
    const wristMoment=input.mass_kg*GRAVITY_MPS2*(input.cog_offset_mm/1000);
    return createCapabilityResult({
      capability:'ergonomics.grip_assessment',status:'EVALUATED',method:'static_wrist_moment_screen',inputs:input,
      result:{
        grip_compatibility:'REQUIRES_ANTHROPOMETRIC_REFERENCE',
        thumb_reach:'REQUIRES_REACH_ENVELOPE',
        static_wrist_moment_nm:Number(wristMoment.toFixed(3)),
        moment_torque_risk:'NOT_CLASSIFIED_NO_APPLICABLE_REFERENCE',
        operation_force_risk:'REQUIRES_TASK_FORCE_REFERENCE',
        posture_risk:'REQUIRES_POSTURE_OBSERVATION',
        fatigue_risk:'REQUIRES_PROTOTYPE_TEST'
      },confidence:0.55,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,
      limitations:['Formula: mass_kg × 9.81 m/s² × cog_offset_mm/1000. Static wrist-moment estimate only; it is not a full biomechanical or musculoskeletal analysis.','No moment-risk band is applied without an applicable, reviewed reference. Grip and reach classifications require an applicable anthropometric reference or prototype observation.','The calculation uses mass, declared moment arm and gravity; grip geometry, population, posture, operation force and duration are recorded inputs, not part of this scalar calculation.']
    });
  }
}
module.exports=ErgonomicsService;
