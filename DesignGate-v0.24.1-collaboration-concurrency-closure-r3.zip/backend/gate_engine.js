class GateEngine {
 evaluateGate(stage,findings=[],options={}) {
  const n=Number(String(stage).match(/Gate\s*([123])/i)?.[1]); if(!n) throw Error('评审阶段必须包含 Gate 1、Gate 2 或 Gate 3');
  const active=findings.filter(f=>!['RESOLVED'].includes(f.status));
  const metrics={critical:0,high:0,medium:0,low:0,unknown:0}; const blocking=[],warnings=[];
  for(const f of active){ if(['UNKNOWN','NEED_HUMAN_REVIEW'].includes(f.status)){metrics.unknown++; continue;} const s=f.severity.toLowerCase();if(s in metrics)metrics[s]++;if(['CRITICAL','HIGH'].includes(f.severity))blocking.push(`[${f.issue_id}] ${f.finding}`);else warnings.push(`[${f.issue_id}] ${f.finding}`); }
  const required=(options.checks||[]).filter(c=>c.required_for_gate<=n&&c.status!=='NOT_APPLICABLE');
  const incomplete=required.filter(c=>!['PASS','FAIL'].includes(c.status));
  const failedChecks=required.filter(c=>c.status==='FAIL');
  // A boolean supplied by a renderer never grants approval. Freezing is a separate hashed-snapshot operation.
  let decision=metrics.critical||metrics.high?'REVISE':incomplete.length||metrics.unknown?'HOLD':metrics.medium||metrics.low?'PASS_WITH_CONDITIONS':'PASS';
  if(!(options.checks||[]).length && !findings.length)decision='HOLD';
  if(failedChecks.length)decision='REVISE';
  const freezeRequested=options.isFreezeRequested||n===3;
  const eligible=n===3&&decision==='PASS'&&required.length>0&&required.every(c=>c.status==='PASS');
  return {gate_stage:stage,revision:options.revision||'A',decision,hard_gate_blocked:['REVISE','HOLD'].includes(decision),metrics,
   status_summary:decision==='PASS'?'本轮已执行检查通过；结论限于声明的规则覆盖范围。':decision==='REVISE'?'存在未解决的高风险问题，需修改后复核。':decision==='HOLD'?'必需资料、验证结果或复核检查尚未完成。':'存在建议处理项，可继续设计；尚不满足冻结条件。',
   blocking_issues:[...blocking,...incomplete.map(c=>`[${c.check_id}] ${c.reason||c.status}`)],warning_issues:warnings,
   freeze_status:freezeRequested?(eligible?'FREEZE_REQUEST_SUBMITTED':'FREEZE_REJECTED'):'NOT_REQUESTED',freeze_eligible:eligible};
 }
}
module.exports=GateEngine;
