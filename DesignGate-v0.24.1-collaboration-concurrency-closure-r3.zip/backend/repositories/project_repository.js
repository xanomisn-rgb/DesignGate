class ProjectRepository {
  getProject() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  listProjects() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  createProject() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  getCurrentVersion() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  getEntity() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  getEntityVersion() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  applyCommand() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  getHistory() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  getEvents() { throw new Error('REPOSITORY_METHOD_NOT_IMPLEMENTED'); }
  transaction(work) { return work(); }
}

module.exports = ProjectRepository;
