const ProjectRepository = require('./project_repository');
const ProjectStateManager = require('../project_state_manager');

function defaultProject(input = {}) {
  return {
    schema_version: '3.1',
    project_id: input.project_id,
    project_name: input.project_name || input.project_id,
    design: { active_revision: 'A' },
    gate: { current_stage: 'Gate 1', status: 'OPEN' },
    requirements: [],
    bom: [],
    findings: []
  };
}

class FileProjectRepository extends ProjectRepository {
  constructor({ directory, stateManager } = {}) {
    super();
    this.stateManager = stateManager || new ProjectStateManager(directory);
    this.projectsDir = this.stateManager.projectsDir;
  }

  getProject(projectId) { return this.stateManager.getProject(projectId); }
  listProjects() { return this.stateManager.listProjects(); }
  createProject(input) {
    if (this.getProject(input.project_id)) throw new Error('PROJECT_ALREADY_EXISTS');
    return this.stateManager.saveProject(defaultProject(input), 0);
  }
  saveProject(project, expectedVersion) { return this.stateManager.saveProject(project, expectedVersion); }
  getCurrentVersion(projectId) {
    const project = this.getProject(projectId);
    if (!project) throw new Error('PROJECT_NOT_FOUND');
    return project.version;
  }
  getEntity(projectId, entityType, entityId) {
    const project = this.getProject(projectId);
    if (!project) throw new Error('PROJECT_NOT_FOUND');
    const maps = { REQUIREMENT: ['requirements', 'req_id'], BOM_ITEM: ['bom', 'part_id'] };
    const descriptor = maps[entityType];
    if (!descriptor) throw new Error('ENTITY_TYPE_NOT_SUPPORTED');
    return project[descriptor[0]].find(row => row[descriptor[1]] === entityId) || null;
  }
  getEntityVersion(projectId, entityType, entityId) {
    const entity = this.getEntity(projectId, entityType, entityId);
    return entity?.version || 0;
  }
  getHistory(projectId) { return this.stateManager.history(projectId); }
  history(projectId) { return this.getHistory(projectId); }
  getEvents() { return []; }
  applyCommand() { throw new Error('SOLO_COMMAND_BUS_NOT_IMPLEMENTED'); }
}

module.exports = FileProjectRepository;
