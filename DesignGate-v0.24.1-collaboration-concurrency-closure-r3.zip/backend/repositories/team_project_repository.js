const ProjectRepository = require('./project_repository');
const CommandService = require('../collaboration/command_service');

function actorId(context = {}) {
  if (typeof context.actor_id !== 'string' || !context.actor_id) throw new Error('AUTH_REQUIRED');
  return context.actor_id;
}

class TeamProjectRepository extends ProjectRepository {
  constructor({ store, commandService } = {}) {
    super();
    if (!store) throw new Error('TEAM_STORE_REQUIRED');
    this.store = store;
    this.commandService = commandService || new CommandService({ store });
  }

  createProject(input, context) { return this.store.createProject(input, { user_id: actorId(context) }); }
  getProject(projectId, context) { return this.store.getProjectForActor(projectId, actorId(context)); }
  listProjects(context) {
    return this.store.listProjectIds(actorId(context)).map(project_id => this.getProject(project_id, context));
  }
  getCurrentVersion(projectId, context) { return this.getProject(projectId, context).version; }
  getEntity(projectId, entityType, entityId, context) {
    const project = this.getProject(projectId, context);
    const maps = { REQUIREMENT: ['requirements', 'req_id'], BOM_ITEM: ['bom', 'part_id'] };
    const descriptor = maps[entityType];
    if (!descriptor) throw new Error('ENTITY_TYPE_NOT_SUPPORTED');
    return project[descriptor[0]].find(row => row[descriptor[1]] === entityId) || null;
  }
  getEntityVersion(projectId, entityType, entityId, context) {
    this.getProject(projectId, context);
    return this.store.entityVersion(projectId, entityType, entityId);
  }
  applyCommand(command, context) { return this.commandService.execute(command, { user_id: actorId(context) }); }
  getHistory() { return []; }
  getEvents(projectId, options, context) {
    this.getProject(projectId, context);
    return this.store.listEvents(projectId, options);
  }
}

module.exports = TeamProjectRepository;
