const {sha256}=require('../crypto/canonical_json');
function normalized(value){return String(value??'').normalize('NFKC').toLowerCase().trim().replace(/\s+/g,' ');}
function buildRetrievalTrace({query,records=[],sources=[],quarantine=[],filters={}}={}){
 if(typeof query!=='string'||!query.trim())throw Error('retrieval trace requires query');
 const needle=normalized(query),matches=records.filter(record=>normalized(JSON.stringify(record)).includes(needle)).filter(record=>Object.entries(filters).every(([key,value])=>value===undefined||record[key]===value)).sort((a,b)=>String(a.knowledge_id||a.id).localeCompare(String(b.knowledge_id||b.id)));
 const returned=matches.map(record=>record.knowledge_id||record.id),sourceIds=[...new Set(matches.flatMap(record=>record.source_ids||[]))].sort();
 return {trace_id:`KTRACE-${sha256({query,filters,returned,sourceIds}).slice(0,20)}`,query,filters:structuredClone(filters),returned_knowledge_ids:returned,returned_source_ids:sourceIds,quarantine_excluded_ids:quarantine.map(row=>row.knowledge_id||row.id).filter(Boolean).sort(),ranking:'EXACT_NORMALIZED_CONTAINS_THEN_KNOWLEDGE_ID_ASC',normal_retrieval_excludes_quarantine:true,engineering_release:false};
}
module.exports={buildRetrievalTrace};
