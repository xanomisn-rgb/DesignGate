const {sha256}=require('../crypto/canonical_json');

const SCHEMA_VERSION='2.0';
const nullOrString=value=>value===null||typeof value==='string';
function assert(condition,message){if(!condition)throw Error(`knowledge v2 invalid: ${message}`);}
function validateClaim(claim,label='claim'){
 assert(claim&&typeof claim==='object'&&!Array.isArray(claim),`${label} object required`);
 assert(typeof claim.property==='string',`${label}.property required`);
 assert(Object.hasOwn(claim,'value'),`${label}.value required`);
 assert(nullOrString(claim.unit)&&nullOrString(claim.conditions)&&nullOrString(claim.test_method),`${label} unit/conditions/test_method invalid`);
}
function validateRecord(record){
 assert(record&&typeof record==='object'&&!Array.isArray(record),'record object required');
 assert(record.schema_version===SCHEMA_VERSION,'schema_version');
 for(const field of ['knowledge_id','domain','kind','title'])assert(typeof record[field]==='string'&&record[field].trim(),field);
 assert(record.entity&&typeof record.entity==='object','entity');
 for(const field of ['manufacturer','model','material_family'])assert(nullOrString(record.entity[field]),`entity.${field}`);
 validateClaim(record.claim);
 assert(Array.isArray(record.claims),'claims array');record.claims.forEach((claim,index)=>validateClaim(claim,`claims.${index}`));
 assert(Array.isArray(record.source_ids)&&record.source_ids.length&&record.source_ids.every(id=>typeof id==='string'&&id.trim()),'source_ids');
 assert(Array.isArray(record.limitations),'limitations');
 assert(record.engineering_release===false&&record.hard_gate===false,'release flags must be false');
 assert(record.review&&typeof record.review.review_status==='string','review status');
 return structuredClone(record);
}
function validateSource(source){
 assert(source&&typeof source==='object'&&!Array.isArray(source),'source object required');
 assert(source.schema_version===SCHEMA_VERSION,'source schema_version');
 for(const field of ['source_id','publisher','title','url','locator','checked_on'])assert(typeof source[field]==='string'&&source[field].trim(),`source ${field}`);
 assert(source.review&&typeof source.review.review_status==='string','source review status');
 return structuredClone(source);
}
function canonicalHash(value){return sha256(value);}
module.exports={SCHEMA_VERSION,validateClaim,validateRecord,validateSource,canonicalHash};
