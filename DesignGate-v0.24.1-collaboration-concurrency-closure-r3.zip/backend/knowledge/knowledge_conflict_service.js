const {canonicalHash}=require('./knowledge_schema_v2');
function normalized(value){return String(value??'').normalize('NFKC').trim().toLowerCase().replace(/\s+/g,' ');}
function claimsFor(record){return Array.isArray(record.claims)&&record.claims.length?record.claims:[record.claim].filter(Boolean);}
function claimIdentity(record,claim){if(!claim||typeof claim!=='object'||Array.isArray(claim)||!normalized(claim.property)||normalized(claim.property)==='statement')return null;return JSON.stringify({manufacturer:normalized(record.entity?.manufacturer||record.scope?.supplier),model:normalized(record.entity?.model||record.scope?.grade),material_family:normalized(record.entity?.material_family||record.scope?.material),property:normalized(claim.property),conditions:normalized(claim.conditions||claim.condition),test_method:normalized(claim.test_method||claim.method)});}
function conflict({type,recordIds,identity=null,details={}}){return {conflict_id:`KCON-${canonicalHash({type,recordIds:[...recordIds].sort(),identity,details}).slice(0,20)}`,conflict_type:type,status:type,resolution_status:'UNRESOLVED_REQUIRES_REVIEW',record_ids:[...recordIds].sort(),claim_identity:identity,details,hard_gate:false,engineering_release:false};}
function detectConflicts(records=[]){
 const out=[],seenIds=new Map(),claims=new Map();
 for(const record of records){const id=record.knowledge_id||record.id;if(!id)continue;const hash=canonicalHash(record),prior=seenIds.get(id);if(prior)out.push(conflict({type:prior.hash===hash?'SAME_RECORD_DUPLICATE':'IDENTITY_CONFLICT',recordIds:[prior.id,id],details:{canonical_hashes:[prior.hash,hash]}}));else seenIds.set(id,{id,hash});
  for(const claim of claimsFor(record)){const identity=claimIdentity(record,claim);if(!identity)continue;const valueHash=canonicalHash({value:claim?.value,unit:claim?.unit||null});const priorClaim=claims.get(identity);if(priorClaim&&priorClaim.valueHash!==valueHash)out.push(conflict({type:'SOURCE_CONFLICT',recordIds:[priorClaim.id,id],identity,details:{prior_value:priorClaim.value,current_value:claim?.value}}));else if(!priorClaim)claims.set(identity,{id,valueHash,value:claim?.value});}
 }
 return out.sort((a,b)=>a.conflict_id.localeCompare(b.conflict_id));
}
module.exports={detectConflicts,claimIdentity};
