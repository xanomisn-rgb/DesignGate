const crypto = require('crypto');
const NUMBERS = ['nominalWall','localMaxWall','ribThickness','draftAngle','sheetThickness','bendRadius','insideRadius','internalCornerRadius','cavityDepthInches','textureDepthMm','targetCost','annualVolume','weightG','cogOffsetMm','operationForceN','operationDurationS','glossMeasurementAngleDeg'];
const FLAGS = ['hasUndercut','hasSharpInsideCorners','toolingStrategySpecified','gateLocationSpecified','partingLineSpecified','hasTexture'];
const TEXT = ['manufacturingSupplier','textureCode','process','material','assembly','dimensions','batteryAttachment','finish','color','gloss','durability','unit','envelopeDimensions','gripSection','cogCoordinatesMm','cogReference','gripPosture','targetPopulation','populationSource','materialFamily','materialGrade','substrate','useEnvironment','cmfCompatibilityEvidence','cmfSamplePlan','cmfDurabilityPlan','cmfKnowledgeStatus','cmfSource','cmfSourceVersion','cmfApplicability','cmfUnits','cmfExceptions','fastenerType','serviceTool','servicePart','serviceAccess','disassemblySteps','irreversibleJoints','assemblyServiceConflicts'];
const STATUSES = ['OPEN','UNRESOLVED','NEED_HUMAN_REVIEW','UNKNOWN','RESOLVED','ACCEPTED_RISK','NEW_ISSUE'];
function stable(v) { if(Array.isArray(v)) return v.map(stable); if(v && typeof v==='object') return Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])); return v; }
function hash(v) { return crypto.createHash('sha256').update(JSON.stringify(stable(v))).digest('hex'); }
function id(v,kind='project') { if(typeof v!=='string' || !(kind==='project'?/^DG-[A-Za-z0-9_-]{1,80}$/:/^[A-Za-z0-9_-]{1,40}$/).test(v)) throw Error('无效的 '+kind+' 标识'); return v; }
function design(input={}) {
 if(!input || typeof input!=='object' || Array.isArray(input)) throw Error('designParams 必须为对象');
 const out={};
 for(const k of NUMBERS) if(Object.hasOwn(input,k)) { const v=input[k]; if(v===null || v==='') out[k]=null; else { if(typeof v!=='number'||!Number.isFinite(v)||v<0||(['nominalWall','localMaxWall','sheetThickness','annualVolume'].includes(k)&&v===0)) throw Error(k+' 必须为有效工程数值'); out[k]=v; } }
 for(const k of FLAGS) if(Object.hasOwn(input,k)) { if(input[k]!==null&&typeof input[k]!=='boolean') throw Error(k+' 必须为布尔值或 null'); out[k]=input[k]; }
 for(const k of TEXT) if(Object.hasOwn(input,k)) {if(input[k]!==null&&typeof input[k]!=='string') throw Error(k+' 必须为文本'); out[k]=input[k]?.trim()||null;}
 if(out.dimensions&&!Object.hasOwn(input,'envelopeDimensions')&&!Object.hasOwn(input,'gripSection')){out.envelopeDimensions=out.dimensions;out.gripSection=null;out.ergonomicsMigration='LEGACY_ENVELOPE_ONLY';}
 if(out.unit && out.unit!=='mm') throw Error('结构化尺寸统一使用 mm，请先换算；CAD 原始单位另行指定');
 return out;
}
function requirements(rows=[]) { if(!Array.isArray(rows)||rows.length>300) throw Error('需求必须为数组，最多300条'); const seen=new Set(); return rows.map(r=>{if(!r.req_id||r.req_id.startsWith('SYS-')||!r.text||typeof r.text!=='string'||seen.has(r.req_id))throw Error('需求需要唯一 req_id 和 text'); seen.add(r.req_id);return {...r,priority:r.priority||'MEDIUM',verification_method:r.verification_method||null,acceptance_criteria:r.acceptance_criteria||null};}); }
function bom(rows=[]) { if(!Array.isArray(rows)||rows.length>2000)throw Error('BOM 必须为数组，最多2000个零件');const seen=new Set();return rows.map(r=>{if(!r||typeof r.part_id!=='string'||!r.part_id.trim()||seen.has(r.part_id)||typeof r.part_name!=='string'||!r.part_name.trim())throw Error('BOM 需要唯一零件编号及名称');seen.add(r.part_id);for(const k of ['quantity','unit_cost'])if(r[k]!=null&&(!Number.isFinite(r[k])||r[k]<0||(k==='quantity'&&r[k]===0)))throw Error('BOM '+k+' 数值无效');return {...r};}); }
function finding(f) { for(const k of ['issue_id','agent_id','category','finding','severity','record_type','evidence_refs','impact','recommendation','confidence','status']) if(f[k]===undefined||f[k]===null) throw Error('Finding 缺少 '+k); if(!['CRITICAL','HIGH','MEDIUM','LOW','INFO'].includes(f.severity)||!STATUSES.includes(f.status)||!Array.isArray(f.evidence_refs)||!Number.isFinite(f.confidence)||f.confidence<0||f.confidence>1) throw Error('Finding 契约无效: '+f.issue_id); return true; }
function gap(id,text,extra={}) { return {issue_id:id,agent_id:'SYSTEM',category:'Verification',finding:text,severity:'INFO',record_type:'DATA_GAP',evidence_refs:[],impact:'当前资料不足，无法完成对应检查。',recommendation:'补齐相关资料并重新送审。',confidence:1,status:'NEED_HUMAN_REVIEW',...extra}; }
module.exports={NUMBERS,FLAGS,TEXT,hash,id,design,requirements,bom,finding,gap};
