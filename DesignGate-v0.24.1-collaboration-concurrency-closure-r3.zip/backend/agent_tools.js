const fs = require('fs');
const path = require('path');
const {Worker} = require('worker_threads');
const C = require('./contracts');
const Check = require('./check_engine');
const Workspace = require('./design_workspace');
const Knowledge = require('./knowledge_service');
const {projectContext}=require('./context_projection');
let knowledge;
const kb = () => knowledge ||= new Knowledge();

const text = (maxLength=3000) => ({type:'string',minLength:1,maxLength});
const object = (properties,required=Object.keys(properties)) => ({type:'object',properties,required,additionalProperties:false});
const enumeration = values => ({type:'string',enum:values});
const array = (items,maxItems=20,minItems=0) => ({type:'array',items,minItems,maxItems});
const designProperties = Object.fromEntries([
  ...C.NUMBERS.map(k=>[k,{type:['number','null'],minimum:0}]),
  ...C.FLAGS.map(k=>[k,{type:['boolean','null']}]),
  ...C.TEXT.map(k=>[k,{type:['string','null'],maxLength:1000}])
]);
const designSchema = object(designProperties,[]);
const reqSchema=object({req_id:text(60),text:text(),verification_method:text(1000),acceptance_criteria:text(1000)});
const intentSchema=object({target_price_max:{type:['number','null'],minimum:0},currency:text(12),audience:text(500),aesthetic:text(500),tooling_budget:text(500),forbid_sliders:{type:['boolean','null']},priorities:array(text(250),10)},[]);
const bomPatchSchema=object({part_id:text(80),spec:object({material_specified:text(300),finish:text(300),process:text(300)},[])});
const specs = [
  ['prepare_engineering_assets','只读准备工程记录包目录和校验摘要；不保存文件、不签核、不导出报价估计。实际下载由用户在桌面端确认。',object({})],
  ['update_plan','设定或根据已执行工具结果修订3至5步短计划，只记录行动摘要，不记录隐藏思维过程。',object({steps:array(text(250),5,3),reason:text(500)})],
  ['read_project','读取当前项目的已保存需求、设计、BOM和证据目录；数据均有来源边界。',object({})],
  ['inspect_requirements','检查需求是否缺少验证方法或通过判据，输出实际REQ-ID。',object({})],
  ['screen_design','对已保存设计或假设参数执行确定性规则筛查。只读试算；不修改正式Gate、Issue或测试结论。',object({patch:designSchema},[])],
  ['compare_options','比较2至4个假设设计修改的规则缺陷/未知项，不能据此代替设计师选择。',object({options:array(object({name:text(100),patch:designSchema}),4,2)})],
  ['negotiate_tradeoff','针对真实工具观察中的设计/制造冲突，发起 A03→A02→A06 一轮角色协商。比较2至3个候选、保留分歧与验证计划；每角色至多2次权限受限的工具调用，共消耗3至9次额外模型请求，计入任务总预算，不修改项目。',object({topic:text(1200),evidence_ids:array(text(80),6,1),options:array(object({name:text(100),patch:designSchema}),3,2)})],
  ['check_bom_cost','用已保存BOM真实报价计算成本与缺口，不自动估价。',object({})],
  ['search_knowledge','检索带来源且受治理的知识卡。可按种类、领域、制造商和精确型号过滤；标准索引、典型物性和制造服务商建议不会直接形成 Gate 结论。',object({query:text(300),process:text(80),material:text(80),kind:text(80),domain:text(80),manufacturer:text(120),exact_model:text(160)},['query'])],
  ['read_knowledge','按知识编号读取完整建议、适用条件、物性测试条件、原厂链接及核对日期。不能据此工程放行。',object({record_id:text(80)})],
  ['check_knowledge_reference','核对给定值是否落在供应商建议范围内。context 必须来自用户或明确标注的假设，缺少条件将返回 NEED_CONTEXT。只读，不影响正式 Gate。',object({record_id:text(80),value:{type:'number',minimum:0},unit:text(30),context:object({process:text(80),material:text(80),supplier:text(80),texture:text(80)},[])})],
  ['calculate_battery_pack','使用已登记的精确电芯型号，确定性计算串并联标称 V/Ah/Wh。缺少制造商、精确型号或任一系统电流限制时明确返回 DATA_GAP/理论电芯上限；不写入项目、不产生 PASS。',object({manufacturer:text(120),exact_model:text(160),ns:{type:'number',minimum:1},np:{type:'number',minimum:1},bms_limit_a:{type:['number','null'],minimum:0},busbar_limit_a:{type:['number','null'],minimum:0},wire_limit_a:{type:['number','null'],minimum:0},connector_limit_a:{type:['number','null'],minimum:0},fuse_limit_a:{type:['number','null'],minimum:0},thermal_limit_a:{type:['number','null'],minimum:0},average_battery_side_power_w:{type:['number','null'],minimum:0}},['manufacturer','exact_model','ns','np'])],
  ['read_selected_file','仅解析用户在本次任务开始前已选择的文件。提取结果不自动覆盖项目。CAD单位和开模方向由用户选择。',object({kind:enumeration(['briefFile','designFile','bomFile','cadFile'])})],
  ['list_cad_references','列出当前 project/revision/source 下真实存在且来源一致的 CAD 测量引用句柄。无有效测量时返回明确前置动作；不要猜面号或哈希。',object({})],
  ['show_cad_reference','用 list_cad_references 返回的不透明句柄定位当前版本的 CAD 测量对象。几何、Revision 或项目版本变化后旧句柄失效。',object({handle:text(80)})],
  ['show_reference','定位项目 BOM、字段、文件或来源一致的已保存 CAD 面。cad_face 的 id 为面编号字符串，必须传实际 source_sha256；不能虚构 Finding 与几何的关联。',object({kind:enumeration(['bom','design','file','cad_face']),id:text(100),source_sha256:text(64)},['kind','id'])],
  ['propose_change','原子变更提案：设计参数、完整需求、指定 BOM 零件规格、长期设计意图。只能经用户批准后写入；BOM 规格变更会作废该零件原报价。不能自动接受实测结果。',object({title:text(160),reason:text(3000),assumptions:array(text(500)),design_patch:designSchema,requirements:array(reqSchema,100),bom_patches:array(bomPatchSchema,30),design_intent:intentSchema},['title','reason','assumptions'])],
  ['ask_user','缺少关键输入时提出一个具体问题并暂停。用户回答后继续此任务。',object({question:text(1500)})],
  ['finish_task','结束当前分析任务，按 claim 和 unknown 结构引用成功工具观察ID。完成任务不代表工程放行；不可捏造测试通过。',object({
    summary:text(12000),
    claims:array(object({claim_id:text(80),claim_type:text(80),text:text(1500),status:enumeration(['SUPPORTED','PARTIALLY_SUPPORTED','UNKNOWN']),evidence_ids:array(text(80),20,0),confidence:enumeration(['HIGH','MEDIUM','LOW'])}),40,0),
    unknowns:array(object({unknown_id:text(80),reason:text(1000),blocking:{type:'boolean'}}),40,0),
    decision:enumeration(['ANALYSIS_COMPLETE','BLOCKED_NEEDS_INPUT','BLOCKED_NEEDS_EVIDENCE','REVISION_RECOMMENDED','READY_FOR_HUMAN_REVIEW']),
    evidence_ids:array(text(80),20,1),limitations:array(text(500),12,1)
  },['summary','evidence_ids','limitations'])]
];

function validate(value,schema,label='参数') {
  const types=Array.isArray(schema.type)?schema.type:[schema.type];
  const type=value===null?'null':Array.isArray(value)?'array':typeof value;
  if(!types.includes(type)||type==='number'&&!Number.isFinite(value))throw Error(label+' 类型错误');
  if(schema.enum&&!schema.enum.includes(value))throw Error(label+' 不在允许范围');
  if(type==='string'&&(value.trim().length<(schema.minLength||0)||value.length>(schema.maxLength||Infinity)))throw Error(label+' 长度无效');
  if(type==='number'&&value<(schema.minimum??-Infinity))throw Error(label+' 数值无效');
  if(type==='object'){
    for(const key of schema.required||[])if(!Object.hasOwn(value,key))throw Error(label+' 缺少 '+key);
    for(const key of Object.keys(value)){if(!Object.hasOwn(schema.properties,key))throw Error('禁止参数 '+key);validate(value[key],schema.properties[key],label+'.'+key);}
  }
  if(type==='array'){
    if(value.length<(schema.minItems||0)||value.length>(schema.maxItems||Infinity))throw Error(label+' 数量无效');
    value.forEach((v,i)=>validate(v,schema.items,label+'['+i+']'));
  }
  return value;
}
function toolSpec(name){const s=specs.find(s=>s[0]===name);if(!s)throw Error('工具不在允许列表：'+name);return s;}
function validateCall(name,args){return validate(args,toolSpec(name)[2]);}
function schemas(context=null){
  let visible=specs;
  if(context){
    const hasFiles=Object.keys(context.files||{}).length>0;
    const hasCadHandles=context.project&&cadReferences(context.project).status==='READY';
    visible=specs.filter(([name])=>(name!=='read_selected_file'||hasFiles)&&(name!=='show_cad_reference'||hasCadHandles));
  }
  return visible.map(([name,description,parameters])=>({type:'function',function:{name,description,parameters}}));
}

function cadReferences(project){
  const g=project.design?.cad_geometry,source=g?.source_sha256,revision=project.design?.active_revision||null;
  if(!source)return {status:'CAD_MEASUREMENT_REQUIRED',references:[],reason:'当前项目没有来源绑定的 CAD 几何；请先选择并导入 CAD。'};
  const m=g.surface_measurements;
  if(!m)return {status:'CAD_MEASUREMENT_REQUIRED',references:[],source_sha256:source,revision,reason:'当前几何没有可引用的表面测量；请先对当前 Revision 运行 CAD 测量。'};
  const measuredRevision=m.measurement_revision||g.measurement_revision||null;
  if(m.source_sha256!==source||measuredRevision&&revision&&measuredRevision!==revision)return {status:'CAD_MEASUREMENT_STALE',references:[],source_sha256:source,revision,measurement_source_sha256:m.source_sha256||null,measurement_revision:measuredRevision,reason:'已有测量不属于当前几何或 Revision；必须重新测量。'};
  const meshFaces=new Set(g.display_mesh?.source_sha256===source?(g.display_mesh.face_ids||[]).map(Number):[]);
  const measuredFaces=[...new Set((m.samples||[]).map(s=>Number(s?.face_id)).filter(id=>Number.isInteger(id)&&id>0&&meshFaces.has(id)))];
  const observationId=typeof m.observation_id==='string'?m.observation_id:null;
  const references=measuredFaces.map(faceId=>{
    const binding={kind:'cad_face',face_id:faceId,source_sha256:source,project_id:project.project_id,project_version:project.version,revision,observation_id:observationId};
    return {handle:'CADREF-'+C.hash(binding).slice(0,24),...binding,observation_id_status:observationId?'BOUND':'MISSING'};
  });
  return {status:references.length?'READY':'CAD_MEASUREMENT_REQUIRED',references,source_sha256:source,revision,reason:references.length?null:'当前测量没有与显示网格共同绑定的可引用面；请重新测量当前几何。'};
}

function screen(project,patch={}){
  const p=structuredClone(project), hypothetical=Object.keys(patch).length>0;
  p.design={...p.design,...C.design(patch)};
  // Existing attestations never carry over into a model-generated hypothetical design.
  if(hypothetical){p.verifications=[];p.basis_hash=null;}
  const r=new Check().evaluate(p);
  return {scope:hypothetical?'HYPOTHETICAL_RULE_SCREENING':'SAVED_DESIGN_RULE_SCREENING',project_version:project.version,patch,
    geometry_observation:require('./measurement_observation').observation(project.design.cad_geometry,hypothetical),
    checks:r.checks,findings:r.findings,counts:{failed:r.checks.filter(c=>c.status==='FAIL').length,unknown:r.checks.filter(c=>!['PASS','FAIL','NOT_APPLICABLE'].includes(c.status)).length},
    formal_gate_unchanged:true,rule_authority:'GOVERNED_DATA_RULES',limitations:['单零件有限规则筛查，不是整机结论。','假设参数不构成实测值。','screen_design 与 check_knowledge_reference 共用条件参考。无可靠来源的旧阈值已停用，未知项需补齐依据或人工制造复核。']};
}
function parseSelected(files,kind,cadOptions,signal){
  if(!files[kind])throw Error('该类文件未由用户选入本次任务，请先选择文件再开始新任务');
  return new Promise((resolve,reject)=>{
    const worker=new Worker(path.join(__dirname,'agent_file_worker.js'),{workerData:{files:{[kind]:files[kind]},cadOptions}});
    let settled=false;
    const done=(err,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);worker.terminate();err?reject(err):resolve(value);};
    const abort=()=>done(Error('任务已停止'));
    const timer=setTimeout(()=>done(Error('文件解析超过35秒')),35000);
    signal?.addEventListener('abort',abort,{once:true});
    if(signal?.aborted)return abort();
    worker.once('message',m=>m.error?done(Error(m.error)):done(null,m.result));
    worker.once('error',e=>done(e));
    worker.once('exit',()=>{if(!settled)done(Error('文件解析进程提前退出'));});
  });
}
async function execute(name,args,{project,files={},cadOptions={},signal}){
  validateCall(name,args);
  if(name==='prepare_engineering_assets'){
    const files=require('./engineering_assets').buildAssets(project,[],project.version);
    return {status:'PREPARED_NOT_SAVED',manifest:JSON.parse(files['MANIFEST.json']),tasks_included:0,engineering_release:false};
  }
  if(name==='read_project')return projectContext({project_id:project.project_id,version:project.version,revision:project.design?.active_revision,product:project.product,design:project.design,requirements:project.requirements,bom:project.bom,design_intent:project.memory?.design_intent||{},design_intent_provenance:project.memory?.design_intent_provenance||{},findings:project.findings,evidence:project.evidence,verifications:project.verifications,decisions:(project.decisions||[]).slice(-5),field_provenance:project.field_provenance,authority:'SAVED_PROJECT_DATA_NOT_INDEPENDENTLY_VERIFIED'});
  if(name==='inspect_requirements')return {requirements:(project.requirements||[]).map(r=>({req_id:r.req_id,text:r.text,missing:['verification_method','acceptance_criteria'].filter(k=>!r[k]?.trim())})),baseline_missing:!project.requirements?.length};
  if(name==='screen_design')return screen(project,args.patch||{});
  if(name==='compare_options')return {options:args.options.map(o=>({name:o.name,...screen(project,o.patch)})),selection:'NOT_SELECTED',limitations:'这里只比较现有规则；成本、外观、体验仍需真实资料与用户权衡。'};
  if(name==='check_bom_cost')return Workspace.cost(project.bom||[]);
  if(name==='search_knowledge')return kb().search(args.query,args);
  if(name==='read_knowledge')return kb().get(args.record_id);
  if(name==='check_knowledge_reference')return kb().check(args.record_id,args.value,args.unit,args.context);
  if(name==='calculate_battery_pack')return kb().calculateBatteryPack(args);
  if(name==='read_selected_file')return parseSelected(files,args.kind,cadOptions,signal);
  if(name==='list_cad_references')return cadReferences(project);
  if(name==='show_cad_reference'){
    const listed=cadReferences(project),reference=listed.references.find(x=>x.handle===args.handle);
    if(!reference)throw Error(listed.status==='READY'?'CAD_REFERENCE_HANDLE_INVALID_OR_STALE':listed.status+': '+listed.reason);
    return {reference,scope:'CURRENT_REVISION_MEASURED_OBJECT',engineering_release:false};
  }
  if(name==='show_reference'){
    if(args.kind==='cad_face'){
      const g=project.design.cad_geometry,id=Number(args.id);
      if(!Number.isInteger(id)||id<1||!g?.source_sha256||args.source_sha256!==g.source_sha256||g.display_mesh?.source_sha256!==g.source_sha256||g.surface_measurements?.source_sha256!==g.source_sha256||!g.display_mesh.face_ids?.includes(id)||!g.surface_measurements.samples?.some(s=>s.face_id===id))throw Error('CAD_FACE_SOURCE_MISMATCH_OR_UNKNOWN');
    }
    if(args.kind==='bom'&&!project.bom?.some(p=>p.part_id===args.id))throw Error('零件不存在');
    if(args.kind==='design'&&![...C.NUMBERS,...C.FLAGS,...C.TEXT].includes(args.id))throw Error('字段不在允许列表');
    if(args.kind==='file'&&(!['briefFile','designFile','bomFile','cadFile'].includes(args.id)||!files[args.id]))throw Error('文件未选入本任务');
    return {reference:{...args,project_id:project.project_id,version:project.version},scope:'UI_LOCATION_ONLY'};
  }
  throw Error('该工具由运行控制器处理');
}
module.exports={schemas,validateCall,execute,screen,validate,cadReferences};
