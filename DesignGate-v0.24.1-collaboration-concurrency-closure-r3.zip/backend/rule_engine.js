const Knowledge=require('./knowledge_service');
function processKind(s=''){if(/钣金|sheet|折弯|冲压/i.test(s))return 'sheet';if(/压铸|die.?cast/i.test(s))return 'casting';if(/cnc|机加|切削/i.test(s))return 'cnc';if(/注塑|injection|overmold/i.test(s))return 'injection';return null;}
class RuleEngine {
 constructor(knowledge=new Knowledge()){this.knowledge=knowledge;}
 evaluateChecks(params={},processContext=null){
  const kind=processKind(processContext?.process||params.process||''),rules=this.knowledge.executionRules().filter(r=>r.process===kind);
  const context={process:kind==='injection'?'injection_molding':params.process,material:params.material,supplier:params.manufacturingSupplier,texture:params.textureCode};
  const groups=new Map();for(const r of rules){if(r.status==='SUSPENDED_UNVERIFIED'&&kind==='injection')continue;if(!groups.has(r.check))groups.set(r.check,[]);groups.get(r.check).push(r);}
  return [...groups].map(([name,entries])=>{
   const base={check_id:'DFM-'+kind+'-'+name,required_for_gate:2,issue_ids:[...new Set(entries.map(r=>r.issue_id)),'DG-CHECK-'+kind+'-'+name],input_fields:[...new Set(entries.flatMap(r=>r.fields).concat(['process','material','manufacturingSupplier','textureCode']))],rule_version:this.knowledge.data.release,engineering_release:false};
   const outputs=entries.map(r=>{
    if(r.status==='SUSPENDED_UNVERIFIED')return {rule_id:r.id,status:'UNKNOWN',reason:r.reason,source_ids:[],review:r.review};
    if(r.status==='PROJECT_DECLARATION_CHECK'){
     if(r.fields.some(k=>typeof params[k]!=='boolean'))return {rule_id:r.id,status:'UNKNOWN',reason:'缺少布尔声明：'+r.fields.filter(k=>typeof params[k]!=='boolean').join('、'),review:r.review};
     const failed=r.requires_true?r.fields.some(k=>!params[k]):Object.entries(r.fail_if).every(([k,v])=>params[k]===v);
     return {rule_id:r.id,status:failed?(r.requires_true?'UNKNOWN':'FAIL'):'PASS',reason:r.reason,review:r.review};
    }
    const input=r.input;
    const value=input.op==='field'?params[input.field]:Number.isFinite(params[input.numerator])&&Number.isFinite(params[input.denominator])&&params[input.denominator]>0?params[input.numerator]/params[input.denominator]:null;
    if(!Number.isFinite(value)||value<0)return {rule_id:r.id,status:'UNKNOWN',reason:'缺少或无效量值：'+r.fields.join('、'),reference:r.reference,source_ids:r.source_ids,review:r.review};
    const result=this.knowledge.check(r.record_id,value,r.unit,context);
    return {...result,reference_status:result.status,status:result.status==='WITHIN_REFERENCE'?'PASS':result.status==='OUTSIDE_REFERENCE'?'FAIL':result.status==='NOT_APPLICABLE'?'NOT_APPLICABLE':'UNKNOWN',reason:result.interpretation||'参考适用条件未齐备',required_context:this.knowledge.get(r.record_id).scope};
   });
   const applicable=outputs.filter(o=>o.status!=='NOT_APPLICABLE'),fail=applicable.find(o=>o.status==='FAIL'),unknown=applicable.find(o=>o.status==='UNKNOWN');
   const status=fail?'FAIL':!applicable.length||unknown?'UNKNOWN':'PASS';
   const selected=fail||unknown||applicable[0]||outputs[0];
   const rule=entries.find(r=>r.id===selected?.rule_id)||entries[0];
   return {...base,status,reason:!applicable.length?'没有与材料、供应商或纹理匹配的已核验参考。':selected.reason,rule_results:outputs,
    finding:status==='PASS'?null:{issue_id:status==='FAIL'?rule.issue_id:'DG-CHECK-'+kind+'-'+name,agent_id:'A03',category:'DFM',finding:status==='FAIL'?rule.id+'：输入超出所选参考或声明存在待处理风险。':name+'：'+(!applicable.length?'适用参考未匹配':selected.reason),severity:status==='FAIL'?rule.severity:'INFO',record_type:status==='FAIL'?'DERIVED_RULE':'DATA_GAP',rule_type:rule.status,evidence_refs:rule.source_ids||[],source_ids:rule.source_ids||[],record_id:rule.record_id||null,review:rule.review,rule_revision:rule.revision,impact:'需要在明确适用条件下复核；不代表实物已经失效或通过。',recommendation:'补齐供应商条件、几何或实测验证，不能仅通过修改表单宣称量产可行。',confidence:1,confidence_scope:'RULE_EXECUTION_NOT_ENGINEERING_CERTAINTY',status:status==='FAIL'?'OPEN':'NEED_HUMAN_REVIEW'}
   };
  });
 }
 evaluateGeometry(params={},processContext=null){return this.evaluateChecks(params,processContext).flatMap(c=>c.finding?[c.finding]:[]);}
}
module.exports=RuleEngine;module.exports.processKind=processKind;
