const Knowledge=require('./knowledge_service');
const {projectContext}=require('./context_projection');
const policies={
 A03:{fields:['process','material','nominalWall','localMaxWall','ribThickness','draftAngle','manufacturingSupplier','cad_geometry'],kinds:['material','process_reference','battery_cell'],tools:['read_role_knowledge','screen_role_design','read_cad_summary','measure_selected_cad']},
 A02:{fields:['material','finish','color','gloss','dimensions','assembly'],kinds:['material','ergonomics_reference','standard_index'],tools:['read_role_knowledge']},
 A05:{fields:['active_revision','material','process'],kinds:['method_reference','standard_index','battery_cell'],tools:['read_role_knowledge','read_evidence_ledger']},
 A06:{fields:['active_revision'],kinds:[],tools:['read_evidence_ledger']}
};
function policy(role){if(!Object.hasOwn(policies,role))throw Error('Unknown specialist role');return policies[role];}
function context(role,project,observations,memory=[]){
 const p=policy(role),kb=new Knowledge();
 return {project:{project_id:project.project_id,version:project.version,design:Object.fromEntries(p.fields.filter(k=>k in project.design).map(k=>[k,projectContext(project.design[k])])),requirements:project.requirements},
   knowledge_index:kb.records.filter(r=>p.kinds.includes(r.kind)).map(r=>({id:r.id,title:r.title,kind:r.kind})),
   observations:observations.map(o=>({id:o.id,tool:o.tool,output:role==='A03'?projectContext(o.output):{scope:'SUMMARY_ONLY',findings:o.output?.findings,counts:o.output?.counts,authority:'PARENT_OBSERVATION_NOT_EXPERT_VALIDATION'}})),
   role_memory:memory.filter(m=>m.role===role).slice(-3).map(projectContext)};
}
function schemas(role){
 const obj=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
 const definitions={read_role_knowledge:obj({record_id:{type:'string',minLength:1,maxLength:80}}),screen_role_design:obj({option_name:{type:'string',minLength:1,maxLength:100}}),read_cad_summary:obj({}),measure_selected_cad:obj({}),read_evidence_ledger:obj({})};
 return policy(role).tools.map(name=>({type:'function',function:{name,description:'Read-only role-scoped '+name,parameters:definitions[name]}}));
}
function execute(role,name,args,{project,candidates,validate,measureSelectedCAD}){
 const p=policy(role),tool=schemas(role).find(t=>t.function.name===name);
 if(!tool)throw Error('ROLE_TOOL_DENIED: '+role+' / '+name);
 validate(args,tool.function.parameters);
 if(name==='measure_selected_cad'){
   if(typeof measureSelectedCAD!=='function')throw Error('CAD_MEASUREMENT_UNAVAILABLE');
   return Promise.resolve(measureSelectedCAD()).then(result=>projectContext({scope:'FRESH_SELECTED_FILE_INTAKE_NOT_PROJECT_MUTATION',result}));
 }
 if(name==='read_role_knowledge'){
   const record=new Knowledge().get(args.record_id);
   if(!p.kinds.includes(record.kind))throw Error('ROLE_KNOWLEDGE_DENIED');
   return record;
 }
 if(name==='screen_role_design'){
   const candidate=candidates.find(c=>c.name===args.option_name);if(!candidate)throw Error('Unknown candidate');
   return projectContext(candidate.screening);
 }
 if(name==='read_cad_summary')return {status:project.design.cad_geometry?'SAVED_GEOMETRY_ONLY':'CAD_NOT_PROVIDED',geometry:projectContext(project.design.cad_geometry||null),fresh_measurement:false};
 if(name==='read_evidence_ledger')return {checks:project.checks||[],evidence:project.evidence||[],verifications:project.verifications||[],authority:'LOCAL_RECORDS_NOT_REVERIFIED'};
 throw Error('ROLE_TOOL_DENIED');
}
module.exports={context,schemas,execute,policy};
