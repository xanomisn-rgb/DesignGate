const C=require('./contracts'),path=require('path');
const {projectContext}=require('./context_projection'),{runPython}=require('../tools/python_runner');
function snapshot(project,runs,expectedVersion){
 if(project.version!==expectedVersion)throw Error('VERSION_CONFLICT');
 const f=project.freeze,r=project.last_review;
 if(!f?.freeze_id||f.authority!=='LOCAL_DESKTOP_APPROVAL'||f.revision!==project.design.active_revision||f.review_id!==r?.review_id||!r?.gate?.freeze_eligible||!project.basis_hash||f.basis_hash!==project.basis_hash||r.basis_hash!==project.basis_hash)throw Error('LOCAL_GATE3_FREEZE_REQUIRED');
 if(runs.length>30||runs.some(r=>r.project_id!==project.project_id))throw Error('TASK_SCOPE_INVALID');
 const p=projectContext(project);
 // Full triangle/sample payloads do not belong in paginated design prose.
 if(p.design.cad_geometry)p.design.cad_geometry={status:p.design.cad_geometry.status,source_sha256:p.design.cad_geometry.source_sha256,wall_thickness:p.design.cad_geometry.wall_thickness,undercut_analysis:p.design.cad_geometry.undercut_analysis};
 const payload={project:p,project_sha256:C.hash(project),tasks:runs.map(({messages,files,cadOptions,callCounts,...r})=>projectContext(r))};
 if(Buffer.byteLength(JSON.stringify(payload))>4*1024*1024)throw Error('HANDOVER_SNAPSHOT_TOO_LARGE');
 return payload;
}
function create(payload){return Buffer.from(runPython(path.join(__dirname,'../tools/handover_package.py'),[],{input:JSON.stringify(payload)}).trim(),'base64');}
module.exports={snapshot,create};
