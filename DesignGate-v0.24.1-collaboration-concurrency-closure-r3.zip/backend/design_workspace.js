const C=require('./contracts');
class DesignWorkspace{
 static compare(input={}){
  const {criteria=[],alternatives=[]}=input;
  if(!criteria.length||!alternatives.length)return {status:'NEED_INPUT',ranking:[],reason:'填写评价维度、权重、备选方案与评分依据。'};
  if(new Set(criteria.map(c=>c.id)).size!==criteria.length||new Set(alternatives.map(a=>a.id)).size!==alternatives.length)throw Error('评价维度和方案 ID 必须唯一');
  if(criteria.some(c=>!c.id||!Number.isFinite(c.weight)||c.weight<=0))throw Error('评价权重必须为正数');
  const total=criteria.reduce((s,c)=>s+c.weight,0);
  const ranking=alternatives.map(a=>{const missing=[];let score=0;for(const c of criteria){const cell=a.scores?.[c.id];if(!cell||!Number.isFinite(cell.value)||cell.value<1||cell.value>5||!cell.reason){missing.push(c.id);continue;}score+=cell.value*c.weight/total;}return {id:a.id,name:a.name||a.id,eligible:a.constraints_status==='PASS',score:missing.length?null:Math.round(score*100)/100,missing,reason:a.constraints_status==='PASS'?'评分来自用户判断，建议结合样机验证':'硬约束未确认通过，暂不参与推荐'};});
  ranking.sort((a,b)=>Number(b.eligible)-Number(a.eligible)||(b.score??-1)-(a.score??-1));
  const complete=ranking.every(a=>a.score!==null);const first=ranking.find(a=>a.eligible&&a.score!==null);
  return {status:complete?'CALCULATED':'INCOMPLETE',method:'用户赋权的 1–5 分加权比较；非客观性能证明',ranking,recommended:complete?first?.id||null:null,weights:criteria.map(c=>({...c,normalized:c.weight/total}))};
 }
 static cost(bom=[]){const missing=[],currencies=new Set();let sum=0;for(const r of bom){if(!Number.isFinite(r.quantity)||r.quantity<=0||!Number.isFinite(r.unit_cost)||r.unit_cost<0||!r.currency||!r.quote_source){missing.push(r.part_id);continue;}currencies.add(r.currency);sum+=r.quantity*r.unit_cost;}return {status:!bom.length||missing.length?'INCOMPLETE':currencies.size>1?'MIXED_CURRENCIES':'CALCULATED',known_subtotal:currencies.size===1?Math.round(sum*100)/100:null,total:bom.length&&!missing.length&&currencies.size===1?Math.round(sum*100)/100:null,currency:currencies.size===1?[...currencies][0]:null,missing,scope:'仅含 BOM 已填报价；不含模具、运费、税费及报废率。'};}
 static build(p,checks,findings){const verification_plan=(p.requirements||[]).map(r=>({req_id:r.req_id,requirement:r.text,method:r.verification_method||'待定义',acceptance:r.acceptance_criteria||'待定义',result:checks.find(c=>c.check_id==='VERIFY-'+r.req_id)?.status||'UNKNOWN'}));verification_plan.push(...checks.filter(c=>c.check_id.startsWith('VERIFY-SYS-')).map(c=>({req_id:c.check_id.slice(7),requirement:c.reason,method:'人工/工具验证并登记证据',acceptance:'依据项目适用条件，由审批人复核',result:c.status})));return {profile:p.product||{},cost:this.cost(p.bom),decision_matrix:this.compare(p.decision_matrix),verification_plan,next_actions:checks.filter(c=>!['PASS','NOT_APPLICABLE'].includes(c.status)).slice(0,5).map(c=>({check_id:c.check_id,action:c.reason,status:c.status})),capability_profile:{requirements_defined:verification_plan.length,checks_executed:checks.filter(c=>['PASS','FAIL'].includes(c.status)).length,checks_pending:checks.filter(c=>!['PASS','FAIL','NOT_APPLICABLE'].includes(c.status)).length,decisions_recorded:(p.decisions||[]).length,grading_status:'NOT_GRADED',note:'过程指标供教师参考，不自动等同能力分或课程成绩。'}};}
}
module.exports=DesignWorkspace;
