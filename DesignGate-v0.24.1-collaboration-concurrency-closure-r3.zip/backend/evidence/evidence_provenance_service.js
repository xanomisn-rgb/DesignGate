const Manifest=require('./evidence_manifest');
const EvidenceManifestStore=require('./evidence_manifest_store');

function sourceStatus(input){
 if(!input.source_id)return 'INCOMPLETE';
 if(!input.source_kind||!input.project_id||!input.revision)return 'INCOMPLETE';
 return 'BOUND';
}
function integrityStatus(input){
 if(input.integrity_status==='INVALID'||input.integrity_verified===false)return 'INVALID';
 if(!input.file_sha256)return 'MISSING';
 return 'VERIFIED';
}
class EvidenceProvenanceService{
 constructor({directory,store}={}){this.store=store||new EvidenceManifestStore(directory||'.designgate-evidence-manifests');}
 createManifest(input={}){
  const manifest=Manifest.createManifest({...input,integrity_status:integrityStatus(input),provenance_status:sourceStatus(input)});
  const recorded=this.store.append(manifest);
  return {manifest,record_status:recorded.status,integrity_status:manifest.integrity_status,provenance_status:manifest.provenance_status};
 }
 verifyManifest(manifest){
  const result=Manifest.verifyManifest(manifest);
  return result.status==='VALID'?{...result,integrity_status:manifest.integrity_status,provenance_status:manifest.provenance_status}:{...result,integrity_status:'INVALID',provenance_status:'MISMATCH'};
 }
 getManifestForEvidence(evidenceId){return this.store.rows().filter(row=>row.evidence_id===evidenceId).at(-1)||null;}
 verifyEvidenceBinding(context={}){
  const manifest=this.getManifestForEvidence(context.evidence_id);
  if(!manifest)return {valid:false,integrity_status:'MISSING',provenance_status:'UNVERIFIED',reason_code:'EVIDENCE_MANIFEST_MISSING'};
  const integrity=this.verifyManifest(manifest);
  if(integrity.status!=='VALID'||manifest.integrity_status!=='VERIFIED')return {valid:false,manifest,...integrity,reason_code:'EVIDENCE_INTEGRITY_INVALID'};
  if(manifest.project_id!==context.project_id)return {valid:false,manifest,integrity_status:'VERIFIED',provenance_status:'MISMATCH',reason_code:'EVIDENCE_PROJECT_MISMATCH'};
  if(manifest.revision!==context.revision)return {valid:false,manifest,integrity_status:'VERIFIED',provenance_status:'STALE',reason_code:'EVIDENCE_REVISION_STALE'};
  if(context.verification_plan_id&&manifest.verification_plan_id!==context.verification_plan_id)return {valid:false,manifest,integrity_status:'VERIFIED',provenance_status:'STALE',reason_code:'EVIDENCE_PLAN_MISMATCH'};
  if(context.verification_plan_hash&&manifest.verification_plan_hash!==context.verification_plan_hash)return {valid:false,manifest,integrity_status:'VERIFIED',provenance_status:'STALE',reason_code:'EVIDENCE_PLAN_HASH_MISMATCH'};
  if(manifest.provenance_status!=='BOUND')return {valid:false,manifest,integrity_status:'VERIFIED',provenance_status:manifest.provenance_status,reason_code:'EVIDENCE_PROVENANCE_INCOMPLETE'};
  return {valid:true,manifest,integrity_status:'VERIFIED',provenance_status:'BOUND',reason_code:'EVIDENCE_CURRENT_BOUND'};
 }
 validateCurrentRevisionEvidence(context){return this.verifyEvidenceBinding(context);}
}
module.exports=EvidenceProvenanceService;
