const {sha256}=require('../crypto/canonical_json');
function entryFromEvidence(evidence={},revision){
 const current=evidence.revision===revision;
 return {evidence_id:evidence.evidence_id,source:evidence.source||'PROJECT_EVIDENCE_REGISTRY',source_version:evidence.source_version||evidence.revision||null,revision:evidence.revision||null,sha256:evidence.sha256||null,registered_at:evidence.registered_at||null,timestamp:evidence.timestamp||evidence.registered_at||null,verification_scope:evidence.verification_scope||'UNSPECIFIED',relation_to_claim:evidence.relation_to_claim||'NOT_REVIEWED_FOR_CLAIM',confidentiality:evidence.confidentiality||'PROJECT_INTERNAL',access_control:evidence.access_control||'PROJECT_ISOLATED',integrity_state:evidence.integrity_status||'UNVERIFIED',integrity_checked_at:evidence.integrity_checked_at||null,applicability:current?'CURRENT_REQUIRES_CLAIM_REVIEW':'HISTORICAL_PENDING_CARRY_FORWARD_REVIEW',current_valid_support:false,carry_forward_decision:null};
}
function createRevisionManifest({project_id,revision,evidence=[],prior_manifest=null}={}){
 if(typeof project_id!=='string'||!project_id||typeof revision!=='string'||!revision)throw Error('evidence manifest requires project_id and revision');
 const entries=(evidence.length?evidence.map(row=>entryFromEvidence(row,revision)):(prior_manifest?.entries||[]).map(row=>({...structuredClone(row),applicability:'HISTORICAL_PENDING_CARRY_FORWARD_REVIEW',current_valid_support:false,carry_forward_decision:null}))).sort((a,b)=>String(a.evidence_id).localeCompare(String(b.evidence_id)));
 const manifest={manifest_id:`EVMAN-${sha256({project_id,revision,entries}).slice(0,20)}`,project_id,revision,created_at:new Date().toISOString(),entries,authority:'EVIDENCE_MANIFEST_NOT_CLAIM_APPROVAL',engineering_release:false};
 manifest.manifest_hash=sha256({...manifest});return manifest;
}
function diffManifests(prior={},current={}){
 const old=new Map((prior.entries||[]).map(row=>[row.evidence_id,row])),now=new Map((current.entries||[]).map(row=>[row.evidence_id,row]));
 return {from_revision:prior.revision||null,to_revision:current.revision||null,added:[...now.keys()].filter(id=>!old.has(id)).sort(),removed:[...old.keys()].filter(id=>!now.has(id)).sort(),carry_forward_review_required:[...now.values()].filter(row=>row.applicability==='HISTORICAL_PENDING_CARRY_FORWARD_REVIEW').map(row=>row.evidence_id).sort(),current_valid_support:[],authority:'DIFF_DOES_NOT_AUTO_CARRY_EVIDENCE'};
}
module.exports={createRevisionManifest,diffManifests};
