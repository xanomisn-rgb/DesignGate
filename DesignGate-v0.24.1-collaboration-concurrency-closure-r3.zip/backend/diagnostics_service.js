const SERVICES=[['inagent','inAgent','INAGENT'],['moodle','Moodle','LMS'],['plm','Mini PLM','PLM']];
async function healthcheck({env=process.env,fetchImpl=globalThis.fetch,timeoutMs=5000}={}){
 const results=await Promise.all(SERVICES.map(async([id,label,prefix])=>{
   const base={id,label,business_integration_verified:false},raw=env[prefix+'_HEALTH_URL'];
   if(!raw)return {...base,status:env.DESIGNGATE_MODE==='production'?'CONTRACT_PENDING':'MOCK_READY',detail:'未配置专用只读健康端点；没有发出网络请求。'};
   let url;try{url=new URL(raw);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw Error();}catch{return {...base,status:'CONFIG_ERROR',detail:'健康端点须为无凭据、无查询参数的 HTTP(S) URL。'};}
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs),started=Date.now();
   try{
     // Only explicit health endpoints, no project data, credentials, writes or redirected requests.
     const response=await fetchImpl(url.href,{method:'GET',redirect:'error',signal:controller.signal,headers:{Accept:'application/json'}});
     const status=response.ok?'HTTP_REACHABLE':response.status===401||response.status===403?'AUTH_REQUIRED':'UNAVAILABLE';
     await response.body?.cancel();
     return {...base,status,http_status:response.status,latency_ms:Date.now()-started,detail:response.ok?'健康 URL 可达；尚未验证检索、课程或归档业务契约。':'健康请求未成功；检查端点或鉴权。'};
   }catch{return {...base,status:'UNAVAILABLE',detail:controller.signal.aborted?'健康检查超时。':'健康请求失败；未返回端点或服务端敏感信息。'};}
   finally{clearTimeout(timer);}
 }));
 return {checked_at:new Date().toISOString(),results,scope:'READ_ONLY_HEALTH_ENDPOINTS',business_integration_verified:false};
}
module.exports={healthcheck};
