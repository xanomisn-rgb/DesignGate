const TERMINAL=new Set(['FROZEN','FAILED_TERMINAL','CANCELLED']);
const ALLOWED={RECEIVED:['REQUIREMENTS_PENDING'],REQUIREMENTS_PENDING:['REQUIREMENTS_READY','FAILED_RECOVERABLE'],REQUIREMENTS_READY:['KNOWLEDGE_PENDING','ANALYSIS_PENDING'],KNOWLEDGE_PENDING:['ANALYSIS_PENDING','GATE_HOLD'],ANALYSIS_PENDING:['TRADEOFF_REQUIRED','REVISION_REQUIRED','VERIFICATION_PENDING','GATE_HOLD'],TRADEOFF_REQUIRED:['REVISION_REQUIRED','GATE_HOLD'],REVISION_REQUIRED:['ANALYSIS_PENDING','VERIFICATION_PENDING'],VERIFICATION_PENDING:['EVIDENCE_PENDING','GATE_HOLD'],EVIDENCE_PENDING:['GATE_HOLD','GATE_ELIGIBLE'],GATE_HOLD:['ANALYSIS_PENDING','REVISION_REQUIRED','VERIFICATION_PENDING'],GATE_ELIGIBLE:['HUMAN_APPROVAL_REQUIRED'],HUMAN_APPROVAL_REQUIRED:['FROZEN','GATE_HOLD'],FAILED_RECOVERABLE:['ANALYSIS_PENDING']};
const FORBIDDEN=new Set(['verification_status','dfmea_risk_status','residual_risk_accepted','gate_status','freeze','compliance_status']);
function error(code){const e=Error(code);e.code=code;return e;}
function transition({from,to,actor,gate_status=null}={}){if(TERMINAL.has(from)||!ALLOWED[from]?.includes(to)||to==='FROZEN'&&(actor!=='human'||from!=='HUMAN_APPROVAL_REQUIRED'||gate_status!=='ELIGIBLE'))throw error('INVALID_RUNTIME_TRANSITION');return {from,to,actor};}
function authoritativeMutation({actor,field,value}={}){
  const deterministic=new Set(['verification_status','dfmea_risk_status','gate_status','compliance_status']);
  if(field==='freeze')throw error('AUTHORITY_DENIED');
  if(deterministic.has(field)&&actor!=='deterministic_service')throw error('AUTHORITY_DENIED');
  if(field==='residual_risk_accepted'&&actor!=='human')throw error('AUTHORITY_DENIED');
  if(FORBIDDEN.has(field)&&!deterministic.has(field)&&field!=='residual_risk_accepted')throw error('AUTHORITY_DENIED');
  return {field,value,actor};
}
module.exports={transition,authoritativeMutation,ALLOWED};
