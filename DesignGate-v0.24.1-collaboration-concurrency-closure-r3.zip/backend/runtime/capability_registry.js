const SEED=[
  ['TASK_INTAKE','READ'],['REQ_PARSE','PROPOSE'],['REQ_TESTABILITY','EVALUATE'],['REQ_CONFLICT','EVALUATE'],['REQ_FREEZE_CANDIDATE','EVALUATE'],
  ['KNOWLEDGE_SEARCH','READ'],['KNOWLEDGE_CONFLICT_CHECK','EVALUATE'],['PLAN_UPDATE','PROPOSE'],['ENGINEERING_CALC','OBSERVE'],['CAD_SCREEN','OBSERVE'],
  ['SPECIALIST_REVIEW','PROPOSE'],['TRADEOFF','PROPOSE'],['REVISION_COMMIT','COMMIT_REVISION'],['DFMEA_UPDATE','EVALUATE'],['VERIFY_PLAN','EVALUATE'],
  ['TEST_RECORD','EVALUATE'],['EVIDENCE_BIND','REGISTER_EVIDENCE'],['COVERAGE_EVAL','EVALUATE'],['GATE_V2','EVALUATE'],['HUMAN_APPROVAL','HUMAN_AUTHORITY'],
  ['FINAL_FREEZE','HUMAN_AUTHORITY'],['TRAINING_EVALUATION_INTERFACE','READ']
];
const DEPENDENCIES={REQ_PARSE:['TASK_INTAKE'],REQ_TESTABILITY:['REQ_PARSE'],REQ_CONFLICT:['REQ_PARSE'],REQ_FREEZE_CANDIDATE:['REQ_TESTABILITY','REQ_CONFLICT'],KNOWLEDGE_SEARCH:['REQ_FREEZE_CANDIDATE'],KNOWLEDGE_CONFLICT_CHECK:['KNOWLEDGE_SEARCH'],TRADEOFF:['SPECIALIST_REVIEW'],TEST_RECORD:['VERIFY_PLAN'],COVERAGE_EVAL:['EVIDENCE_BIND'],GATE_V2:['COVERAGE_EVAL'],HUMAN_APPROVAL:['GATE_V2'],FINAL_FREEZE:['GATE_V2','HUMAN_APPROVAL'],TRAINING_EVALUATION_INTERFACE:['GATE_V2']};
function fail(code){const error=Error(code);error.code=code;throw error;}
class CapabilityRegistry{
  constructor(){this.capabilities=new Map(SEED.map(([capability_id,authority])=>[capability_id,{capability_id,version:'1.0.0',authority,allowed_callers:['runtime'],dependencies:DEPENDENCIES[capability_id]||[],fallback_policy:'FAIL_CLOSED',checkpoint_policy:'AFTER_SUCCESS',status:'REGISTERED'}]));}
  get(capabilityId){const entry=this.capabilities.get(capabilityId);if(!entry)fail('CAPABILITY_NOT_REGISTERED');return structuredClone(entry);}
  list(){return [...this.capabilities.values()].map(entry=>structuredClone(entry));}
  authorize(capabilityId,caller){const entry=this.get(capabilityId);if(!entry.allowed_callers.includes(caller))fail('CAPABILITY_CALLER_DENIED');return entry;}
}
module.exports=CapabilityRegistry;
