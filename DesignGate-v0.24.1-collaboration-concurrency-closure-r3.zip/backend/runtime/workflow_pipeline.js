const crypto=require('crypto');
const Guard=require('./transition_guard');
const CapabilityRegistry=require('./capability_registry');
class WorkflowPipeline{
 constructor({project_id,revision}){if(!project_id||!revision)throw Error('RUNTIME_PROJECT_AND_REVISION_REQUIRED');this.registry=new CapabilityRegistry();this.state={schema_version:'1.0',project_id,revision,runtime_status:'REQUIREMENTS_PENDING',proposals:[],authoritative:{verification_status:null,gate_status:null,freeze:null},created_at:new Date().toISOString()};}
 advance({to,actor='runtime',gate_status=null}={}){Guard.transition({from:this.state.runtime_status,to,actor,gate_status});this.state.runtime_status=to;this.state.last_transition={to,actor,at:new Date().toISOString()};return structuredClone(this.state);}
 ingestProposal({actor='model',text='',claims=[],capability_id=null}={}){if(!['model','specialist','chief','cad','device'].includes(actor))throw Error('RUNTIME_PROPOSAL_ACTOR_INVALID');if(capability_id)this.registry.authorize(capability_id,'runtime');const guarded=claims.map(claim=>{try{Guard.authoritativeMutation({actor,field:claim.claim_type,value:claim.value});return {...claim,authority_status:'PROPOSAL_ONLY'};}catch{return {...claim,authority_status:'AUTHORITY_DENIED_PROPOSAL_RETAINED'};}});this.state.proposals.push({proposal_id:`PROP-${crypto.randomUUID()}`,actor,text:String(text),capability_id,claims:guarded,status:'UNVERIFIED_PROPOSAL',recorded_at:new Date().toISOString()});return structuredClone(this.state);}
 snapshot(){return structuredClone(this.state);}
}
module.exports=WorkflowPipeline;
