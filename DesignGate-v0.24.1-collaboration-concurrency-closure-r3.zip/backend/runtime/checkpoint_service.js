const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const Canonical=require('../crypto/canonical_json');
function fail(code){const error=Error(code);error.code=code;throw error;}
class CheckpointService{
  constructor({dir}={}){if(typeof dir!=='string'||!dir)fail('CHECKPOINT_DIRECTORY_REQUIRED');this.dir=path.resolve(dir);fs.mkdirSync(this.dir,{recursive:true});}
  file(id){if(typeof id!=='string'||!/^CHK-[a-f0-9-]{36}$/.test(id))fail('CHECKPOINT_INVALID');return path.join(this.dir,`${id}.json`);}
  save({project_id,revision,payload}={}){
    if(typeof project_id!=='string'||!project_id||typeof revision!=='string'||!revision||!payload||typeof payload!=='object'||Array.isArray(payload))fail('CHECKPOINT_INVALID');
    const record={checkpoint_id:`CHK-${crypto.randomUUID()}`,project_id,revision,payload:structuredClone(payload),payload_hash:Canonical.sha256(payload),created_at:new Date().toISOString()};
    const file=this.file(record.checkpoint_id),temp=`${file}.tmp`;fs.writeFileSync(temp,Canonical.canonicalize(record),{mode:0o600});fs.renameSync(temp,file);return structuredClone(record);
  }
  load(project_id,checkpoint_id){
    let record;try{record=JSON.parse(fs.readFileSync(this.file(checkpoint_id),'utf8'));}catch(error){if(error?.code==='CHECKPOINT_INVALID')throw error;fail('CHECKPOINT_NOT_FOUND');}
    if(record.project_id!==project_id)fail('PROJECT_SCOPE_DENIED');
    if(!record.payload||Canonical.sha256(record.payload)!==record.payload_hash)fail('CHECKPOINT_CORRUPT');
    return structuredClone(record);
  }
}
module.exports=CheckpointService;
