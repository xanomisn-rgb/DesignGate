const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const Canonical=require('../crypto/canonical_json');
function fail(code){const error=Error(code);error.code=code;throw error;}
class RuntimeTraceService{
  constructor({dir}={}){if(typeof dir!=='string'||!dir)fail('TRACE_DIRECTORY_REQUIRED');this.dir=path.resolve(dir);this.file=path.join(this.dir,'runtime_trace.json');this.project_id=null;fs.mkdirSync(this.dir,{recursive:true});}
  read(){try{const rows=JSON.parse(fs.readFileSync(this.file,'utf8'));if(!Array.isArray(rows))fail('TRACE_CORRUPT');return rows;}catch(error){if(error?.code==='TRACE_CORRUPT')throw error;if(error?.code==='ENOENT')return [];fail('TRACE_CORRUPT');}}
  ensureProject(project_id,rows=this.read()){const owner=rows[0]?.project_id||this.project_id;if(owner&&owner!==project_id)fail('PROJECT_SCOPE_DENIED');this.project_id=project_id;return rows;}
  append({project_id,revision,event_type,payload}={}){
    if(typeof project_id!=='string'||!project_id||typeof revision!=='string'||!revision||typeof event_type!=='string'||!event_type||!payload||typeof payload!=='object'||Array.isArray(payload))fail('TRACE_INVALID');
    const rows=this.ensureProject(project_id),previous_hash=rows.at(-1)?.entry_hash||'GENESIS';
    const entry={trace_id:`TRACE-${crypto.randomUUID()}`,project_id,revision,event_type,payload:structuredClone(payload),payload_hash:Canonical.sha256(payload),previous_hash,recorded_at:new Date().toISOString()};
    entry.entry_hash=Canonical.sha256(entry);const next=[...rows,entry],temp=`${this.file}.tmp`;fs.writeFileSync(temp,Canonical.canonicalize(next),{mode:0o600});fs.renameSync(temp,this.file);return structuredClone(entry);
  }
  list(project_id){return this.ensureProject(project_id).map(entry=>structuredClone(entry));}
  verify(project_id){const rows=this.list(project_id);let previous='GENESIS';for(const entry of rows){const {entry_hash,...unsigned}=entry;if(entry.previous_hash!==previous||Canonical.sha256(entry.payload)!==entry.payload_hash||Canonical.sha256(unsigned)!==entry_hash)fail('TRACE_CORRUPT');previous=entry_hash;}return {valid:true,entries:rows.length,last_hash:previous};}
}
module.exports=RuntimeTraceService;
