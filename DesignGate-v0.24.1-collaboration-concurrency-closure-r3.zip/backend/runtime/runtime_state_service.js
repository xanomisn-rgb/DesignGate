const crypto=require('crypto');
function fail(code){const error=Error(code);error.code=code;throw error;}
class RuntimeStateService{
 constructor({project_id,revision,knowledge_snapshot_id=null,rule_version=null,verification_plan_hash=null}={}){if(!project_id||!revision)fail('RUNTIME_PROJECT_AND_REVISION_REQUIRED');this.state={schema_version:'1.0',project_id,revision,runtime_status:'REQUIREMENTS_PENDING',knowledge_snapshot_id,rule_version,verification_plan_hash,revalidation_reasons:[],history:[]};}
 checkpoint(){const payload=structuredClone(this.state),hash=crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');return {payload,hash};}
  revise(revision,reason){if(!revision||revision===this.state.revision)fail('RUNTIME_REVISION_INVALID');this.state.history.push({event:'REVISION_CHANGED',from:this.state.revision,to:revision,reason:String(reason||''),at:new Date().toISOString()});this.state.revision=revision;this.state.runtime_status='REVISION_REQUIRED';this.state.revalidation_reasons=['REVISION_CHANGED'];return structuredClone(this.state);}
  updateBindings(bindings={}){
    const fields={knowledge_snapshot_id:'KNOWLEDGE_SNAPSHOT_CHANGED',rule_version:'RULE_VERSION_CHANGED',verification_plan_hash:'VERIFICATION_PLAN_CHANGED'};
    const reasons=[];
    for(const [field,reason] of Object.entries(fields)){
      if(Object.hasOwn(bindings,field)&&bindings[field]!==this.state[field]){this.state[field]=bindings[field]??null;reasons.push(reason);}
    }
    if(reasons.length){this.state.history.push({event:'GOVERNED_BINDING_CHANGED',reasons,at:new Date().toISOString()});this.state.runtime_status='REVISION_REQUIRED';this.state.revalidation_reasons=reasons;}
    return structuredClone(this.state);
  }
  resume(checkpoint){if(!checkpoint?.payload||!checkpoint.hash)fail('CHECKPOINT_INVALID');const actual=crypto.createHash('sha256').update(JSON.stringify(checkpoint.payload)).digest('hex');if(actual!==checkpoint.hash)fail('CHECKPOINT_CORRUPT');if(checkpoint.payload.project_id!==this.state.project_id)fail('PROJECT_SCOPE_DENIED');if(checkpoint.payload.revision!==this.state.revision)fail('REVALIDATION_REQUIRED');for(const field of ['knowledge_snapshot_id','rule_version','verification_plan_hash'])if(checkpoint.payload[field]!==this.state[field])fail('REVALIDATION_REQUIRED');return structuredClone(this.state);}
 snapshot(){return structuredClone(this.state);}
}
module.exports=RuntimeStateService;
