const C=require('./contracts');
const RuleEngine=require('./rule_engine');
function processKind(s=''){if(/钣金|sheet|折弯|冲压/i.test(s))return 'sheet';if(/压铸|die.?cast/i.test(s))return 'casting';if(/cnc|机加|切削/i.test(s))return 'cnc';if(/注塑|injection|overmold/i.test(s))return 'injection';return null;}
class CheckEngine{
 constructor(knowledge){this.rules=new RuleEngine(knowledge);}
 evaluate(p,intakeErrors=[]){const checks=[],findings=[],d=p.design||{},revision=d.active_revision,basis=C.hash({design:d,requirements:p.requirements,bom:p.bom}),kind=processKind(d.process);
 const add=(id,status,fields,issues,reason,gate=2)=>checks.push({check_id:id,status,required_for_gate:gate,issue_ids:issues||[],input_fields:fields||[],input_fingerprint:C.hash({basis,fields:(fields||[]).map(k=>[k,d[k]])}),rule_version:this.rules.knowledge.data.release,revision,reason});
 add('REQUIREMENT_BASELINE',p.requirements?.length?'PASS':'UNKNOWN',[],['DG-REQ-MISSING'],'需要明确的需求基线',1);
 if(kind==='injection'&&d.material&&/铝|钢|金属|6061|aluminum|steel/i.test(d.material)){add('PROCESS_MATERIAL','FAIL',['process','material'],['DG-PROCESS-MATERIAL'],'当前注塑规则不能用于金属材料');findings.push(C.gap('DG-PROCESS-MATERIAL','声明的注塑工艺与金属材料不匹配；请明确零件工艺。',{severity:'HIGH',status:'OPEN',record_type:'INPUT_CONFLICT'}));}
 if(!kind)add('PROCESS',d.process?'NOT_IMPLEMENTED':'UNKNOWN',['process'],[],'工艺未指定或当前规则尚未覆盖');else{
 if(d.material&&!/铝|钢|金属|6061|aluminum|steel/i.test(d.material)&&kind==='injection')add('PROCESS_MATERIAL','PASS',['process','material'],['DG-PROCESS-MATERIAL'],'工艺材料组合已重新声明');

 const manufacturing=(p.verifications||[]).find(v=>v.req_id==='SYS-MANUFACTURING'&&v.status==='PASS'&&v.basis_hash&&v.basis_hash===p.basis_hash&&v.revision===revision&&v.evidence_id&&(p.evidence||[]).some(e=>e.evidence_id===v.evidence_id));
 try{
  for(const item of this.rules.evaluateChecks(d)){
   const {finding,...check}=item;
   if(check.status==='UNKNOWN'&&manufacturing){check.status='PASS';check.reason='当前基线已有人工制造复核声明；原自动规则仍未能判定。';check.manual_verification=manufacturing.evidence_id;check.automatic_status='UNKNOWN';}
   checks.push({...check,revision,input_fingerprint:C.hash({basis,fields:check.input_fields.map(k=>[k,d[k]]),rules:this.rules.knowledge.catalog,records:this.rules.knowledge.records})});
   if(finding&&check.status!=='PASS')findings.push(finding);
  }
 }catch(e){add('DFM_EXECUTION','ERROR',[],[],e.message);}

 }
 for(const r of p.requirements||[]){
  add('PLAN-'+r.req_id,r.verification_method&&r.acceptance_criteria?'PASS':'UNKNOWN',[],['DG-REQ-PLAN-'+r.req_id],'需要验证方法与通过判据',1);
  const v=(p.verifications||[]).find(v=>v.req_id===r.req_id&&v.revision===revision&&v.basis_hash===p.basis_hash&&v.evidence_id);
  add('VERIFY-'+r.req_id,v?(v.status==='PASS'?'PASS':v.status==='FAIL'?'FAIL':'UNKNOWN'):'UNKNOWN',[],['DG-QUA-'+r.req_id],'需要当前设计基线的实测证据',3);
  if(v?.status==='FAIL')findings.push(C.gap('DG-VERIFY-FAIL-'+r.req_id,`需求 ${r.req_id} 的验证结果为失败。`,{severity:'HIGH',status:'OPEN',record_type:'VERIFICATION_RESULT',evidence_refs:[v.evidence_id]}));
 }
 if((p.requirements||[]).some(r=>/电池|battery/i.test(r.text)&&/可更换|快拆|removable|quick.release/i.test(r.text))){const known=['screws','latch','removable_connector','permanent_bond'].includes(d.batteryAttachment);add('BATTERY_SERVICE',known?(d.batteryAttachment==='permanent_bond'?'FAIL':'PASS'):'UNKNOWN',['batteryAttachment'],['DG-REQ-002','DG-REQ-BATTERY-CONFIRM'],'需要明确电池固定方式',1);}
 add('MATERIAL',d.material?'PASS':'UNKNOWN',['material'],['DG-MAT-001'],'需要材料声明；物性仍需原厂资料核对',2);
 add('CMF',d.finish&&d.color&&d.gloss?'PASS':'UNKNOWN',['finish','color','gloss'],['DG-CMF-001'],'需要 CMF 定义',2);
 if(/手持|handheld/i.test(p.product?.category||'')){const ergo=(p.requirements||[]).filter(r=>/握持|舒适|操作|grip|usability/i.test(r.text));const done=ergo.length&&ergo.every(r=>(p.verifications||[]).some(v=>v.req_id===r.req_id&&v.basis_hash===p.basis_hash&&v.status==='PASS'));add('ERGONOMICS',done?'PASS':'UNKNOWN',['dimensions'],['DG-ERG-INFO-01','DG-ERG-PROTOTYPE'],'需要基于握持任务的样机验证',3);}
 add('BOM',p.bom?.length?'PASS':'UNKNOWN',[],[],'冻结前需要完整 BOM',3);
 for(const [i,e] of intakeErrors.entries()){add('INTAKE-'+i,'ERROR',[],[],e,1);findings.push(C.gap('DG-INTAKE-'+i,e));}
 const finalChecks=[['SYS-MATERIAL','材料来源及适用物性复核'],['SYS-MANUFACTURING','制造与装配可行性人工/工具验证'],['SYS-CMF','CMF 样板与表面耐久验证']];
 if(d.cad_geometry)finalChecks.push(['SYS-CAD','CAD 实体几何及模具/装配验证']);
 for(const [id,label]of finalChecks){const v=(p.verifications||[]).find(v=>v.req_id===id&&v.revision===revision&&v.basis_hash===p.basis_hash&&v.evidence_id);add('VERIFY-'+id,v?.status||'UNKNOWN',[],['DG-VERIFY-FAIL-'+id],label,3);if(v?.status==='FAIL')findings.push(C.gap('DG-VERIFY-FAIL-'+id,label+'未通过',{severity:'HIGH',status:'OPEN',record_type:'VERIFICATION_RESULT',evidence_refs:[v.evidence_id]}));}

 return {checks,findings};
 }
}
module.exports=CheckEngine;module.exports.processKind=processKind;
