const Knowledge=require('./knowledge_service');
class EvidenceRegistry {
 constructor(knowledge=new Knowledge()){this.knowledge=knowledge;this.records=new Map();this.loadBuiltinSources();}
 loadBuiltinSources(){
  for(const kind of ['rules','materials','standards'])for(const [i,r] of this.knowledge.legacy(kind).entries()){
   const id=r.record_id||r.code;
   this.registerEvidence({evidence_id:kind==='standards'?'EVD-STD-'+(i+1):'EVD-'+id,record_id:id,source_id:r.source_id,title:r.title||r.name||r.grade,claim:r.content||r.scope||'历史材料名称索引，物性未核验',source_url:r.source_url,evidence_level:'UNREVIEWED',verification_scope:'LEGACY_UNREVIEWED',verified:false,normative:false,mandatory_requirement:false});
  }
  for(const r of this.knowledge.records)this.registerEvidence({evidence_id:'KB-'+r.id,record_id:r.id,title:r.title,claim:r.claim,source_ids:r.source_ids,scope:r.scope,limitations:r.limitations,evidence_level:'REFERENCE_ONLY',verified:false,normative:false,mandatory_requirement:false});
 }
 registerEvidence(item){
  // Local catalog registration never confers B1 or project verification authority.
  const safe={...item,verified:false,evidence_level:item.evidence_level==='B1'?'UNREVIEWED':item.evidence_level};
  this.records.set(safe.evidence_id,safe);if(safe.record_id)this.records.set(safe.record_id,safe);
 }
 getEvidence(id){const r=this.records.get(id);return r?structuredClone(r):null;}
 hasEvidence(id){return this.records.has(id);}
}
module.exports=EvidenceRegistry;
