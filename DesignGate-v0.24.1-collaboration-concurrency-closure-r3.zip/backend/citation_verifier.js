const Knowledge = require('./knowledge_service');

function escapeRegex(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

class CitationVerifier {
  constructor(knowledge = new Knowledge()) {
    this.knowledge = knowledge;
    this.materials = knowledge.legacy('materials');
    this.standards = knowledge.legacy('standards');
  }

  verifyMaterialGrade(inputMaterialText) {
    if (!inputMaterialText) {
      return { verified: false, reason: "未提供材料信息" };
    }

    const text = inputMaterialText.toLowerCase();

    // 1. 严格牌号词边界匹配 (Exact Normalized Grade Matching with Token Boundaries)
    // 杜绝 24050 误匹配 2405、T65 XFA 误匹配 T65 XF
    const exactGradeMatch = this.materials.find(m => {
      if (!m.grade) return false;
      const cleanGrade = m.grade.trim().toLowerCase();
      const gradePattern = new RegExp(`(?:^|[^a-zA-Z0-9])(${escapeRegex(cleanGrade)})(?:$|[^a-zA-Z0-9])`, "i");
      return gradePattern.test(text);
    });

    if (exactGradeMatch) {
      return {
        verified: true,
        verification_scope: "LOCAL_INDEX_MATCH_ONLY",
        properties_verified: false,
        warning: "仅匹配历史索引。物性须读取经整理知识卡并保留测试条件；后缀变体应独立核对。",
        record_id: exactGradeMatch.record_id,
        supplier: exactGradeMatch.supplier,
        trade_name: exactGradeMatch.trade_name,
        grade: exactGradeMatch.grade,
        evidence_level: exactGradeMatch.evidence_level,
        tds_status: exactGradeMatch.verification_status,
        properties: {},
        curated_record_id: exactGradeMatch.curated_record_id || null
      };
    }

    // 2. 若仅输入了商标系列名称 (Trade Family, 如 Bayblend / Makrolon / Estane)，严禁直接通过 B1 验证！
    const tradeOnlyMatch = this.materials.find(m => {
      if (!m.trade_name) return false;
      const cleanTrade = m.trade_name.trim().toLowerCase();
      const tradePattern = new RegExp(`(?:^|[^a-zA-Z0-9])(${escapeRegex(cleanTrade)})(?:$|[^a-zA-Z0-9])`, "i");
      return tradePattern.test(text);
    });

    if (tradeOnlyMatch) {
      return {
        verified: false,
        is_trade_family_only: true,
        trade_name: tradeOnlyMatch.trade_name,
        supplier: tradeOnlyMatch.supplier,
        reason: `送审资料仅指定了原厂商标系列名称 [${tradeOnlyMatch.trade_name}]，未锁定具体原厂牌号 (Specific Grade)，无法引用确定性 B1 级 TDS 数据表。`
      };
    }

    // 3. 泛称材料族识别 (使用精确词边界，防范 IPC 误判)
    const genericPattern = /(?:^|[^a-zA-Z0-9])(abs|pc|pp|pa6|pa66|tpu|pc\+abs|pc\/abs|铝合金|不锈钢|塑料|金属)(?:$|[^a-zA-Z0-9])/i;
    const isGeneric = genericPattern.test(text);

    return {
      verified: false,
      is_generic_family: isGeneric,
      reason: isGeneric 
        ? "仅提及泛指材料族名称，缺少原厂具体牌号 (B1 TDS)，按 DesignGate 规则禁止输出确定性机械数值计算结论。"
        : "未在已核验原厂数据库中检索到该材料牌号。"
    };
  }

  verifyStandardCitation(standardCode) {
    if (!standardCode) return { verified: false };
    const cleanCode = standardCode.replace(/[\[\]]/g, "").trim().toLowerCase();
    const normalized = cleanCode.replace(/\s+/g, '').toUpperCase();
    const matched = this.standards.find(s => s.code.replace(/\s+/g, '').toUpperCase() === normalized);

    if (matched) {
      return {
        verified: true,
        verification_scope: "LOCAL_INDEX_MATCH_ONLY",
        currency_verified: false,
        code: matched.code,
        name: matched.name,
        evidence_level: matched.evidence_level,
        scope: matched.scope,
        source_url: matched.source_url || "http://openstd.samr.gov.cn/"
      };
    }

    return {
      verified: false,
      reason: `引用之标准代号 [${standardCode}] 未能在 DesignGate 生产标准索引库中核验，严禁以此作为终审合规依据。`
    };
  }
}

module.exports = CitationVerifier;
