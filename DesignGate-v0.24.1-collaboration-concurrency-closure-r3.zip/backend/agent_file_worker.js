const {parentPort,workerData}=require('worker_threads');
try {parentPort.postMessage({result:require('./file_intake_manager').processIntake(workerData.files,workerData.cadOptions)});}
catch(e){parentPort.postMessage({error:e.message});}
