const crypto=require('crypto');
const C=require('./contracts');
const RISK_POLICY_VERSION='DG-RISK-ACCEPT-1.0';
const EXECUTION_STATUSES=new Set(['PASS','FAILED']);
function clone(v){return structuredClone(v??{});}
function normalizeStatus(s){return s==='FAIL'?'FAILED':String(s||'').toUpperCase();}
function riskDefinition(input={}){return {items:clone(input.items||[]),requirement_links:clone(input.requirement_links||[])};}
function riskHash(project){return project.dfmea?C.hash(riskDefinition(project.dfmea)):null;}
function designHash(project){return project.dfmea?C.hash({project_id:project.project_id,revision:project.design?.active_revision||null,design:project.design||{},requirements:project.requirements||[],rule_version:'0.20.3'}):null;}
function planHash(plan){return plan?C.hash({plan_id:plan.plan_id,version:plan.version,items:plan.items||[]}):null;}
function currentBindings(project){return {project_id:project.project_id,revision:project.design?.active_revision||null,design_baseline_hash:project.dfmea_design_hash||designHash(project),risk_definition_hash:project.dfmea_baseline_hash||riskHash(project),verification_plan_id:project.dfmea_verification_plan?.plan_id||null,verification_plan_version:project.dfmea_verification_plan?.version||null,verification_plan_hash:project.dfmea_verification_plan_hash||planHash(project.dfmea_verification_plan)};}
function refreshHashes(project){
  project.dfmea_baseline_hash=riskHash(project);project.dfmea_design_hash=designHash(project);project.dfmea_verification_plan_hash=planHash(project.dfmea_verification_plan);return project;
}
function failureModes(project){const out=new Map();for(const item of project.dfmea?.items||[])for(const mode of item.failure_modes||[])if(mode?.failure_mode_id)out.set(mode.failure_mode_id,mode);return out;}
function assertPlanItem(project,item){
  if(!item||typeof item.plan_item_id!=='string'||!item.plan_item_id.trim())throw Error('验证计划项需要 plan_item_id');
  if(!Array.isArray(item.failure_mode_ids)||!item.failure_mode_ids.length)throw Error('验证计划项需要 failure_mode_ids');
  const modes=failureModes(project);if(item.failure_mode_ids.some(id=>!modes.has(id)))throw Error('验证计划引用了不存在的失效模式');
  if(typeof item.method!=='string'||!item.method.trim()||typeof item.acceptance_criteria!=='string'||!item.acceptance_criteria.trim())throw Error('验证计划需要方法和验收判据');
}
function setPlan(project,input={},actor='USER'){
  if(!project.dfmea)throw Error('请先建立 DFMEA 风险定义');const items=clone(input.items||[]);if(!items.length)throw Error('验证计划至少包含一项');
  const ids=new Set();for(const item of items){assertPlanItem(project,item);if(ids.has(item.plan_item_id))throw Error('验证计划 plan_item_id 必须唯一');ids.add(item.plan_item_id);}
  const old=project.dfmea_verification_plan;if(old){project.dfmea_verification_plan_history=[...(project.dfmea_verification_plan_history||[]),clone(old)];}
  project.dfmea_verification_plan={plan_id:old?.plan_id||String(input.plan_id||'VPLAN-'+crypto.randomUUID()),version:(old?.version||0)+1,items,change_reason:String(input.change_reason||'Verification plan updated').slice(0,1000),supersedes_plan_version:old?.version||null,created_at:new Date().toISOString(),created_by:actor,authority:'SERVER_VERSIONED_VERIFICATION_PLAN'};
  refreshHashes(project);project.last_review=null;project.freeze=null;return project;
}
function verifyEvidenceRecord(project,evidenceId,verifyEvidence){
  if(typeof evidenceId!=='string'||!evidenceId)throw Error('测试执行必须绑定证据');const ev=(project.evidence||[]).find(e=>e.evidence_id===evidenceId);if(!ev)throw Error('测试证据不存在');
  if(typeof verifyEvidence==='function')verifyEvidence(project,ev);return ev;
}
function appendTest(project,input={},verifyEvidence,{importMode=false}={}){
  if(!project.dfmea_verification_plan)throw Error('请先建立版本化验证计划');refreshHashes(project);
  const testId=String(input.test_id||'').trim();if(!testId)throw Error('测试执行需要 test_id');
  const existing=(project.dfmea_test_records||[]).find(r=>r.test_id===testId);if(existing){if(importMode)return project;throw Error('测试 test_id 已存在；执行记录不可覆盖，请创建复测或更正记录');}
  const planItem=(project.dfmea_verification_plan.items||[]).find(x=>x.plan_item_id===input.plan_item_id)||(project.dfmea_verification_plan.items||[]).find(x=>Array.isArray(input.failure_mode_ids)&&input.failure_mode_ids.length&&input.failure_mode_ids.every(id=>x.failure_mode_ids.includes(id)));
  if(!planItem)throw Error('测试执行必须关联当前验证计划项');
  const status=normalizeStatus(input.status);if(!EXECUTION_STATUSES.has(status))throw Error('测试执行状态只能是 PASS 或 FAILED；计划状态属于验证计划而非执行记录');
  const modeIds=Array.isArray(input.failure_mode_ids)&&input.failure_mode_ids.length?[...new Set(input.failure_mode_ids)]:[...planItem.failure_mode_ids];if(modeIds.some(id=>!planItem.failure_mode_ids.includes(id)))throw Error('测试失效模式与验证计划不一致');
  if(typeof input.actual_result!=='string'||!input.actual_result.trim()||typeof input.reviewer!=='string'||!input.reviewer.trim())throw Error('测试执行需要实际结果和审核记录人');
  const completed=Date.parse(input.completed_at);if(typeof input.completed_at!=='string'||Number.isNaN(completed))throw Error('测试完成时间无效');
  const ev=verifyEvidenceRecord(project,input.evidence_id,verifyEvidence),bindings=currentBindings(project);
  let retestOf=null;if(input.retest_of){retestOf=(project.dfmea_test_records||[]).find(r=>r.test_id===input.retest_of);if(!retestOf)throw Error('retest_of 必须指向真实原测试');if(retestOf.test_id===testId)throw Error('复测不能自引用');if(!modeIds.some(id=>(retestOf.failure_mode_ids||[]).includes(id)))throw Error('复测与原测试风险无关联');if(completed<=Date.parse(retestOf.completed_at))throw Error('复测完成时间必须晚于原测试');let cursor=retestOf,seen=new Set([testId]);while(cursor?.retest_of){if(seen.has(cursor.retest_of))throw Error('复测关系存在循环引用');seen.add(cursor.retest_of);cursor=(project.dfmea_test_records||[]).find(r=>r.test_id===cursor.retest_of);}}
  const raw={record_id:'TESTREC-'+crypto.randomUUID(),test_id:testId,plan_item_id:planItem.plan_item_id,failure_mode_ids:modeIds,status,source_status:normalizeStatus(input.status),actual_result:input.actual_result.trim(),acceptance_criteria_snapshot:planItem.acceptance_criteria,method_snapshot:planItem.method,reviewer:input.reviewer.trim(),completed_at:new Date(completed).toISOString(),evidence_id:ev.evidence_id,retest_of:input.retest_of||null,recorded_at:new Date().toISOString(),...bindings,authority:'APPEND_ONLY_SERVER_BOUND_TEST_EXECUTION'};
  raw.record_hash=C.hash(raw);project.dfmea_test_records=[...(project.dfmea_test_records||[]),raw];project.last_review=null;project.freeze=null;return project;
}
function appendCorrection(project,input={}){
  const original=(project.dfmea_test_records||[]).find(r=>r.test_id===input.corrects_test_id);if(!original)throw Error('更正必须关联真实原测试');
  if(typeof input.reason!=='string'||!input.reason.trim()||typeof input.corrected_by!=='string'||!input.corrected_by.trim())throw Error('更正记录需要理由和责任人');
  const row={correction_id:'CORR-'+crypto.randomUUID(),corrects_test_id:original.test_id,reason:input.reason.trim(),corrected_by:input.corrected_by.trim(),created_at:new Date().toISOString(),replacement_fields:clone(input.replacement_fields||{}),authority:'APPEND_ONLY_CORRECTION_DOES_NOT_DELETE_ORIGINAL'};row.record_hash=C.hash(row);project.dfmea_test_corrections=[...(project.dfmea_test_corrections||[]),row];project.last_review=null;return project;
}
function requiresResidualAcceptance(mode={}){const rpn=(mode.severity||0)*(mode.occurrence||0)*(mode.detection||0);return mode.severity>=9||rpn>=200;}
function acceptRisk(project,input={}){
  refreshHashes(project);const mode=failureModes(project).get(input.failure_mode_id);if(!mode)throw Error('风险接受必须关联当前真实失效模式');if(!requiresResidualAcceptance(mode))throw Error('当前风险不要求额外残余风险接受，可在普通评审记录中处置');
  if(typeof input.reason!=='string'||!input.reason.trim()||typeof input.responsible_person!=='string'||!input.responsible_person.trim()||typeof input.conditions!=='string'||!input.conditions.trim()||!Array.isArray(input.follow_up_actions)||!input.follow_up_actions.length||input.follow_up_actions.some(x=>typeof x!=='string'||!x.trim()))throw Error('风险接受需要理由、责任人、条件和后续措施');
  const row={acceptance_id:'RISKACC-'+crypto.randomUUID(),failure_mode_id:input.failure_mode_id,reason:input.reason.trim(),responsible_person:input.responsible_person.trim(),conditions:input.conditions.trim(),follow_up_actions:input.follow_up_actions.map(x=>x.trim()),accepted_at:new Date().toISOString(),policy_version:RISK_POLICY_VERSION,...currentBindings(project),authority:'LOCAL_RESIDUAL_RISK_ACCEPTANCE_NOT_PRODUCTION_RELEASE'};row.record_hash=C.hash(row);project.risk_acceptances=[...(project.risk_acceptances||[]),row];project.last_review=null;project.freeze=null;return project;
}
function disposeFailure(project,input={}){
  refreshHashes(project);const original=(project.dfmea_test_records||[]).find(r=>r.test_id===input.failed_test_id&&r.status==='FAILED');if(!original)throw Error('处置必须关联真实 FAILED 测试');if(typeof input.reason!=='string'||!input.reason.trim()||typeof input.reviewed_by!=='string'||!input.reviewed_by.trim())throw Error('失败处置需要理由和审核人');
  const row={disposition_id:'DISP-'+crypto.randomUUID(),failed_test_id:original.test_id,failure_mode_ids:[...(original.failure_mode_ids||[])],reason:input.reason.trim(),reviewed_by:input.reviewed_by.trim(),created_at:new Date().toISOString(),...currentBindings(project),authority:'EXPLICIT_FAILURE_DISPOSITION'};row.record_hash=C.hash(row);project.dfmea_failure_dispositions=[...(project.dfmea_failure_dispositions||[]),row];project.last_review=null;return project;
}
function migrateProject(project){
  if(!project||typeof project!=='object')return project;project.schema_version='3.1';project.dfmea_test_records=project.dfmea_test_records||[];project.dfmea_test_corrections=project.dfmea_test_corrections||[];project.risk_acceptances=project.risk_acceptances||[];project.dfmea_failure_dispositions=project.dfmea_failure_dispositions||[];
  const legacy=Array.isArray(project.dfmea?.verification_tests)?clone(project.dfmea.verification_tests):[];
  if(project.dfmea)project.dfmea=riskDefinition(project.dfmea);
  refreshHashes(project);
  if(legacy.length&&!project.dfmea_verification_plan){
    const items=legacy.filter(t=>t?.test_id&&Array.isArray(t.failure_mode_ids)&&t.failure_mode_ids.length).map(t=>({plan_item_id:'LEGACY-PLAN-'+t.test_id,failure_mode_ids:[...new Set(t.failure_mode_ids)],method:'LEGACY_UNSPECIFIED_METHOD',acceptance_criteria:typeof t.acceptance_criteria==='string'&&t.acceptance_criteria.trim()?t.acceptance_criteria:'LEGACY_UNSPECIFIED_CRITERIA'}));
    if(items.length)project.dfmea_verification_plan={plan_id:'VPLAN-LEGACY-'+crypto.randomUUID(),version:1,items,created_at:new Date().toISOString(),created_by:'MIGRATION',authority:'MIGRATED_PLAN_REQUIRES_REVIEW'};
  }
  refreshHashes(project);
  for(const t of legacy){if(!t?.test_id||project.dfmea_test_records.some(r=>r.test_id===t.test_id))continue;const raw={record_id:'TESTREC-LEGACY-'+crypto.randomUUID(),test_id:t.test_id,plan_item_id:'LEGACY-PLAN-'+t.test_id,failure_mode_ids:Array.isArray(t.failure_mode_ids)?[...t.failure_mode_ids]:[],status:normalizeStatus(t.status)||'UNKNOWN',source_status:normalizeStatus(t.status)||'UNKNOWN',actual_result:t.actual_result||'',acceptance_criteria_snapshot:t.acceptance_criteria||'',method_snapshot:'LEGACY_UNKNOWN',reviewer:t.reviewer||'',completed_at:t.completed_at||null,evidence_id:t.evidence_id||null,retest_of:t.retest_of||null,recorded_at:new Date().toISOString(),project_id:project.project_id,revision:t.revision||null,design_baseline_hash:null,risk_definition_hash:null,verification_plan_id:null,verification_plan_version:null,verification_plan_hash:null,legacy_client_baseline:t.baseline_fingerprint||null,migration_status:'LEGACY_UNBOUND_REQUIRES_REVALIDATION',authority:'MIGRATED_APPEND_ONLY_HISTORY'};raw.record_hash=C.hash(raw);project.dfmea_test_records.push(raw);}
  delete project.dfmea?.verification_tests;refreshHashes(project);return project;
}
function recordHashValid(record){if(!record?.record_hash)return false;const copy={...record};delete copy.record_hash;return C.hash(copy)===record.record_hash;}
function acceptanceHashValid(record){return recordHashValid(record);}
module.exports={RISK_POLICY_VERSION,EXECUTION_STATUSES,normalizeStatus,riskDefinition,riskHash,designHash,planHash,currentBindings,refreshHashes,setPlan,appendTest,appendCorrection,acceptRisk,disposeFailure,migrateProject,requiresResidualAcceptance,recordHashValid,acceptanceHashValid};
