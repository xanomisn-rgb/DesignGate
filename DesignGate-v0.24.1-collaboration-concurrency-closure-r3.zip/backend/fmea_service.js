const {createCapabilityResult}=require('./capability_contract');
const Records=require('./dfmea_records');
const TEST_STATUSES=Object.freeze(['PLANNED','RUNNING','UNKNOWN','CANCELLED','STALE','PASS','FAILED']);
const LEGACY_STATUS_ALIASES=Object.freeze({FAIL:'FAILED'});
function score(value,name){if(!Number.isInteger(value)||value<1||value>10)throw Error(name+' must be an integer from 1 to 10');return value;}
function actionPriority(severity,occurrence,detection){if(severity>=9&&(occurrence>=4||detection>=6))return'HIGH';if(severity>=7||occurrence>=7||detection>=8)return'MEDIUM';return'LOW';}
function normalizedStatus(status){return LEGACY_STATUS_ALIASES[status]||status||'UNKNOWN';}
function evidenceIsValid(test,meta){if(typeof test.evidence_id!=='string'||!test.evidence_id)return false;if(typeof meta.evidenceValidator==='function')return meta.evidenceValidator(test.evidence_id)===true;return Array.isArray(meta.valid_evidence_ids)&&meta.valid_evidence_ids.includes(test.evidence_id);}
function validDate(value){return typeof value==='string'&&!Number.isNaN(Date.parse(value));}
function bindingMatches(test,meta){
  if(meta.project_id&&test.project_id!==meta.project_id)return false;
  if(test.revision!==meta.revision)return false;
  if(meta.design_baseline_hash&&test.design_baseline_hash!==meta.design_baseline_hash)return false;
  if(meta.risk_definition_hash&&test.risk_definition_hash!==meta.risk_definition_hash)return false;
  if(meta.verification_plan_hash&&test.verification_plan_hash!==meta.verification_plan_hash)return false;
  if(meta.verification_plan_id&&test.verification_plan_id!==meta.verification_plan_id)return false;
  if(meta.verification_plan_version&&test.verification_plan_version!==meta.verification_plan_version)return false;
  return true;
}
function canonicalValidity(test,meta,planItems){
  const status=normalizedStatus(test.status),hashValid=Records.recordHashValid(test),plan=planItems.get(test.plan_item_id),planMatch=!!plan&&Array.isArray(test.failure_mode_ids)&&test.failure_mode_ids.length&&test.failure_mode_ids.every(id=>plan.failure_mode_ids.includes(id))&&test.acceptance_criteria_snapshot===plan.acceptance_criteria&&test.method_snapshot===plan.method;
  const fields=typeof test.test_id==='string'&&!!test.test_id&&typeof test.actual_result==='string'&&!!test.actual_result.trim()&&typeof test.reviewer==='string'&&!!test.reviewer.trim()&&validDate(test.completed_at);
  const current=bindingMatches(test,meta),evidenceValid=evidenceIsValid(test,meta),validStatus=['PASS','FAILED'].includes(status);
  return {...test,status,hashValid,planMatch,fields,current,evidenceValid,pass:status==='PASS'&&hashValid&&planMatch&&fields&&current&&evidenceValid,failed:status==='FAILED'&&hashValid&&fields,validStatus};
}
function legacyValidity(source,meta){
  const test={...source,status:normalizedStatus(source?.status)},date=validDate(source?.completed_at),common=typeof test.test_id==='string'&&test.test_id&&Array.isArray(test.failure_mode_ids)&&test.failure_mode_ids.length&&typeof test.revision==='string'&&test.revision===meta.revision&&typeof test.baseline_fingerprint==='string'&&test.baseline_fingerprint===meta.baseline_fingerprint,fields=typeof test.actual_result==='string'&&test.actual_result.trim()&&typeof test.acceptance_criteria==='string'&&test.acceptance_criteria.trim()&&typeof test.reviewer==='string'&&test.reviewer.trim()&&date;
  return {...test,hashValid:true,planMatch:true,fields:!!fields,current:!!common,evidenceValid:evidenceIsValid(test,meta),pass:test.status==='PASS'&&common&&fields&&evidenceIsValid(test,meta),failed:test.status==='FAILED'&&common,validStatus:TEST_STATUSES.includes(test.status),legacy:true};
}
function cycleIds(tests){const byId=new Map(tests.map(t=>[t.test_id,t])),bad=new Set();for(const test of tests){let cur=test,seen=new Set([test.test_id]);while(cur?.retest_of){if(seen.has(cur.retest_of)){for(const id of seen)bad.add(id);bad.add(cur.retest_of);break;}seen.add(cur.retest_of);cur=byId.get(cur.retest_of);}}return bad;}
function acceptanceValid(row,modeId,meta){return row?.failure_mode_id===modeId&&Records.acceptanceHashValid(row)&&bindingMatches(row,meta)&&typeof row.reason==='string'&&!!row.reason.trim()&&typeof row.responsible_person==='string'&&!!row.responsible_person.trim()&&typeof row.conditions==='string'&&!!row.conditions.trim()&&Array.isArray(row.follow_up_actions)&&row.follow_up_actions.length>0;}
function dispositionValid(row,fail,modeId,meta){return row?.failed_test_id===fail.test_id&&(row.failure_mode_ids||[]).includes(modeId)&&Records.recordHashValid(row)&&bindingMatches(row,meta)&&typeof row.reason==='string'&&!!row.reason.trim()&&typeof row.reviewed_by==='string'&&!!row.reviewed_by.trim();}
class FMEAService {
 evaluate(model={},meta={}){
  if(!Array.isArray(model.items)||!model.items.length)return createCapabilityResult({capability:'quality.dfmea',status:'NOT_EVALUATED_MISSING_INPUT',method:'dfmea_risk_engine',inputs:model,result:{missing_inputs:['items_with_failure_modes']},confidence:0,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,limitations:['Provide at least one DFMEA item, function and failure mode before evaluating risk.']});
  const linked=new Map(),invalidLinks=[];for(const link of model.requirement_links||[]){if(link?.failure_mode_id&&link?.requirement_id&&(!Array.isArray(meta.valid_requirement_ids)||meta.valid_requirement_ids.includes(link.requirement_id)))linked.set(link.failure_mode_id,link.requirement_id);else invalidLinks.push(link);}
  const canonical=Array.isArray(meta.test_records),planItems=new Map((meta.verification_plan?.items||[]).map(item=>[item.plan_item_id,item])),sources=canonical?meta.test_records:(model.verification_tests||[]),tests=[],invalidTests=[],testIds=new Set();
  for(const source of sources){const test=canonical?canonicalValidity(source,meta,planItems):legacyValidity(source,meta);const structuralInvalid=!test.validStatus||!test.test_id||testIds.has(test.test_id)||!Array.isArray(test.failure_mode_ids)||test.failure_mode_ids.some(id=>typeof id!=='string'||!id)||(canonical&&(!test.hashValid||!test.fields));if(structuralInvalid){invalidTests.push({test_id:test.test_id||null,reason:!test.hashValid?'TEST_RECORD_HASH_INVALID':!test.fields?'EXECUTION_METADATA_INVALID':'INVALID_TEST_RECORD',status:test.status});continue;}testIds.add(test.test_id);tests.push(test);if(canonical&&!test.planMatch)invalidTests.push({test_id:test.test_id,reason:'PLAN_BINDING_INVALID',status:test.status});}
  const cycles=cycleIds(tests);for(const id of cycles)invalidTests.push({test_id:id,reason:'INVALID_RETEST_CYCLE'});
  const failureModes=[],seenModes=new Set(),invalidItems=[];
  for(const item of model.items){if(!item?.item_id||!Array.isArray(item.failure_modes)||!item.failure_modes.length){invalidItems.push(item?.item_id||null);continue;}for(const mode of item.failure_modes){
    if(!mode?.failure_mode_id||seenModes.has(mode.failure_mode_id)||!mode.effect||!mode.cause){invalidItems.push(item.item_id);continue;}seenModes.add(mode.failure_mode_id);
    const severity=score(mode.severity,'severity'),occurrence=score(mode.occurrence,'occurrence'),detection=score(mode.detection,'detection'),rpn=severity*occurrence*detection;
    const modeTests=tests.filter(test=>test.failure_mode_ids.includes(mode.failure_mode_id)&&!cycles.has(test.test_id)),currentPass=modeTests.filter(test=>test.pass),allFails=modeTests.filter(test=>test.status==='FAILED'&&test.hashValid&&test.fields),dispositions=meta.failure_dispositions||[];
    const unresolvedFails=allFails.filter(fail=>{
      if(dispositions.some(row=>dispositionValid(row,fail,mode.failure_mode_id,meta)))return false;
      return !currentPass.some(retest=>retest.retest_of===fail.test_id&&retest.test_id!==fail.test_id&&Date.parse(retest.completed_at)>Date.parse(fail.completed_at));
    });
    const verificationStatus=unresolvedFails.length?'RISK_REOPENED':currentPass.length?'VERIFIED':'VERIFICATION_GAP',requiresAcceptance=Records.requiresResidualAcceptance({severity,occurrence,detection}),acceptance=(meta.risk_acceptances||[]).find(row=>acceptanceValid(row,mode.failure_mode_id,meta))||null;
    failureModes.push({item_id:item.item_id,function:item.function||null,failure_mode_id:mode.failure_mode_id,effect:mode.effect,cause:mode.cause,controls:[...(mode.controls||[])],requirement_id:linked.get(mode.failure_mode_id)||null,severity,occurrence,detection,rpn,action_priority:actionPriority(severity,occurrence,detection),action_priority_basis:'INTERNAL_HEURISTIC_NOT_STANDARD_AP',verification_status:verificationStatus,verification_test_ids:modeTests.map(test=>test.test_id),unresolved_failed_test_ids:unresolvedFails.map(test=>test.test_id),residual_risk_acceptance_required:requiresAcceptance,residual_risk_acceptance_id:acceptance?.acceptance_id||null});
  }}
  if(!failureModes.length)return createCapabilityResult({capability:'quality.dfmea',status:'NOT_EVALUATED_MISSING_INPUT',method:'dfmea_risk_engine',inputs:model,result:{missing_inputs:['valid_failure_modes'],invalid_items:invalidItems},confidence:0,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,limitations:['Empty, duplicate or malformed failure modes cannot be treated as an evaluation.']});
  const verificationGaps=failureModes.filter(mode=>mode.verification_status==='VERIFICATION_GAP').map(mode=>mode.failure_mode_id),reopened=failureModes.filter(mode=>mode.verification_status==='RISK_REOPENED').map(mode=>mode.failure_mode_id),acceptanceGaps=failureModes.filter(mode=>mode.verification_status==='VERIFIED'&&mode.residual_risk_acceptance_required&&!mode.residual_risk_acceptance_id).map(mode=>mode.failure_mode_id);
  const incomplete=verificationGaps.length||reopened.length||acceptanceGaps.length||invalidItems.length||invalidTests.length||invalidLinks.length;
  return createCapabilityResult({capability:'quality.dfmea',status:incomplete?'PARTIALLY_EVALUATED':'EVALUATED',method:'dfmea_risk_engine_v0.20.3',inputs:model,result:{failure_modes:failureModes,verification_gaps:verificationGaps,risk_reopened:reopened,residual_risk_acceptance_gaps:acceptanceGaps,invalid_tests:invalidTests,invalid_links:invalidLinks,coverage:{failure_modes:failureModes.length,verified:failureModes.filter(mode=>mode.verification_status==='VERIFIED').length},risk_policy_version:Records.RISK_POLICY_VERSION},confidence:0.8,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,limitations:['Only a server-bound append-only PASS on the current project, Revision, design baseline, risk definition and verification-plan version can be VERIFIED.','A prior FAILED execution remains open until an explicitly linked, later, current valid retest or reviewed disposition addresses that exact failure.','Action Priority and residual-risk acceptance thresholds are internal DesignGate governance heuristics, not a standards-based AP implementation.','Test PASS and control effectiveness do not automatically constitute residual-risk acceptance or production release.']});
 }
}
module.exports=FMEAService;module.exports.TEST_STATUSES=TEST_STATUSES;module.exports.normalizedStatus=normalizedStatus;module.exports.bindingMatches=bindingMatches;
