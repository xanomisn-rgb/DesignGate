const LEGACY_DEFAULT_TOKEN_BUDGET=180000;
const DEFAULTS=Object.freeze({
  baseUrl:'https://api.deepseek.com/v1',apiKey:'',model:'deepseek-chat',temperature:0.1,systemPrompt:'',isEncrypted:false,
  maxOutputTokens:null,modelContextWindowTokens:null,modelRequestTimeoutMs:120000,maxLengthRecoveryAttempts:2,maxProviderRetries:1,
  cumulativeTokenBudgetEnabled:false,cumulativeTokenBudget:null,maxToolSteps:80,maxModelRequests:120,maxNegotiationRounds:24,agentRunDurationMs:900000,reviewPipelineTimeoutMs:1800000
});
function nullablePositiveInt(value,name){if(value===undefined||value===null||value==='')return null;const n=typeof value==='string'?Number(value):value;if(!Number.isInteger(n)||n<=0||!Number.isFinite(n))throw Error(name+' 必须为正整数或留空');return n;}
function positiveInt(value,name,def){if(value===undefined||value===null||value==='')return def;const n=typeof value==='string'?Number(value):value;if(!Number.isInteger(n)||n<=0||!Number.isFinite(n))throw Error(name+' 必须为正整数');return n;}
function bool(value,def=false){if(value===undefined)return def;if(typeof value==='boolean')return value;if(value==='true'||value==='1'||value===1)return true;if(value==='false'||value==='0'||value===0||value==='')return false;throw Error('布尔配置值无效');}
function migrateSaved(saved={}){
  const out={...DEFAULTS,...saved};
  // v0.20.2 historical default: maxTokens=180000 was an application hard stop, not an explicit user budget.
  if(Object.hasOwn(saved,'maxTokens')){
    const legacy=Number(saved.maxTokens);
    if(Number.isFinite(legacy)&&legacy>0&&legacy!==LEGACY_DEFAULT_TOKEN_BUDGET&&!Object.hasOwn(saved,'cumulativeTokenBudget')){out.cumulativeTokenBudgetEnabled=true;out.cumulativeTokenBudget=Math.floor(legacy);}
    else if(legacy===LEGACY_DEFAULT_TOKEN_BUDGET&&!Object.hasOwn(saved,'cumulativeTokenBudgetEnabled')){out.cumulativeTokenBudgetEnabled=false;out.cumulativeTokenBudget=null;}
  }
  if((saved.cumulativeTokenBudget===LEGACY_DEFAULT_TOKEN_BUDGET)&&saved.cumulativeTokenBudgetEnabled!==true){out.cumulativeTokenBudgetEnabled=false;out.cumulativeTokenBudget=null;}
  if(saved.tokenBudgetEnabled!==undefined&&!Object.hasOwn(saved,'cumulativeTokenBudgetEnabled'))out.cumulativeTokenBudgetEnabled=bool(saved.tokenBudgetEnabled,false);
  if(out.cumulativeTokenBudgetEnabled!==true)out.cumulativeTokenBudget=null;
  delete out.maxTokens;delete out.tokenBudgetEnabled;
  return out;
}
function normalize(input={},base=DEFAULTS){
  const cfg=migrateSaved({...base,...input});
  const url=new URL(cfg.baseUrl||base.baseUrl);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('模型端点必须是无内嵌凭据的 HTTP(S) URL');
  const temperature=typeof cfg.temperature==='string'?Number(cfg.temperature):cfg.temperature;if(!Number.isFinite(temperature)||temperature<0||temperature>2)throw Error('温度范围为0–2');
  const budgetEnabled=bool(cfg.cumulativeTokenBudgetEnabled,false),budget=nullablePositiveInt(cfg.cumulativeTokenBudget,'累计 token 预算');if(budgetEnabled&&budget===null)throw Error('启用累计 token 预算时必须填写正整数预算');
  return {...cfg,baseUrl:url.href.replace(/\/$/,''),model:String(cfg.model||base.model),temperature,systemPrompt:String(cfg.systemPrompt||''),
    maxOutputTokens:nullablePositiveInt(cfg.maxOutputTokens,'模型单次最大输出 token'),modelContextWindowTokens:nullablePositiveInt(cfg.modelContextWindowTokens,'模型上下文窗口 token'),
    modelRequestTimeoutMs:positiveInt(cfg.modelRequestTimeoutMs,'单次模型请求超时',DEFAULTS.modelRequestTimeoutMs),maxLengthRecoveryAttempts:Math.min(4,positiveInt(cfg.maxLengthRecoveryAttempts,'截断恢复次数',DEFAULTS.maxLengthRecoveryAttempts)),maxProviderRetries:Math.min(2,positiveInt(cfg.maxProviderRetries,'供应商重试次数',DEFAULTS.maxProviderRetries)),
    cumulativeTokenBudgetEnabled:budgetEnabled,cumulativeTokenBudget:budgetEnabled?budget:null,maxToolSteps:positiveInt(cfg.maxToolSteps,'每段工具步数',DEFAULTS.maxToolSteps),maxModelRequests:positiveInt(cfg.maxModelRequests,'每段模型请求数',DEFAULTS.maxModelRequests),maxNegotiationRounds:positiveInt(cfg.maxNegotiationRounds,'每段协商轮数',DEFAULTS.maxNegotiationRounds),agentRunDurationMs:positiveInt(cfg.agentRunDurationMs,'Agent 每段运行时间',DEFAULTS.agentRunDurationMs),reviewPipelineTimeoutMs:positiveInt(cfg.reviewPipelineTimeoutMs,'正式评审超时',DEFAULTS.reviewPipelineTimeoutMs)};
}
function agentOptions(cfg){return {maxToolSteps:cfg.maxToolSteps,maxModelRequests:cfg.maxModelRequests,maxNegotiationRounds:cfg.maxNegotiationRounds,maxDurationMs:cfg.agentRunDurationMs,cumulativeTokenBudget:cfg.cumulativeTokenBudgetEnabled?cfg.cumulativeTokenBudget:null,tokenBudgetEnabled:cfg.cumulativeTokenBudgetEnabled,outputTokenReserve:cfg.maxOutputTokens||0};}
function publicView(cfg){return {baseUrl:cfg.baseUrl,model:cfg.model,temperature:cfg.temperature,systemPrompt:cfg.systemPrompt,isKeyConfigured:!!cfg.apiKey,isEncrypted:!!cfg.isEncrypted,maxOutputTokens:cfg.maxOutputTokens,modelContextWindowTokens:cfg.modelContextWindowTokens,modelRequestTimeoutMs:cfg.modelRequestTimeoutMs,maxLengthRecoveryAttempts:cfg.maxLengthRecoveryAttempts,cumulativeTokenBudgetEnabled:cfg.cumulativeTokenBudgetEnabled,cumulativeTokenBudget:cfg.cumulativeTokenBudget,maxToolSteps:cfg.maxToolSteps,maxModelRequests:cfg.maxModelRequests,maxNegotiationRounds:cfg.maxNegotiationRounds,agentRunDurationMs:cfg.agentRunDurationMs,reviewPipelineTimeoutMs:cfg.reviewPipelineTimeoutMs,providerQuotaPolicy:'供应商账号配额由模型服务商执行，DesignGate 不绕过。'};}
module.exports={DEFAULTS,LEGACY_DEFAULT_TOKEN_BUDGET,migrateSaved,normalize,agentOptions,publicView};
