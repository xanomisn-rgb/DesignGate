function summarize(measurement){
 if(!measurement||typeof measurement!=='object')return null;
 const {samples=[],...metadata}=measurement;
 const valid=samples.filter(s=>s&&Number.isFinite(s.normal_chord_mm));
 const selected=[...valid].sort((a,b)=>a.normal_chord_mm-b.normal_chord_mm).slice(0,6);
 for(const s of samples.filter(s=>s?.visibility_plus==='OCCLUDED'&&s?.visibility_minus==='OCCLUDED').slice(0,6))if(!selected.includes(s))selected.push(s);
 return {...metadata,samples:selected,samples_truncated:samples.length>selected.length,total_stored_samples:samples.length,
   scope:'BOUNDED_SURFACE_SAMPLES_NOT_GLOBAL_DFM_PASS'};
}
function observation(geometry,hypothetical=false,binding={}){
 if(!geometry?.surface_measurements)return {status:'NO_BREP_SURFACE_MEASUREMENTS'};
 const m=geometry.surface_measurements;
 if(!geometry.source_sha256||m.source_sha256!==geometry.source_sha256)return {status:'GEOMETRY_SOURCE_MISMATCH'};
 if(geometry.measurement_revision&&m.measurement_revision!==geometry.measurement_revision)return {status:'GEOMETRY_REVISION_MISMATCH',
   expected_revision:geometry.measurement_revision,measurement_revision:m.measurement_revision||null,source_sha256:geometry.source_sha256};
 const measuredRevision=m.measurement_revision||geometry.measurement_revision||null;
 if(binding.revision&&!measuredRevision)return {status:'GEOMETRY_REVISION_UNBOUND',
   expected_revision:binding.revision,measurement_revision:null,source_sha256:geometry.source_sha256};
 if(binding.revision&&measuredRevision&&binding.revision!==measuredRevision)return {status:'GEOMETRY_REVISION_MISMATCH',
   expected_revision:binding.revision,measurement_revision:measuredRevision,source_sha256:geometry.source_sha256};
 return {status:hypothetical?'ORIGINAL_GEOMETRY_NOT_PATCH_VALIDATED':'SAVED_SOURCE_BOUND_SAMPLES',
   source_sha256:geometry.source_sha256,measurement_revision:measuredRevision,measurement:summarize(m),formal_gate_pass:false,
   design_parameter_substitution:false};
}
module.exports={summarize,observation};
