const C=require('./contracts');
const Check=require('./check_engine');
const Gate=require('./gate_engine');
function prepare(project,change){
 const next=structuredClone(project),diff=[];
 const set=(entity,id,object,field,value)=>{const old=object[field]??null;if(C.hash(old)===C.hash(value))return;diff.push({entity,id,field,old_value:old,new_value:value});object[field]=value;};
 for(const [k,v] of Object.entries(C.design(change.design_patch||{})))set('design',null,next.design,k,v);
 if(change.requirements){const rows=C.requirements(change.requirements);set('project',null,next,'requirements',rows);}
 const seen=new Set();
 for(const item of change.bom_patches||[]){
   if(seen.has(item.part_id))throw Error('同一提案不能重复修改一个 BOM 零件');seen.add(item.part_id);
   const row=next.bom?.find(r=>r.part_id===item.part_id);if(!row)throw Error('BOM 零件不存在：'+item.part_id);
   const before=diff.length;
   for(const [k,v] of Object.entries(item.spec))set('bom',item.part_id,row,k,v);
   if(diff.length>before){set('bom',item.part_id,row,'unit_cost',null);set('bom',item.part_id,row,'quote_source',null);row.quote_status='INVALIDATED_BY_SPEC_CHANGE';}
 }
 if(change.design_intent){
   next.memory=next.memory||{};next.memory.design_intent=next.memory.design_intent||{};
   for(const [k,v] of Object.entries(change.design_intent))set('intent',null,next.memory.design_intent,k,v);
   if(next.memory.design_intent.target_price_max!=null&&!next.memory.design_intent.currency)throw Error('价格意图需要明确币种');
 }
 if(!diff.length)throw Error('草案没有实际变更');
 if(change.requirements&&change.requirements.length===0)throw Error('Agent 草案不能清空需求基线');
 C.bom(next.bom||[]);
 return {next,diff};
}
function apply(project,draft,runId){
 const {next,diff}=prepare(project,draft.proposal);
 const preflight=require('./proposal_critique').critique(project,next);
 if(preflight.status==='BLOCKED_REGRESSION')throw Error('提交前复筛发现退化，请重新生成提案');
 if(C.hash(diff)!==draft.diff_hash)throw Error('草案差异已改变，请重新生成');
 if(draft.proposal.requirements)next.requirements=next.requirements.map(r=>({...r,origin:'USER_APPROVED_AGENT_PROPOSAL',source_run:runId,verified:false}));
 const provenance={origin:'USER_APPROVED_AGENT_PROPOSAL',run_id:runId,draft_id:draft.draft_id,measured:false};
 next.field_provenance={...next.field_provenance,...Object.fromEntries(diff.filter(d=>d.entity==='design').map(d=>[d.field,provenance]))};
 for(const part of draft.proposal.bom_patches||[])next.bom.find(r=>r.part_id===part.part_id).spec_provenance=provenance;
 if(draft.proposal.design_intent)next.memory.design_intent_provenance={...next.memory.design_intent_provenance,...Object.fromEntries(Object.keys(draft.proposal.design_intent).map(k=>[k,{...provenance,recorded_at:new Date().toISOString()}]))};
 next.verifications=[];next.basis_hash=null;next.last_review=null;next.checks=[];next.approval=null;
 // Re-screen now but never create a formal review or inherit a release decision.
 const screening=new Check().evaluate(next);
 next.agent_patch_screening={checks:screening.checks,findings:screening.findings,gate:new Gate().evaluateGate('Gate 2',screening.findings,{checks:screening.checks}),formal_review:false};
 next.gate={current_stage:'Gate 1',status:'OPEN'};
 next.agent_applied_drafts=[...(next.agent_applied_drafts||[]),draft.draft_id];
 next.agent_changes=[...(next.agent_changes||[]),{draft_id:draft.draft_id,run_id:runId,revision:next.design.active_revision,diff,reason:draft.proposal.reason,at:new Date().toISOString()}];
 return next;
}
module.exports={prepare,apply};
