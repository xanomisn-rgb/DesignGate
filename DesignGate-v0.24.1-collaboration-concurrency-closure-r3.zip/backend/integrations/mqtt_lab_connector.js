const {EventEmitter}=require('events');

class MqttIntegrationError extends Error {
  constructor(code,message,details={}){super(message);this.name='MqttIntegrationError';this.code=code;Object.assign(this,details);}
}

function toIntegrationError(error){
  if(error instanceof MqttIntegrationError)return error;
  if(error?.code==='HMAC_SIGNATURE_MISMATCH'||error?.code==='UNAUTHORIZED')return error;
  if(error?.returnCode===4||error?.code===4||error?.returnCode===5||error?.code===5||/bad user|not authorized|connection refused/i.test(String(error?.message||'')))return new MqttIntegrationError('MQTT_AUTHENTICATION_FAILED','MQTT broker rejected credentials',{returnCode:error?.returnCode||error?.code||null});
  return new MqttIntegrationError('MQTT_CONNECTION_FAILED',String(error?.message||error));
}

class MqttLabConnector extends EventEmitter {
  constructor({gateway,workflow=null,brokerUrl,username, password,topic='lab/telemetry',clientId=`designgate-lab-${process.pid}`,timeoutMs=5000,connect=null,logger=()=>{}}={}){
    super();if(!gateway||typeof gateway.ingest!=='function')throw Error('MQTT connector requires LabDeviceGateway');if(typeof brokerUrl!=='string'||!brokerUrl)throw Error('MQTT broker URL is required');
    this.gateway=gateway;this.workflow=workflow;this.brokerUrl=brokerUrl;this.topic=topic;this.timeoutMs=timeoutMs;this.logger=logger;this.clientId=clientId;this.credentials={username,password};this.connect=connect||require('mqtt').connect;this.client=null;this.receivedCount=0;this.acceptedCount=0;
  }
  start(){
    if(this.client)return Promise.resolve(this);
    return new Promise((resolve,reject)=>{
      let settled=false;const finish=(error)=>{if(settled)return;settled=true;clearTimeout(timer);if(error){this.client?.end?.(true);this.client=null;reject(toIntegrationError(error));}else resolve(this);};
      const timer=setTimeout(()=>finish(new MqttIntegrationError('MQTT_CONNECTION_TIMEOUT','MQTT connection timed out')) ,this.timeoutMs);
      try { this.client=this.connect(this.brokerUrl,{protocolVersion:4,clientId:this.clientId,clean:true,reconnectPeriod:0,username:this.credentials.username,password:this.credentials.password}); }
      catch(error){finish(error);return;}
      this.client.once('error',error=>finish(error));
      this.client.once('connect',()=>this.client.subscribe(this.topic,{qos:1},error=>finish(error||null)));
      this.client.on('message',(topic,buffer)=>this.receive(topic,buffer));
    });
  }
  receive(topic,buffer){
    this.receivedCount+=1;
    if(topic!==this.topic)return this.reject('MQTT_TOPIC_REJECTED','Unexpected MQTT topic',{topic});
    let payload;try{payload=JSON.parse(Buffer.from(buffer).toString('utf8'));}catch(error){return this.reject('MQTT_PAYLOAD_INVALID','MQTT telemetry payload is not JSON',{topic});}
    try {
      const result=this.workflow?this.gateway.ingestToWorkflow(payload,this.workflow):this.gateway.ingest(payload);
      this.acceptedCount+=1;this.emit('accepted',result);return result;
    } catch(error) { return this.reject(error?.code||(/signature/.test(String(error?.message))?'HMAC_SIGNATURE_MISMATCH':'MQTT_TELEMETRY_REJECTED'),String(error?.message||error),{topic,device_id:payload?.device_id,project_id:payload?.project_id}); }
  }
  reject(code,message,details={}){const row={level:'warn',code,message,...details};this.logger(row);this.emit('rejected',row);return {status:'REJECTED',...row};}
  stop(){return new Promise(resolve=>{if(!this.client)return resolve();const client=this.client;this.client=null;client.end(true,resolve);});}
}

module.exports=MqttLabConnector;
module.exports.MqttIntegrationError=MqttIntegrationError;
module.exports.toIntegrationError=toIntegrationError;
