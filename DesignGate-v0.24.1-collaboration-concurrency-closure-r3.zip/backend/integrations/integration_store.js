const fs=require('fs');
const path=require('path');
class Store{
 constructor(dir){this.dir=dir;fs.mkdirSync(dir,{recursive:true});this.file=path.join(dir,'integration-events.jsonl');this.indexFile=path.join(dir,'integration-event-index.json');}
 rows(){if(!fs.existsSync(this.file))return[];return fs.readFileSync(this.file,'utf8').split('\n').filter(Boolean).map(line=>JSON.parse(line));}
 readIndex(){try{return JSON.parse(fs.readFileSync(this.indexFile,'utf8'));}catch{return {schema_version:'1.0',projects:{}};}}
 writeIndex(index){const temp=this.indexFile+'.tmp';fs.writeFileSync(temp,JSON.stringify(index,null,2),{encoding:'utf8',mode:0o600});fs.renameSync(temp,this.indexFile);}
 append(event){fs.appendFileSync(this.file,JSON.stringify(event)+'\n',{encoding:'utf8',mode:0o600});const index=this.readIndex(),project=index.projects[event.project_id]||{event_count:0,last_event_hash:null,last_event_id:null,last_received_at:null};project.event_count++;project.last_event_hash=event.event_hash;project.last_event_id=event.event_id;project.last_received_at=event.received_at;index.projects[event.project_id]=project;this.writeIndex(index);return event;}
 find(projectId,sourceId,eventType,idempotencyKey){return this.rows().find(row=>row.project_id===projectId&&row.source_id===sourceId&&row.event_type===eventType&&row.idempotency_key===idempotencyKey)||null;}
 list(projectId){return this.rows().filter(row=>!projectId||row.project_id===projectId);}
 index(projectId){const project=this.readIndex().projects[projectId];if(project)return {...project};const rows=this.list(projectId);return {event_count:rows.length,last_event_hash:rows.at(-1)?.event_hash||null,last_event_id:rows.at(-1)?.event_id||null,last_received_at:rows.at(-1)?.received_at||null};}
}
module.exports=Store;
