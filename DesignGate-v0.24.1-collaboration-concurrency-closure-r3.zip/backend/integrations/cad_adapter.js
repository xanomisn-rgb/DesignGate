const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {CadAnalysisRunner}=require('./cad_analysis_runner');
const IntegrationEventBus=require('./integration_event_bus');

function string(value,name){if(typeof value!=='string'||!value.trim())throw Error(`${name} is required`);return value.trim();}
function analysisSummary(analysis={}){
 return {
  file_sha256:analysis.file_sha256||null,analysis_status:analysis.analysis_status||'NOT_EVALUATED',
  analyzer_backend:analysis.analyzer_backend||null,analyzer_version:analysis.analyzer_version||null,
  solid_count:Number.isInteger(analysis.solid_count)?analysis.solid_count:null,
  face_count:Number.isInteger(analysis.face_count)?analysis.face_count:null,
  bounding_box:analysis.bounding_box||null,assembly_analysis:analysis.assembly_analysis||null,
  thickness_oracle:analysis.thickness_oracle||null,undercut_oracle:analysis.undercut_oracle||null,
  limitations:Array.isArray(analysis.limitations)?analysis.limitations:[]
 };
}
class CadAdapter{
 constructor({stateManager,workflowService,eventBus,runner,results_directory}={}){if(!stateManager||!workflowService)throw Error('CAD_ADAPTER_REQUIRES_WORKFLOW_AND_STATE');this.stateManager=stateManager;this.workflowService=workflowService;this.eventBus=eventBus||new IntegrationEventBus(path.join(stateManager.projectsDir,'integration-events'));this.runner=runner||new CadAnalysisRunner();this.resultsFile=path.join(results_directory||path.join(stateManager.projectsDir,'integration-events'),'cad-adapter-results.jsonl');fs.mkdirSync(path.dirname(this.resultsFile),{recursive:true});}
 results(){return fs.existsSync(this.resultsFile)?fs.readFileSync(this.resultsFile,'utf8').split('\n').filter(Boolean).map(JSON.parse):[];}
 recordResult(result){fs.appendFileSync(this.resultsFile,JSON.stringify(result)+'\n',{encoding:'utf8',mode:0o600});return result;}
 publish(input){return this.eventBus.publish({occurred_at:new Date().toISOString(),...input});}
 appendProjectEvents(project,eventRows){project.integration_events=[...(project.integration_events||[]),...eventRows.map(event=>({integration_event_id:event.event_id,event_type:event.event_type,status:event.status,revision:event.revision,source:event.source,received_at:event.received_at,payload_hash:event.payload_sha256}))];return this.stateManager.saveProject(project,project.version);}
 async upload(input={}){
  const project_id=string(input.project_id,'project_id'),revision=string(input.revision,'revision'),source_system=string(input.source_system,'source_system'),idempotency_key=string(input.idempotency_key,'idempotency_key');if(!input.authorization?.authorized)throw Error('PROJECT_AUTHORIZATION_DENIED');if(typeof input.file_path!=='string'||!fs.existsSync(input.file_path)||!fs.statSync(input.file_path).isFile())throw Error('CAD_INPUT_MISSING');
  const project=this.stateManager.getProject(project_id);if(!project)throw Error('PROJECT_NOT_FOUND');if(project.design?.active_revision!==revision)throw Error('REJECT_OLD_REVISION');
  const file_sha256=crypto.createHash('sha256').update(fs.readFileSync(input.file_path)).digest('hex');const upload=this.publish({event_type:'CAD_REVISION_UPLOADED',project_id,revision,source:source_system,source_id:source_system,idempotency_key,payload:{file_sha256,size_bytes:fs.statSync(input.file_path).size}});
  if(upload.status==='DUPLICATE_REPLAY'){const stored=this.results().find(row=>row.upload_event_id===upload.event_id);if(!stored)throw Error('DUPLICATE_RESULT_MISSING');return {...stored,status:'DUPLICATE_REPLAY',duplicate_of:upload.event_id};}
  const events=[upload];const started=this.publish({event_type:'CAD_ANALYSIS_STARTED',project_id,revision,source:source_system,source_id:source_system,idempotency_key,payload:{upload_event_id:upload.event_id,file_sha256}});events.push(started);
  let analysis;try{analysis=await this.runner.analyze({input_path:input.file_path,params:input.params||{}});}catch(error){const failed=this.publish({event_type:'CAD_ANALYSIS_FAILED',project_id,revision,source:source_system,source_id:source_system,idempotency_key,payload:{upload_event_id:upload.event_id,file_sha256,error_code:String(error.message)} });this.appendProjectEvents(project,[...events,failed]);throw error;}
  if(analysis.file_sha256!==file_sha256)throw Error('CAD_ANALYSIS_FILE_HASH_MISMATCH');if(!analysis.analysis_success)throw Error(`CAD_ANALYSIS_INVALID:${analysis.analysis_status}`);
  const completed=this.publish({event_type:'CAD_ANALYSIS_COMPLETE',project_id,revision,source:source_system,source_id:source_system,idempotency_key,payload:{upload_event_id:upload.event_id,file_sha256,analysis_status:analysis.analysis_status,analyzer_backend:analysis.analyzer_backend,analyzer_version:analysis.analyzer_version}});events.push(completed);
  const current=this.stateManager.getProject(project_id);const added=this.workflowService.addEvidence(project_id,input.file_path,current.version,{source_kind:'CAD_ANALYSIS',source_id:source_system,source_event_id:completed.event_id,payload:{analysis},analyzer_backend:analysis.analyzer_backend,analyzer_version:analysis.analyzer_version,parser_version:'run_brep_analysis.py/1'});
  const created=this.publish({event_type:'EVIDENCE_CREATED',project_id,revision,source:source_system,source_id:source_system,idempotency_key,payload:{evidence_id:added.evidence.evidence_id,manifest_id:added.manifest.manifest_id,manifest_hash:added.manifest.manifest_hash,file_sha256}});events.push(created);
  const after=this.stateManager.getProject(project_id);after.cad_observations=[...(after.cad_observations||[]),{observation_id:`CADOBS-${completed.event_id}`,revision,file_sha256,analysis_status:analysis.analysis_status,event_id:completed.event_id,evidence_id:added.evidence.evidence_id,status:'NEEDS_HUMAN_REVIEW',analysis_summary:analysisSummary(analysis),limitations:analysis.limitations||[],authority:'CAD_OBSERVATION_NOT_GATE_DECISION'}];this.appendProjectEvents(after,events);
  const result={status:'ACCEPTED',upload_event_id:upload.event_id,event_id:completed.event_id,analysis_reference:{event_id:completed.event_id,analysis_status:analysis.analysis_status,file_sha256},evidence_reference:{evidence_id:added.evidence.evidence_id,manifest_id:added.manifest.manifest_id,manifest_hash:added.manifest.manifest_hash},revision};return this.recordResult(result);
 }
}
module.exports={CadAdapter};
