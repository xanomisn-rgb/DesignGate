const Store=require('./integration_store');
const Schema=require('./integration_schema');
class IntegrationEventBus{
 constructor(dir){this.store=new Store(dir);}
 publish(input){
  const event=Schema.validate(input), prior=this.store.find(event.project_id,event.source_id,event.event_type,event.idempotency_key);
  if(prior){if(prior.payload_sha256===event.payload_sha256)return {...prior,status:'DUPLICATE_REPLAY',duplicate_of:prior.event_id};throw Error('IDEMPOTENCY_CONFLICT');}
  const projectEvents=this.store.list(event.project_id);event.previous_event_hash=projectEvents.at(-1)?.event_hash||null;
  event.event_hash=Schema.hash({previous_event_hash:event.previous_event_hash,event_type:event.event_type,project_id:event.project_id,revision:event.revision,source:event.source,source_id:event.source_id,idempotency_key:event.idempotency_key,occurred_at:event.occurred_at,payload_sha256:event.payload_sha256});
  return this.store.append(event);
 }
 list(projectId){return this.store.list(projectId);}
 index(projectId){return this.store.index(projectId);}
 verifyReplay(projectId){const rows=this.store.list(projectId);let previous=null;const errors=[];for(const [index,row] of rows.entries()){if(Schema.hash(row.payload)!==row.payload_sha256)errors.push({index,event_id:row.event_id,reason:'PAYLOAD_HASH_MISMATCH'});const expected=Schema.hash({previous_event_hash:previous,event_type:row.event_type,project_id:row.project_id,revision:row.revision,source:row.source,source_id:row.source_id,idempotency_key:row.idempotency_key,occurred_at:row.occurred_at,payload_sha256:row.payload_sha256});if(row.previous_event_hash!==previous||row.event_hash!==expected)errors.push({index,event_id:row.event_id,reason:'EVENT_CHAIN_MISMATCH'});previous=row.event_hash;}return {project_id:projectId,status:errors.length?'INVALID':'VALID',event_count:rows.length,last_event_hash:previous,errors};}
}
module.exports=IntegrationEventBus;
