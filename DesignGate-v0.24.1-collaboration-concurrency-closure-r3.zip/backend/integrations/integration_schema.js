const crypto=require('crypto');
const Canonical=require('../crypto/canonical_json');
const EVENT_TYPES=new Set(['CAD_REVISION_UPLOADED','CAD_ANALYSIS_STARTED','CAD_ANALYSIS_COMPLETE','CAD_ANALYSIS_FAILED','LAB_TELEMETRY_RECEIVED','TEST_RECORD_CREATED','TEST_FAILED','TEST_PASSED','EVIDENCE_CREATED','REVISION_CHANGED','LMS_ASSIGNMENT_RECEIVED','LMS_RESULT_PENDING','LMS_RESULT_SYNCED']);
const STATUSES=new Set(['RECEIVED','VALIDATED','PROCESSED','ACKNOWLEDGED','RETRY_PENDING','REJECTED','DEAD_LETTER']);
const canonical=Canonical.canonicalize;
const hash=Canonical.sha256;
function string(value,name,max=200){if(typeof value!=='string'||!value.trim()||value.length>max)throw Error(`${name} is required`);return value.trim();}
function timestamp(value,name){if(typeof value!=='string'||Number.isNaN(Date.parse(value)))throw Error(`${name} must be an ISO timestamp`);return value;}
function validate(input={}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('integration event must be an object');
 const event_type=string(input.event_type,'event_type',80);if(!EVENT_TYPES.has(event_type))throw Error('unsupported integration event type');
 const event={event_id:input.event_id||`IEV-${crypto.randomUUID()}`,schema_version:'1.0',event_type,project_id:string(input.project_id,'project_id',80),revision:string(input.revision,'revision',80),source:string(input.source,'source',80),source_id:string(input.source_id,'source_id',160),idempotency_key:string(input.idempotency_key,'idempotency_key',160),occurred_at:timestamp(input.occurred_at,'occurred_at'),received_at:new Date().toISOString(),payload:input.payload};
 if(!event.payload||typeof event.payload!=='object'||Array.isArray(event.payload))throw Error('payload must be an object');
 event.payload_sha256=hash(event.payload);event.status='RECEIVED';return event;
}
module.exports={EVENT_TYPES,STATUSES,canonical,hash,validate};
