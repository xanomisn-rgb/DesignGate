const crypto=require('crypto');
const Canonical=require('../crypto/canonical_json');
const Bus=require('./integration_event_bus');
function compare(value,operator,threshold){if(operator==='<=')return value<=threshold;if(operator==='>=')return value>=threshold;if(operator==='===')return value===threshold;throw Error('unsupported verification operator');}
function safeEqual(expected,actual){const left=Buffer.from(expected,'hex'),right=Buffer.from(String(actual),'hex');return left.length===right.length&&crypto.timingSafeEqual(left,right);}
class LabDeviceGateway{
 constructor({deviceSecrets={},testResolver=()=>null,eventBus=null}={}){this.deviceSecrets=deviceSecrets;this.testResolver=testResolver;this.eventBus=eventBus||new Bus(require('path').join(require('os').tmpdir(),'designgate-lab-events',crypto.randomUUID()));}
 sign(payload,secret){if(typeof secret!=='string'||!secret)throw Error('HMAC secret required');const signing=Canonical.telemetrySigningInput(payload);return crypto.createHmac('sha256',secret).update(signing.text,'utf8').digest('hex');}
 ingest(input={}){
  const forbidden=['status','gate_status','risk_closed'].find(key=>Object.hasOwn(input,key));if(forbidden)throw Error(`forbidden telemetry property: ${forbidden}`);
  for(const key of ['device_id','project_id','revision','test_id','metric','unit','source_timestamp','idempotency_key','signature'])if(typeof input[key]!=='string'||!input[key].trim())throw Error(`missing ${key}`);
  if(!Number.isFinite(input.value)||!Number.isInteger(input.sequence)||input.sequence<0)throw Error('invalid telemetry measurement or sequence');
  const device=this.deviceSecrets[input.device_id],secret=typeof device==='string'?device:device?.secret,keyId=typeof device==='object'?(device.key_id||input.device_id):input.device_id;if(!secret)throw Object.assign(Error('unknown device'),{code:'UNAUTHORIZED'});
  if(Array.isArray(device?.project_ids)&&!device.project_ids.includes(input.project_id))throw Object.assign(Error('device is not authorized for project'),{code:'UNAUTHORIZED'});
  const expected=this.sign(input,secret);if(!safeEqual(expected,input.signature))throw Object.assign(Error('invalid telemetry signature'),{code:'HMAC_SIGNATURE_MISMATCH'});
  const plan=this.testResolver(input);if(!plan||plan.metric!==input.metric||plan.unit!==input.unit)throw Error('telemetry does not match current verification plan');
  const status=compare(input.value,plan.operator,plan.threshold)?'PASS':'FAIL';
  const source=device?.source==='MOCK'||input.device_id.startsWith('MOCK-')?'MOCK':input.device_id.startsWith('SIM-')?'SIMULATED_DEVICE':'DEVICE_TELEMETRY_NOT_LIVE_VERIFIED';
  const event=this.eventBus.publish({event_type:'LAB_TELEMETRY_RECEIVED',project_id:input.project_id,revision:input.revision,source,source_id:input.device_id,idempotency_key:input.idempotency_key,occurred_at:input.source_timestamp,payload:{device_id:input.device_id,test_id:input.test_id,sequence:input.sequence,metric:input.metric,value:input.value,unit:input.unit,signature_algorithm:'HMAC-SHA256',signature_input_version:Canonical.TELEMETRY_SIGNATURE_INPUT_VERSION,key_id:keyId,verification:{operator:plan.operator,threshold:plan.threshold,status}}});
  return {status:event.status,event,source,verification:{status,criterion:{operator:plan.operator,threshold:plan.threshold,unit:plan.unit},actual:{value:input.value,unit:input.unit}},engineering_release:false};
 }
 ingestToWorkflow(input,workflow){
  if(!workflow||typeof workflow.get!=='function'||typeof workflow.addEvidence!=='function'||typeof workflow.recordDfmeaTest!=='function')throw Error('workflow service is required');
  const result=this.ingest(input);if(result.status==='DUPLICATE_REPLAY')return {...result,workflow_status:'NO_DUPLICATE_SIDE_EFFECT'};
  const project=workflow.get(input.project_id);if(project.design?.active_revision!==input.revision)throw Error('telemetry revision is not current');
  const plan=this.testResolver(input);if(!plan.plan_item_id||!Array.isArray(plan.failure_mode_ids)||!plan.failure_mode_ids.length)throw Error('verification plan binding is required for DFMEA execution');
  const fs=require('fs'),os=require('os'),path=require('path');const file=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'dg-telemetry-')),'telemetry.json');
  try {
   fs.writeFileSync(file,JSON.stringify({event:result.event,telemetry:{device_id:input.device_id,metric:input.metric,value:input.value,unit:input.unit,source_timestamp:input.source_timestamp},verification:result.verification}),{mode:0o600});
   const evidence=workflow.addEvidence(input.project_id,file,project.version).evidence;
   const current=workflow.get(input.project_id);
   const recorded=workflow.recordDfmeaTest(input.project_id,{test_id:input.test_id,plan_item_id:plan.plan_item_id,failure_mode_ids:plan.failure_mode_ids,status:result.verification.status==='PASS'?'PASS':'FAILED',actual_result:`${input.metric}=${input.value} ${input.unit}`,reviewer:`integration:${input.device_id}`,completed_at:input.source_timestamp,evidence_id:evidence.evidence_id,retest_of:input.retest_of||undefined},current.version);
   return {...result,evidence_id:evidence.evidence_id,test_record_id:recorded.dfmea_test_records.at(-1)?.record_id,workflow_status:'RECORDED_THROUGH_WORKFLOW'};
  } finally {fs.rmSync(path.dirname(file),{recursive:true,force:true});}
 }
}
module.exports=LabDeviceGateway;
