class RevisionDiffEngine {
 computeDiff(pastIssues=[],currentIssues=[],studentResponse='',checks=[]) {
  const diff={resolved:[],unresolved:[],new_issues:[],accepted_risk:[],pending_verification:[]};
  const current=new Map(currentIssues.map(i=>[i.issue_id,i]));
  for(const old of pastIssues){
   if(old.status==='RESOLVED'&&!current.has(old.issue_id))continue;
   const now=current.get(old.issue_id);
   if(now){diff.unresolved.push({...now,status:['UNKNOWN','NEED_HUMAN_REVIEW'].includes(now.status)?now.status:'UNRESOLVED'});continue;}
   const check=checks.find(c=>c.issue_ids?.includes(old.issue_id)&&c.status==='PASS'&&c.input_fingerprint&&c.rule_version);
   if(check)diff.resolved.push({...old,status:'RESOLVED',closed_by_check:check.check_id,closure_evidence:check.input_fingerprint,closure_note:'对应检查已在当前版本成功执行并通过。'});
   else {const pending={...old,status:'NEED_HUMAN_REVIEW',closure_note:'本轮未取得对应检查通过的证据，不能判定问题已解决。',carried_forward:true};diff.pending_verification.push(pending);diff.unresolved.push(pending);}
  }
  for(const f of currentIssues)if(!pastIssues.some(p=>p.issue_id===f.issue_id&&p.status!=='RESOLVED'))diff.new_issues.push(f);
  return {metrics:{resolved_count:diff.resolved.length,unresolved_count:diff.unresolved.length,new_count:diff.new_issues.length,accepted_risk_count:0,pending_verification_count:diff.pending_verification.length},lineage:diff};
 }
}
module.exports=RevisionDiffEngine;
