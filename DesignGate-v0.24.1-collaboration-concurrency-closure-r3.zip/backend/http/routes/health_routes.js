function health(){return {status:'OK',scope:'LOOPBACK_ONLY',service:'DesignGate integration API'};}
module.exports={health};
