const REQUIRED=['project_id','revision','source_system','idempotency_key'];
function validateCadFields(fields,file){for(const key of REQUIRED)if(!fields[key])throw Object.assign(Error(`MISSING_${key.toUpperCase()}`),{http_status:400});if(!file||file.size_bytes===0)throw Object.assign(Error('STEP_EMPTY_OR_MISSING'),{http_status:422});if(!/\.(step|stp)$/i.test(file.filename||''))throw Object.assign(Error('STEP_EXTENSION_REQUIRED'),{http_status:422});return true;}
module.exports={REQUIRED,validateCadFields};
