const fs=require('fs');
const path=require('path');
const CONTRACT_PATH=path.join(__dirname,'../../docs/integrations/openapi.yaml');
function parseOpenApiYaml(text){if(typeof text!=='string'||!/^openapi:\s*3\.0\.3/m.test(text))throw Error('OPENAPI_PARSE_ERROR');const paths=[...text.matchAll(/^  (\/api\/[^:]+):$/gm)].map(match=>match[1]);const statuses=[...text.matchAll(/^        '([0-9]{3})':/gm)].map(match=>Number(match[1]));const required=(text.match(/required: \[([^\]]+)\]/)||[])[1]?.split(',').map(item=>item.trim())||[];return {paths,statuses,required,hasSecurity:/DesignGateIntegrationKey/.test(text),raw:text};}
function loadOpenApi(){return parseOpenApiYaml(fs.readFileSync(CONTRACT_PATH,'utf8'));}
module.exports={CONTRACT_PATH,parseOpenApiYaml,loadOpenApi};
