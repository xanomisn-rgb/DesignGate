const Canonical = require('../crypto/canonical_json');
const DfmeaRecords = require('../dfmea_records');
const FMEAService = require('../fmea_service');

function fail(code) { const error = new Error(code); error.code = code; throw error; }

class FinalFreezeService {
  constructor({ store, artifactVerifier = null } = {}) {
    if (!store) fail('FINAL_FREEZE_STORE_REQUIRED');
    this.store = store;
    this.artifactVerifier = artifactVerifier;
  }

  revalidate({ project_id, state }) {
    const revision_id = state?.design?.active_revision;
    if (!project_id || !revision_id) fail('FINAL_FREEZE_REVISION_REQUIRED');
    const evidence = (state.evidence || []).filter(row => row.project_id === project_id && row.revision_id === revision_id && row.status === 'CURRENT');
    for (const item of evidence) {
      const artifact = this.store.getArtifact(item.artifact_id);
      if (!artifact || !artifact.immutable || artifact.project_id !== project_id || artifact.revision_id !== revision_id || artifact.sha256 !== item.artifact_sha256 || (this.artifactVerifier && !this.artifactVerifier(artifact))) fail('ARTIFACT_INTEGRITY_INVALID');
    }
    let dfmea_evaluation = null;
    if (state.dfmea) {
      const bindings = DfmeaRecords.currentBindings(state);
      dfmea_evaluation = new FMEAService().evaluate(state.dfmea, {
        ...bindings,
        test_records: state.dfmea_test_records || [],
        verification_plan: state.dfmea_verification_plan || null,
        valid_evidence_ids: evidence.map(item => item.evidence_id),
        valid_requirement_ids: (state.requirements || []).map(item => item.req_id),
        risk_acceptances: state.risk_acceptances || [],
        failure_dispositions: state.dfmea_failure_dispositions || []
      });
      if (dfmea_evaluation.status !== 'EVALUATED') fail('FINAL_FREEZE_DFMEA_NOT_CLOSED');
    }
    const gate = state.gate;
    const gateRecord = gate?.gate_record;
    if (gate?.current_stage !== 'Gate 3' || gate?.status !== 'PASS' || gate?.freeze_eligible !== true
      || gateRecord?.revision !== revision_id || gateRecord?.decision !== 'PASS' || gateRecord?.freeze_eligible !== true) fail('FINAL_FREEZE_GATE_STALE');
    return {
      revision_id,
      artifact_manifest_hash: Canonical.sha256(evidence.map(row => ({ artifact_id: row.artifact_id, sha256: row.artifact_sha256 })).sort((a, b) => a.artifact_id.localeCompare(b.artifact_id))),
      evidence_set_hash: Canonical.sha256(evidence.map(row => ({ evidence_id: row.evidence_id, artifact_id: row.artifact_id, sha256: row.artifact_sha256 })).sort((a, b) => a.evidence_id.localeCompare(b.evidence_id))),
      verification_state_hash: Canonical.sha256(state.dfmea_test_records || []),
      dfmea_state_hash: Canonical.sha256({ dfmea: state.dfmea || null, verification_plan: state.dfmea_verification_plan || null, evaluation: dfmea_evaluation?.result || null }),
      risk_state_hash: Canonical.sha256(state.risk_acceptances || []),
      gate_state_hash: Canonical.sha256(state.gate?.gate_record || state.gate || {})
    };
  }

  validateApproval({ approval, bindings }) {
    if (!approval || approval.status !== 'CURRENT' || approval.decision !== 'APPROVED' || approval.revision_id !== bindings.revision_id) fail('STALE_APPROVAL');
    for (const field of ['evidence_set_hash', 'verification_state_hash', 'dfmea_state_hash', 'risk_state_hash', 'gate_state_hash']) if (approval[field] !== bindings[field]) fail('STALE_APPROVAL');
    return true;
  }
}

module.exports = FinalFreezeService;
