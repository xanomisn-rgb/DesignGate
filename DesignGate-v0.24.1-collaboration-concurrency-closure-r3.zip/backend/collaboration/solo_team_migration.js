const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function identifier(value, name) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)) fail(`INVALID_${name}`);
  return value;
}

function hashFile(filePath) {
  const bytes = fs.readFileSync(filePath);
  return { sha256: crypto.createHash('sha256').update(bytes).digest('hex'), size_bytes: bytes.length };
}

function pushReference(target, candidate, artifact_type, revision_id, source_id) {
  if (!candidate || typeof candidate !== 'string') return;
  target.push({ artifact_type, source_path: candidate, revision_id, source_id: source_id || null });
}

function discoverReferences(project) {
  const activeRevision = project.design?.active_revision || 'A';
  const references = [];
  for (const field of ['cad_path', 'cad_file', 'cad_file_path']) {
    pushReference(references, project.design?.[field], 'CAD', activeRevision, `design.${field}`);
  }
  for (const artifact of Array.isArray(project.cad_artifacts) ? project.cad_artifacts : []) {
    pushReference(references, artifact?.file_path || artifact?.filePath || artifact?.path, 'CAD', artifact?.revision_id || artifact?.revision || activeRevision, artifact?.artifact_id || null);
  }
  for (const evidence of Array.isArray(project.evidence) ? project.evidence : []) {
    pushReference(references, evidence?.file_path || evidence?.filePath || evidence?.path, 'EVIDENCE', evidence?.revision_id || evidence?.revision || activeRevision, evidence?.evidence_id || null);
  }
  return references;
}

function revisionCount(project) {
  const active = project.design?.active_revision || 'A';
  const revisions = new Set([active]);
  for (const edge of Array.isArray(project.revision_lineage) ? project.revision_lineage : []) {
    if (typeof edge?.from === 'string') revisions.add(edge.from);
    if (typeof edge?.to === 'string') revisions.add(edge.to);
  }
  return revisions.size;
}

function buildMigrationPlan({ soloProject, target_project_id } = {}) {
  if (!soloProject || typeof soloProject !== 'object' || Array.isArray(soloProject)) fail('SOLO_PROJECT_REQUIRED');
  const source_project_id = identifier(soloProject.project_id, 'SOURCE_PROJECT_ID');
  const targetProjectId = identifier(target_project_id, 'TARGET_PROJECT_ID');
  const artifacts = [];
  const missing_artifacts = [];
  const seen = new Set();
  for (const reference of discoverReferences(soloProject)) {
    const key = `${reference.artifact_type}:${reference.revision_id}:${reference.source_path}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (!fs.existsSync(reference.source_path) || !fs.statSync(reference.source_path).isFile()) {
      missing_artifacts.push({ ...reference, status: 'MISSING_ARTIFACT' });
      continue;
    }
    const digest = hashFile(reference.source_path);
    artifacts.push({ ...reference, ...digest, status: 'DISCOVERED', integrity_status: 'SHA256_COMPUTED' });
  }
  const dfmeaItems = Array.isArray(soloProject.dfmea?.items) ? soloProject.dfmea.items : (Array.isArray(soloProject.dfmea_items) ? soloProject.dfmea_items : []);
  const warnings = missing_artifacts.map(item => `MISSING_ARTIFACT:${item.source_id || item.source_path}`);
  const summary = { source_project_id, target_project_id: targetProjectId, artifacts: artifacts.map(item => ({ artifact_type: item.artifact_type, revision_id: item.revision_id, sha256: item.sha256 })), missing_artifacts };
  const migration_plan_id = `MPLAN-${crypto.createHash('sha256').update(JSON.stringify(summary)).digest('hex').slice(0, 20)}`;
  return {
    schema_version: '1.0',
    migration_plan_id,
    source_project_id,
    target_project_id: targetProjectId,
    source_schema_version: soloProject.schema_version || null,
    status: warnings.length ? 'READY_WITH_WARNINGS' : 'READY',
    created_at: new Date().toISOString(),
    counts: {
      requirements: Array.isArray(soloProject.requirements) ? soloProject.requirements.length : 0,
      bom: Array.isArray(soloProject.bom) ? soloProject.bom.length : 0,
      revisions: revisionCount(soloProject),
      artifacts: artifacts.length,
      missing_artifacts: missing_artifacts.length,
      evidence: Array.isArray(soloProject.evidence) ? soloProject.evidence.length : 0,
      tests: Array.isArray(soloProject.dfmea_test_records) ? soloProject.dfmea_test_records.length : 0,
      dfmea_items: dfmeaItems.length
    },
    artifacts,
    missing_artifacts,
    warnings,
    execution: 'NOT_EXECUTED_CONFIRMATION_REQUIRED',
    production_release: false
  };
}

function sourceEvidence(project, sourceId) {
  return (Array.isArray(project.evidence) ? project.evidence : []).find(item => item?.evidence_id === sourceId) || null;
}

function importedState(soloProject, artifactMap) {
  const state = {
    schema_version: '3.1-team-metadata-v1',
    project_id: soloProject.project_id,
    project_name: soloProject.project_name || soloProject.project_id,
    design: structuredClone(soloProject.design || { active_revision: 'A' }),
    requirements: structuredClone(Array.isArray(soloProject.requirements) ? soloProject.requirements : []),
    bom: structuredClone(Array.isArray(soloProject.bom) ? soloProject.bom : []),
    findings: structuredClone(Array.isArray(soloProject.findings) ? soloProject.findings : []),
    decisions: structuredClone(Array.isArray(soloProject.decisions) ? soloProject.decisions : []),
    revision_lineage: structuredClone(Array.isArray(soloProject.revision_lineage) ? soloProject.revision_lineage : []),
    dfmea: structuredClone(soloProject.dfmea || { items: [] }),
    dfmea_test_records: structuredClone(Array.isArray(soloProject.dfmea_test_records) ? soloProject.dfmea_test_records : []).map(record => ({ ...record, migration_status: 'LEGACY_IMPORTED_REQUIRES_REVALIDATION', authority: 'MIGRATED_APPEND_ONLY_HISTORY' })),
    verifications: [],
    evidence: []
  };
  for (const field of ['cad_path', 'cad_file', 'cad_file_path']) delete state.design[field];
  const currentCad = [...artifactMap.values()].find(item => item.artifact_type === 'CAD' && item.revision_id === state.design.active_revision) || [...artifactMap.values()].find(item => item.artifact_type === 'CAD');
  if (currentCad) Object.assign(state.design, { cad_artifact_id: currentCad.artifact_id, cad_artifact_sha256: currentCad.sha256, cad_artifact_revision: currentCad.revision_id });
  for (const [sourcePath, artifact] of artifactMap.entries()) {
    if (artifact.artifact_type !== 'EVIDENCE') continue;
    const original = sourceEvidence(soloProject, artifact.source_id) || {};
    state.evidence.push({
      evidence_id: typeof original.evidence_id === 'string' ? original.evidence_id : `EVD-MIG-${artifact.artifact_id}`,
      project_id: soloProject.project_id,
      revision_id: artifact.revision_id,
      artifact_id: artifact.artifact_id,
      artifact_sha256: artifact.sha256,
      purpose: typeof original.purpose === 'string' && original.purpose.trim() ? original.purpose.trim() : 'Migrated legacy evidence; revalidation required.',
      requirement_ids: Array.isArray(original.requirement_ids) ? [...original.requirement_ids] : [],
      status: 'HISTORICAL_REQUIRES_REVALIDATION',
      provenance: 'MIGRATED_LOCAL_FILE',
      immutable: true
    });
  }
  return state;
}

function executeMigration({ plan, soloProject, store, artifactStore, actor } = {}) {
  if (!plan || typeof plan !== 'object') fail('MIGRATION_PLAN_REQUIRED');
  if (!soloProject || typeof soloProject !== 'object') fail('SOLO_PROJECT_REQUIRED');
  if (!store || typeof store.createImportedProject !== 'function' || !artifactStore || typeof artifactStore.put !== 'function') fail('MIGRATION_SERVICE_UNAVAILABLE');
  const actor_id = identifier(actor?.user_id, 'ACTOR_ID');
  const expected = buildMigrationPlan({ soloProject, target_project_id: plan.target_project_id });
  if (plan.migration_plan_id !== expected.migration_plan_id || plan.source_project_id !== expected.source_project_id) fail('MIGRATION_PLAN_STALE_REPREFLIGHT_REQUIRED');
  if (expected.status !== 'READY') fail('MIGRATION_MISSING_ARTIFACTS');
  if (store.hasProject(expected.target_project_id)) fail('PROJECT_ALREADY_EXISTS');
  const importedArtifacts = [];
  const artifactMap = new Map();
  for (const discovered of expected.artifacts) {
    const metadata = artifactStore.put({ project_id: expected.target_project_id, revision_id: discovered.revision_id, artifact_type: discovered.artifact_type, original_filename: path.basename(discovered.source_path), bytes: fs.readFileSync(discovered.source_path), created_by: actor_id });
    if (metadata.sha256 !== discovered.sha256 || !artifactStore.verifyHash(metadata)) fail('MIGRATION_ARTIFACT_HASH_MISMATCH');
    const imported = { ...metadata, source_path: discovered.source_path, source_id: discovered.source_id };
    importedArtifacts.push(imported);
    artifactMap.set(discovered.source_path, imported);
  }
  const state = importedState(soloProject, artifactMap);
  store.createImportedProject({ project_id: expected.target_project_id, project_name: soloProject.project_name || expected.target_project_id, state, artifacts: importedArtifacts, source_project_id: expected.source_project_id, migration_plan_id: expected.migration_plan_id }, { user_id: actor_id });
  return {
    migration_id: `MIG-${crypto.randomUUID()}`,
    source_project_id: expected.source_project_id,
    target_project_id: expected.target_project_id,
    status: 'SUCCESS',
    artifact_count: importedArtifacts.length,
    requirements_count: expected.counts.requirements,
    bom_count: expected.counts.bom,
    revision_count: expected.counts.revisions,
    evidence_count: expected.counts.evidence,
    test_count: expected.counts.tests,
    dfmea_count: expected.counts.dfmea_items,
    uploaded_files: importedArtifacts.map(item => ({ artifact_id: item.artifact_id, sha256: item.sha256, artifact_type: item.artifact_type })),
    artifact_bindings: importedArtifacts.map(item => ({ source_id: item.source_id || null, artifact_id: item.artifact_id, sha256: item.sha256 })),
    missing_files: [],
    warnings: ['MIGRATED_RECORDS_REQUIRE_CURRENT_REVISION_REVALIDATION'],
    hash_verification: 'VERIFIED_AT_IMPORT',
    production_release: false
  };
}

module.exports = { buildMigrationPlan, executeMigration };
