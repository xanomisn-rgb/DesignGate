const PermissionService = require('./permission_service');
const DfmeaRecords = require('../dfmea_records');
const FMEAService = require('../fmea_service');
const ProfessionalGate = require('../professional_gate');
const GateV2 = require('../gate/gate_v2');
const Canonical = require('../crypto/canonical_json');
const FinalFreezeService = require('./final_freeze_service');

const COMMANDS = Object.freeze({
  UPDATE_BOM_ITEM: { entity_type: 'BOM_ITEM', action: 'UPDATE_BOM_ITEM', event_type: 'BOM_ITEM_UPDATED', collection: 'bom', id_field: 'part_id', required_field: 'part_name', required_error: 'BOM_PART_NAME_REQUIRED' },
  UPDATE_REQUIREMENT: { entity_type: 'REQUIREMENT', action: 'UPDATE_REQUIREMENT', event_type: 'REQUIREMENT_UPDATED', collection: 'requirements', id_field: 'req_id', required_field: 'text', required_error: 'REQUIREMENT_TEXT_REQUIRED' },
  REVISION_CREATE: { entity_type: 'REVISION', action: 'CREATE_REVISION', event_type: 'REVISION_CREATED', special: 'REVISION_CREATE' },
  CAD_ARTIFACT_REGISTER: { entity_type: 'CAD_ARTIFACT', action: 'UPLOAD_CAD_REVISION', event_type: 'CAD_ARTIFACT_CREATED', special: 'CAD_ARTIFACT_REGISTER' },
  EVIDENCE_ADD: { entity_type: 'EVIDENCE', action: 'ADD_EVIDENCE', event_type: 'EVIDENCE_ADDED', special: 'EVIDENCE_ADD' },
  COMMENT_CREATE: { entity_type: 'COMMENT', action: 'ADD_COMMENT', event_type: 'COMMENT_CREATED', special: 'COMMENT_CREATE' },
  COMMENT_RESOLVE: { entity_type: 'COMMENT', action: 'UPDATE_COMMENT', event_type: 'COMMENT_RESOLVED', special: 'COMMENT_RESOLVE' },
  TASK_CREATE: { entity_type: 'TASK', action: 'ASSIGN_TASK', event_type: 'TASK_CREATED', special: 'TASK_CREATE' },
  TASK_UPDATE: { entity_type: 'TASK', action: 'UPDATE_TASK', event_type: 'TASK_UPDATED', special: 'TASK_UPDATE' },
  TASK_ASSIGN: { entity_type: 'TASK', action: 'ASSIGN_TASK', event_type: 'TASK_ASSIGNED', special: 'TASK_ASSIGN' },
  REVIEW_REQUEST_CREATE: { entity_type: 'REVIEW_REQUEST', action: 'REQUEST_REVIEW', event_type: 'REVIEW_REQUEST_CREATED', special: 'REVIEW_REQUEST_CREATE' },
  RISK_ACCEPTANCE_REQUEST: { entity_type: 'RISK_ACCEPTANCE', action: 'REQUEST_RISK_ACCEPTANCE', event_type: 'RISK_ACCEPTANCE_REQUESTED', special: 'RISK_ACCEPTANCE_REQUEST' },
  RISK_ACCEPTANCE_DECIDE: { entity_type: 'RISK_ACCEPTANCE', action: 'APPROVE_RISK', event_type: 'RISK_ACCEPTANCE_DECIDED', special: 'RISK_ACCEPTANCE_DECIDE' },
  APPROVAL_RECORD: { entity_type: 'APPROVAL', action: 'RECORD_APPROVAL', event_type: 'APPROVAL_RECORDED', special: 'APPROVAL_RECORD' },
  DFMEA_ITEM_CREATE: { entity_type: 'DFMEA_ITEM', action: 'UPDATE_DFMEA', event_type: 'DFMEA_ITEM_CREATED', special: 'DFMEA_ITEM_CREATE' },
  TEST_RECORD_CREATE: { entity_type: 'TEST_RECORD', action: 'RECORD_TEST_RESULT', event_type: 'TEST_RECORDED', special: 'TEST_RECORD_CREATE' },
  TEST_RETEST_CREATE: { entity_type: 'TEST_RECORD', action: 'RECORD_TEST_RESULT', event_type: 'TEST_RETEST_RECORDED', special: 'TEST_RETEST_CREATE' },
  GATE_RECALCULATE_REQUEST: { entity_type: 'GATE', action: 'REQUEST_REVIEW', event_type: 'GATE_RECALCULATED', special: 'GATE_RECALCULATE_REQUEST' },
  FINAL_FREEZE_APPROVE: { entity_type: 'FINAL_FREEZE', action: 'APPROVE_FINAL_FREEZE', event_type: 'FINAL_FREEZE_APPROVED', special: 'FINAL_FREEZE_APPROVE' }
});

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function identifier(value, name) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)) fail(`INVALID_${name}`);
  return value;
}

function nonNegativeInteger(value, name) {
  if (!Number.isInteger(value) || value < 0) fail(`INVALID_${name}`);
  return value;
}

function object(value, name) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail(`INVALID_${name}`);
  return value;
}

class CommandService {
  constructor({ store, permissions = new PermissionService(), artifactVerifier = null, finalFreezeService = null } = {}) {
    if (!store) fail('COMMAND_STORE_REQUIRED');
    this.store = store;
    this.permissions = permissions;
    this.artifactVerifier = artifactVerifier;
    this.finalFreezeService = finalFreezeService || new FinalFreezeService({ store, artifactVerifier });
  }

  validate(command = {}) {
    const command_id = identifier(command.command_id, 'COMMAND_ID');
    const idempotency_key = identifier(command.idempotency_key, 'IDEMPOTENCY_KEY');
    const project_id = identifier(command.project_id, 'PROJECT_ID');
    const entity_id = identifier(command.entity_id, 'ENTITY_ID');
    const definition = COMMANDS[command.command_type];
    if (!definition || command.entity_type !== definition.entity_type) fail('UNSUPPORTED_COMMAND');
    return {
      command_id,
      idempotency_key,
      project_id,
      command_type: command.command_type,
      entity_type: command.entity_type,
      entity_id,
      base_project_version: nonNegativeInteger(command.base_project_version, 'BASE_PROJECT_VERSION'),
      base_entity_version: nonNegativeInteger(command.base_entity_version, 'BASE_ENTITY_VERSION'),
      payload: object(command.payload, 'PAYLOAD'),
      correlation_id: command.correlation_id ? identifier(command.correlation_id, 'CORRELATION_ID') : null,
      event_type: definition.event_type,
      definition
    };
  }

  execute(input, actor) {
    const command = this.validate(input);
    const actor_id = identifier(actor?.user_id, 'ACTOR_ID');
    return this.store.applyEntityCommand({
      command,
      actor: { user_id: actor_id },
      authorize: role_id => this.permissions.require(role_id, command.definition.action),
      mutate: (state, { read_only }) => {
        const definition = command.definition;
        if (!read_only && state.freeze && definition.special !== 'REVISION_CREATE') fail('FROZEN_REVISION');
        if (definition.special === 'REVISION_CREATE') {
          if (read_only) return state.design?.active_revision === command.entity_id ? { revision: command.entity_id } : null;
          if (command.payload.revision !== command.entity_id || typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('REVISION_REASON_REQUIRED');
          const previous = state.design?.active_revision;
          if (!previous || previous === command.entity_id || (state.revision_lineage || []).some(row => row.to === command.entity_id)) fail('REVISION_ALREADY_EXISTS');
          state.revision_lineage = [...(state.revision_lineage || []), { from: previous, to: command.entity_id, reason: command.payload.reason.trim(), at: new Date().toISOString() }];
          state.design_snapshots = [...(state.design_snapshots || []), { revision: previous, captured_at: new Date().toISOString(), design: structuredClone(state.design), authority: 'TEAM_REVISION_COMMAND' }];
          state.design = { ...state.design, active_revision: command.entity_id };
          for (const key of ['cad_geometry', 'display_mesh', 'surface_measurements', 'measurement_revision']) delete state.design[key];
          state.verifications = [];
          state.last_review = null;
          state.basis_hash = null;
          state.freeze = null;
          state.gate = { current_stage: 'Gate 1', status: 'OPEN' };
          return state;
        }
        if (definition.special === 'CAD_ARTIFACT_REGISTER') {
          const artifact = this.store.getArtifact(command.entity_id);
          if (!artifact || artifact.project_id !== command.project_id || artifact.artifact_type !== 'CAD' || !artifact.immutable) fail('ARTIFACT_NOT_CURRENT_IMMUTABLE_CAD');
          if (artifact.revision_id !== state.design?.active_revision) fail('ARTIFACT_REVISION_MISMATCH');
          if (command.payload.artifact_id !== command.entity_id || command.payload.sha256 !== artifact.sha256) fail('ARTIFACT_HASH_MISMATCH');
          if (read_only) return state.design?.cad_artifact_id === command.entity_id ? structuredClone(artifact) : null;
          state.design = { ...state.design, cad_artifact_id: artifact.artifact_id, cad_artifact_sha256: artifact.sha256, cad_artifact_revision: artifact.revision_id };
          state.last_review = null;
          state.basis_hash = null;
          return state;
        }
        if (definition.special === 'EVIDENCE_ADD') {
          const artifactId = identifier(command.payload.artifact_id, 'ARTIFACT_ID');
          const artifact = this.store.getArtifact(artifactId);
          if (!artifact || artifact.project_id !== command.project_id || artifact.artifact_type !== 'EVIDENCE' || !artifact.immutable) fail('ARTIFACT_NOT_CURRENT_IMMUTABLE_EVIDENCE');
          if (artifact.revision_id !== state.design?.active_revision) fail('ARTIFACT_REVISION_MISMATCH');
          if (command.payload.sha256 !== artifact.sha256) fail('ARTIFACT_HASH_MISMATCH');
          if (typeof command.payload.purpose !== 'string' || !command.payload.purpose.trim()) fail('EVIDENCE_PURPOSE_REQUIRED');
          const requirementIds = command.payload.requirement_ids === undefined ? [] : command.payload.requirement_ids;
          if (!Array.isArray(requirementIds) || new Set(requirementIds).size !== requirementIds.length) fail('INVALID_REQUIREMENT_IDS');
          const requirements = new Set((state.requirements || []).map(requirement => requirement.req_id));
          for (const requirementId of requirementIds) if (!requirements.has(identifier(requirementId, 'REQUIREMENT_ID'))) fail('REQUIREMENT_NOT_FOUND');
          const existing = (state.evidence || []).find(evidence => evidence.evidence_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('EVIDENCE_IMMUTABLE');
          state.evidence = [...(state.evidence || []), {
            evidence_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            artifact_id: artifact.artifact_id,
            artifact_sha256: artifact.sha256,
            purpose: command.payload.purpose.trim(),
            requirement_ids: [...requirementIds],
            rule_version: command.payload.rule_version || null,
            provenance: command.payload.provenance || null,
            created_by: actor_id,
            created_at: new Date().toISOString(),
            immutable: true,
            status: 'CURRENT'
          }];
          return state;
        }
        if (definition.special === 'COMMENT_CREATE') {
          const existing = (state.comments || []).find(comment => comment.comment_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('COMMENT_IMMUTABLE');
          if (typeof command.payload.text !== 'string' || !command.payload.text.trim()) fail('COMMENT_TEXT_REQUIRED');
          const anchor = command.payload.anchor === undefined ? null : object(command.payload.anchor, 'COMMENT_ANCHOR');
          if (anchor && (!anchor.entity_type || !anchor.entity_id)) fail('INVALID_COMMENT_ANCHOR');
          state.comments = [...(state.comments || []), {
            comment_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            text: command.payload.text.trim(),
            anchor: anchor ? structuredClone(anchor) : null,
            created_by: actor_id,
            created_at: new Date().toISOString(),
            immutable: true
          }];
          return state;
        }
        if (definition.special === 'COMMENT_RESOLVE') {
          const comment = (state.comments || []).find(row => row.comment_id === command.entity_id);
          const existing = (state.comment_resolutions || []).find(row => row.comment_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : (comment ? structuredClone(comment) : null);
          if (!comment) fail('COMMENT_NOT_FOUND');
          if (existing) fail('COMMENT_ALREADY_RESOLVED');
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('COMMENT_RESOLUTION_REASON_REQUIRED');
          state.comment_resolutions = [...(state.comment_resolutions || []), {
            resolution_id: `CMR-${command.entity_id}-${Date.now()}`,
            comment_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            reason: command.payload.reason.trim(),
            resolved_by: actor_id,
            resolved_at: new Date().toISOString()
          }];
          return state;
        }
        if (definition.special === 'TASK_CREATE') {
          const existing = (state.tasks || []).find(task => task.task_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('TASK_ALREADY_EXISTS');
          if (typeof command.payload.title !== 'string' || !command.payload.title.trim()) fail('TASK_TITLE_REQUIRED');
          const target = object(command.payload.target, 'TASK_TARGET');
          if (!target.entity_type || !target.entity_id) fail('INVALID_TASK_TARGET');
          const assignee_id = identifier(command.payload.assignee_id, 'TASK_ASSIGNEE_ID');
          if (!this.store.getMembership(command.project_id, assignee_id)) fail('TASK_ASSIGNEE_NOT_MEMBER');
          const priority = command.payload.priority || 'MEDIUM';
          if (!['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(priority)) fail('INVALID_TASK_PRIORITY');
          state.tasks = [...(state.tasks || []), {
            task_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            title: command.payload.title.trim(),
            description: typeof command.payload.description === 'string' ? command.payload.description.trim() : null,
            target: structuredClone(target),
            assignee_id,
            creator_id: actor_id,
            status: 'OPEN',
            priority,
            due_at: command.payload.due_at || null,
            created_at: new Date().toISOString(),
            updated_at: null,
            updated_by: null
          }];
          return state;
        }
        if (definition.special === 'TASK_UPDATE' || definition.special === 'TASK_ASSIGN') {
          const index = (state.tasks || []).findIndex(task => task.task_id === command.entity_id);
          const current = index < 0 ? null : state.tasks[index];
          if (read_only) return current ? structuredClone(current) : null;
          if (!current) fail('TASK_NOT_FOUND');
          const patch = {};
          if (definition.special === 'TASK_ASSIGN') {
            const assignee_id = identifier(command.payload.assignee_id, 'TASK_ASSIGNEE_ID');
            if (!this.store.getMembership(command.project_id, assignee_id)) fail('TASK_ASSIGNEE_NOT_MEMBER');
            patch.assignee_id = assignee_id;
          } else {
            for (const field of ['title', 'description', 'completion_note', 'due_at']) if (Object.hasOwn(command.payload, field)) patch[field] = command.payload[field];
            if (Object.hasOwn(command.payload, 'status')) {
              if (!['OPEN', 'IN_PROGRESS', 'BLOCKED', 'DONE'].includes(command.payload.status)) fail('INVALID_TASK_STATUS');
              patch.status = command.payload.status;
            }
            if (Object.hasOwn(command.payload, 'priority')) {
              if (!['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(command.payload.priority)) fail('INVALID_TASK_PRIORITY');
              patch.priority = command.payload.priority;
            }
          }
          state.tasks[index] = { ...current, ...patch, updated_by: actor_id, updated_at: new Date().toISOString() };
          return state;
        }
        if (definition.special === 'REVIEW_REQUEST_CREATE') {
          const existing = (state.review_requests || []).find(request => request.review_request_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('REVIEW_REQUEST_ALREADY_EXISTS');
          if (!['TEACHER_REVIEWER', 'EXPERT_REVIEWER'].includes(command.payload.requested_role)) fail('INVALID_REVIEWER_ROLE');
          if (typeof command.payload.scope !== 'string' || !command.payload.scope.trim()) fail('REVIEW_SCOPE_REQUIRED');
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('REVIEW_REASON_REQUIRED');
          state.review_requests = [...(state.review_requests || []), {
            review_request_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            requested_role: command.payload.requested_role,
            scope: command.payload.scope.trim(),
            reason: command.payload.reason.trim(),
            requested_by: actor_id,
            requested_at: new Date().toISOString(),
            status: 'OPEN'
          }];
          return state;
        }
        if (definition.special === 'RISK_ACCEPTANCE_REQUEST') {
          const existing = (state.risk_acceptance_requests || []).find(row => row.acceptance_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('RISK_ACCEPTANCE_ALREADY_EXISTS');
          if (typeof command.payload.risk_id !== 'string' || !command.payload.risk_id) fail('RISK_ID_REQUIRED');
          if (!Number.isInteger(command.payload.risk_version) || command.payload.risk_version < 1) fail('INVALID_RISK_VERSION');
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('RISK_ACCEPTANCE_REASON_REQUIRED');
          if (typeof command.payload.residual_risk !== 'string' || !command.payload.residual_risk.trim()) fail('RESIDUAL_RISK_REQUIRED');
          if (typeof command.payload.evidence_set_hash !== 'string' || !/^[a-f0-9]{64}$/i.test(command.payload.evidence_set_hash)) fail('INVALID_EVIDENCE_SET_HASH');
          state.risk_acceptance_requests = [...(state.risk_acceptance_requests || []), {
            acceptance_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            project_version: state.version,
            risk_id: command.payload.risk_id,
            risk_version: command.payload.risk_version,
            reason: command.payload.reason.trim(),
            residual_risk: command.payload.residual_risk.trim(),
            evidence_set_hash: command.payload.evidence_set_hash.toLowerCase(),
            requested_by: actor_id,
            requested_at: new Date().toISOString(),
            status: 'REQUESTED'
          }];
          return state;
        }
        if (definition.special === 'RISK_ACCEPTANCE_DECIDE') {
          const index = (state.risk_acceptance_requests || []).findIndex(row => row.acceptance_id === command.entity_id);
          const current = index < 0 ? null : state.risk_acceptance_requests[index];
          if (read_only) return current ? structuredClone(current) : null;
          if (!current) fail('RISK_ACCEPTANCE_NOT_FOUND');
          if (current.status !== 'REQUESTED') fail('RISK_ACCEPTANCE_ALREADY_DECIDED');
          if (!['ACCEPTED', 'REJECTED'].includes(command.payload.decision)) fail('INVALID_RISK_DECISION');
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('RISK_ACCEPTANCE_DECISION_REASON_REQUIRED');
          state.risk_acceptance_requests[index] = { ...current, status: command.payload.decision, decision_reason: command.payload.reason.trim(), decided_by: actor_id, decided_at: new Date().toISOString() };
          return state;
        }
        if (definition.special === 'APPROVAL_RECORD') {
          const existing = (state.approvals || []).find(row => row.approval_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('APPROVAL_ALREADY_EXISTS');
          if (!['APPROVED', 'REJECTED'].includes(command.payload.decision)) fail('INVALID_APPROVAL_DECISION');
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('APPROVAL_REASON_REQUIRED');
          const hashes = ['evidence_set_hash', 'verification_state_hash', 'dfmea_state_hash', 'gate_state_hash', 'risk_state_hash'];
          const suppliedBindings = hashes.some(field => Object.hasOwn(command.payload, field));
          let bindings;
          if (suppliedBindings) {
            for (const field of hashes) if (typeof command.payload[field] !== 'string' || !/^[a-f0-9]{64}$/i.test(command.payload[field])) fail(`INVALID_${field.toUpperCase()}`);
            bindings = Object.fromEntries(hashes.map(field => [field, command.payload[field].toLowerCase()]));
          } else {
            bindings = this.finalFreezeService.revalidate({ project_id: command.project_id, state });
          }
          state.approvals = [...(state.approvals || []), {
            approval_id: command.entity_id,
            project_id: command.project_id,
            revision_id: state.design.active_revision,
            project_version: state.version,
            revision_version: this.store.entityVersion(command.project_id, 'REVISION', state.design.active_revision),
            evidence_set_hash: bindings.evidence_set_hash,
            verification_state_hash: bindings.verification_state_hash,
            dfmea_state_hash: bindings.dfmea_state_hash,
            gate_state_hash: bindings.gate_state_hash,
            risk_state_hash: bindings.risk_state_hash,
            actor_id,
            actor_role: this.store.getMembership(command.project_id, actor_id)?.role_id || null,
            decision: command.payload.decision,
            reason: command.payload.reason.trim(),
            created_at: new Date().toISOString(),
            status: 'CURRENT'
          }];
          return state;
        }
        if (definition.special === 'DFMEA_ITEM_CREATE') {
          const items = Array.isArray(state.dfmea?.items) ? state.dfmea.items : [];
          const existing = items.find(item => item.item_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('DFMEA_ITEM_ALREADY_EXISTS');
          if (typeof command.payload.function !== 'string' || !command.payload.function.trim()) fail('DFMEA_FUNCTION_REQUIRED');
          if (!Array.isArray(command.payload.failure_modes) || !command.payload.failure_modes.length) fail('DFMEA_FAILURE_MODES_REQUIRED');
          const failureModes = command.payload.failure_modes.map(mode => {
            if (!mode || typeof mode.failure_mode_id !== 'string' || !mode.failure_mode_id || typeof mode.effect !== 'string' || !mode.effect.trim() || typeof mode.cause !== 'string' || !mode.cause.trim()) fail('INVALID_DFMEA_FAILURE_MODE');
            for (const field of ['severity', 'occurrence', 'detection']) if (!Number.isInteger(mode[field]) || mode[field] < 1 || mode[field] > 10) fail(`INVALID_DFMEA_${field.toUpperCase()}`);
            return structuredClone(mode);
          });
          const planItem = object(command.payload.verification_plan_item, 'VERIFICATION_PLAN_ITEM');
          state.dfmea = { ...(state.dfmea || {}), items: [...items, { item_id: command.entity_id, function: command.payload.function.trim(), failure_modes: failureModes }] };
          const priorItems = state.dfmea_verification_plan?.items || [];
          DfmeaRecords.setPlan(state, { items: [...priorItems, planItem], change_reason: `DFMEA item ${command.entity_id} added` }, actor_id);
          return state;
        }
        if (definition.special === 'TEST_RECORD_CREATE' || definition.special === 'TEST_RETEST_CREATE') {
          const existing = (state.dfmea_test_records || []).find(record => record.test_id === command.entity_id);
          if (read_only) return existing ? structuredClone(existing) : null;
          if (existing) fail('TEST_RECORD_IMMUTABLE');
          if (definition.special === 'TEST_RETEST_CREATE' && typeof command.payload.retest_of !== 'string') fail('RETEST_OF_REQUIRED');
          if (definition.special === 'TEST_RECORD_CREATE' && command.payload.retest_of) fail('RETEST_MUST_USE_RETEST_COMMAND');
          const requestedStatus = DfmeaRecords.normalizeStatus(command.payload.status);
          const modeIds = Array.isArray(command.payload.failure_mode_ids) ? command.payload.failure_mode_ids : [];
          if (requestedStatus === 'PASS' && !command.payload.retest_of && (state.dfmea_test_records || []).some(record => record.status === 'FAILED' && modeIds.some(modeId => record.failure_mode_ids?.includes(modeId)))) fail('PASS_REQUIRES_RETEST_OF_FAILED_TEST');
          DfmeaRecords.appendTest(state, { ...command.payload, test_id: command.entity_id }, (project, evidence) => {
            if (evidence.revision_id !== project.design?.active_revision || evidence.status !== 'CURRENT') fail('TEST_EVIDENCE_NOT_CURRENT');
            const artifact = this.store.getArtifact(evidence.artifact_id);
            if (!artifact || artifact.project_id !== command.project_id || artifact.revision_id !== project.design.active_revision || artifact.sha256 !== evidence.artifact_sha256 || !artifact.immutable) fail('TEST_EVIDENCE_ARTIFACT_INVALID');
            if (this.artifactVerifier && !this.artifactVerifier(artifact)) fail('TEST_EVIDENCE_ARTIFACT_INTEGRITY_INVALID');
          });
          return state;
        }
        if (definition.special === 'GATE_RECALCULATE_REQUEST') {
          if (read_only) return structuredClone(state.gate || null);
          if (command.payload.stage !== 'Gate 3') fail('INVALID_GATE_STAGE');
          const bindings = DfmeaRecords.currentBindings(state);
          const dfmea = state.dfmea ? new FMEAService().evaluate(state.dfmea, { ...bindings, test_records: state.dfmea_test_records || [], verification_plan: state.dfmea_verification_plan || null, valid_evidence_ids: (state.evidence || []).filter(e => e.revision_id === state.design.active_revision && e.status === 'CURRENT').map(e => e.evidence_id), valid_requirement_ids: (state.requirements || []).map(r => r.req_id), risk_acceptances: state.risk_acceptances || [] }) : null;
          const professional = dfmea ? ProfessionalGate.toGateArtifacts({ dfmea }, { dfmea: 'APPLICABLE' }) : { checks: [], findings: [] };
          const evidenceContext = (state.evidence || []).map(evidence => {
            const artifact = this.store.getArtifact(evidence.artifact_id);
            const provenanceBound = Boolean(artifact && artifact.immutable && artifact.project_id === command.project_id && artifact.revision_id === state.design.active_revision && artifact.sha256 === evidence.artifact_sha256);
            const integrityVerified = provenanceBound && typeof this.artifactVerifier === 'function' && this.artifactVerifier(artifact) === true;
            return {
              evidence_id: evidence.evidence_id,
              integrity_status: integrityVerified ? 'VERIFIED' : 'UNVERIFIED',
              provenance_status: provenanceBound ? 'BOUND' : 'UNVERIFIED',
              current_revision_valid: evidence.revision_id === state.design.active_revision && evidence.status === 'CURRENT' && integrityVerified
            };
          });
          const gate = GateV2.evaluateFormalGateV2({ stage: 'Gate 3', revision: state.design.active_revision, project: state, checks: professional.checks, prior_issues: state.findings || [], evidence_context: evidenceContext, knowledge: {} });
          state.checks = [...professional.checks, ...gate.checks];
          state.findings = [...(state.findings || []), ...professional.findings];
          state.gate = { current_stage: 'Gate 3', status: gate.decision, gate_record: gate, blocking_reasons: gate.blocking_reasons, freeze_eligible: gate.freeze_eligible, recalculated_at: new Date().toISOString(), authority: 'SERVER_GATE_RECALCULATION_NOT_PRODUCTION_RELEASE' };
          return state;
        }
        if (definition.special === 'FINAL_FREEZE_APPROVE') {
          if (read_only) return structuredClone(state.freeze || null);
          if (state.freeze) fail('FINAL_FREEZE_ALREADY_EXISTS');
          if (state.gate?.current_stage !== 'Gate 3' || state.gate?.status !== 'PASS' || state.gate?.freeze_eligible !== true) fail('FINAL_FREEZE_GATE_NOT_ELIGIBLE');
          const freezeBindings = this.finalFreezeService.revalidate({ project_id: command.project_id, state });
          const approval = (state.approvals || []).find(row => row.status === 'CURRENT' && row.decision === 'APPROVED' && row.revision_id === state.design?.active_revision);
          if (!approval) fail('FINAL_FREEZE_CURRENT_HUMAN_APPROVAL_REQUIRED');
          this.finalFreezeService.validateApproval({ approval, bindings: freezeBindings });
          if (typeof command.payload.reason !== 'string' || !command.payload.reason.trim()) fail('FINAL_FREEZE_REASON_REQUIRED');
          state.freeze = { freeze_id: command.entity_id, project_id: command.project_id, revision: state.design.active_revision, project_version: state.version, revision_version: this.store.entityVersion(command.project_id, 'REVISION', state.design.active_revision), ...freezeBindings, gate_record_hash: Canonical.sha256(state.gate.gate_record), approval_id: approval.approval_id, approval_hash: Canonical.sha256(approval), approved_by: actor_id, actor_role: this.store.getMembership(command.project_id, actor_id)?.role_id, reason: command.payload.reason.trim(), approved_at: new Date().toISOString(), authority: 'TEAM_SERVER_HUMAN_FREEZE_NOT_PRODUCTION_RELEASE', external_release: false };
          state.freeze_records = [...(state.freeze_records || []), structuredClone(state.freeze)];
          return state;
        }
        const rows = Array.isArray(state[definition.collection]) ? state[definition.collection] : [];
        const index = rows.findIndex(item => item[definition.id_field] === command.entity_id);
        if (read_only) return index < 0 ? null : structuredClone(rows[index]);
        const previous = index < 0 ? null : rows[index];
        const next = { ...(previous || {}), ...command.payload, [definition.id_field]: command.entity_id };
        if (typeof next[definition.required_field] !== 'string' || !next[definition.required_field].trim()) fail(definition.required_error);
        if (index < 0) rows.push(next); else rows[index] = next;
        state[definition.collection] = rows;
        return state;
      }
    });
  }
}

module.exports = CommandService;
