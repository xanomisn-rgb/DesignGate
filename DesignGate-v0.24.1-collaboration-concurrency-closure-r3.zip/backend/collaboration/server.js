const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const TeamProjectRepository = require('../repositories/team_project_repository');
const IntegrationServer = require('../http/integration_server');
const PresenceService = require('./presence_service');
const CommandService = require('./command_service');
const AgentRunCoordinator = require('./agent_run_coordinator');

const parseMultipart = IntegrationServer.multipart;

function json(response, status, body) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  response.end(JSON.stringify(body));
}

function statusFor(error) {
  if (['UNAUTHENTICATED', 'INVALID_CREDENTIALS'].includes(error.code)) return 401;
  if (['PERMISSION_DENIED', 'PROJECT_SCOPE_DENIED', 'AGENT_RUN_COMPLETION_FORBIDDEN'].includes(error.code)) return 403;
  if (['PROJECT_NOT_FOUND', 'ENTITY_NOT_FOUND', 'AGENT_RUN_NOT_FOUND'].includes(error.code)) return 404;
  if (['PROJECT_ALREADY_EXISTS', 'MEMBER_ALREADY_EXISTS', 'ENTITY_VERSION_CONFLICT', 'PROJECT_VERSION_CONFLICT', 'IDEMPOTENCY_CONFLICT', 'FINAL_FREEZE_ALREADY_EXISTS', 'FROZEN_REVISION'].includes(error.code)) return 409;
  if (['ARTIFACT_HASH_INVALID', 'ARTIFACT_MUTABILITY_FORBIDDEN', 'ARTIFACT_FILENAME_INVALID', 'ARTIFACT_BYTES_REQUIRED', 'ARTIFACT_REVISION_MISMATCH', 'ARTIFACT_TYPE_UNSUPPORTED'].includes(error.code)) return 422;
  if (error.code === 'ARTIFACT_STORE_UNAVAILABLE') return 503;
  if (['INVALID_JSON', 'REQUEST_TOO_LARGE', 'PROJECT_PATH_MISMATCH'].includes(error.code) || String(error.code || '').startsWith('INVALID_')) return 400;
  if (['INVALID_PASSWORD', 'INVALID_USERNAME', 'INVALID_USER_ID'].includes(error.code)) return 400;
  if (['LAST_OWNER_CANNOT_REMOVE', 'LAST_OWNER_CANNOT_LEAVE', 'OWNER_ROLE_CHANGE_FORBIDDEN', 'OWNER_TRANSFER_TARGET_INVALID'].includes(error.code)) return 400;
  return 500;
}

function readJson(request, maxBytes = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let bytes = 0;
    const chunks = [];
    request.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > maxBytes) {
        const error = new Error('REQUEST_TOO_LARGE');
        error.code = 'REQUEST_TOO_LARGE';
        request.destroy(error);
        reject(error);
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { const error = new Error('INVALID_JSON'); error.code = 'INVALID_JSON'; reject(error); }
    });
    request.on('error', reject);
  });
}

class CollaborationServer {
  constructor({ identity, store, host = '127.0.0.1', port = 43124, version = '0.24.1', artifactStore = null, presence = null, agentRunCoordinator = null, maxUploadBytes = 50 * 1024 * 1024, uploadTempDir = os.tmpdir() } = {}) {
    if (!identity || !store) throw new Error('COLLABORATION_SERVER_CONFIGURATION_REQUIRED');
    this.identity = identity;
    this.store = store;
    this.host = host;
    this.port = port;
    this.version = version;
    this.artifactStore = artifactStore;
    this.presence = presence || new PresenceService();
    this.agentRunCoordinator = agentRunCoordinator || new AgentRunCoordinator({ store });
    this.maxUploadBytes = maxUploadBytes;
    this.uploadTempDir = uploadTempDir;
    this.repository = new TeamProjectRepository({
      store,
      commandService: new CommandService({
        store,
        artifactVerifier: artifact => {
          const metadata = this.artifactStore?.getMetadata(artifact.artifact_id);
          return Boolean(metadata && metadata.project_id === artifact.project_id && metadata.revision_id === artifact.revision_id && metadata.sha256 === artifact.sha256 && this.artifactStore.verifyHash(metadata));
        }
      })
    });
    this.startedAt = null;
    this.server = http.createServer((request, response) => this.handle(request, response));
    this.websocket = new WebSocketServer({ noServer: true });
    this.subscribers = new Map();
    this.server.on('upgrade', (request, socket, head) => this.handleUpgrade(request, socket, head));
  }

  address() { return this.server.address(); }
  healthcheck() {
    return {
      status: 'OK',
      version: this.version,
      database: this.store.databasePath ? 'READY' : 'UNAVAILABLE',
      artifact_store: this.artifactStore ? 'READY' : 'NOT_INITIALIZED',
      websocket: this.websocket ? 'READY' : 'NOT_INITIALIZED',
      started_at: this.startedAt
    };
  }
  start() {
    if (this.startedAt) return Promise.resolve(this.address());
    return new Promise((resolve, reject) => {
      this.server.once('error', reject);
      this.server.listen(this.port, this.host, () => {
        this.server.off('error', reject);
        this.startedAt = new Date().toISOString();
        resolve(this.address());
      });
    });
  }
  stop() {
    if (!this.startedAt) return Promise.resolve();
    for (const sockets of this.subscribers.values()) for (const socket of sockets) socket.close();
    return new Promise((resolve, reject) => this.websocket.close(() => this.server.close(error => {
      if (error) reject(error); else { this.startedAt = null; resolve(); }
    })));
  }
  authenticate(request) {
    const header = request.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    return this.identity.authenticate(token);
  }
  rejectUpgrade(socket, statusCode) {
    socket.write(`HTTP/1.1 ${statusCode} ${statusCode === 401 ? 'Unauthorized' : 'Forbidden'}\r\nConnection: close\r\n\r\n`);
    socket.destroy();
  }
  handleUpgrade(request, socket, head) {
    const url = new URL(request.url, 'http://localhost');
    const match = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/events$/);
    if (!match) return this.rejectUpgrade(socket, 404);
    let actor;
    try {
      actor = this.authenticate(request);
      this.repository.getProject(match[1], { actor_id: actor.user_id });
    } catch (error) { return this.rejectUpgrade(socket, statusFor(error)); }
    this.websocket.handleUpgrade(request, socket, head, ws => {
      const projectId = match[1];
      if (!this.subscribers.has(projectId)) this.subscribers.set(projectId, new Set());
      this.subscribers.get(projectId).add(ws);
      ws.on('close', () => this.subscribers.get(projectId)?.delete(ws));
      const project = this.repository.getProject(projectId, { actor_id: actor.user_id });
      ws.send(JSON.stringify({ type: 'CONNECTED', project_id: projectId, current_project_version: project.version, latest_event_id: null }));
    });
  }
  broadcastProjectEvent(event) {
    const envelope = { type: event.event_type, event_id: event.event_id, event_seq: event.event_seq, project_id: event.project_id, project_version: event.project_version, entity_type: event.entity_type, entity_id: event.entity_id, entity_version: event.entity_version };
    for (const socket of this.subscribers.get(event.project_id) || []) if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(envelope));
  }
  broadcastLatestProjectEvent(projectId) {
    const events = this.store.listEvents(projectId, { after: 0, limit: 500 });
    const event = events.at(-1);
    if (event) this.broadcastProjectEvent(event);
  }
  broadcastPresence(record) {
    const envelope = { type: 'PRESENCE_UPDATED', project_id: record.project_id, presence: record };
    for (const socket of this.subscribers.get(record.project_id) || []) if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(envelope));
  }
  artifactUploadPermission(artifactType) {
    if (artifactType === 'CAD') return 'UPLOAD_CAD_REVISION';
    if (artifactType === 'EVIDENCE') return 'ADD_EVIDENCE';
    const error = new Error('ARTIFACT_TYPE_UNSUPPORTED');
    error.code = 'ARTIFACT_TYPE_UNSUPPORTED';
    throw error;
  }
  validateArtifactFilename(artifactType, filename) {
    const extension = path.extname(filename || '').toLowerCase();
    const supported = artifactType === 'CAD'
      ? new Set(['.step', '.stp', '.stl', '.glb'])
      : new Set(['.pdf', '.png', '.jpg', '.jpeg', '.csv', '.json']);
    if (!supported.has(extension)) {
      const error = new Error('ARTIFACT_TYPE_UNSUPPORTED');
      error.code = 'ARTIFACT_TYPE_UNSUPPORTED';
      throw error;
    }
  }
  async uploadArtifact(request, response, projectId) {
    if (!this.artifactStore) { const error = new Error('ARTIFACT_STORE_UNAVAILABLE'); error.code = 'ARTIFACT_STORE_UNAVAILABLE'; throw error; }
    const actor = this.authenticate(request);
    const project = this.repository.getProject(projectId, { actor_id: actor.user_id });
    const contentType = request.headers['content-type'] || '';
    const boundary = contentType.match(/boundary=([^;]+)/i)?.[1]?.replace(/^"|"$/g, '');
    if (!boundary) { const error = new Error('MULTIPART_REQUIRED'); error.code = 'INVALID_MULTIPART_REQUIRED'; throw error; }
    let parsed;
    try {
      parsed = await parseMultipart(request, boundary, { maxBytes: this.maxUploadBytes, tempDir: this.uploadTempDir });
      const revisionId = parsed.fields.revision_id;
      const artifactType = parsed.fields.artifact_type;
      if (typeof revisionId !== 'string' || revisionId !== project.design?.active_revision) { const error = new Error('ARTIFACT_REVISION_MISMATCH'); error.code = 'ARTIFACT_REVISION_MISMATCH'; throw error; }
      if (typeof artifactType !== 'string') { const error = new Error('ARTIFACT_TYPE_UNSUPPORTED'); error.code = 'ARTIFACT_TYPE_UNSUPPORTED'; throw error; }
      const member = this.store.getMembership(projectId, actor.user_id);
      this.repository.commandService.permissions.require(member?.role_id, this.artifactUploadPermission(artifactType));
      if (!parsed.file?.path || !parsed.file.filename || parsed.file.size_bytes < 1) { const error = new Error('ARTIFACT_BYTES_REQUIRED'); error.code = 'ARTIFACT_BYTES_REQUIRED'; throw error; }
      this.validateArtifactFilename(artifactType, parsed.file.filename);
      const artifact = this.artifactStore.put({
        project_id: projectId,
        revision_id: revisionId,
        artifact_type: artifactType,
        original_filename: parsed.file.filename,
        bytes: fs.readFileSync(parsed.file.path),
        mime_type: contentType,
        created_by: actor.user_id
      });
      const stored = this.store.registerArtifact(artifact);
      const event = this.store.appendAuditEvent({
        project_id: projectId,
        actor_id: actor.user_id,
        actor_role_snapshot: member.role_id,
        entity_type: 'ARTIFACT',
        entity_id: artifact.artifact_id,
        event_type: 'ARTIFACT_CREATED',
        payload: { artifact_id: artifact.artifact_id, artifact_type: artifact.artifact_type, revision_id: artifact.revision_id, sha256: artifact.sha256 }
      });
      this.broadcastProjectEvent(event);
      return json(response, 201, { artifact: { ...artifact, registry: stored }, event });
    } finally {
      if (parsed?.directory) fs.rmSync(parsed.directory, { recursive: true, force: true });
    }
  }
  async handle(request, response) {
    const url = new URL(request.url, 'http://localhost');
    try {
      if (request.method === 'GET' && url.pathname === '/health') return json(response, 200, this.healthcheck());
      if (request.method === 'POST' && url.pathname === '/api/auth/login') {
        const session = this.identity.login(await readJson(request));
        return json(response, 200, session);
      }
      if (request.method === 'POST' && url.pathname === '/api/auth/logout') {
        const header = request.headers.authorization || '';
        const token = header.startsWith('Bearer ') ? header.slice(7) : '';
        this.authenticate(request);
        this.identity.revoke(token);
        return json(response, 204, {});
      }
      if (request.method === 'GET' && url.pathname === '/api/auth/me') return json(response, 200, { user: this.authenticate(request) });
      if (url.pathname === '/api/projects' && request.method === 'GET') {
        const actor = this.authenticate(request);
        return json(response, 200, { projects: this.repository.listProjects({ actor_id: actor.user_id }) });
      }
      if (url.pathname === '/api/projects' && request.method === 'POST') {
        const actor = this.authenticate(request);
        const project = this.repository.createProject(await readJson(request), { actor_id: actor.user_id });
        return json(response, 201, { project });
      }
      const agentRunDetailMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/agent-runs\/([A-Za-z0-9_-]+)\/complete$/);
      if (agentRunDetailMatch && request.method === 'POST') {
        const [, projectId, runId] = agentRunDetailMatch;
        const actor = this.authenticate(request);
        this.repository.getProject(projectId, { actor_id: actor.user_id });
        const existing = this.store.getAgentRun(runId);
        if (!existing) { const error = new Error('AGENT_RUN_NOT_FOUND'); error.code = 'AGENT_RUN_NOT_FOUND'; throw error; }
        if (existing.project_id !== projectId) { const error = new Error('PROJECT_PATH_MISMATCH'); error.code = 'PROJECT_PATH_MISMATCH'; throw error; }
        const run = this.agentRunCoordinator.complete(runId, (await readJson(request)).result, { user_id: actor.user_id });
        this.broadcastLatestProjectEvent(projectId);
        return json(response, 200, { run });
      }
      const agentRunMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/agent-runs$/);
      if (agentRunMatch && request.method === 'POST') {
        const projectId = agentRunMatch[1];
        const actor = this.authenticate(request);
        const body = await readJson(request);
        if (body.project_id !== projectId) { const error = new Error('PROJECT_PATH_MISMATCH'); error.code = 'PROJECT_PATH_MISMATCH'; throw error; }
        const run = this.agentRunCoordinator.start(body, { user_id: actor.user_id });
        this.broadcastLatestProjectEvent(projectId);
        return json(response, 201, { run });
      }
      const presenceMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/presence$/);
      if (presenceMatch) {
        const projectId = presenceMatch[1];
        const actor = this.authenticate(request);
        this.repository.getProject(projectId, { actor_id: actor.user_id });
        if (request.method === 'GET') return json(response, 200, { presence: this.presence.list(projectId) });
        if (request.method === 'POST') {
          const body = await readJson(request);
          const record = this.presence.heartbeat({ project_id: projectId, user_id: actor.user_id, status: body.status });
          this.broadcastPresence(record);
          return json(response, 200, { presence: record });
        }
      }
      const artifactMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/artifacts$/);
      if (artifactMatch && request.method === 'POST') return this.uploadArtifact(request, response, artifactMatch[1]);
      if (artifactMatch && request.method === 'GET') {
        const actor = this.authenticate(request);
        this.repository.getProject(artifactMatch[1], { actor_id: actor.user_id });
        return json(response, 200, { artifacts: this.store.listArtifacts(artifactMatch[1]) });
      }
      const ownershipMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/ownership$/);
      if (ownershipMatch && request.method === 'POST') {
        const actor = this.authenticate(request);
        const result = this.store.transferOwner(ownershipMatch[1], (await readJson(request)).target_user_id, { user_id: actor.user_id });
        this.broadcastLatestProjectEvent(ownershipMatch[1]);
        return json(response, 200, result);
      }
      const reviewRequestMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/review-request$/);
      if (reviewRequestMatch && request.method === 'POST') {
        const actor = this.authenticate(request);
        const command = await readJson(request);
        if (command.project_id !== reviewRequestMatch[1]) { const error = new Error('PROJECT_PATH_MISMATCH'); error.code = 'PROJECT_PATH_MISMATCH'; throw error; }
        if (command.command_type !== 'REVIEW_REQUEST_CREATE') { const error = new Error('INVALID_REVIEW_REQUEST_COMMAND'); error.code = 'INVALID_REVIEW_REQUEST_COMMAND'; throw error; }
        const result = this.repository.applyCommand(command, { actor_id: actor.user_id });
        if (result.status === 'APPLIED') this.broadcastProjectEvent(result);
        return json(response, 201, result);
      }
      const memberDetailMatch = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)\/members\/([A-Za-z0-9_-]+)$/);
      if (memberDetailMatch) {
        const [, projectId, targetUserId] = memberDetailMatch;
        const actor = this.authenticate(request);
        if (request.method === 'PATCH') {
          const member = this.store.changeMemberRole(projectId, targetUserId, (await readJson(request)).role_id, { user_id: actor.user_id });
          this.broadcastLatestProjectEvent(projectId);
          return json(response, 200, { member });
        }
        if (request.method === 'DELETE') {
          const result = this.store.removeMember(projectId, targetUserId, { user_id: actor.user_id });
          this.broadcastLatestProjectEvent(projectId);
          return json(response, 200, result);
        }
      }
      const match = url.pathname.match(/^\/api\/projects\/([A-Za-z0-9_-]+)(?:\/(members|commands|events))?$/);
      if (match) {
        const [, projectId, resource] = match;
        const actor = this.authenticate(request);
        const context = { actor_id: actor.user_id };
        if (!resource && request.method === 'GET') return json(response, 200, { project: this.repository.getProject(projectId, context) });
        if (resource === 'members' && request.method === 'GET') {
          this.repository.getProject(projectId, context);
          return json(response, 200, { members: this.store.listMembers(projectId) });
        }
        if (resource === 'members' && request.method === 'POST') {
          const member = this.store.addMember(projectId, await readJson(request), { user_id: actor.user_id });
          this.broadcastLatestProjectEvent(projectId);
          return json(response, 201, { member });
        }
        if (resource === 'events' && request.method === 'GET') {
          const after = Number(url.searchParams.get('after') || 0);
          const limit = Number(url.searchParams.get('limit') || 100);
          return json(response, 200, { events: this.repository.getEvents(projectId, { after, limit }, context), full_resync_required: false });
        }
        if (resource === 'commands' && request.method === 'POST') {
          const command = await readJson(request);
          if (command.project_id !== projectId) { const error = new Error('PROJECT_PATH_MISMATCH'); error.code = 'PROJECT_PATH_MISMATCH'; throw error; }
          const result = this.repository.applyCommand(command, context);
          if (result.status === 'APPLIED') this.broadcastProjectEvent(result);
          return json(response, 200, result);
        }
      }
      return json(response, 404, { code: 'NOT_FOUND' });
    } catch (error) {
      const body = { code: error.code || 'INTERNAL_ERROR' };
      if (error.code === 'ENTITY_VERSION_CONFLICT') Object.assign(body, {
        entity_type: error.entity_type,
        entity_id: error.entity_id,
        expected_version: error.expected_version,
        current_version: error.current_version,
        current_snapshot: error.current_snapshot,
        conflicting_fields: error.conflicting_fields,
        updated_by: error.updated_by,
        updated_at: error.updated_at
      });
      return json(response, statusFor(error), body);
    }
  }
}

module.exports = CollaborationServer;
