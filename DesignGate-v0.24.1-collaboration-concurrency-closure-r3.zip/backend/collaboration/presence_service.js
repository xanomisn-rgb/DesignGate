class PresenceService {
  constructor({ now = () => Date.now(), ttlMs = 60_000 } = {}) {
    this.now = now;
    this.ttlMs = ttlMs;
    this.sessions = new Map();
  }

  heartbeat({ project_id, user_id, status }) {
    if (typeof project_id !== 'string' || !project_id) return this.fail('INVALID_PRESENCE_PROJECT');
    if (typeof user_id !== 'string' || !user_id) return this.fail('INVALID_PRESENCE_USER');
    if (!['ONLINE', 'IDLE'].includes(status)) return this.fail('INVALID_PRESENCE_STATUS');
    const record = { project_id, user_id, status, last_seen_at: new Date(this.now()).toISOString() };
    this.sessions.set(`${project_id}:${user_id}`, record);
    return { ...record };
  }

  list(projectId) {
    const cutoff = this.now() - this.ttlMs;
    const active = [];
    for (const [key, record] of this.sessions) {
      if (Date.parse(record.last_seen_at) < cutoff) { this.sessions.delete(key); continue; }
      if (record.project_id === projectId) active.push({ ...record });
    }
    return active.sort((a, b) => a.user_id.localeCompare(b.user_id));
  }

  fail(code) { const error = new Error(code); error.code = code; throw error; }
}

module.exports = PresenceService;
