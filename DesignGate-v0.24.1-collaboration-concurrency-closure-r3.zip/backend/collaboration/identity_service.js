const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SESSION_PREFIX = 'DGS_';
const DEFAULT_TTL_MS = 8 * 60 * 60 * 1000;

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function hash(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function validateId(value, label) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{1,79}$/.test(value)) fail(`INVALID_${label}`);
  return value;
}

function validatePassword(value) {
  if (typeof value !== 'string' || value.length < 12 || value.length > 512) fail('INVALID_PASSWORD');
  return value;
}

class IdentityService {
  constructor({ directory, sessionSecret, sessionTtlMs = DEFAULT_TTL_MS, now = () => Date.now() } = {}) {
    if (!directory || !sessionSecret) fail('IDENTITY_CONFIGURATION_REQUIRED');
    this.directory = directory;
    this.file = path.join(directory, 'identity.json');
    this.sessionSecret = String(sessionSecret);
    this.sessionTtlMs = sessionTtlMs;
    this.now = now;
    fs.mkdirSync(directory, { recursive: true });
  }

  read() {
    try {
      const value = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (value?.schema_version === '1.0' && Array.isArray(value.users) && Array.isArray(value.sessions)) return value;
    } catch (error) {
      if (error.code !== 'ENOENT') fail('IDENTITY_STORE_INVALID');
    }
    return { schema_version: '1.0', users: [], sessions: [] };
  }

  write(value) {
    const temp = `${this.file}.${crypto.randomUUID()}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    fs.renameSync(temp, this.file);
  }

  publicUser(user) {
    return { user_id: user.user_id, username: user.username, display_name: user.display_name, created_at: user.created_at };
  }

  register(input = {}) {
    const user_id = validateId(input.user_id, 'USER_ID');
    const username = validateId(input.username, 'USERNAME').toLowerCase();
    const password = validatePassword(input.password);
    const display_name = typeof input.display_name === 'string' && input.display_name.trim()
      ? input.display_name.trim().slice(0, 120)
      : username;
    const state = this.read();
    if (state.users.some(user => user.user_id === user_id || user.username === username)) fail('IDENTITY_ALREADY_EXISTS');
    const salt = crypto.randomBytes(16).toString('hex');
    const user = {
      user_id,
      username,
      display_name,
      password_salt: salt,
      password_hash: crypto.scryptSync(password, salt, 64).toString('hex'),
      created_at: new Date(this.now()).toISOString()
    };
    state.users.push(user);
    this.write(state);
    return this.publicUser(user);
  }

  login(input = {}) {
    const username = validateId(input.username, 'USERNAME').toLowerCase();
    const password = validatePassword(input.password);
    const state = this.read();
    const user = state.users.find(candidate => candidate.username === username);
    if (!user || !safeEqual(crypto.scryptSync(password, user.password_salt, 64).toString('hex'), user.password_hash)) fail('INVALID_CREDENTIALS');
    const token = `${SESSION_PREFIX}${crypto.randomBytes(32).toString('base64url')}`;
    const created = this.now();
    const session = {
      session_id: `SES-${crypto.randomUUID()}`,
      token_hash: hash(`${this.sessionSecret}:${token}`),
      user_id: user.user_id,
      created_at: new Date(created).toISOString(),
      expires_at: new Date(created + this.sessionTtlMs).toISOString()
    };
    state.sessions = state.sessions.filter(candidate => Date.parse(candidate.expires_at) > created);
    state.sessions.push(session);
    this.write(state);
    return { token, expires_at: session.expires_at, user: this.publicUser(user) };
  }

  authenticate(token) {
    if (typeof token !== 'string' || !token.startsWith(SESSION_PREFIX)) fail('UNAUTHENTICATED');
    const state = this.read();
    const now = this.now();
    const session = state.sessions.find(candidate => safeEqual(candidate.token_hash, hash(`${this.sessionSecret}:${token}`)));
    if (!session || Date.parse(session.expires_at) <= now) fail('UNAUTHENTICATED');
    const user = state.users.find(candidate => candidate.user_id === session.user_id);
    if (!user) fail('UNAUTHENTICATED');
    return this.publicUser(user);
  }

  revoke(token) {
    const state = this.read();
    const tokenHash = hash(`${this.sessionSecret}:${token}`);
    const before = state.sessions.length;
    state.sessions = state.sessions.filter(session => !safeEqual(session.token_hash, tokenHash));
    if (state.sessions.length !== before) this.write(state);
  }
}

module.exports = IdentityService;
