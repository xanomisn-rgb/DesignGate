const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const Canonical = require('../crypto/canonical_json');
const { ROLE_IDS } = require('./permission_service');

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function id(value, name) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)) fail(`INVALID_${name}`);
  return value;
}

function timestamp() {
  return new Date().toISOString();
}

const APPROVAL_INVALIDATING_COMMANDS = new Set([
  'UPDATE_REQUIREMENT', 'UPDATE_BOM_ITEM', 'REVISION_CREATE', 'CAD_ARTIFACT_REGISTER', 'EVIDENCE_ADD',
  'RISK_ACCEPTANCE_REQUEST', 'RISK_ACCEPTANCE_DECIDE', 'TEST_RECORD_CREATE', 'TEST_RETEST_CREATE',
  'DFMEA_ITEM_CREATE', 'DFMEA_ITEM_UPDATE', 'GATE_RECALCULATE_REQUEST'
]);

function staleCurrentApprovals(state, commandType, at) {
  if (!APPROVAL_INVALIDATING_COMMANDS.has(commandType) || !Array.isArray(state.approvals)) return;
  state.approvals = state.approvals.map(approval => approval.status === 'CURRENT'
    ? { ...approval, status: 'STALE', stale_at: at, stale_reason: `INVALIDATED_BY_${commandType}` }
    : approval);
}

class TeamStore {
  constructor({ directory } = {}) {
    if (!directory) fail('TEAM_STORE_DIRECTORY_REQUIRED');
    fs.mkdirSync(directory, { recursive: true });
    this.directory = directory;
    this.databasePath = path.join(directory, 'designgate-collaboration.sqlite');
    this.db = new DatabaseSync(this.databasePath);
    this.db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS team_projects (
        project_id TEXT PRIMARY KEY,
        project_name TEXT NOT NULL,
        project_version INTEGER NOT NULL,
        active_revision TEXT NOT NULL,
        state_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS project_members (
        project_id TEXT NOT NULL REFERENCES team_projects(project_id) ON DELETE CASCADE,
        user_id TEXT NOT NULL,
        role_id TEXT NOT NULL,
        added_at TEXT NOT NULL,
        PRIMARY KEY (project_id, user_id)
      ) STRICT;
      CREATE TABLE IF NOT EXISTS entity_versions (
        project_id TEXT NOT NULL REFERENCES team_projects(project_id) ON DELETE CASCADE,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        entity_version INTEGER NOT NULL,
        PRIMARY KEY (project_id, entity_type, entity_id)
      ) STRICT;
      CREATE TABLE IF NOT EXISTS artifact_metadata (
        artifact_id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL REFERENCES team_projects(project_id) ON DELETE CASCADE,
        revision_id TEXT NOT NULL,
        artifact_type TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        immutable INTEGER NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS agent_runs (
        run_id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL REFERENCES team_projects(project_id) ON DELETE CASCADE,
        revision_id TEXT NOT NULL,
        base_project_version INTEGER NOT NULL,
        relevant_entities_json TEXT NOT NULL,
        knowledge_snapshot_hash TEXT NOT NULL,
        rule_version TEXT NOT NULL,
        tool_registry_hash TEXT NOT NULL,
        requested_by TEXT NOT NULL,
        status TEXT NOT NULL,
        result_json TEXT,
        changed_entities_json TEXT,
        started_at TEXT NOT NULL,
        completed_at TEXT
      ) STRICT;
      CREATE TABLE IF NOT EXISTS collaboration_events (
        event_id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL REFERENCES team_projects(project_id) ON DELETE CASCADE,
        project_version INTEGER NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        entity_version INTEGER,
        event_seq INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        actor_role_snapshot TEXT NOT NULL,
        correlation_id TEXT,
        command_id TEXT,
        idempotency_key TEXT,
        base_version INTEGER,
        payload_json TEXT NOT NULL,
        payload_sha256 TEXT NOT NULL,
        previous_event_hash TEXT,
        event_hash TEXT NOT NULL,
        result_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(project_id, idempotency_key)
      ) STRICT;
    `);
  }

  close() {
    this.db.close();
  }

  transaction(work) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const value = work();
      this.db.exec('COMMIT');
      return value;
    } catch (error) {
      this.db.exec('ROLLBACK');
      throw error;
    }
  }

  appendAuditEvent({ project_id, actor_id, actor_role_snapshot, entity_type, entity_id, event_type, payload = {}, base_version = null, increment_project = true }) {
    const project = this.db.prepare('SELECT project_version, active_revision, state_json FROM team_projects WHERE project_id = ?').get(project_id);
    if (!project) fail('PROJECT_NOT_FOUND');
    const project_version = increment_project ? project.project_version + 1 : project.project_version;
    const created_at = timestamp();
    if (increment_project) {
      const state = JSON.parse(project.state_json);
      state.version = project_version;
      state.updated_at = created_at;
      this.db.prepare('UPDATE team_projects SET project_version = ?, state_json = ?, updated_at = ? WHERE project_id = ?')
        .run(project_version, JSON.stringify(state), created_at, project_id);
    }
    const prior = this.db.prepare('SELECT event_hash, event_seq FROM collaboration_events WHERE project_id = ? ORDER BY event_seq DESC LIMIT 1').get(project_id);
    const event = {
      event_id: `CEV-${crypto.randomUUID()}`,
      project_id,
      project_version,
      entity_type,
      entity_id,
      entity_version: null,
      event_seq: (prior?.event_seq || 0) + 1,
      event_type,
      actor_id,
      actor_role_snapshot,
      correlation_id: null,
      command_id: null,
      idempotency_key: null,
      base_version,
      payload,
      payload_sha256: Canonical.sha256(payload),
      previous_event_hash: prior?.event_hash || null,
      created_at
    };
    event.event_hash = Canonical.sha256({ ...event });
    const result = { project_id, project_version, entity_type, entity_id, event_id: event.event_id, event_seq: event.event_seq, event_type, status: 'APPLIED' };
    this.db.prepare('INSERT INTO collaboration_events(event_id, project_id, project_version, entity_type, entity_id, entity_version, event_seq, event_type, actor_id, actor_role_snapshot, correlation_id, command_id, idempotency_key, base_version, payload_json, payload_sha256, previous_event_hash, event_hash, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(event.event_id, project_id, project_version, entity_type, entity_id, null, event.event_seq, event_type, actor_id, actor_role_snapshot, null, null, null, base_version, JSON.stringify(payload), event.payload_sha256, event.previous_event_hash, event.event_hash, JSON.stringify(result), created_at);
    return result;
  }

  createProject(input = {}, actor = {}) {
    const project_id = id(input.project_id, 'PROJECT_ID');
    const owner = id(actor.user_id, 'ACTOR_ID');
    const project_name = typeof input.project_name === 'string' && input.project_name.trim()
      ? input.project_name.trim().slice(0, 160)
      : project_id;
    return this.transaction(() => {
      if (this.db.prepare('SELECT 1 FROM team_projects WHERE project_id = ?').get(project_id)) fail('PROJECT_ALREADY_EXISTS');
      const created_at = timestamp();
      const state = {
        schema_version: '3.1-team-metadata-v1',
        project_id,
        project_name,
        version: 1,
        design: { active_revision: 'A' },
        gate: { current_stage: 'Gate 1', status: 'OPEN' },
        requirements: [],
        bom: [],
        findings: [],
        evidence: [],
        decisions: [],
        verifications: []
      };
      this.db.prepare('INSERT INTO team_projects(project_id, project_name, project_version, active_revision, state_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(project_id, project_name, 1, 'A', JSON.stringify(state), created_at, created_at);
      this.db.prepare('INSERT INTO project_members(project_id, user_id, role_id, added_at) VALUES (?, ?, ?, ?)')
        .run(project_id, owner, 'PROJECT_OWNER', created_at);
      this.appendAuditEvent({ project_id, actor_id: owner, actor_role_snapshot: 'PROJECT_OWNER', entity_type: 'PROJECT', entity_id: project_id, event_type: 'PROJECT_CREATED', payload: { project_name }, increment_project: false });
      return structuredClone(state);
    });
  }

  hasProject(projectId) {
    return Boolean(this.db.prepare('SELECT 1 FROM team_projects WHERE project_id = ?').get(id(projectId, 'PROJECT_ID')));
  }

  createImportedProject(input = {}, actor = {}) {
    const project_id = id(input.project_id, 'PROJECT_ID');
    const owner = id(actor.user_id, 'ACTOR_ID');
    if (!input.state || typeof input.state !== 'object' || Array.isArray(input.state)) fail('IMPORT_STATE_REQUIRED');
    const project_name = typeof input.project_name === 'string' && input.project_name.trim() ? input.project_name.trim().slice(0, 160) : project_id;
    const active_revision = id(input.state.design?.active_revision || 'A', 'REVISION_ID');
    const artifacts = Array.isArray(input.artifacts) ? input.artifacts : [];
    return this.transaction(() => {
      if (this.hasProject(project_id)) fail('PROJECT_ALREADY_EXISTS');
      const created_at = timestamp();
      const state = structuredClone(input.state);
      state.schema_version = '3.1-team-metadata-v1';
      state.project_id = project_id;
      state.project_name = project_name;
      state.version = 1;
      state.design = { ...(state.design || {}), active_revision };
      state.gate = { current_stage: 'Gate 1', status: 'OPEN', migration_status: 'REVALIDATION_REQUIRED' };
      state.freeze = null;
      this.db.prepare('INSERT INTO team_projects(project_id, project_name, project_version, active_revision, state_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(project_id, project_name, 1, active_revision, JSON.stringify(state), created_at, created_at);
      this.db.prepare('INSERT INTO project_members(project_id, user_id, role_id, added_at) VALUES (?, ?, ?, ?)')
        .run(project_id, owner, 'PROJECT_OWNER', created_at);
      for (const artifact of artifacts) {
        const artifact_id = id(artifact.artifact_id, 'ARTIFACT_ID');
        const revision_id = id(artifact.revision_id, 'REVISION_ID');
        const artifact_type = id(artifact.artifact_type, 'ARTIFACT_TYPE');
        if (typeof artifact.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(artifact.sha256)) fail('ARTIFACT_HASH_INVALID');
        this.db.prepare('INSERT INTO artifact_metadata(artifact_id, project_id, revision_id, artifact_type, sha256, immutable, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
          .run(artifact_id, project_id, revision_id, artifact_type, artifact.sha256.toLowerCase(), 1, owner, artifact.created_at || created_at);
      }
      this.appendAuditEvent({ project_id, actor_id: owner, actor_role_snapshot: 'PROJECT_OWNER', entity_type: 'PROJECT', entity_id: project_id, event_type: 'SOLO_PROJECT_IMPORTED', payload: { source_project_id: input.source_project_id || null, migration_plan_id: input.migration_plan_id || null, artifact_count: artifacts.length, revalidation_required: true }, increment_project: false });
      return structuredClone(state);
    });
  }

  getMembership(projectId, userId) {
    const row = this.db.prepare('SELECT project_id, user_id, role_id, added_at FROM project_members WHERE project_id = ? AND user_id = ?')
      .get(id(projectId, 'PROJECT_ID'), id(userId, 'USER_ID'));
    return row ? { ...row } : null;
  }

  listMembers(projectId) {
    return this.db.prepare('SELECT project_id, user_id, role_id, added_at FROM project_members WHERE project_id = ? ORDER BY added_at, user_id')
      .all(id(projectId, 'PROJECT_ID')).map(row => ({ ...row }));
  }

  registerArtifact(input = {}) {
    const artifact_id = id(input.artifact_id, 'ARTIFACT_ID');
    const project_id = id(input.project_id, 'PROJECT_ID');
    const revision_id = id(input.revision_id, 'REVISION_ID');
    const artifact_type = id(input.artifact_type, 'ARTIFACT_TYPE');
    if (typeof input.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(input.sha256)) fail('ARTIFACT_HASH_INVALID');
    if (input.immutable !== true) fail('ARTIFACT_MUTABILITY_FORBIDDEN');
    const created_by = id(input.created_by, 'USER_ID');
    if (!this.db.prepare('SELECT 1 FROM team_projects WHERE project_id = ?').get(project_id)) fail('PROJECT_NOT_FOUND');
    this.db.prepare('INSERT INTO artifact_metadata(artifact_id, project_id, revision_id, artifact_type, sha256, immutable, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(artifact_id, project_id, revision_id, artifact_type, input.sha256.toLowerCase(), 1, created_by, input.created_at || timestamp());
    return this.getArtifact(artifact_id);
  }

  getArtifact(artifactId) {
    const row = this.db.prepare('SELECT artifact_id, project_id, revision_id, artifact_type, sha256, immutable, created_by, created_at FROM artifact_metadata WHERE artifact_id = ?').get(id(artifactId, 'ARTIFACT_ID'));
    return row ? { ...row, immutable: Boolean(row.immutable) } : null;
  }

  listArtifacts(projectId) {
    return this.db.prepare('SELECT artifact_id, project_id, revision_id, artifact_type, sha256, immutable, created_by, created_at FROM artifact_metadata WHERE project_id = ? ORDER BY created_at, artifact_id')
      .all(id(projectId, 'PROJECT_ID')).map(row => ({ ...row, immutable: Boolean(row.immutable) }));
  }

  createAgentRun(input = {}, actor = {}) {
    const run_id = id(input.run_id, 'AGENT_RUN_ID');
    const project_id = id(input.project_id, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    return this.transaction(() => {
      const member = this.getMembership(project_id, actor_id);
      if (!member) fail('PROJECT_SCOPE_DENIED');
      const project = this.db.prepare('SELECT project_version FROM team_projects WHERE project_id = ?').get(project_id);
      if (!project) fail('PROJECT_NOT_FOUND');
      const started_at = timestamp();
      this.db.prepare('INSERT INTO agent_runs(run_id, project_id, revision_id, base_project_version, relevant_entities_json, knowledge_snapshot_hash, rule_version, tool_registry_hash, requested_by, status, result_json, changed_entities_json, started_at, completed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, NULL)')
        .run(run_id, project_id, input.revision_id, input.base_project_version, JSON.stringify(input.relevant_entity_versions), input.knowledge_snapshot_hash, input.rule_version, input.tool_registry_hash, actor_id, 'RUNNING', started_at);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: member.role_id, entity_type: 'AGENT_RUN', entity_id: run_id, event_type: 'AGENT_RUN_STARTED', payload: { revision_id: input.revision_id, base_project_version: input.base_project_version } });
      return this.getAgentRun(run_id);
    });
  }

  getAgentRun(runId) {
    const row = this.db.prepare('SELECT run_id, project_id, revision_id, base_project_version, relevant_entities_json, knowledge_snapshot_hash, rule_version, tool_registry_hash, requested_by, status, result_json, changed_entities_json, started_at, completed_at FROM agent_runs WHERE run_id = ?').get(id(runId, 'AGENT_RUN_ID'));
    return row ? { ...row, relevant_entity_versions: JSON.parse(row.relevant_entities_json), result: row.result_json ? JSON.parse(row.result_json) : null, changed_entities: row.changed_entities_json ? JSON.parse(row.changed_entities_json) : [], relevant_entities_json: undefined, result_json: undefined, changed_entities_json: undefined } : null;
  }

  completeAgentRun(runId, result, actor = {}) {
    const run_id = id(runId, 'AGENT_RUN_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    return this.transaction(() => {
      const run = this.getAgentRun(run_id);
      if (!run) fail('AGENT_RUN_NOT_FOUND');
      const member = this.getMembership(run.project_id, actor_id);
      if (!member) fail('PROJECT_SCOPE_DENIED');
      if (run.requested_by !== actor_id) fail('AGENT_RUN_COMPLETION_FORBIDDEN');
      if (run.status !== 'RUNNING') fail('AGENT_RUN_NOT_RUNNING');
      const changed_entities = run.relevant_entity_versions.filter(entity => this.entityVersion(run.project_id, entity.entity_type, entity.entity_id) !== entity.version)
        .map(entity => ({ entity_type: entity.entity_type, entity_id: entity.entity_id, expected_version: entity.version, current_version: this.entityVersion(run.project_id, entity.entity_type, entity.entity_id) }));
      const status = changed_entities.length ? 'REVALIDATION_REQUIRED' : 'COMPLETED';
      const completed_at = timestamp();
      this.db.prepare('UPDATE agent_runs SET status = ?, result_json = ?, changed_entities_json = ?, completed_at = ? WHERE run_id = ?')
        .run(status, JSON.stringify(result), JSON.stringify(changed_entities), completed_at, run_id);
      this.appendAuditEvent({ project_id: run.project_id, actor_id, actor_role_snapshot: member.role_id, entity_type: 'AGENT_RUN', entity_id: run_id, event_type: status === 'COMPLETED' ? 'AGENT_RUN_COMPLETED' : 'AGENT_RESULT_STALE', payload: { revision_id: run.revision_id, changed_entities } });
      return this.getAgentRun(run_id);
    });
  }

  listProjectIds(userId) {
    return this.db.prepare('SELECT project_id FROM project_members WHERE user_id = ? ORDER BY project_id')
      .all(id(userId, 'USER_ID')).map(row => row.project_id);
  }

  listEvents(projectId, { after = 0, limit = 100 } = {}) {
    const safeAfter = Number.isInteger(after) && after >= 0 ? after : 0;
    const safeLimit = Number.isInteger(limit) && limit > 0 && limit <= 500 ? limit : 100;
    return this.db.prepare('SELECT event_id, project_id, project_version, entity_type, entity_id, entity_version, event_seq, event_type, actor_id, actor_role_snapshot, correlation_id, command_id, idempotency_key, base_version, payload_json, payload_sha256, previous_event_hash, event_hash, created_at FROM collaboration_events WHERE project_id = ? AND event_seq > ? ORDER BY event_seq ASC LIMIT ?')
      .all(id(projectId, 'PROJECT_ID'), safeAfter, safeLimit)
      .map(row => ({ ...row, payload: JSON.parse(row.payload_json), payload_json: undefined }));
  }

  getProjectForActor(projectId, userId) {
    const member = this.getMembership(projectId, userId);
    if (!member) fail('PROJECT_SCOPE_DENIED');
    const row = this.db.prepare('SELECT state_json FROM team_projects WHERE project_id = ?').get(id(projectId, 'PROJECT_ID'));
    if (!row) fail('PROJECT_NOT_FOUND');
    return JSON.parse(row.state_json);
  }

  addMember(projectId, member = {}, actor = {}) {
    const project_id = id(projectId, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    const user_id = id(member.user_id, 'USER_ID');
    const role_id = id(member.role_id, 'ROLE_ID');
    if (!ROLE_IDS.includes(role_id)) fail('INVALID_ROLE_ID');
    return this.transaction(() => {
      const owner = this.getMembership(project_id, actor_id);
      if (!owner || owner.role_id !== 'PROJECT_OWNER') fail('PERMISSION_DENIED');
      if (!this.db.prepare('SELECT 1 FROM team_projects WHERE project_id = ?').get(project_id)) fail('PROJECT_NOT_FOUND');
      if (this.getMembership(project_id, user_id)) fail('MEMBER_ALREADY_EXISTS');
      const added_at = timestamp();
      this.db.prepare('INSERT INTO project_members(project_id, user_id, role_id, added_at) VALUES (?, ?, ?, ?)')
        .run(project_id, user_id, role_id, added_at);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: owner.role_id, entity_type: 'MEMBER', entity_id: user_id, event_type: 'MEMBER_ADDED', payload: { role_id } });
      return this.getMembership(project_id, user_id);
    });
  }

  transferOwner(projectId, targetUserId, actor = {}) {
    const project_id = id(projectId, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    const target_id = id(targetUserId, 'USER_ID');
    return this.transaction(() => {
      const owner = this.getMembership(project_id, actor_id);
      const target = this.getMembership(project_id, target_id);
      if (!owner || owner.role_id !== 'PROJECT_OWNER') fail('PERMISSION_DENIED');
      if (!target) fail('MEMBER_NOT_FOUND');
      if (target_id === actor_id) fail('OWNER_TRANSFER_TARGET_INVALID');
      this.db.prepare('UPDATE project_members SET role_id = ? WHERE project_id = ? AND user_id = ?').run('PROJECT_OWNER', project_id, target_id);
      this.db.prepare('UPDATE project_members SET role_id = ? WHERE project_id = ? AND user_id = ?').run('TEACHER_REVIEWER', project_id, actor_id);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: 'PROJECT_OWNER', entity_type: 'MEMBER', entity_id: target_id, event_type: 'OWNER_TRANSFERRED', payload: { previous_owner_id: actor_id, new_owner_id: target_id } });
      return { previous_owner: this.getMembership(project_id, actor_id), new_owner: this.getMembership(project_id, target_id) };
    });
  }

  changeMemberRole(projectId, targetUserId, roleId, actor = {}) {
    const project_id = id(projectId, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    const target_id = id(targetUserId, 'USER_ID');
    const role_id = id(roleId, 'ROLE_ID');
    if (!ROLE_IDS.includes(role_id)) fail('INVALID_ROLE_ID');
    return this.transaction(() => {
      const owner = this.getMembership(project_id, actor_id);
      const target = this.getMembership(project_id, target_id);
      if (!owner || owner.role_id !== 'PROJECT_OWNER') fail('PERMISSION_DENIED');
      if (!target) fail('MEMBER_NOT_FOUND');
      // Ownership has a dedicated, atomic transfer path; role editing must
      // never accidentally create, demote, or strand an owner.
      if (target.role_id === 'PROJECT_OWNER' || role_id === 'PROJECT_OWNER') fail('OWNER_ROLE_CHANGE_FORBIDDEN');
      if (target.role_id === role_id) return target;
      this.db.prepare('UPDATE project_members SET role_id = ? WHERE project_id = ? AND user_id = ?').run(role_id, project_id, target_id);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: owner.role_id, entity_type: 'MEMBER', entity_id: target_id, event_type: 'MEMBER_ROLE_CHANGED', payload: { previous_role_id: target.role_id, role_id } });
      return this.getMembership(project_id, target_id);
    });
  }

  removeMember(projectId, targetUserId, actor = {}) {
    const project_id = id(projectId, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    const target_id = id(targetUserId, 'USER_ID');
    return this.transaction(() => {
      const owner = this.getMembership(project_id, actor_id);
      const target = this.getMembership(project_id, target_id);
      if (!owner || owner.role_id !== 'PROJECT_OWNER') fail('PERMISSION_DENIED');
      if (!target) fail('MEMBER_NOT_FOUND');
      if (target.role_id === 'PROJECT_OWNER') fail('LAST_OWNER_CANNOT_REMOVE');
      this.db.prepare('DELETE FROM project_members WHERE project_id = ? AND user_id = ?').run(project_id, target_id);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: owner.role_id, entity_type: 'MEMBER', entity_id: target_id, event_type: 'MEMBER_REMOVED', payload: { removed_role_id: target.role_id } });
      return { project_id, user_id: target_id, status: 'REMOVED' };
    });
  }

  leaveProject(projectId, actor = {}) {
    const project_id = id(projectId, 'PROJECT_ID');
    const actor_id = id(actor.user_id, 'ACTOR_ID');
    return this.transaction(() => {
      const member = this.getMembership(project_id, actor_id);
      if (!member) fail('PROJECT_SCOPE_DENIED');
      const owners = this.db.prepare('SELECT user_id FROM project_members WHERE project_id = ? AND role_id = ?').all(project_id, 'PROJECT_OWNER');
      if (member.role_id === 'PROJECT_OWNER' && owners.length <= 1) fail('LAST_OWNER_CANNOT_LEAVE');
      this.db.prepare('DELETE FROM project_members WHERE project_id = ? AND user_id = ?').run(project_id, actor_id);
      this.appendAuditEvent({ project_id, actor_id, actor_role_snapshot: member.role_id, entity_type: 'MEMBER', entity_id: actor_id, event_type: 'MEMBER_LEFT', payload: {} });
      return { project_id, user_id: actor_id, status: 'LEFT' };
    });
  }

  entityVersion(projectId, entityType, entityId) {
    const row = this.db.prepare('SELECT entity_version FROM entity_versions WHERE project_id = ? AND entity_type = ? AND entity_id = ?')
      .get(projectId, entityType, entityId);
    return row?.entity_version || 0;
  }

  applyEntityCommand({ command, actor, authorize, mutate }) {
    return this.transaction(() => {
      const project_id = id(command.project_id, 'PROJECT_ID');
      const actor_id = id(actor.user_id, 'ACTOR_ID');
      const member = this.getMembership(project_id, actor_id);
      if (!member) fail('PROJECT_SCOPE_DENIED');
      authorize(member.role_id);

      const payload_sha256 = Canonical.sha256({
        command_type: command.command_type,
        entity_type: command.entity_type,
        entity_id: command.entity_id,
        payload: command.payload
      });
      const replay = this.db.prepare('SELECT payload_sha256, result_json FROM collaboration_events WHERE project_id = ? AND idempotency_key = ?')
        .get(project_id, command.idempotency_key);
      if (replay) {
        if (replay.payload_sha256 !== payload_sha256) fail('IDEMPOTENCY_CONFLICT');
        return { ...JSON.parse(replay.result_json), status: 'DUPLICATE_REPLAY' };
      }

      const project = this.db.prepare('SELECT project_version, active_revision, state_json FROM team_projects WHERE project_id = ?').get(project_id);
      if (!project) fail('PROJECT_NOT_FOUND');
      const current_entity_version = this.entityVersion(project_id, command.entity_type, command.entity_id);
      if (command.base_entity_version !== current_entity_version) {
        const error = new Error('ENTITY_VERSION_CONFLICT');
        error.code = 'ENTITY_VERSION_CONFLICT';
        error.entity_type = command.entity_type;
        error.entity_id = command.entity_id;
        error.expected_version = command.base_entity_version;
        error.current_version = current_entity_version;
        error.current_snapshot = mutate(JSON.parse(project.state_json), { read_only: true });
        // Retain this legacy property for callers that shipped before the
        // collaboration conflict contract was expanded.
        error.current_value = error.current_snapshot;
        error.conflicting_fields = Object.keys(command.payload).filter(field => JSON.stringify(command.payload[field]) !== JSON.stringify(error.current_snapshot?.[field]));
        const latest = this.db.prepare('SELECT actor_id, created_at FROM collaboration_events WHERE project_id = ? AND entity_type = ? AND entity_id = ? ORDER BY event_seq DESC LIMIT 1')
          .get(project_id, command.entity_type, command.entity_id);
        error.updated_by = latest?.actor_id || null;
        error.updated_at = latest?.created_at || null;
        throw error;
      }
      const state = JSON.parse(project.state_json);
      const nextState = mutate(state, { read_only: false });
      const project_version = project.project_version + 1;
      const entity_version = current_entity_version + 1;
      const created_at = timestamp();
      staleCurrentApprovals(nextState, command.command_type, created_at);
      nextState.version = project_version;
      nextState.updated_at = created_at;
      this.db.prepare('UPDATE team_projects SET project_version = ?, active_revision = ?, state_json = ?, updated_at = ? WHERE project_id = ?')
        .run(project_version, nextState.design?.active_revision || project.active_revision, JSON.stringify(nextState), created_at, project_id);
      this.db.prepare('INSERT INTO entity_versions(project_id, entity_type, entity_id, entity_version) VALUES (?, ?, ?, ?) ON CONFLICT(project_id, entity_type, entity_id) DO UPDATE SET entity_version = excluded.entity_version')
        .run(project_id, command.entity_type, command.entity_id, entity_version);

      const prior = this.db.prepare('SELECT event_hash, event_seq FROM collaboration_events WHERE project_id = ? ORDER BY event_seq DESC LIMIT 1').get(project_id);
      const event = {
        event_id: `CEV-${crypto.randomUUID()}`,
        project_id,
        project_version,
        entity_type: command.entity_type,
        entity_id: command.entity_id,
        entity_version,
        event_seq: (prior?.event_seq || 0) + 1,
        event_type: command.event_type,
        actor_id,
        actor_role_snapshot: member.role_id,
        correlation_id: command.correlation_id || null,
        command_id: command.command_id,
        idempotency_key: command.idempotency_key,
        base_version: command.base_project_version,
        payload: command.payload,
        payload_sha256,
        previous_event_hash: prior?.event_hash || null,
        created_at
      };
      event.event_hash = Canonical.sha256({ ...event });
      const result = { project_id, project_version, entity_type: command.entity_type, entity_id: command.entity_id, entity_version, event_id: event.event_id, event_seq: event.event_seq, event_type: event.event_type, status: 'APPLIED' };
      this.db.prepare('INSERT INTO collaboration_events(event_id, project_id, project_version, entity_type, entity_id, entity_version, event_seq, event_type, actor_id, actor_role_snapshot, correlation_id, command_id, idempotency_key, base_version, payload_json, payload_sha256, previous_event_hash, event_hash, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .run(event.event_id, project_id, project_version, event.entity_type, event.entity_id, entity_version, event.event_seq, event.event_type, actor_id, member.role_id, event.correlation_id, event.command_id, event.idempotency_key, event.base_version, JSON.stringify(event.payload), event.payload_sha256, event.previous_event_hash, event.event_hash, JSON.stringify(result), created_at);
      return result;
    });
  }
}

module.exports = TeamStore;
