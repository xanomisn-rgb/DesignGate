const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function identifier(value, name) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)) fail(`INVALID_${name}`);
  return value;
}

function filename(value) {
  if (typeof value !== 'string' || !value || value !== path.basename(value) || value.length > 180) fail('ARTIFACT_FILENAME_INVALID');
  return value;
}

class LocalImmutableArtifactStore {
  constructor({ directory } = {}) {
    if (!directory) fail('ARTIFACT_DIRECTORY_REQUIRED');
    this.directory = directory;
    this.metadataFile = path.join(directory, 'artifact-metadata.jsonl');
    fs.mkdirSync(directory, { recursive: true });
  }

  pathFor(storageKey) {
    if (typeof storageKey !== 'string' || !/^[A-Za-z0-9_/-]+$/.test(storageKey)) fail('ARTIFACT_STORAGE_KEY_INVALID');
    const target = path.resolve(this.directory, storageKey);
    if (!target.startsWith(`${path.resolve(this.directory)}${path.sep}`)) fail('ARTIFACT_STORAGE_KEY_INVALID');
    return target;
  }

  put(input = {}) {
    const project_id = identifier(input.project_id, 'PROJECT_ID');
    const revision_id = identifier(input.revision_id, 'REVISION_ID');
    const artifact_type = identifier(input.artifact_type, 'ARTIFACT_TYPE');
    const original_filename = filename(input.original_filename);
    const created_by = identifier(input.created_by, 'USER_ID');
    if (!Buffer.isBuffer(input.bytes) || input.bytes.length === 0) fail('ARTIFACT_BYTES_REQUIRED');
    const artifact_id = `ART-${crypto.randomUUID()}`;
    const sha256 = crypto.createHash('sha256').update(input.bytes).digest('hex');
    const storage_key = `${project_id}/${revision_id}/${artifact_id}-${sha256.slice(0, 16)}`;
    const destination = this.pathFor(storage_key);
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    const temporary = `${destination}.${crypto.randomUUID()}.tmp`;
    fs.writeFileSync(temporary, input.bytes, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, destination);
    const metadata = {
      artifact_id,
      project_id,
      revision_id,
      artifact_type,
      original_filename,
      storage_key,
      mime_type: input.mime_type || 'application/octet-stream',
      size_bytes: input.bytes.length,
      sha256,
      created_by,
      created_at: new Date().toISOString(),
      supersedes: input.supersedes || null,
      immutable: true
    };
    fs.appendFileSync(this.metadataFile, `${JSON.stringify(metadata)}\n`, { encoding: 'utf8', mode: 0o600 });
    return metadata;
  }

  getMetadata(artifactId) {
    if (!fs.existsSync(this.metadataFile)) return null;
    return fs.readFileSync(this.metadataFile, 'utf8').split('\n').filter(Boolean).map(JSON.parse).find(row => row.artifact_id === artifactId) || null;
  }

  exists(storageKey) { return fs.existsSync(this.pathFor(storageKey)); }
  verifyHash(metadata) {
    if (!metadata || !this.exists(metadata.storage_key)) return false;
    const actual = crypto.createHash('sha256').update(fs.readFileSync(this.pathFor(metadata.storage_key))).digest('hex');
    return actual === metadata.sha256;
  }
}

module.exports = LocalImmutableArtifactStore;
