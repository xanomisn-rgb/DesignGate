const crypto = require('crypto');

function fail(code) { const error = new Error(code); error.code = code; throw error; }
function hash(value, name) { if (typeof value !== 'string' || !/^[a-f0-9]{64}$/i.test(value)) fail(`INVALID_${name}`); return value.toLowerCase(); }
function identifier(value, name) { if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value)) fail(`INVALID_${name}`); return value; }

class AgentRunCoordinator {
  constructor({ store } = {}) { if (!store) fail('AGENT_RUN_STORE_REQUIRED'); this.store = store; }
  start(input = {}, actor = {}) {
    const project_id = identifier(input.project_id, 'PROJECT_ID');
    const project = this.store.getProjectForActor(project_id, identifier(actor.user_id, 'ACTOR_ID'));
    const revision_id = identifier(input.revision_id, 'REVISION_ID');
    if (project.design?.active_revision !== revision_id) fail('AGENT_RUN_REVISION_MISMATCH');
    if (!Array.isArray(input.relevant_entity_versions)) fail('INVALID_RELEVANT_ENTITY_VERSIONS');
    const relevant_entity_versions = input.relevant_entity_versions.map(entity => ({ entity_type: identifier(entity?.entity_type, 'ENTITY_TYPE'), entity_id: identifier(entity?.entity_id, 'ENTITY_ID'), version: Number.isInteger(entity?.version) && entity.version >= 0 ? entity.version : (() => { fail('INVALID_ENTITY_VERSION'); })() }));
    return this.store.createAgentRun({ run_id: `ARUN-${crypto.randomUUID()}`, project_id, revision_id, base_project_version: project.version, relevant_entity_versions, knowledge_snapshot_hash: hash(input.knowledge_snapshot_hash, 'KNOWLEDGE_SNAPSHOT_HASH'), rule_version: identifier(input.rule_version, 'RULE_VERSION'), tool_registry_hash: hash(input.tool_registry_hash, 'TOOL_REGISTRY_HASH') }, actor);
  }
  complete(runId, result = {}, actor = {}) {
    if (!result || typeof result !== 'object' || Array.isArray(result)) fail('INVALID_AGENT_RESULT');
    return this.store.completeAgentRun(runId, result, actor);
  }
}

module.exports = AgentRunCoordinator;
