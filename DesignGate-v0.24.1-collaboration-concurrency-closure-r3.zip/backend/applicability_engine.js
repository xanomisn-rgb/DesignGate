class ApplicabilityEngine {
  // 定义热塑性塑料及常见原厂商品名白名单列表，杜绝金属件误判为热塑性塑料
  static THERMOPLASTICS = new Set([
    "abs", "pc", "pp", "pa6", "pa66", "pom", "pbt", "pc+abs", "pc/abs", 
    "tpu", "peek", "pmma", "ps", "hips", "pet", "pvc", "pla",
    // 常见热塑性塑料原厂商品名 (Trade Names)
    "bayblend", "makrolon", "cycolac", "moplen", "ultramid", "lexan", "zettel", "delrin"
  ]);

  static isRuleApplicable(rule, context = {}) {
    if (!rule || !rule.applies_if) {
      return { status: "APPLICABLE", applicable: true };
    }

    const { process = null, material = null, stage = null } = context;
    const cond = rule.applies_if;

    // 1. 校验成型工艺适用性 (三态判断：缺失信息时判定为 UNKNOWN_APPLICABILITY，绝不默认适用)
    if (cond.process && cond.process.length > 0) {
      if (!process) {
        return {
          status: "UNKNOWN_APPLICABILITY",
          applicable: false,
          reason: `规则适用工艺为 [${cond.process.join(",")}]，当前未指定成型工艺，无法确认适用性 (STATUS: UNKNOWN)。`
        };
      }
      const matchProcess = cond.process.some(p => process.toLowerCase().includes(p.toLowerCase()));
      if (!matchProcess) {
        return {
          status: "NOT_APPLICABLE",
          applicable: false,
          reason: `规则适用工艺为 [${cond.process.join(",")}]，当前方案成型工艺为 [${process}]，规则不适用。`
        };
      }
    }

    // 2. 校验材料族适用性 (修复 thermoplastics 误判金属 Bug)
    if (cond.material_family && cond.material_family.length > 0) {
      if (!material) {
        return {
          status: "UNKNOWN_APPLICABILITY",
          applicable: false,
          reason: `规则限定材料族为 [${cond.material_family.join(",")}]，当前未指定材料，无法确认适用性 (STATUS: UNKNOWN)。`
        };
      }

      const cleanMat = material.toLowerCase().replace(/[()（）]/g, " ").trim();
      const isThermoplastic = Array.from(ApplicabilityEngine.THERMOPLASTICS).some(tp => cleanMat.includes(tp));

      const tradeToFamily = {
        "bayblend": "pc+abs",
        "makrolon": "pc",
        "cycolac": "abs",
        "moplen": "pp",
        "ultramid": "pa6"
      };

      const matchMat = cond.material_family.some(targetFamily => {
        const tf = targetFamily.toLowerCase();
        if (tf === "thermoplastics") {
          return isThermoplastic;
        }
        if (cleanMat.includes(tf)) {
          return true;
        }
        // 检查商品名映射
        for (const [trade, fam] of Object.entries(tradeToFamily)) {
          if (cleanMat.includes(trade) && fam.includes(tf)) {
            return true;
          }
        }
        return false;
      });

      if (!matchMat) {
        return {
          status: "NOT_APPLICABLE",
          applicable: false,
          reason: `规则适用材料族为 [${cond.material_family.join(",")}]，当前方案材料为 [${material}]，材料族不匹配。`
        };
      }
    }

    // 3. 校验评审阶段适用性
    if (cond.stage && cond.stage.length > 0 && stage) {
      const matchStage = cond.stage.some(s => stage.includes(s));
      if (!matchStage) {
        return {
          status: "NOT_APPLICABLE",
          applicable: false,
          reason: `规则限定评审阶段为 [${cond.stage.join(",")}]，当前阶段不适用。`
        };
      }
    }

    return { status: "APPLICABLE", applicable: true };
  }
}

module.exports = ApplicabilityEngine;
