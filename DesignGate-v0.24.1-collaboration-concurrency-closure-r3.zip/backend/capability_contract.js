const CAPABILITY_STATUSES=Object.freeze([
  'EVALUATED',
  'PARTIALLY_EVALUATED',
  'NOT_EVALUATED_MISSING_INPUT',
  'NOT_EVALUATED_UNSUPPORTED_METHOD',
  'REQUIRES_EXTERNAL_SOLVER',
  'REQUIRES_EXPERT_REVIEW',
  'NOT_EVALUATED_RUNTIME_ERROR'
]);

function safeObject(value,name){
  if(value===undefined) return {};
  if(!value || typeof value!=='object' || Array.isArray(value)) throw Error(name+' must be an object');
  return structuredClone(value);
}
function stringArray(value,name){
  if(value===undefined) return [];
  if(!Array.isArray(value)||value.some(item=>typeof item!=='string'||!item.trim())) throw Error(name+' must be a string array');
  return [...new Set(value.map(item=>item.trim()))];
}
function createCapabilityResult(input={}){
  if(!input || typeof input!=='object'||Array.isArray(input)) throw Error('capability result must be an object');
  if(typeof input.capability!=='string'||!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(input.capability)) throw Error('capability must be a namespaced identifier');
  if(!CAPABILITY_STATUSES.includes(input.status)) throw Error('invalid capability status');
  if(input.method!==undefined && (typeof input.method!=='string'||!input.method.trim())) throw Error('method must be a non-empty string');
  if(input.confidence!==undefined && (!Number.isFinite(input.confidence)||input.confidence<0||input.confidence>1)) throw Error('confidence must be between 0 and 1');
  if(input.revision!==undefined && (typeof input.revision!=='string'||!input.revision.trim())) throw Error('revision must be a non-empty string');
  const record={
    capability:input.capability,
    status:input.status,
    method:input.method||null,
    inputs:safeObject(input.inputs,'inputs'),
    result:safeObject(input.result,'result'),
    confidence:input.confidence??0,
    limitations:stringArray(input.limitations,'limitations'),
    evidence_ids:stringArray(input.evidence_ids,'evidence_ids'),
    source_ids:stringArray(input.source_ids,'source_ids'),
    revision:input.revision||null
  };
  if(record.status==='EVALUATED'&&!record.method) throw Error('EVALUATED capability requires a method');
  if(record.status==='EVALUATED'&&!record.evidence_ids.length) record.limitations.push('No evidence is bound to this evaluation.');
  return record;
}

module.exports={CAPABILITY_STATUSES,createCapabilityResult};
