/* Online regression screen, not the offline model-quality scorer. */
const Check = require('./check_engine');
const C = require('./contracts');
function critique(before, after, evaluate = p => new Check().evaluate(p)) {
  const baseline = structuredClone(before), candidate = structuredClone(after);
  // Compare like-for-like automatic coverage; old attestations cannot bless a candidate.
  for (const p of [baseline, candidate]) { p.verifications = []; p.basis_hash = null; }
  const a = evaluate(baseline), b = evaluate(candidate);
  const previous = new Map(a.checks.map(c => [c.check_id, c]));
  const reasons = b.checks.filter(c => c.status === 'FAIL' && previous.get(c.check_id)?.status !== 'FAIL')
    .map(c => ({code:'NEW_FAILED_CHECK', check_id:c.check_id}));
  for (const c of b.checks) if (previous.get(c.check_id)?.status === 'PASS' && !['PASS','NOT_APPLICABLE'].includes(c.status))
    reasons.push({code:'LOST_KNOWN_COVERAGE', check_id:c.check_id});
  for (const c of a.checks) if (c.status === 'PASS' && !b.checks.some(x => x.check_id === c.check_id))
    reasons.push({code:'REMOVED_CHECK', check_id:c.check_id});
  const ids = new Set(a.findings.filter(f => ['HIGH','CRITICAL'].includes(f.severity)).map(f => f.issue_id));
  for (const f of b.findings) if (['HIGH','CRITICAL'].includes(f.severity) && !ids.has(f.issue_id))
    reasons.push({code:'NEW_HIGH_RISK', issue_id:f.issue_id});
  return {status:reasons.length?'BLOCKED_REGRESSION':'NO_DETECTED_REGRESSION',reasons,
    candidate_hash:C.hash(after),engineering_approval:false,
    limitation:'Only covered deterministic checks were compared. No simulation or model-quality evaluation was performed.'};
}
module.exports={critique};
