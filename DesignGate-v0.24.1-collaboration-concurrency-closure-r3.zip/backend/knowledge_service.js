const fs = require('fs');
const C = require('./contracts');
const path = require('path');

const norm = value => String(value ?? '').normalize('NFKC').toLowerCase().trim().replace(/\s+/g, ' ');
const aliases = {
  injection_molding:['注塑','injection molding'], cnc_milling:['cnc','机加工','铣削'],
  sheet_metal:['钣金','折弯','sheet metal'], extrusion:['挤压','extrusion'], sls:['sls','选择性激光烧结'],
  pc:['聚碳酸酯','pc'], abs:['abs'], pp:['聚丙烯','pp'], pom:['聚甲醛','acetal','pom'],
  pa:['尼龙','nylon','pa'], pmma:['亚克力','acrylic','pmma'], aluminum:['铝合金','aluminum'],
  'pc+abs':['pc/abs','pc+abs'], wall:['壁厚','wall thickness'], draft:['拔模','脱模','draft'],
  rib:['加强筋','肋厚','rib'], density:['密度','density'], battery:['电池','电芯','battery','cell']
};
const canonical = value => {
  const valueNorm=norm(value);
  return Object.entries(aliases).find(([key,values])=>key===valueNorm||values.includes(valueNorm))?.[0]||valueNorm;
};
const readJson = file => JSON.parse(fs.readFileSync(file,'utf8'));
const exists = file => fs.existsSync(file);
const finitePositiveInteger = (value,name) => {
  if(!Number.isInteger(value)||value<1) throw Error(`${name} must be a positive integer`);
  return value;
};
function contains(haystack, term) {
  const normalized=norm(term); if(!normalized) return false;
  if(/^[a-z0-9+/_ .-]+$/.test(normalized)) {
    const escaped=normalized.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    return new RegExp(`(?:^|[^a-z0-9])${escaped}(?:$|[^a-z0-9])`,'i').test(haystack);
  }
  return haystack.includes(normalized);
}
function dedupeById(rows) {
  const result=[], seen=new Set();
  for(const row of rows) if(row?.id&&!seen.has(row.id)) { seen.add(row.id); result.push(row); }
  return result;
}
function standardRecord(row) {
  const id=`STD-${row.code}`;
  return {
    id,title:`${row.code} — ${row.name}`,kind:'standard_index',domain:row.domain,
    terms:[row.code,row.name,row.domain].filter(Boolean),claim:`Standard index only: ${row.applicability||'project applicability requires review.'}`,
    scope:{domain:row.domain||'unknown'},limitations:[
      'This is an index entry, not licensed full standard text or a project applicability decision.',
      'It cannot independently establish product compliance, a hard gate, or engineering release.'
    ],source_ids:[`STD-SOURCE-${C.hash(row.code).slice(0,16)}`],verification_status:'INDEX_ONLY',hard_gate:false,
    source_metadata:{code:row.code,type:row.type,status:row.status,source_url:row.source_url,applicability:row.applicability}
  };
}
function standardSource(row) {
  return {id:`STD-SOURCE-${C.hash(row.code).slice(0,16)}`,publisher:row.source_org||'Standard index',title:row.code,
    url:row.source_url,locator:'Metadata index only; full text was not imported.',checked_on:'2026-09-09',
    verification_scope:'STANDARD_INDEX_METADATA_ONLY',document_date:row.publication_date||null};
}

class KnowledgeService {
  constructor(root=path.join(__dirname,'../knowledge/curated')) {
    this.root=root;
    this.data=readJson(path.join(root,'records.json'));
    this.catalog=readJson(path.join(root,'executable_rules.json'));
    const expansion=path.join(root,'..','expansion');
    const patchRecords=exists(path.join(expansion,'records.upsert.json')) ? readJson(path.join(expansion,'records.upsert.json')).records : [];
    const patchSources=exists(path.join(expansion,'sources.upsert.json')) ? readJson(path.join(expansion,'sources.upsert.json')) : [];
    this.standards=exists(path.join(expansion,'standards.upsert.json')) ? readJson(path.join(expansion,'standards.upsert.json')) : [];
    this.quarantine=exists(path.join(expansion,'quarantine.review_required.json')) ? readJson(path.join(expansion,'quarantine.review_required.json')) : [];
    this.batteryCells=exists(path.join(expansion,'battery_cells.json')) ? readJson(path.join(expansion,'battery_cells.json')) : [];
    this.batteryRules=exists(path.join(expansion,'battery_pack_rules.json')) ? readJson(path.join(expansion,'battery_pack_rules.json')) : [];
    const baselineSources=readJson(path.join(root,'sources.json'));
    const sourceMap=new Map();
    for(const source of [...baselineSources,...patchSources,...this.standards.map(standardSource)]) sourceMap.set(source.id,source);
    this.sources=[...sourceMap.values()];
    // Existing curated cards win on duplicate IDs so earlier, tested condition semantics remain stable.
    this.records=dedupeById([...this.data.records,...patchRecords,...this.standards.map(standardRecord)]);
    this.recordMap=new Map(this.records.map(record=>[record.id,record]));
    this.quarantineMap=new Map(this.quarantine.map(record=>[record.id,record]));
    this.lexicon=[...new Set(this.records.flatMap(record=>record.terms||[]).concat(Object.values(aliases).flat()))];
    this.release=`${this.data.release}+knowledge-2026-09-09`;
    this.validate();
  }
  validate() {
    if(this.catalog.release!==this.data.release) throw Error('知识与规则版本不一致');
    const sourceIds=new Set(this.sources.map(source=>source.id));
    if(sourceIds.size!==this.sources.length) throw Error('知识来源编号重复');
    for(const source of this.sources) if(!source.id||!source.url||!source.locator||!source.checked_on) throw Error(`知识来源字段无效：${source.id||'unknown'}`);
    for(const record of this.records) {
      if(!record.id||!record.kind||!record.claim||!Array.isArray(record.limitations)||!record.limitations.length||!Array.isArray(record.source_ids)||!record.source_ids.length) throw Error(`知识条目结构无效：${record.id||'unknown'}`);
      if(record.source_ids.some(id=>!sourceIds.has(id))) throw Error(`知识条目来源无效：${record.id}`);
    }
    const ruleIds=new Set();
    for(const rule of this.catalog.rules) {
      if(ruleIds.has(rule.id)||rule.revision!==this.catalog.release||!rule.review||!['ACTIVE_REFERENCE','PROJECT_DECLARATION_CHECK','SUSPENDED_UNVERIFIED'].includes(rule.status)) throw Error('规则治理字段无效');
      ruleIds.add(rule.id);
      const record=this.recordMap.get(rule.record_id);
      if(rule.status==='ACTIVE_REFERENCE'&&(!record?.reference||!rule.review.reviewer||!rule.review.reviewed_on)) throw Error('活动规则参考或复核字段无效');
    }
    for(const cell of this.batteryCells) {
      if(!cell.knowledge_id||!cell.manufacturer||!cell.model||!Number.isFinite(cell.nominal_voltage_v)||!Number.isFinite(cell.nominal_capacity_ah??cell.typical_capacity_ah)) throw Error(`电芯数据字段无效：${cell.knowledge_id||'unknown'}`);
      if(!this.recordMap.has(cell.knowledge_id)) throw Error(`电芯没有可检索知识卡：${cell.knowledge_id}`);
    }
  }
  fingerprint() { return C.hash({release:this.release,records:this.records,sources:this.sources,standards:this.standards,batteryCells:this.batteryCells,batteryRules:this.batteryRules}); }
  sourcesFor(record) { return this.sources.filter(source=>record.source_ids.includes(source.id)); }
  executionRules() {
    return this.catalog.rules.map(rule=>({...structuredClone(rule),source_ids:rule.record_id?this.get(rule.record_id).source_ids:rule.source_ids||[],reference:rule.record_id?this.get(rule.record_id).reference:rule.reference,condition:rule.record_id?this.get(rule.record_id).scope:{process:rule.process}}));
  }
  legacy(kind) {
    const names={rules:'engineering_rules.json',materials:'materials.json',standards:'standards_index.json'};
    if(!Object.hasOwn(names,kind)) throw Error('未知兼容知识种类');
    return readJson(path.join(this.root,'..',names[kind])).map(row=>({...row,properties:{},evidence_level:'UNREVIEWED',verification_status:'LEGACY_UNREVIEWED',verified:false,used_for_gate:false}));
  }
  assessPromotion(record) {
    const missing=[];
    for(const key of ['id','title','claim','scope','limitations','source_ids']) if(!record[key]||(Array.isArray(record[key])&&!record[key].length)) missing.push(key);
    const sources=this.sources.filter(source=>(record.source_ids||[]).includes(source.id));
    if(!sources.length||(record.source_ids||[]).some(id=>!this.sources.some(source=>source.id===id))) missing.push('registered_primary_sources');
    for(const [index,property] of (record.properties||[]).entries()) for(const key of ['property','unit','condition','method','status']) if(!property[key]) missing.push(`properties.${index}.${key}`);
    if(record.evidence_target==='B1') {
      if(!record.properties?.length) missing.push('conditioned_properties');
      if(!sources.some(source=>source.document_type==='manufacturer_tds'&&/^[a-f0-9]{64}$/.test(source.document_sha256||'')&&source.document_media_type==='application/pdf')) missing.push('versioned_manufacturer_pdf_with_sha256');
      if(!record.review?.reviewer||!record.review?.reviewed_on||!record.review?.field_check_notes) missing.push('human_field_review');
    }
    return {status:missing.length?'BLOCKED':'ELIGIBLE_FOR_HUMAN_REVIEW',missing,promoted:false,engineering_release:false};
  }
  get(id) {
    const record=this.recordMap.get(id);
    if(record) return {...structuredClone(record),domain:record.domain||record.scope?.domain||null,sources:this.sourcesFor(record),authority:'REFERENCE_ONLY',verification_status:record.verification_status||'CURATED_REFERENCE',hard_gate:false,engineering_release:false};
    const quarantined=this.quarantineMap.get(id);
    if(quarantined) return {...structuredClone(quarantined),kind:'quarantine',authority:'QUARANTINE_DO_NOT_PROMOTE',verification_status:quarantined.status||'REVIEW_REQUIRED',hard_gate:false,engineering_release:false,sources:[]};
    throw Error('未知知识编号');
  }
  recordText(record) {
    return norm([record.id,record.title,record.claim,...(record.terms||[]),record.scope?.grade,record.scope?.model,record.scope?.manufacturer,record.scope?.material,record.scope?.supplier,record.manufacturer,record.model].filter(Boolean).join(' '));
  }
  search(query,{process,material,kind,domain,manufacturer,exact_model,limit=4}={}) {
    if(typeof query!=='string'||!query.trim()||query.length>300) throw Error('查询长度无效');
    if(kind!==undefined&&typeof kind!=='string') throw Error('知识种类筛选无效');
    if(domain!==undefined&&typeof domain!=='string') throw Error('知识领域筛选无效');
    if(manufacturer!==undefined&&typeof manufacturer!=='string') throw Error('制造商筛选无效');
    if(exact_model!==undefined&&typeof exact_model!=='string') throw Error('精确型号筛选无效');
    const queryNorm=norm(query), words=queryNorm.split(/\s+/).filter(word=>word.length>1);
    const queryTerms=[...new Set(this.lexicon.filter(term=>contains(queryNorm,term)).map(canonical))];
    const genericCell=/\b(18650|21700)\b/.test(queryNorm)&&/\b\d{4,5}\s*mah\b/.test(queryNorm)&&!manufacturer&&!exact_model;
    const matches=this.records.filter(record=>{
      if(process&&canonical(record.scope?.process)!==canonical(process)) return false;
      if(material&&canonical(record.scope?.material)!==canonical(material)) return false;
      if(kind&&record.kind!==kind) return false;
      if(domain&&(record.domain||record.scope?.domain)!==domain) return false;
      if(manufacturer&&canonical(record.manufacturer||record.scope?.manufacturer||record.scope?.supplier)!==canonical(manufacturer)) return false;
      if(exact_model&&canonical(record.model||record.scope?.model||record.scope?.grade)!==canonical(exact_model)) return false;
      return true;
    }).map(record=>{
      const text=this.recordText(record);
      const ownTerms=[...new Set((record.terms||[]).map(canonical))];
      let score=queryTerms.reduce((sum,term)=>sum+(ownTerms.includes(term)?5:0),0)+words.reduce((sum,word)=>sum+(contains(text,word)?4:0),0);
      if(record.scope?.grade) {
        const grade=norm(record.scope.grade), index=queryNorm.indexOf(grade);
        if(index>=0) {
          const tail=queryNorm.slice(index+grade.length);
          if(/^[a-z0-9]/.test(tail)||/^\s+(?:re|bbs\w*|high speed|bmb|mas\w*|rp\w*|cq)(?:\b|$)/.test(tail)) score=0;
          else score+=12;
        }
      }
      if(contains(text,queryNorm)) score+=20;
      if(exact_model&&canonical(record.model||record.scope?.model||record.scope?.grade)===canonical(exact_model)) score+=40;
      if(manufacturer&&canonical(record.manufacturer||record.scope?.manufacturer||record.scope?.supplier)===canonical(manufacturer)) score+=12;
      return {record,score};
    }).filter(match=>match.score>0).sort((left,right)=>right.score-left.score||left.record.id.localeCompare(right.record.id));
    const quarantineMatches=[...this.quarantineMap.values()].filter(record=>contains(norm(JSON.stringify(record)),queryNorm)).map(record=>({id:record.id,status:record.status,reason:record.reason}));
    const hits=matches.slice(0,Math.min(12,Math.max(1,limit))).map(({record,score})=>({id:record.id,title:record.title,kind:record.kind,domain:record.domain||null,score,claim:record.claim,scope:record.scope,limitations:record.limitations,source_ids:record.source_ids,verification_status:record.verification_status||'CURATED_REFERENCE',hard_gate:false,engineering_release:false}));
    return {status:genericCell?'DATA_GAP':'OK',query,scope:'CURATED_AND_GOVERNED_EXPANSION_RETRIEVAL',release:this.release,total_matches:matches.length,hits,
      data_gaps:genericCell?['manufacturer','exact_model']:[],quarantine_matches:quarantineMatches,legacy_included:false,engineering_release:false,
      next_action:genericCell?'“21700 5000mAh”不是完整电芯身份；请提供制造商和精确型号。':matches.length?'Use read_knowledge to inspect the selected card, source, conditions and limitations.':'No curated applicable record was found; request a traceable source rather than inventing a value.'};
  }
  resolveBatteryCell({manufacturer,exact_model}={}) {
    if(typeof manufacturer!=='string'||!manufacturer.trim()||typeof exact_model!=='string'||!exact_model.trim()) return {status:'DATA_GAP',missing:['manufacturer','exact_model'],cell:null};
    const cells=this.batteryCells.filter(cell=>canonical(cell.manufacturer)===canonical(manufacturer)&&canonical(cell.model)===canonical(exact_model));
    if(cells.length!==1) return {status:'DATA_GAP',missing:['registered_exact_cell_model'],cell:null};
    return {status:'OK',cell:structuredClone(cells[0])};
  }
  calculateBatteryPack(input={}) {
    if(!input||typeof input!=='object'||Array.isArray(input)) throw Error('battery pack input must be an object');
    const resolved=this.resolveBatteryCell(input);
    if(resolved.status!=='OK') return {status:'DATA_GAP',...resolved,engineering_release:false};
    const ns=finitePositiveInteger(input.ns,'ns'), np=finitePositiveInteger(input.np,'np'), cell=resolved.cell;
    const capacity=cell.nominal_capacity_ah??cell.typical_capacity_ah;
    const voltage=Number((ns*cell.nominal_voltage_v).toFixed(6));
    const ampHours=Number((np*capacity).toFixed(6));
    const wattHours=Number((ns*np*cell.nominal_voltage_v*capacity).toFixed(6));
    const theoreticalCellLimit=Number((np*cell.max_continuous_discharge_a).toFixed(6));
    const limiterNames=['bms_limit_a','busbar_limit_a','wire_limit_a','connector_limit_a','fuse_limit_a','thermal_limit_a'];
    const supplied=limiterNames.filter(name=>Number.isFinite(input[name])&&input[name]>=0);
    const invalid=limiterNames.filter(name=>input[name]!==undefined&&(!Number.isFinite(input[name])||input[name]<0));
    if(invalid.length) throw Error(`invalid current limits: ${invalid.join(',')}`);
    const current=supplied.length===limiterNames.length ? {status:'SYSTEM_LIMIT_IDENTIFIED',continuous_a:Math.min(theoreticalCellLimit,...supplied.map(name=>input[name])),limits:{cell_parallel_limit_a:theoreticalCellLimit,...Object.fromEntries(supplied.map(name=>[name,input[name]]))}} : {status:'THEORETICAL_CELL_LIMIT_ONLY',continuous_a:null,theoretical_cell_parallel_limit_a:theoreticalCellLimit,missing:limiterNames.filter(name=>!supplied.includes(name)),reason:'Cell capability is not a verified BMS/interconnect/fuse/thermal system current rating.'};
    const result={status:'CALCULATED',cell_id:cell.knowledge_id,manufacturer:cell.manufacturer,exact_model:cell.model,ns,np,nominal_voltage_v:voltage,capacity_ah:ampHours,energy_wh:wattHours,formulas:{nominal_voltage_v:'Ns × cell nominal voltage',capacity_ah:'Np × cell capacity',energy_wh:'Ns × Np × cell nominal voltage × cell capacity'},current,cycle_condition:cell.cycle_condition||null,verification_status:cell.verification_status,limitations:['Calculated nominal pack values are not a tested pack or product claim.','Cell maximum discharge is not a recommended continuous system current without every verified limiter.'],engineering_release:false};
    if(Number.isFinite(input.average_battery_side_power_w)&&input.average_battery_side_power_w>0) result.ideal_runtime_h=Number((wattHours/input.average_battery_side_power_w).toFixed(4));
    return result;
  }
  check(id,value,unit,context={}) {
    const record=this.get(id), reference=record.reference;
    if(!Number.isFinite(value)||value<0) throw Error('数值须为有限非负数');
    const executable=this.executionRules().find(rule=>rule.record_id===id);
    const base={record_id:id,rule_id:executable?.id||null,rule_version:this.data.release,review:executable?.review||null,authority:'SUPPLIER_GUIDANCE_ONLY',engineering_release:false,limitations:record.limitations,sources:record.sources};
    if(!reference||!executable) return {...base,status:'NOT_EXECUTABLE',reason:'This card is reference/index/governance material and is not an approved executable gate rule.'};
    const scope=record.scope||{};
    const missing=Object.keys(scope).filter(key=>!context[key]);
    const mismatches=Object.keys(scope).filter(key=>context[key]&&canonical(context[key])!==canonical(scope[key]));
    if(mismatches.length) return {...base,status:'NOT_APPLICABLE',mismatches,required_context:scope};
    if(missing.length) return {...base,status:'NEED_CONTEXT',missing,required_context:scope};
    if(unit!==reference.unit) return {...base,status:'UNIT_MISMATCH',expected_unit:reference.unit};
    const within=(reference.min===undefined||value>=reference.min)&&(reference.max===undefined||value<=reference.max);
    return {...base,status:within?'WITHIN_REFERENCE':'OUTSIDE_REFERENCE',input:{value,unit,context},reference,interpretation:'Only compares the supplied value with a supplier reference; it is not test evidence, an approval, or a formal Gate result.'};
  }
}
module.exports=KnowledgeService;
