const fs=require('fs');const path=require('path');const crypto=require('crypto');const C=require('./contracts');
class ProjectStateManager {
 constructor(storageDir=null){this.projectsDir=storageDir||process.env.DESIGNGATE_STORAGE_DIR||path.join(__dirname,'../data/projects');fs.mkdirSync(this.projectsDir,{recursive:true});}
 file(id){return path.join(this.projectsDir,C.id(id)+'.json');}
 getProject(id){const f=this.file(id);return fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')):null;}
 listProjects(){return fs.readdirSync(this.projectsDir).filter(f=>/^DG-.*\.json$/.test(f)).flatMap(f=>{try{const p=JSON.parse(fs.readFileSync(path.join(this.projectsDir,f),'utf8'));return [{project_id:p.project_id,project_name:p.project_name,product_category:p.product?.category||'未分类',current_gate:p.gate?.current_stage||'Gate 1',active_revision:p.design?.active_revision||'A',version:p.version||0,open_issues_count:(p.findings||[]).filter(i=>i.status!=='RESOLVED').length}];}catch{return[];}});}
 saveProject(data,expectedVersion){
  const f=this.file(data.project_id),lock=f+'.lock';let fd;
  try{fd=fs.openSync(lock,'wx');}catch{throw Error('项目正在写入，请刷新后重试');}
  try{const old=fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')):null;
   if(expectedVersion!==undefined && (old?.version||0)!==expectedVersion)throw Error('VERSION_CONFLICT: 项目已更新，请刷新');
   if(old?.freeze && old.design.active_revision===data.design?.active_revision)throw Error('FROZEN_REVISION: 已冻结版本不可修改，请新建 Revision');
   data.version=(old?.version||0)+1;data.updated_at=new Date().toISOString();
   const dir=path.join(this.projectsDir,'history',data.project_id);fs.mkdirSync(dir,{recursive:true});
   const content=JSON.stringify(data,null,2);const snap=path.join(dir,String(data.version).padStart(6,'0')+'.json');
   // A leftover snapshot from an interrupted previous write is never overwritten.
   if(fs.existsSync(snap))throw Error('发现未完成的历史快照，请先恢复项目');
   const temp=f+'.'+crypto.randomUUID()+'.tmp';fs.writeFileSync(temp,content,{mode:0o600});fs.writeFileSync(snap,content,{flag:'wx',mode:0o600});fs.renameSync(temp,f);return data;
  }finally{fs.closeSync(fd);fs.unlinkSync(lock);}
 }
 history(id){C.id(id);const dir=path.join(this.projectsDir,'history',id);if(!fs.existsSync(dir))return [];return fs.readdirSync(dir).filter(f=>f.endsWith('.json')).sort().map(f=>{const p=JSON.parse(fs.readFileSync(path.join(dir,f),'utf8'));return {version:p.version,revision:p.design?.active_revision,created_at:p.updated_at,decision:p.gate?.status,review_id:p.last_review?.review_id,stage:p.last_review?.stage,frozen:!!p.freeze};});}
}
module.exports=ProjectStateManager;
