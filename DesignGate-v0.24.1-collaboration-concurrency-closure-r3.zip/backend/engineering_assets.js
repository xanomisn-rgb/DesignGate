const fs=require('fs'),path=require('path'),C=require('./contracts');
const {runPython}=require('../tools/python_runner');
const {projectContext}=require('./context_projection');
const units={nominalWall:'mm',localMaxWall:'mm',ribThickness:'mm',draftAngle:'deg',sheetThickness:'mm',bendRadius:'mm',internalCornerRadius:'mm',textureDepthMm:'mm'};
function parameterPlan(p){
 const last=(p.agent_changes||[]).filter(x=>x.revision===p.design.active_revision).at(-1);
 const changes=(last?.diff||[]).filter(x=>x.entity==='design'&&Object.hasOwn(units,x.field)&&Number.isFinite(x.old_value)&&Number.isFinite(x.new_value));
 if(changes.some(c=>p.design[c.field]!==c.new_value))throw Error('Approved parameters changed since the last patch; export a fresh approved plan');
 return {status:changes.length?'APPROVED_PROJECT_PARAMETERS_NOT_CAD_APPLIED':'NO_SUPPORTED_APPROVED_PARAMETERS',draft_id:last?.draft_id||null,
  source_geometry_sha256:p.design.cad_geometry?.source_sha256||null,changes:changes.map(c=>({...c,unit:units[c.field]})),
  cad_binding:'REQUIRES_HUMAN_OBJECT_PROPERTY_MAPPING',unsupported_changes:(last?.diff||[]).filter(c=>!changes.includes(c)),
  limitation:'A generic STEP solid has no guaranteed named wall-thickness parameter. This plan does not alter CAD.'};
}
function buildAssets(p,runs=[],expectedVersion){
 C.id(p.project_id);if(expectedVersion!==p.version)throw Error('VERSION_CONFLICT: export snapshot changed');
 if(runs.some(r=>r.project_id!==p.project_id))throw Error('Cross-project task export denied');
 const json=v=>JSON.stringify(projectContext(v),null,2),files={};
 const scope={project_id:p.project_id,revision:p.design.active_revision,project_version:p.version,project_hash:C.hash(p),
  status:'ENGINEERING_RECORDS_NOT_FACTORY_RELEASE',external_release:false,local_freeze_record:p.freeze||null};
 files['01_Requirements_Traceability.json']=json({...scope,requirements:p.requirements||[],verifications:p.verifications||[],evidence:p.evidence||[]});
 files['02_BOM_Revision.json']=json({...scope,bom:p.bom||[],cost_scope:'Null or invalidated quotations remain unknown; no price estimation performed.'});
 files['03_Parameter_Plan.json']=json({...scope,...parameterPlan(p)});
 files['04_Decision_Audit.json']=json({...scope,decisions:p.decisions||[],changes:p.agent_changes||[],intent:p.memory?.design_intent||{},task_window:{included:runs.length,limit:30,complete_history:false},tasks:runs.map(({messages,files,cadOptions,callCounts,...r})=>r)});
 files['05_Coverage_And_Unknowns.json']=json({...scope,checks:p.checks||[],findings:p.findings||[],geometry:p.design.cad_geometry||null,
  outstanding:['No manufacturer sign-off is generated','No award compliance is asserted','No wall-thickness / undercut certification is generated']});
 const geometry=p.design.cad_geometry;
 if(geometry?.surface_measurements&&geometry.source_sha256===geometry.surface_measurements.source_sha256)
   files['06_BRep_Surface_Samples.json']=JSON.stringify({...scope,measurement:geometry.surface_measurements},null,2);
 files['freecad_parameter_adapter.py']=fs.readFileSync(path.join(__dirname,'../tools/freecad_parameter_adapter.py'),'utf8');
 files['CAD_Bindings_TEMPLATE.json']=json({document_name:'REPLACE_WITH_FREECAD_DOCUMENT_NAME',fields:{},status:'MANUAL_MAPPING_REQUIRED'});
 files['README.md']='# DesignGate engineering records\n\nThis is an unsigned engineering record package, not a factory approval, a conformity certificate, or a complete PDF/XLSX handover.\n\nBOM is JSON in this version. Missing prices stay null. Source spreadsheets are never overwritten.\n\nCAD adapter: experimental, unit-tested using doubles only; not validated in FreeCAD. Review code and back up your file. Import apply_parameter_plan, load 03_Parameter_Plan.json and a manually completed CAD_Bindings_TEMPLATE.json. Run with dry_run=True first. Only explicit dry_run=False changes the current document; it never saves. Existing typed properties only; no automatic STEP hollowing, filleting, face mapping, or original feature-history reconstruction.\n\nManifest SHA-256 values detect accidental corruption, not malicious rewriting or signatures.\n\nAPI references: https://freecad.github.io/SourceDoc/d8/d3e/classApp_1_1Document.html\n';
 const entries=Object.entries(files).map(([name,content])=>({name,sha256:require('crypto').createHash('sha256').update(content).digest('hex'),bytes:Buffer.byteLength(content)}));
 files['MANIFEST.json']=json({...scope,entries,signature:null});
 if(Buffer.byteLength(JSON.stringify(files))>8*1024*1024)throw Error('Export exceeds 8 MB; narrow the task history');
 return files;
}
function zipAssets(files){return Buffer.from(runPython(path.join(__dirname,'../tools/asset_zip.py'),[],{input:JSON.stringify(files)}).trim(),'base64');}
module.exports={buildAssets,zipAssets,parameterPlan};
