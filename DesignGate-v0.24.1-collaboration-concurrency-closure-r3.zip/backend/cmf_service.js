const {createCapabilityResult}=require('./capability_contract');

const DEFAULT_RULES=Object.freeze([
  {material:'PC+ABS',process:'injection_molding',finish:'molded_texture',environment:'indoor',compatibility:'KNOWN_COMPATIBLE',rule_id:'CMF-PCABS-TEXTURE-001',source_id:null,source_version:null,review_status:'UNREVIEWED'},
  {material:'PC+ABS',process:'injection_molding',finish:'high_gloss_paint',environment:'outdoor_uv',compatibility:'KNOWN_RISK',rule_id:'CMF-PCABS-PAINT-002',risk:'UV durability requires a qualified coating system.',source_id:null,source_version:null,review_status:'UNREVIEWED'}
]);
const required=['material','process','finish','environment'];
class CMFService {
  constructor(rules=DEFAULT_RULES){this.rules=rules.map(rule=>({...rule}));}
  evaluateCompatibility(spec={},meta={}){
    const missing=required.filter(key=>typeof spec[key]!=='string'||!spec[key].trim());
    if(missing.length) return createCapabilityResult({capability:'cmf.compatibility',status:'NOT_EVALUATED_MISSING_INPUT',method:'compatibility_matrix',inputs:spec,result:{missing_inputs:missing},confidence:0,evidence_ids:meta.evidence_ids,source_ids:meta.source_ids,revision:meta.revision,limitations:['Material, process, finish and environment are all required.']});
    const match=this.rules.find(rule=>required.every(key=>rule[key]===spec[key]));
    const reviewed=match?.review_status==='REVIEWED'&&typeof match.source_id==='string'&&match.source_id&&typeof match.source_version==='string'&&match.source_version;
    const compatibility=reviewed?match.compatibility:match?'REFERENCE_ONLY_REQUIRES_REVIEW':'UNKNOWN_REQUIRES_TEST';
    return createCapabilityResult({
      capability:'cmf.compatibility',status:reviewed?'EVALUATED':'PARTIALLY_EVALUATED',method:'compatibility_matrix',inputs:spec,
      result:{compatibility,rule_id:match?.rule_id||null,rule_source_id:match?.source_id||null,rule_source_version:match?.source_version||null,rule_review_status:match?.review_status||'NO_MATCH',risk:match?.risk||null,production_release:'HUMAN_APPROVAL_REQUIRED',required_measurements:['Lab*','DeltaE','gloss_unit','measurement_angle','Ra_or_Rz','coating_thickness'],sample_loop:'MASTER_SAMPLE_TO_SUPPLIER_SAMPLE_TO_MEASURED_DELTA_TO_APPROVAL'},
      confidence:reviewed?0.75:0.25,evidence_ids:meta.evidence_ids||[],source_ids:reviewed?[match.source_id]:[],revision:meta.revision,
      limitations:reviewed?['Compatibility is conditional on the exact specified material, process, finish and environment. Production approval requires supplier samples and measured results.']:['No reviewed, sourced compatibility rule covers this combination. A rule ID is not project evidence; supplier samples and durability testing are required before any production decision.']
    });
  }
}
module.exports=CMFService;
