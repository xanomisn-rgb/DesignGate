const crypto=require('crypto');
const CANONICALIZATION_VERSION='DG-CANONICAL-JSON-v1';
const TELEMETRY_SIGNATURE_INPUT_VERSION='DG-TELEMETRY-SIGNATURE-v1';

function validate(value,seen=new Set()){
 if(value===null||typeof value==='string'||typeof value==='boolean')return;
 if(typeof value==='number'){if(!Number.isFinite(value))throw Error('canonical JSON requires finite numbers');return;}
 if(Array.isArray(value)){if(seen.has(value))throw Error('canonical JSON rejects cyclic data');seen.add(value);for(const item of value)validate(item,seen);seen.delete(value);return;}
 if(typeof value==='object'){
  if(Object.getPrototypeOf(value)!==Object.prototype)throw Error('canonical JSON accepts plain objects only');
  if(seen.has(value))throw Error('canonical JSON rejects cyclic data');seen.add(value);
  for(const key of Object.keys(value)){if(typeof value[key]==='undefined'||typeof value[key]==='function'||typeof value[key]==='symbol')throw Error('canonical JSON rejects non-JSON values');validate(value[key],seen);}seen.delete(value);return;
 }
 throw Error('canonical JSON rejects non-JSON values');
}
function normalized(value){if(Array.isArray(value))return value.map(normalized);if(value&&typeof value==='object'){return Object.fromEntries(Object.keys(value).sort().map(key=>[key,normalized(value[key])]))}return value;}
function canonicalize(value){validate(value);return JSON.stringify(normalized(value));}
function bytes(value){return Buffer.from(canonicalize(value),'utf8');}
function sha256(value){return crypto.createHash('sha256').update(bytes(value)).digest('hex');}
function hmacSha256(value,secret){if(typeof secret!=='string'||!secret)throw Error('HMAC secret required');return crypto.createHmac('sha256',secret).update(bytes(value)).digest('hex');}
function telemetrySigningInput(input={}){
 const fields=['device_id','project_id','revision','test_id','sequence','metric','value','unit','source_timestamp','idempotency_key'];
 const values=fields.map(field=>{
  const value=input[field];
  if(value===undefined||value===null||value==='')throw Error(`telemetry signature input missing ${field}`);
  if((field==='sequence'&&!Number.isInteger(value))||(field==='value'&&!Number.isFinite(value)))throw Error(`telemetry signature input invalid ${field}`);
  const text=String(value);
  if(/[\r\n]/.test(text))throw Error(`telemetry signature input contains line break: ${field}`);
  return text;
 });
 return {version:TELEMETRY_SIGNATURE_INPUT_VERSION,text:[TELEMETRY_SIGNATURE_INPUT_VERSION,...values].join('\n')};
}
module.exports={CANONICALIZATION_VERSION,TELEMETRY_SIGNATURE_INPUT_VERSION,canonicalize,bytes,sha256,hmacSha256,telemetrySigningInput};
