const crypto=require('crypto');const fs=require('fs');const path=require('path');const DocumentParser=require('../tools/document_parser');const BOMParser=require('../tools/bom_parser');const CADGeometryTool=require('../tools/cad_geometry_tool');
class FileIntakeManager{
 static computeFileHash(f){return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');}
 static processIntake(files={},cadOptions={}){
  const out={files_processed:[],requirements:[],bom:[],design_params:{},field_provenance:{},source_pointers:[],cad_analysis:null,errors:[],conflicts:[]};
  for(const [key,f] of Object.entries(files)){
   if(!f)continue;
   try{if(!['briefFile','designFile','bomFile','cadFile'].includes(key))throw Error('不支持的文件类型');
    const st=fs.statSync(f);if(!st.isFile()||st.size>50*1024*1024)throw Error('文件无效或超过 50MB');
    const ext=path.extname(f).toLowerCase();const allowed=key==='cadFile'?['.stl','.step','.stp']:key==='bomFile'?['.xlsx']:['.pdf'];if(!allowed.includes(ext))throw Error('不支持的扩展名 '+ext);
    const file=path.basename(f),sha256=this.computeFileHash(f);
    const parsed=key==='cadFile'?CADGeometryTool.analyze({cad_file:f,...cadOptions}):key==='bomFile'?BOMParser.parseXLSX(f):DocumentParser.parsePDF(f);
    if(!parsed.success)throw Error(parsed.error||parsed.message||'解析失败');
    out.files_processed.push({type:key,file,sha256,status:parsed.status||'PARSED',pages:parsed.total_pages});
    if(key==='briefFile'){
     for(const pg of parsed.pages||[])for(const line of pg.text.split('\n')){const m=line.match(/(REQ-[A-Za-z0-9_-]+)[:：]\s*(.+)/i);if(m)out.requirements.push({req_id:m[1].toUpperCase(),text:m[2].trim(),verification_method:null,acceptance_criteria:null,source_pointer:{file,page:pg.page_number,sha256}});}
     if(!out.requirements.length)out.errors.push(file+' 未提取到带 REQ-ID 的结构化需求，请在项目资料中人工整理；扫描件需要 OCR。');
    }
    if(key==='designFile')for(const item of parsed.extracted_dimensions_by_page||[])for(const [k,v]of Object.entries(item.dimensions)){if(v===null)continue; if(Object.hasOwn(out.design_params,k)&&out.design_params[k]!==v){out.conflicts.push({field:k,values:[out.design_params[k],v],file,page:item.page});out.design_params[k]=null;}else if(!out.conflicts.some(c=>c.field===k)){out.design_params[k]=v;out.field_provenance[k]={file,page:item.page,sha256,field:k,value:v,origin:'DOCUMENT_EXTRACTED'};}}
    if(key==='bomFile')out.bom=parsed.components;
    if(key==='cadFile')out.cad_analysis=parsed;
   }catch(e){out.errors.push(`${key}: ${e.message}`);}
  }
  out.source_pointers=[...Object.values(out.field_provenance),...out.requirements.map(r=>r.source_pointer),...out.bom.map(r=>r.source_pointer).filter(Boolean)];
  for(const c of out.conflicts)out.errors.push(`图纸内 ${c.field} 数值冲突，请明确评审零件和有效值`);
  return out;
 }
}
module.exports=FileIntakeManager;
