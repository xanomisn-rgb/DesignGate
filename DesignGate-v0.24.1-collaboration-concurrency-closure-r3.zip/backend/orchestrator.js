const Knowledge=require('./knowledge_service');const fs=require('fs');const path=require('path');
const crypto=require('crypto');const C=require('./contracts');const Schema=require('../tools/schema_validator');
const Gate=require('./gate_engine');const Diff=require('./revision_diff_engine');const FileProjectRepository=require('./repositories/file_project_repository');const Checks=require('./check_engine');const Intake=require('./file_intake_manager');const Parser=require('../tools/document_parser');const Workspace=require('./design_workspace');const Citation=require('./citation_verifier');
const GateV2=require('./gate/gate_v2');const EvidenceProvenanceService=require('./evidence/evidence_provenance_service');
const Requirement=require('../agents/requirement_agent');const Product=require('../agents/product_agent');const CMF=require('../agents/cmf_agent');const Quality=require('../agents/quality_agent');const Chief=require('../agents/chief_reviewer_agent');
const InAgent=require('../connectors/inagent_adapter');const PLM=require('../connectors/plm_adapter');
const ErgonomicsService=require('./ergonomics_service');const CMFService=require('./cmf_service');const FMEAService=require('./fmea_service');const EvidenceGraph=require('./evidence_graph');const Records=require('./dfmea_records');const {createCapabilityResult}=require('./capability_contract');const {toGateArtifacts}=require('./professional_gate');
function safeCapability(capability,revision,evidenceIds,fn){try{return fn();}catch(error){return createCapabilityResult({capability,status:'NOT_EVALUATED_RUNTIME_ERROR',method:'isolated_exception_boundary',inputs:{},result:{error_code:'CAPABILITY_RUNTIME_ERROR',message:String(error&&error.message||error).slice(0,300)},confidence:0,evidence_ids:evidenceIds,revision,limitations:['该专业能力发生受控运行异常；其他已完成能力结果保留。','若该能力适用且为 Gate 必需项，本异常必须阻断，不能降级为 PASS。']});}}
function applicability(project){const declared=project.professional_applicability||{},category=String(project.product?.category||'');return {dfmea:declared.dfmea||(project.dfmea?'APPLICABLE':'NOT_APPLICABLE'),dfmea_reason:project.dfmea?'DFMEA scope is saved for this project.':'No DFMEA scope is saved for this project.',cmf:declared.cmf||'NOT_APPLICABLE',cmf_reason:declared.cmf_reason||'No v0.20.1 CMF Gate scope is declared; legacy CMF verification remains separate.',ergonomics:declared.ergonomics||(/handheld|手持/i.test(category)?'APPLICABLE':'NOT_APPLICABLE'),ergonomics_reason:declared.ergonomics_reason||'Product category is not declared as handheld.'};}
class DesignGateOrchestrator{
 constructor(apiCaller=null,options={}){this.apiCaller=apiCaller;this.repository=options.repository||new FileProjectRepository({directory:options.storageDir});this.stateManager=this.repository;this.knowledge=options.knowledge||new Knowledge();this.checkEngine=new Checks(this.knowledge);this.ruleEngine=this.checkEngine.rules;this.gateEngine=new Gate();this.evidenceProvenance=new EvidenceProvenanceService({directory:path.join(this.repository.projectsDir,'evidence-provenance')});this.diffEngine=new Diff();this.citationVerifier=new Citation(this.knowledge);this.inagentAdapter=new InAgent();this.plmAdapter=new PLM();this.locks=new Set();this.agents={requirement:new Requirement(),product:new Product(),cmf:new CMF(this.citationVerifier),quality:new Quality(this.citationVerifier),chief:new Chief()};}
 evidenceContext(project){return (project.evidence||[]).map(evidence=>{const context={evidence_id:evidence.evidence_id,manifest_id:evidence.manifest_id||null,project_id:project.project_id,revision:evidence.revision||null,integrity_status:evidence.integrity_status||'UNVERIFIED',provenance_status:evidence.manifest_id?(evidence.provenance_status||'UNVERIFIED'):'LEGACY_UNBOUND',verification_plan_id:evidence.verification_plan_id||null,verification_plan_hash:evidence.verification_plan_hash||null,source_kind:evidence.source_kind||null,source_id:evidence.source_id||null,source_event_id:evidence.source_event_id||null,current_revision_valid:false};try{const file=path.join(this.stateManager.projectsDir,'evidence',project.project_id,evidence.sha256||'');if(!evidence.sha256||!fs.existsSync(file)||crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==evidence.sha256)return {...context,integrity_status:'INVALID',provenance_status:'MISMATCH',reason_code:'EVIDENCE_FILE_HASH_MISMATCH'};const binding=this.evidenceProvenance.validateCurrentRevisionEvidence({project_id:project.project_id,revision:project.design?.active_revision,evidence_id:evidence.evidence_id});return {...context,...binding,current_revision_valid:binding.valid};}catch(error){return {...context,reason_code:String(error.message)};}});}
 professionalCapabilities(project){
  const d=project.design||{};
  const gripMatch=String(d.gripSection||'').match(/([0-9]+(?:\.[0-9]+)?)\s*[x×]\s*([0-9]+(?:\.[0-9]+)?)/i);
  const ergonomicsInput={mass_kg:Number.isFinite(d.weightG)?d.weightG/1000:undefined,grip_section_mm:gripMatch?{width:Number(gripMatch[1]),depth:Number(gripMatch[2])}:undefined,target_population:d.targetPopulation&&d.populationSource?{description:d.targetPopulation,source:d.populationSource}:undefined,posture:d.gripPosture,operation_force_n:d.operationForceN,duration_s:d.operationDurationS};
  if(Number.isFinite(d.cogOffsetMm)) ergonomicsInput.cog_offset_mm=d.cogOffsetMm;
  const evidenceIds=this.evidenceContext(project).filter(e=>e.current_revision_valid).map(e=>e.evidence_id);
  const bindings=Records.currentBindings(project);
  const fmeaMeta={...bindings,revision:d.active_revision,baseline_fingerprint:project.dfmea_baseline_hash,valid_evidence_ids:evidenceIds,valid_requirement_ids:(project.requirements||[]).map(r=>r.req_id),evidence_ids:evidenceIds,verification_plan:project.dfmea_verification_plan||null,test_records:project.dfmea_test_records||[],risk_acceptances:project.risk_acceptances||[],failure_dispositions:project.dfmea_failure_dispositions||[]};
  return {
   ergonomics:safeCapability('ergonomics.grip_assessment',d.active_revision,evidenceIds,()=>new ErgonomicsService().assessGrip(ergonomicsInput,{revision:d.active_revision,evidence_ids:evidenceIds})),
   cmf:safeCapability('cmf.compatibility',d.active_revision,evidenceIds,()=>new CMFService().evaluateCompatibility({material:d.materialFamily||d.material,process:d.process,finish:d.finish,environment:d.useEnvironment},{revision:d.active_revision,evidence_ids:evidenceIds})),
   dfmea:safeCapability('quality.dfmea',d.active_revision,evidenceIds,()=>new FMEAService().evaluate(project.dfmea||{},fmeaMeta))
  };
 }
 async runReviewPipeline(params={}){
  const id=C.id(params.projectId);if(this.locks.has(id))throw Error('项目正在评审，请等待完成');this.locks.add(id);
  try{return await this._run({...params,projectId:id});}finally{this.locks.delete(id);}
 }
 async _run(params){
  const {projectId,files={},proposalText='',mode='designgate'}=params;
  if(typeof proposalText!=='string'||proposalText.length>50000)throw Error('方案文字必须为文本且不超过50000字');
  const existingProject=this.stateManager.getProject(projectId);let p=existingProject||{schema_version:'3.1',project_id:projectId,project_name:projectId,design:{active_revision:'A'},requirements:[],bom:[],findings:[],version:0,gate_engine_version:'v2'};
  p=Records.migrateProject(p);
  const expected=p.version||0;
  if(params.expectedVersion!==undefined&&params.expectedVersion!==expected)throw Error('VERSION_CONFLICT: 请刷新项目后重新送审');
  const revision=C.id(params.revision||p.design.active_revision||'A','revision');
  if(p.freeze&&p.design.active_revision===revision)throw Error('FROZEN_REVISION: 请先新建 Revision');
  if(revision!==p.design.active_revision)throw Error('请先通过“新建 Revision”创建版本，以保存变更原因和来源');
  const stage=params.stage||'Gate 2: 详细工程评审';const stageNumber=Number(stage.match(/Gate\s*([123])/i)?.[1]);if(!stageNumber)throw Error('无效 Gate 阶段');
  const log=[];const step=(s,message)=>log.push({step:s,status:'COMPLETED',message});
  const intake=Intake.processIntake(files,params.cadOptions||{});step('FILE_INTAKE',`解析 ${intake.files_processed.length} 个文件，${intake.errors.length} 个问题`);
  if(Object.hasOwn(params,'requirements'))p.requirements=C.requirements(params.requirements);else if(files.briefFile)p.requirements=C.requirements(intake.requirements);
  if(Object.hasOwn(params,'bom')){p.bom=C.bom(params.bom);}else if(files.bomFile)p.bom=C.bom(intake.bom);
  const explicit=C.design(params.designParams||{}),extracted=C.design(intake.design_params),fromText=C.design(Parser.extractDimensions(proposalText));
  const previous=p.design||{},d={...previous,active_revision:revision},provenance={...(p.field_provenance||{})};
  // Each submitted source is treated as current; absent geometry in a replacement drawing invalidates older dimensions.
  if(files.designFile)for(const k of ['nominalWall','localMaxWall','ribThickness','draftAngle']){d[k]=null;delete provenance[k];}
  for(const [k,v]of Object.entries(fromText))if(v!==null){d[k]=v;provenance[k]={origin:'USER_TEXT',field:k,value:v};}
  for(const [k,v]of Object.entries(extracted)){d[k]=v;provenance[k]=intake.field_provenance[k];}
  for(const [k,v]of Object.entries(explicit)){
   if(v!==null&&extracted[k]!=null&&v!==extracted[k]){intake.errors.push(`字段 ${k} 的手填值与图纸冲突，需确认后重交`);d[k]=null;delete provenance[k];}
   else {d[k]=v;provenance[k]={origin:'USER_DECLARED',field:k,value:v};}
  }
  d.proposalText=proposalText||previous.proposalText||'';d.imageAttached=!!params.imageAttached;
  if(files.cadFile)d.cad_geometry=intake.cad_analysis;
  if(!d.material){const candidates=(p.bom||[]).filter(b=>/外壳|housing|enclosure/i.test(b.part_name||''));if(candidates.length===1){d.material=candidates[0].material_specified;d.process=d.process||candidates[0].process;}}
  p.design=C.design({...d});p.design={...p.design,active_revision:revision,proposalText:d.proposalText,imageAttached:d.imageAttached,cad_geometry:d.cad_geometry||null};
  if(params.product){if(typeof params.product!=='object'||Array.isArray(params.product))throw Error('product 必须为对象');p.product={...p.product,...params.product};}
  const submittedDfmeaTests=params.dfmea&&Array.isArray(params.dfmea.verification_tests)?structuredClone(params.dfmea.verification_tests):[];
  if(params.dfmea!==undefined){if(!params.dfmea||typeof params.dfmea!=='object'||Array.isArray(params.dfmea))throw Error('dfmea 必须为对象');p.dfmea=Records.riskDefinition(params.dfmea);}
  if(params.projectName)p.project_name=String(params.projectName).slice(0,160);
  p.field_provenance=provenance;p.requirements=C.requirements(p.requirements||[]);
  Records.refreshHashes(p);
  if(submittedDfmeaTests.length){
   // v0.20.3 security boundary: execution records are never accepted through the DFMEA definition payload.
   // Historical embedded records are migrated only when loading an existing project; new executions must use
   // WorkflowService.recordDfmeaTest(), which creates server-bound append-only records.
   p.dfmea_import_warnings=[...(p.dfmea_import_warnings||[]),`Ignored ${submittedDfmeaTests.length} embedded verification_tests record(s). Use the verification-plan/test business APIs; uploaded DFMEA JSON cannot restore verification state.`];
  }
  Records.refreshHashes(p);
  p.basis_hash=C.hash({design:p.design,requirements:p.requirements,bom:p.bom,product:p.product||{},dfmea_baseline_hash:p.dfmea_baseline_hash,dfmea_design_hash:p.dfmea_design_hash,dfmea_verification_plan_hash:p.dfmea_verification_plan_hash,professional_rule_versions:{dfmea:'0.20.3',cmf:'0.20.3',ergonomics:'0.20.3',knowledge:this.knowledge.release},knowledge_fingerprint:this.knowledge.fingerprint()});
  p.verifications=(p.verifications||[]).filter(v=>v.basis_hash===p.basis_hash&&v.revision===revision);
  const {checks,findings}=this.checkEngine.evaluate(p,intake.errors);
  if(Object.values(files).some(Boolean)&&!intake.errors.length)checks.push({check_id:'INTAKE_RECOVERY',status:'PASS',required_for_gate:1,issue_ids:(p.findings||[]).filter(f=>f.issue_id.startsWith('DG-INTAKE-')&&Object.entries(files).some(([key,file])=>file&&f.finding.startsWith(key+':'))).map(f=>f.issue_id),input_fingerprint:C.hash(intake.files_processed),rule_version:this.knowledge.data.release,reason:'重新提交资料已成功解析'});
  let all=[...findings,...this.agents.requirement.evaluate(p)];
  if(stageNumber>=2)all.push(...(checks.some(c=>c.check_id==='ERGONOMICS'&&c.status==='PASS')?[]:this.agents.product.evaluate(p)),...this.agents.cmf.evaluate(p));
  if(stageNumber===3)all.push(...this.agents.quality.evaluate(p));
  all=[...new Map(all.map(f=>[f.issue_id,f])).values()];
  // Skip optional downstream check gaps at earlier gates; keep actual known defects.
  all=all.filter(f=>!f.issue_id.startsWith('DG-CHECK-')||stageNumber>=2);
  for(const f of all){f.revision=revision;f.part_id=params.partId||'MAIN';f.knowledge_authority='LOCAL_SCREENING_OR_USER_EVIDENCE';if(f.evidence_level==='B1'){f.evidence_level='UNREVIEWED';f.knowledge_warning='本地知识引用未获 B1 晋升核验';}f.assertion_type=f.record_type==='DATA_GAP'?'MISSING_EVIDENCE':'RULE_SCREENING';const ck=checks.find(c=>c.issue_ids.includes(f.issue_id));if(ck)f.check_id=ck.check_id;
   f.input_sources=(ck?.input_fields||[]).map(k=>provenance[k]).filter(Boolean);
   const req=p.requirements.find(r=>r.req_id===f.requirement_id);if(req?.source_pointer)f.evidence_pointer=req.source_pointer;else if(f.input_sources.length)f.evidence_pointer=f.input_sources[0];
  }
  const professionalCapabilities=this.professionalCapabilities(p),professionalArtifacts=toGateArtifacts(professionalCapabilities,applicability(p));
  for(const check of professionalArtifacts.checks){check.input_fingerprint=C.hash({capability:check.check_id,dfmea_baseline_hash:p.dfmea_baseline_hash,dfmea_design_hash:p.dfmea_design_hash,dfmea_verification_plan_hash:p.dfmea_verification_plan_hash,applicability:applicability(p)});check.rule_version='0.20.3';checks.push(check);}all.push(...professionalArtifacts.findings);
  step('ENGINEERING_CHECKS',`执行 ${checks.length} 项状态明确的检查`);
  const diff=this.diffEngine.computeDiff(p.findings||[],all,params.studentResponse||'',checks);
  for(const f of diff.lineage.pending_verification)if(!all.some(x=>x.issue_id===f.issue_id))all.push(f);
  // Remove carried data-gap entries once the same diagnostic has an explicit current PASS.
  const evidenceContext=this.evidenceContext(p),currentEvidenceIds=evidenceContext.filter(row=>row.current_revision_valid).map(row=>row.evidence_id);if(currentEvidenceIds.length)for(const check of checks)if(check.status==='PASS'&&Array.isArray(check.issue_ids)&&check.issue_ids.length&&!check.closure_basis)check.closure_basis={revision,baseline_hash:p.basis_hash,evidence_ids:currentEvidenceIds,evaluation_ids:[`CURRENT_RULE_EVALUATION:${check.check_id}`],rule_version:check.rule_version||this.knowledge.release,closure_kind:'CURRENT_RULE_REEVALUATION_NOT_TEST_EXECUTION'};const gate=p.gate_engine_version==='v2'?GateV2.evaluateFormalGateV2({stage,revision,project:p,checks,evidence_context:evidenceContext,prior_issues:p.findings||[],integration_events:p.integration_events||[],knowledge:{release:this.knowledge.release,fingerprint:this.knowledge.fingerprint()}}):{...this.gateEngine.evaluateGate(stage,all,{revision,checks,isFreezeRequested:stageNumber===3}),gate_engine_version:'v1'};
  step('GATE',gate.status_summary);
  const workspace=Workspace.build(p,checks,all);let rag=null,plm=null,narrative='',narrativeStatus='NOT_CONFIGURED';
  if(params.inagentRAG){rag=await this.inagentAdapter.searchEvidence(proposalText||p.project_name);step('INAGENT',rag.status||'RECEIVED');}
  const ragEvidence=(rag?.results||[]).map((r,i)=>({candidate_id:'RAG-'+i,title:r.title||'',source_id:r.source_id||null,source_url:r.source_url||null,excerpt:r.excerpt||r.text||'',status:'UNVERIFIED_RETRIEVAL',used_for_gate:false}));
  if(this.apiCaller){try{narrative=await this.apiCaller({stage,revision,findings:all,gate_result:gate,proposalText,workspace,rag_candidates:ragEvidence,imageAttached:params.imageAttached});narrativeStatus='GENERATED_UNVERIFIED';}catch(e){narrative='模型说明不可用：'+e.message;narrativeStatus='FAILED';}}
  const reviewId='REV-'+crypto.randomUUID();
  const evidenceGraph=EvidenceGraph.fromProject(p,{projectsDir:this.stateManager.projectsDir}).snapshot();
  const result={knowledge_release:this.knowledge.release,knowledge_fingerprint:this.knowledge.fingerprint(),review_scope:{kind:'SINGLE_PART_RULE_SCREENING',part_id:params.partId||'MAIN',whole_product_verified:false},project_id:projectId,review_id:reviewId,revision,stage,basis_hash:p.basis_hash,workflow_status:rag?.status==='CONNECTION_FAILED'?'EXTERNAL_READ_FAILED':'COMPLETED',archive_status:'LOCAL_ONLY',pipeline_log:log,checks:[...checks,...(gate.checks||[])],findings:all,material_verification:this.citationVerifier.verifyMaterialGrade(p.design.material),gate,revision_diff:diff,chief_review:this.agents.chief.synthesize(all,gate,p),external_receipts:{plm:null,lms:null,inagent:rag},narrative,narrative_status:narrativeStatus,workspace,rag_candidates:ragEvidence,professional_capabilities:professionalCapabilities,evidence_context:evidenceContext,evidence_graph:evidenceGraph,specialized_artifacts:{cmf_matrix:this.agents.cmf.generateCmfMatrix(p),knowledge_governance:{release:this.knowledge.release,fingerprint:this.knowledge.fingerprint(),record_count:this.knowledge.records.length,standard_index_count:this.knowledge.standards.length,battery_cell_count:this.knowledge.batteryCells.length,quarantine_count:this.knowledge.quarantine.length,authority:'REFERENCE_AND_INDEX_ONLY',hard_gate_promotion:false,engineering_release:false}},limitations:['规则筛查不替代 CAD/CAE、样机测试或认证。','本地材料与标准索引未在本轮联网复核。','RAG 片段和模型建议不参与冻结裁决。']};
  Schema.validatePipelineResult(result);
  result.project_version=expected+1;
  p.findings=all;p.checks=result.checks;p.gate={current_stage:stage,status:gate.decision,gate_engine_version:gate.gate_engine_version};p.last_review=result;p.freeze=null;
  this.stateManager.saveProject(p,expected);
  result.project_version=p.version;
  if(params.archivePLM){plm=await this.plmAdapter.createReviewRecord(projectId,revision,all,gate.decision,reviewId);result.external_receipts.plm=plm;result.archive_status=plm.mode==='mock'?'MOCK_ONLY':plm.status==='CREATED'?'EXTERNAL_SUCCESS':'EXTERNAL_FAILED';if(result.archive_status==='EXTERNAL_FAILED')result.workflow_status='EXTERNAL_WRITE_FAILED';p.last_review=result;this.stateManager.saveProject(p,p.version);result.project_version=p.version;}
  if(params.syncLMS){result.external_receipts.lms={status:'NOT_SENT',reason:'评审结果不自动生成课程成绩；需教师另行确认评分和作业。'};}
  return result;
 }
}
module.exports=DesignGateOrchestrator;
