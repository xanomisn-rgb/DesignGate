# v0.21.1 validation record

## Scope

Knowledge-expansion integration only. No new production connection, paid model call, external archive, automatic production release, or claim of engineering approval is introduced.

## Added governed data

| Data group | Count | Treatment |
| --- | ---: | --- |
| Expansion knowledge cards | 36 | searchable/readable, source-limited reference |
| Concrete battery cells | 8 | exact-model lookup plus deterministic calculation |
| Battery-pack rules | 10 | exposed as governed calculation context; not hard Gate rules |
| Standard indexes | 15 | applicability entry points only |
| Quarantine records | 3 | historical/review-required, excluded from current evidence |

## Regression coverage

- Exact EVE 50E lookup and 2S2P calculation: 7.3 V, 10 Ah, 73 Wh.
- Exact Molicel P45B/P50B/M65A ranking.
- Generic `21700 5000mAh` remains `DATA_GAP`.
- Incomplete current-limit evidence remains `THEORETICAL_CELL_LIMIT_ONLY`; complete limits select the weakest current limit.
- Standard index is non-executable; Hostaform historical data remains quarantine.
- Agent tool filters/calculation are read-only; A02/A03/A05 knowledge reads stay role-scoped.
- Existing curated knowledge retrieval, grade-suffix rejection, reference bounds, and agent loop regression cases remain covered.

## Commands

Run:

```powershell
npm test
npm run check
npm run test:cad
npm run test:adapter
npm run test:handover
```

Actual validation in this workspace:

- `npm test`: PASS, 276/276 Node tests.
- `npm run check`: PASS; syntax/JSON check covered 109 JavaScript files and the answer-key validator reported 40 valid dataset and 40 valid gold cases.
- `npm run test:adapter`: PASS, 5/5 Python tests.
- `npm run test:handover`: PASS, 3/3 Python tests.
- `npm run test:cad`: NOT RUN to assertions because Python raised `ModuleNotFoundError: No module named 'OCP'` while importing the BRep test fixture.

## Not validated

- Real industrial project outcomes, prototype test results, certified battery-pack performance, paid standards full-text applicability, independent expert review, and production release.
- Native Electron click-through verification: not run; this extracted source environment does not include `node_modules/electron`.
