const Canonical=require('../backend/crypto/canonical_json');
const {listPublicTrainingTasks,isPublicTrainingTask}=require('./public_task_catalog');

function requireId(value,name){
 if(typeof value!=='string'||!value.trim())throw Error(`${name} is required`);
 return value.trim();
}

function requireTimestamp(value,name){
 if(typeof value!=='string'||Number.isNaN(Date.parse(value)))throw Error(`${name} must be an ISO-parseable timestamp`);
 return value;
}

function createTrainingSession({session_id,learner_id,project_id,task_id,engineering_state={},started_at}={}){
 const snapshot=structuredClone(engineering_state);
 const normalizedTaskId=requireId(task_id,'task_id');
 if(!isPublicTrainingTask(normalizedTaskId))throw Error('A registered public training task is required');
 return {
  training_session_id:requireId(session_id,'session_id'),
  learner_id:requireId(learner_id,'learner_id'),
  project_id:requireId(project_id,'project_id'),
  task_id:normalizedTaskId,
  started_at:requireTimestamp(started_at,'started_at'),
  status:'ACTIVE',
  authority:'TRAINING_ONLY_NOT_ENGINEERING_APPROVAL',
  engineering_state_snapshot:snapshot,
  engineering_state_snapshot_hash:Canonical.sha256(snapshot)
 };
}

function submitTrainingAttempt({session,attempt_id,observed_actions=[],submitted_at}={}){
 if(!session||session.status!=='ACTIVE')throw Error('An active training session is required');
 if(Canonical.sha256(session.engineering_state_snapshot)!==session.engineering_state_snapshot_hash)throw Error('Training session snapshot integrity check failed');
 if(!Array.isArray(observed_actions))throw Error('observed_actions must be an array');
 const attempt={
  training_attempt_id:requireId(attempt_id,'attempt_id'),
  training_session_id:requireId(session.training_session_id,'training_session_id'),
  learner_id:requireId(session.learner_id,'learner_id'),
  project_id:requireId(session.project_id,'project_id'),
  task_id:requireId(session.task_id,'task_id'),
  submitted_at:requireTimestamp(submitted_at,'submitted_at'),
  observed_actions:structuredClone(observed_actions),
  status:'PENDING_INSTRUCTOR_REVIEW',
  authority:'TRAINING_ONLY_NOT_ENGINEERING_APPROVAL'
 };
 return {...attempt,attempt_hash:Canonical.sha256(attempt)};
}

function reviewTrainingAttempt({attempt,reviewer_id,outcome,rationale,reviewed_at}={}){
 if(!attempt||attempt.status!=='PENDING_INSTRUCTOR_REVIEW')throw Error('A pending training attempt is required');
 const {attempt_hash,...attemptPayload}=attempt;
 if(typeof attempt_hash!=='string'||Canonical.sha256(attemptPayload)!==attempt_hash)throw Error('Training attempt integrity check failed');
 if(!['SATISFACTORY','NEEDS_REWORK'].includes(outcome))throw Error('Training review outcome is invalid');
 const reviewedAt=requireTimestamp(reviewed_at,'reviewed_at');
 if(Date.parse(reviewedAt)<Date.parse(attempt.submitted_at))throw Error('reviewed_at must not precede submitted_at');
 if(typeof rationale!=='string'||!rationale.trim())throw Error('rationale is required');
 return {
  training_review_id:Canonical.sha256({training_attempt_id:attempt.training_attempt_id,reviewer_id,outcome,reviewed_at:reviewedAt}).slice(0,24),
  training_attempt_id:attempt.training_attempt_id,
  training_session_id:attempt.training_session_id,
  reviewer_id:requireId(reviewer_id,'reviewer_id'),
  outcome,
  rationale:rationale.trim(),
  reviewed_at:reviewedAt,
  status:'TRAINING_REVIEWED',
  authority:'TRAINING_ONLY_NOT_ENGINEERING_APPROVAL'
 };
}

module.exports={createTrainingSession,submitTrainingAttempt,reviewTrainingAttempt,listPublicTrainingTasks};
