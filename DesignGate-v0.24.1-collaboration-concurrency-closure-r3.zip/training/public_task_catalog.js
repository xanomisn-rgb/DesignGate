const PUBLIC_TASKS=Object.freeze([
 {task_id:'PUBLIC-DFMEA-INTRO-1',title:'DFMEA traceability practice',scope:'Record a risk and identify missing verification evidence.'},
 {task_id:'PUBLIC-CAD-EVIDENCE-1',title:'CAD evidence boundary practice',scope:'Distinguish a registered CAD observation from a Gate decision.'},
 {task_id:'PUBLIC-RETEST-TRACE-1',title:'Retest traceability practice',scope:'Link a later retest to an earlier failed execution without overwriting history.'},
 {task_id:'PUBLIC-GATE-BOUNDARY-1',title:'Gate authority boundary practice',scope:'Identify the conditions that keep a local Gate on HOLD.'}
]);

function listPublicTrainingTasks(){return structuredClone(PUBLIC_TASKS);}
function isPublicTrainingTask(taskId){return PUBLIC_TASKS.some(task=>task.task_id===taskId);}

module.exports={listPublicTrainingTasks,isPublicTrainingTask};
