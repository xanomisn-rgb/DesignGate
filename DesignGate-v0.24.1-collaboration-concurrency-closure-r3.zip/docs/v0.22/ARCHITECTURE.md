# v0.22.0 RC architecture

`IntegrationEventBus` → JSONL `IntegrationStore` → hash-chain event record. `LabDeviceGateway` verifies a device HMAC, resolves a current verification criterion, emits telemetry, then optionally delegates evidence and test execution to `WorkflowService`. Existing DFMEA, evidence integrity, retest, Gate and local-freeze controls remain the decision authority.

No external sender can submit PASS, FAIL override, Gate decision, risk closure, risk acceptance, or final freeze. The gateway calculates only the test criterion outcome; `WorkflowService` retains evidence/revision/plan/retest validation.
