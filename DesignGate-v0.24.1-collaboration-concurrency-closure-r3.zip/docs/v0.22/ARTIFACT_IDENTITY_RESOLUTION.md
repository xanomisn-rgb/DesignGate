# Artifact Identity Resolution

Resolution date: 2026-09-09.

No independently verifiable v0.22.1 artifact was available in the supplied workspace. The prior RC-derived copy was therefore not relabeled as v0.22.1. Instead, the tested independent worktree was made the explicit `0.22.2-dev` development baseline and committed locally.

| Field | Value |
| --- | --- |
| Development version | `0.22.2-dev` |
| Baseline commit | `adcb208a206dbfd47f4ce602bb333c6021fbc7e7` |
| Node / npm | `v24.20.0` / `11.19.0` |
| Electron / builder | `44.2.0` / `24.13.3` |
| Python | `3.13.15` |
| cadquery-ocp | `NOT_INSTALLED` |
| Baseline tests | `292/292 PASS` |
| Static check | `PASS` |

This baseline resolves local provenance and reproducibility, not native CAD, Windows E2E, or production validation.
