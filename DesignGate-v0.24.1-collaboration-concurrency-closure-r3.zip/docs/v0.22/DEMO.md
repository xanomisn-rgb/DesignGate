# Local contract demo

1. Create a project, DFMEA risk, and current verification plan using the existing workflow UI/API.
2. Configure a local `LabDeviceGateway` with a test-only device secret and resolver; label the device `SIM-*`.
3. Send signed telemetry. The gateway stores `LAB_TELEMETRY_RECEIVED`; it cannot accept a device-provided PASS.
4. Use `ingestToWorkflow` only with a current revision/plan binding. A failed result becomes an append-only FAILED record.
5. Submit a later passing measurement with a valid `retest_of`; existing DFMEA logic decides whether closure is eligible.
6. Complete the existing human approval and local-freeze workflow. No step is a production release.
