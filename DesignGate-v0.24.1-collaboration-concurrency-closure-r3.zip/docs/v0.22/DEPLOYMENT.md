# Deployment boundary

The integration server is loopback-only (`127.0.0.1`) by design. It must not be exposed by changing it to `0.0.0.0`; use a reverse proxy with TLS, an authenticated allow-list, CORS restrictions, and a reviewed public IP or domain policy when a network deployment is approved.

Open only the required HTTP and MQTT/WebSockets ports in a security group. Terminate TLS at the proxy and use authenticated Mosquitto listeners. Pass `DG_API_KEY`, `DG_MQTT_BROKER_URL`, broker credentials, `DG_MOODLE_BASE_URL`, and `DG_MOODLE_SERVICE_TOKEN` as protected environment variables, never source-controlled values.

Mock MQTT and Moodle sources are explicitly marked `MOCK` / `NOT_LIVE_VERIFIED`. A passed test, local review, package build, or local freeze is not production approval or an external engineering release.
