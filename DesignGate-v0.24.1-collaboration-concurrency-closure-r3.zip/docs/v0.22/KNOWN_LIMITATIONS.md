# v0.22.0 RC known limitations

| Capability | Status |
| --- | --- |
| Existing DFMEA/evidence/gate/local-freeze closure | IMPLEMENTED and regression-tested |
| Governed local knowledge retrieval | IMPLEMENTED; reference-only boundaries retained |
| Event bus / replay / HMAC telemetry contract | IMPLEMENTED_BUT_NOT_LIVE_VERIFIED |
| Telemetry-to-Workflow delegation | IMPLEMENTED_BUT_NOT_LIVE_VERIFIED |
| Real CAD upload/OCP execution | NOT_LIVE_VERIFIED; local OCP dependency absent |
| HTTP endpoints / MQTT | NOT_IMPLEMENTED |
| Moodle external service | NOT_IMPLEMENTED; no token/account configured |
| Requirement Schema v2 / source conflict service / DVP&R coverage | NOT_IMPLEMENTED in this RC |
| Training UI, teacher mode, four full fixtures, live benchmark | NOT_IMPLEMENTED in this RC |
| Windows Electron E2E | NOT_LIVE_VERIFIED |
| Production release / certified compliance / CAE | NOT_IMPLEMENTED |

The measured baseline coverage is below the requested v0.22 target. Therefore release status is `NOT_FULLY_VERIFIED`.
