# v0.21.1 code audit for v0.22.0

The audit inspected the package scripts, 169 files in `backend`, `connectors`, `knowledge`, `tests`, `eval`, and `docs`, plus 235 code/document keyword hits for state, evidence, gate, role, retry, and approval controls. This is a code-based audit, not a README capability claim.

| Area | Status | Code evidence / v0.22.0 action |
| --- | --- | --- |
| Agent runtime | IMPLEMENTED | `agent_runtime.js` has tool schemas, bounded runs, cancellation, resume/checkpoint, token and timeout controls. Preserve these boundaries. |
| Knowledge retrieval | PARTIAL | `knowledge_service.js` has curated/expansion records, source IDs, exact battery identity safeguards and quarantine; it lacks Schema v2 normalization, first-class source-conflict objects and retrieval traces. Upgrade. |
| DFMEA/verification | IMPLEMENTED | `dfmea_records.js`, `fmea_service.js`, `workflow_service.js` retain append-only execution records, `retest_of`, evidence hash checks, stale handling and residual-risk acceptance. Preserve; add coverage/provenance views only. |
| Evidence graph | PARTIAL | `evidence_registry.js` and `evidence_graph.js` bind source hashes and current support, but lack tamper-evident event-chain manifests and carry-forward manifests. Add. |
| Gate/freeze | IMPLEMENTED | `gate_engine.js`, `professional_gate.js`, `workflow_service.js` recheck current review/baseline and local approval. Do not turn new reference knowledge into Gate PASS. |
| CAD | PARTIAL | CAD intake and OCP/BRep-facing tools exist, but the local test environment lacks OCP and there is no integration event/store adapter. Add bounded adapter with an injectable analyzer and mark live/OCP state explicitly. |
| Lab/LMS integration | NOT_IMPLEMENTED | No event bus, idempotency store, HMAC lab gateway, Moodle adapter, or HTTP integration endpoints are in the audited source. Add local-contract adapters only. |
| Role boundaries | PARTIAL | `role_boundary.js` is read-only kind/tool scoping; it lacks project/action/resource/revision policy audit events. Add fail-closed authorization helper. |
| Multi-role negotiation | PARTIAL | `negotiation_service.js` uses a bounded A03→A02→A06 single round. It is not independent-expert or heterogeneous-model validation. Document limitation; do not overclaim. |
| UI / native E2E | PARTIAL | Renderer contract tests exist; Electron native interaction was not verified in baseline. New data surfaces must use real stored state, not mock status. |
| Benchmark/live model | PARTIAL | Offline eval harness and gold validation exist. No configured live-model evidence was found; v0.22 must state `LIVE_MODEL_VALIDATION_NOT_RUN` unless actual authorized runs occur. |

## Existing safety properties retained

- A model cannot directly write PASS, close risk, accept residual risk, freeze, or release production.
- Evidence and verification are revision/basis-bound; historical FAIL is not overwritten.
- Knowledge reference checks are advisory/reference outputs, not automatic Gate approval.
- Project state uses version checks; agent cancellation/resume is persisted.

## v0.22.0 modification scope

Knowledge schema/conflicts/retrieval trace, deterministic calculators, requirements/traceability, evidence provenance/carry-forward, append-only local integration events with idempotency, contract-level CAD/lab/Moodle adapters, and training fixtures. Full CAD/CAE/MES/ERP/production PLM are out of scope.
