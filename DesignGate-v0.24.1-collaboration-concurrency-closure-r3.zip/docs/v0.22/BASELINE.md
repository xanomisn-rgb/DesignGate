# v0.21.1 baseline frozen for v0.22.0

Baseline source: the supplied `DesignGate-Agent-v0.21.1-governed-knowledge-integration.zip`, extracted to an independent v0.22.0 worktree. No source archive was modified.

| Command | Actual result |
| --- | --- |
| `npm install` | Completed; 232 packages installed. `npm audit` reported 8 dependency advisories (7 high, 1 critical); no unsafe automatic upgrade was applied. |
| `npm test` | PASS, 276/276. |
| `npm run check` | PASS; 109 JavaScript files, 40 dataset cases, 40 gold cases. |
| `npm run test:cad` | BLOCKED before assertions: `ModuleNotFoundError: No module named 'OCP'`. |
| `npm run test:adapter` | PASS, 5/5. |
| `npm run test:handover` | PASS, 3/3. |
| `node --test --experimental-test-coverage tests/*.test.js` | PASS, 276/276; line 93.92%, branch 75.78%, function 87.37%. |

The measured coverage is below the requested release target (95% lines / 85% branches); it is an evidence-based RC constraint, not a waived requirement.
