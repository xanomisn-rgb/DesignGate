# v0.22.1 implementation audit and next steps

Audit date: 2026-09-09. This is a code-and-test inventory, not evidence of live integration, industrial qualification, or production approval.

## Confirmed starting state

- The project already has append-only DFMEA execution records in `backend/dfmea_records.js`; records bind project, revision, design baseline, risk definition, verification plan, evidence, reviewer and completion time.
- `backend/fmea_service.js` retains a failed execution as open until a later explicitly linked retest or a recorded disposition. A simple new PASS does not itself replace a FAIL.
- `backend/workflow_service.js` stores SHA-256 checked evidence and rechecks integrity before use. It also makes a local freeze re-evaluate current DFMEA state.
- `backend/evidence_graph.js` distinguishes registered evidence, rechecked integrity, current support, and historical trace; only current valid PASS paths are exposed as valid support.
- The initial integration event bus is append-only and idempotent, but its lookup is JSONL scan based and the temporary default used by the laboratory gateway is unsuitable as a durable application configuration.
- `backend/integrations/lab_device_gateway.js` derives PASS/FAIL from a plan resolver and routes records through the workflow service. It does not accept caller-supplied engineering status.

## Findings to address in Milestone A

| Area | Finding | Planned corrective boundary |
| --- | --- | --- |
| Canonical data | A deterministic JSON helper exists, but it has no version identifier or repository-owned golden vectors. | Add a versioned contract and vectors before it is used as a cross-system compatibility claim. |
| Knowledge | Curated and expansion records are loaded directly by the legacy service. There is no v2 migration ledger, source/claim conflict store, or reproducible retrieval trace. | Add a non-destructive v2 migration layer; leave the legacy reader compatible while v2 is introduced. |
| Requirements | Existing requirements are largely free-form contract inputs. | Add a canonical requirement model, validation and traceability without silently inventing IDs or mandatory status. |
| Evidence/revisions | Evidence itself is revision-bound, but `newRevision` currently rebuilds `design` with only material/process and has no explicit evidence manifest or carry-forward decision record. | Preserve design state; add snapshot/diff/carry-forward semantics that never make prior evidence current automatically. |
| Gate | Existing gate and professional checks exist, but v2 check IDs, rule versions, applicability state and required-input contracts are not centrally modelled. | Introduce a structured gate-v2 check layer and preserve existing gate behavior until its regression suite passes. |
| Event store | Events have hashes and idempotency checks but no indexed replay verifier, migration ledger, or explicit tamper test suite. | Add indexed metadata, replay verification, and migration audit trails. |

## Deliberately not claimed

No current code proves MQTT hardware interoperability, STEP/BREP capability in this local environment, Moodle connectivity, live device identity, production release, or independent engineering approval. Those belong to later milestones and require the relevant environment and evidence.
