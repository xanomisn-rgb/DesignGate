# DesignGate v0.22.2 P0 Core Closure report

## Artifact identity

Working artifact: `0.22.2-p0-core-closure`, Git baseline commit `adcb208a206dbfd47f4ce602bb333c6021fbc7e7`. This is an independent worktree; the supplied ZIP is not overwritten. The baseline and final raw command logs are stored under `artifacts/validation/p0-core-closure/`.

## Baseline

Before this P0 implementation, `npm test` passed 293 tests and `npm run check` passed. The existing CAD test suite passed with the dedicated OCP environment. The first handover invocation was blocked only because that CAD-only virtual environment does not include `pypdf`; the final handover run used the normal Python environment and passed.

## Evidence provenance and WorkflowService

`EvidenceProvenanceService` now creates and appends the existing canonical `Evidence Manifest`; no second manifest format was introduced. It separates `integrity_status` (`VERIFIED`, `INVALID`, `MISSING`) from `provenance_status` (`BOUND`, `INCOMPLETE`, `MISMATCH`, `STALE`, `UNVERIFIED`, `LEGACY_UNBOUND`). `WorkflowService.addEvidence` calls the service, stores the manifest reference and refuses legacy/unbound evidence for new formal verification. `currentEvidenceContext` is supplied to formal review.

## Gate migration and compatibility

See [GATE_V2_MIGRATION_AUDIT.md](GATE_V2_MIGRATION_AUDIT.md). New orchestrator projects use v2. Existing records without a marker retain v1 and are not rewritten. Gate v2 never treats model prose as a state transition, and local freeze still requires an explicit local human approver and reason.

## CAD integration

`CadAnalysisRunner` discovers `PYTHON_BIN`, then `python`, then `py`; it only uses `child_process.spawn` with `shell:false`, resource limits and random temporary directories. `tools/run_brep_analysis.py` is a CLI boundary around the existing `brep_analyzer.py` / `brep_measurements.py`; it does not reimplement B-Rep analysis. Its output is schema checked and retains sampled/heuristic limitations.

`CadAdapter` publishes `CAD_REVISION_UPLOADED`, `CAD_ANALYSIS_STARTED`, `CAD_ANALYSIS_COMPLETE` or `CAD_ANALYSIS_FAILED`, and `EVIDENCE_CREATED` to the existing event bus. It checks project/revision/currentness/idempotency, registers evidence through WorkflowService, and never writes a Gate pass, risk close, or freeze. Current unreviewed CAD observations hold Gate v2; a current human `SYS-CAD` verification can close that observation. A new revision leaves prior evidence historical/stale.

The loopback server is implemented by `backend/http/integration_server.js`; it binds only `127.0.0.1`, authenticates `X-DesignGate-Integration-Key`, performs project-level authorization, streams multipart upload to temporary storage, enforces `CAD_UPLOAD_MAX_BYTES` (default 50 MiB), and maps the documented error statuses. [openapi.yaml](../integrations/openapi.yaml) is the checked-in API contract and is validated by a route contract test.

## Validation and live scope

Final results: `npm test` passed 313/313; `npm run check` passed; CAD tests passed 17/17 in the pinned OCP environment; adapter tests passed 5/5; handover tests passed 3/3 in the normal Python environment. The explicit P0 scenario passed 1/1. Full `tests/*.test.js` coverage passed 313/313 with 94.30% lines, 74.46% branches and 88.70% functions. Raw logs and the exact environment record are stored in `artifacts/validation/p0-core-closure/`.

The P0 scenario verifies the complete local test chain: loopback auth → project authorization → SHA-256 → idempotency → event bus → CAD adapter → evidence manifest/provenance → WorkflowService → Gate v2 → explicit human-approval boundary.

This is not production approval, engineering release, a complete CAD/CAE assessment, or evidence from a real industrial project. CAD surface sampling remains bounded and does not prove global wall thickness, draft, undercut, fatigue, ergonomics or manufacturing acceptance. No MQTT, ESP32, Moodle, Student/Teacher modes, training UI, installer, release ZIP, or benchmark v2/live benchmark was implemented in this P0 scope.
