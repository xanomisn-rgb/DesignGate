# Gate v2 migration audit

| Caller / path | Previous engine | State mutation | Migration | Status |
| --- | --- | --- | --- | --- |
| `backend/orchestrator.js` `runReviewPipeline` | v1 `GateEngine.evaluateGate` | `project.gate`, `last_review`, freeze eligibility | New projects persist `gate_engine_version: v2`; v2 evaluates formal checks plus existing engineering checks. | Migrated |
| `backend/workflow_service.js` `freeze` | Cached review eligibility | Local freeze record | Revalidates current file hashes, provenance bindings, DFMEA, review basis and human approval. | Migrated boundary |
| `backend/agent_runtime.js` `finish_task` | No formal Gate write | Agent task record only | Model prose remains `MODEL_SYNTHESIS_UNVERIFIED`; it does not invoke a Gate mutation. | No Gate write |
| `backend/action_patch.js` screening | v1 screening result | Draft-screening field only | Retained as non-formal draft screening; it is not a formal review/freeze path. | Legacy/non-formal |
| Existing projects without marker | v1 | Historical `last_review` unchanged | Never recomputed or rewritten. | Preserved as v1/legacy |

Gate v2 is fail-closed. Its formal check families are requirement completeness, evidence integrity and provenance, verification currency and coverage, integration source, knowledge release, source conflicts, critical risk, and revision currency. `HOLD` returns every blocker; a blocking `FAIL` returns `REVISE`.

Current rule re-evaluation can close only a mapped historical rule issue when the current revision, baseline, bound evidence and rule version are recorded. This is explicitly labelled `CURRENT_RULE_REEVALUATION_NOT_TEST_EXECUTION`; it is not a fabricated test execution record. DFMEA test closure continues to use immutable test/retest records.
