# v0.22.1 Core Governance rebaseline

This document supersedes the numerical portion of the RC baseline for work performed after the initial v0.22.0 extraction.  It is a test baseline, not a release approval.

| Command | Result observed on 2026-09-09 |
| --- | --- |
| `npm test` | PASS, 279/279 |
| `npm run check` | PASS; syntax check and evaluation-data validation |
| `npm run test:adapter` | PASS, 5/5 |
| `npm run test:handover` | PASS, 3/3 |
| `npm run test:cad` | Not rerun in this rebaseline. The prior RC attempt was blocked because the local Python environment did not provide OCP. |

The prior measured coverage (93.92% line, 75.78% branch, 87.37% function) remains below the stated release target. It must not be represented as waived or as production validation.

## Scope of this baseline

The worktree is an independent extraction derived from the supplied archive. The source ZIP has not been modified. Existing project history, approval, cancellation/recovery, gate, and local-freeze controls remain in scope for regression testing.
