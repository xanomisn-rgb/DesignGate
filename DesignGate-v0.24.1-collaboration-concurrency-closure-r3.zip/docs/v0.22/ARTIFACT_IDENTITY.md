# Artifact Identity Gate — 2026-09-09

Status: `RESOLVED_IN_INDEPENDENT_WORKTREE`.

This independent worktree now reports package version `0.22.2-p0-core-closure`. It contains post-RC governance work such as `backend/crypto/canonical_json.js`. A local Git baseline was established before P0 changes; it identifies the independent worktree only and does not assert provenance for the supplied ZIP.

| Item | Observed value |
| --- | --- |
| Package version | `0.22.2-p0-core-closure` |
| Git commit/status | `adcb208a206dbfd47f4ce602bb333c6021fbc7e7` baseline; working tree changes are P0 implementation |
| Node / npm | `v24.20.0` / `11.19.0` |
| Electron / electron-builder | `44.2.0` / `24.13.3` |
| Python | `3.13.15` |
| `requirements-cad.txt` | `cadquery-ocp==8.0.1.0.0` |
| Installed cadquery-ocp | `8.0.1.0.0` in `.venv-cad` |
| FreeCAD command | `NOT_AVAILABLE` |
| Mosquitto commands | `NOT_AVAILABLE` |

OCP was subsequently installed in the dedicated venv and its repository CAD test suite passed. FreeCAD, MQTT broker, ESP32, Moodle, Windows packaged-app, CAD HTTP and production integration remain unverified. All future artifacts must retain this provenance and use a distinct release version rather than relabeling the source archive.
