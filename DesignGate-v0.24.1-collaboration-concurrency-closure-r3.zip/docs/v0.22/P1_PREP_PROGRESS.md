# v0.22.3-p1-prep execution record

## 0. Baseline

- Target version: `0.22.3-p1-prep`.
- Dependency installation: completed with `npm install`; the audit reported eight upstream dependency advisories. No automatic or breaking audit remediation was applied in this preparation release.
- Baseline regression: `npm test` passed (313 tests); `npm run check` passed.
- CAD regression: the host `python` has no OCP package, so `npm run test:cad` correctly recorded an environment failure. The supported `.venv-cad` interpreter then passed all 17 CAD tests.
- Logs: `artifacts/p1-prep/validation/baseline-*.log`.

Subsequent sections are appended only after their scoped implementation and regression run are complete.

## 1. MQTT / Mosquitto

- Installed Mosquitto 2.1.2 locally for this validation only, with authenticated TCP (`18883`) and WebSockets (`19001`) listeners. Runtime credentials and broker files are excluded from Git.
- Added `mqtt_lab_connector`, an explicit `MOCK` ESP32 publisher, project-scoped device secrets, HMAC rejection diagnostics, and workflow-bound recording. Telemetry cannot supply a result status; the gateway derives PASS/FAIL from the bound plan.
- Real localhost validation: `mosquitto_sub` received the MQTT.js mock message; a bad broker credential was rejected; a signed live MQTT.js message reached the connector. The broker returned MQTT v3 return code 5 (`Not authorized`) for this Mosquitto configuration; the adapter normalizes both protocol codes 4 and 5 to `MQTT_AUTHENTICATION_FAILED` while retaining the broker code.
- Test and coverage logs: `artifacts/p1-prep/validation/mqtt-*.log`. `mqtt_lab_connector.js` and `lab_device_gateway.js` both reached 100% branch coverage in the scoped coverage command.

## 2. Moodle adapter

- Added a REST adapter for Moodle's documented `server.php` web-service route, with scoped project authorization, timeout handling, and explicit `MOCK`/`NOT_LIVE_VERIFIED` provenance.
- Mock regression covers course parsing, invalid token, denied project scope, and service timeout. No Moodle server or service-account token was supplied, so live Moodle verification remains unperformed.

## 3. Deployment and Windows build

- Added `.env.example` and `DEPLOYMENT.md`; the integration HTTP server remains loopback-only. Public exposure is documented as a reverse-proxy/TLS/allow-list review, never an automatic `0.0.0.0` switch.
- Added NSIS x64 configuration and `scripts/build_windows.ps1`. The local build generated `dist/DesignGate Studio Setup 0.22.3-p1-prep.exe`.
- The installer was not installed and a desktop UI workflow was not completed; only packaging was verified. This is not a production release assertion.
