# Integration MVP

`integration_event_bus` persists append-only local JSONL events. Its business idempotency key is `(project_id, source_id, event_type, idempotency_key)`: identical payloads return `DUPLICATE_REPLAY`; divergent payloads fail `IDEMPOTENCY_CONFLICT`. Each project event has a SHA-256 payload hash and previous-event/event hash chain. The chain is tamper-evident, not an assertion of absolute immutability.

`lab_device_gateway` accepts only measurement telemetry and checks device HMAC before deterministic criterion evaluation. Telemetry cannot carry `PASS`, Gate state or risk closure. `ingestToWorkflow` creates registered evidence and append-only DFMEA test execution through `WorkflowService`; a failed telemetry result remains a FAILED test and a later pass must still meet the existing `retest_of` controls.

The adapters are local contract implementations and are marked `SIMULATED_DEVICE` or `DEVICE_TELEMETRY_NOT_LIVE_VERIFIED`. CAD, Moodle REST, MQTT, HTTP server routing, real devices, and production external services are not live verified.
