# v0.22.0 benchmark status

Offline Node regression: 278/278 after the event-bus additions. No authorized live model API configuration was found or used; `LIVE_MODEL_VALIDATION_NOT_RUN`. A 10,000-event replay benchmark and requested Retrieval v2 benchmark gold sets are not implemented in this RC.
