# v0.22.0 RC integration security

- Fail closed on unknown device, invalid signature, invalid revision/plan binding, unsupported event type, and idempotency conflict.
- Device telemetry property allowlist rejects status, Gate state and risk-closure fields.
- Idempotency prevents duplicate event business effects; divergent replays are rejected without overwriting the first event.
- Events are local JSONL with restrictive write mode and SHA-256 chain metadata. This is tamper-evident, not an absolute immutable ledger.
- Live authentication, TLS termination, production key rotation, MQTT, Moodle service accounts, rate limiting, and HTTP routing are not live verified.
