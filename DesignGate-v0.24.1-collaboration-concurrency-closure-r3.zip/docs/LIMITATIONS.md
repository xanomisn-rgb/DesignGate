# Limitations v0.18

- All 40 atomic cases, 4 scenarios and 10 A/B cases are authored synthetic. They provide regression and capability probes, not proof of factory performance.
- Gold labels are `AUTHOR_DRAFT_REQUIRES_EXPERT_REVIEW`. Until an identified expert reviews them, deterministic success remains `PENDING_REVIEW`.
- No live model baseline is included unless valid model configuration is present at execution time. Offline plans contain no model quality scores.
- `pass@k` measures at least one success and `pass^k` measures all-success reliability only among formally eligible reviewed trials. Small samples are not statistical significance.
- STEP support is bounded BRep sampling. It does not solve global wall thickness, prove absence of undercuts, detect assembly interference, perform CAE, approve a mold, or release production.
- STL results remain mesh heuristics. PDF extraction has no OCR. Local knowledge applicability and source currency still require engineering review.
- Multi-Agent roles use isolated prompts/tools but may use the same base model. Measured gain must be reported with token, latency and request cost; role count alone is not intelligence gain.
- External platform adapters fail closed. inAgent/LMS/production PLM success is not claimed, and no Agent tool can grant final engineering release.
