# Capability Matrix v0.20.3

本表汇总当前源码可确认能力；历史 v0.18 表继续保留在 `docs/CAPABILITY_MATRIX.md`。状态含义以代码、自动化与 release validation 为准。

| Capability | Status | Evidence / boundary |
| --- | --- | --- |
| Stateful Agent planning/tool loop | CONFIRMED | `backend/agent_runtime.js`; 270/270 local suite includes runtime/integration regression |
| Proposal approval + stale version protection | CONFIRMED | Draft/base version/diff binding; user approval required |
| Default cumulative token hard cap removed | CONFIRMED | v0.20.3 runtime/config tests; default null/disabled |
| Independent long-run stop reasons + resumable segments | CONFIRMED | Tool/model/negotiation/time/timeout/user/no-progress separated |
| Multi-role A03→A02→A06 trade-off calls | CONFIRMED | Independent model requests with role tool permissions; one-round protocol |
| Knowledge search/read/reference checking | CONFIRMED | Structured curated cards and governed conditions; breadth remains limited |
| STEP BRep parsing and bounded measurements | CONFIRMED | CAD 17/17 local tests; OCP/OpenCascade |
| DFMEA versioned verification plan + append-only execution | CONFIRMED | v0.20.3 closure regressions and Workflow interfaces |
| Retest linkage / failed-history closure protection | CONFIRMED | Linked `retest_of`, baseline/evidence/time/risk checks |
| Residual risk acceptance separated from PASS | CONFIRMED | Current policy requires separate acceptance for configured high residual risk |
| Evidence integrity re-hash and current-support graph | CONFIRMED | File SHA recheck; stale/failed/planned excluded from current support |
| Agent-controlled production release | NOT_IMPLEMENTED | Formal Gate/Freeze remain Workflow/HITL controlled |
| Global minimum wall thickness solver | NOT_IMPLEMENTED | Thickness is bounded/sample-based candidate measurement |
| Full mold undercut/parting proof | NOT_IMPLEMENTED | Visibility sampling is bounded heuristic evidence |
| Assembly interference/tolerance stack/CAE | NOT_IMPLEMENTED | Outside current single-part scope |
| Real-project senior industrial-design intelligence | UNVERIFIED | v0.20.3 lacks independent expert-reviewed real-project proof |
| v0.20.3 live-model 200-run reliability | UNVERIFIED | Old v0.18.1 run is diagnostic only; must rerun current version |
| Windows Electron/WebGL manual E2E | UNVERIFIED | Automated UI/IPC contracts pass; native target-machine click-through not run |
| Production inAgent / LMS / PLM integration | NOT_IMPLEMENTED / MOCK_ONLY | Adapter/gateway boundaries exist; no verified production contract |
