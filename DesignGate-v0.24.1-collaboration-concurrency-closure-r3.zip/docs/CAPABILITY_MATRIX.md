# Capability Matrix v0.18

| Capability | Status | Evidence / boundary |
| --- | --- | --- |
| Project and cross-project isolation | CONFIRMED | State manager and runtime tests |
| Proposal approval and stale revision protection | CONFIRMED | Runtime/action patch tests |
| Observation validation and source binding | CONFIRMED | Runtime and measurement tests |
| STEP BRep basic parsing | CONFIRMED | `tools/test_brep.py` |
| Bounded surface derivatives, normals, chord and visibility samples | CONFIRMED | BRep measurement and fixture tests |
| Trial isolation and deterministic grading | CONFIRMED | v0.18 Eval tests |
| Agent planning, routing and trade-off quality | UNVERIFIED | Requires live multi-trial model run and human review |
| Real-project industrial design intelligence | UNVERIFIED | Current datasets are authored synthetic |
| Windows Electron/WebGL behavior | UNVERIFIED | Requires local native acceptance |
| Global minimum wall thickness | NOT_IMPLEMENTED | Bounded samples are not a global solver |
| Global undercut proof | NOT_IMPLEMENTED | Visibility samples only identify candidates |
| Assembly interference and CAE | NOT_IMPLEMENTED | Outside current single-part scope |
| Production PLM release | NOT_IMPLEMENTED | PLM path is mock/gateway only |

## Connector Capability Matrix

| Connector | Mock | Implemented locally | Production connected | Status |
| --- | --- | --- | --- | --- |
| inAgent | Yes | Adapter boundary only | No verified contract | NOT_IMPLEMENTED |
| LMS | No | No | No | NOT_IMPLEMENTED |
| PLM | Yes | Mock/gateway adapter | No verified vendor integration | MOCK_ONLY |
| releaseDesignFreeze | No | Local freeze is separate | No enterprise permission link | NOT_IMPLEMENTED |
