# DesignGate v0.20.3 后续专业化路线

本路线以 v0.20.3 已实现能力为起点。旧路线已保留在 `docs/history/ROADMAP_pre_v0.20.3.md`。

| 优先级 | 下一阶段工作 | v0.20.3 起点 | 建议验收目标 |
| --- | --- | --- | --- |
| P0 | 真实模型多轮基准复测 | 已有 40-case / multi-trial / scenario harness；v0.20.3 未重新完成同等级 live 200-run | 冻结模型、参数、工具集，完成 ≥200 次可复现 live run，并输出 failure taxonomy、工具恢复率、证据绑定率和人工抽审 |
| P0 | 独立专业专家 Gold / Holdout | Gold 仍需独立专家审核 | 至少 1 名工业设计专家 + 1 名结构/制造专家盲审，建立不可由开发者同时编写与评分的 holdout |
| P0 | Windows Electron 全链人工验收 | IPC/UI contract 自动化已通过 | 在目标 Windows 机器逐项完成项目、CAD、Agent、DFMEA、复测、风险接受、Gate、Freeze、WebGL 与异常恢复点击验收 |
| P1 | 主 Agent 与正式 Workflow 的受控桥接 | Agent 主要做分析/Proposal，DFMEA/Gate/Freeze 在 Workflow | 只开放低风险、可审批的业务动作；所有 Test/Retest/Risk Accept/Freeze 保留人审与版本/证据约束 |
| P1 | CAD DFM 求解能力升级 | 已有 OCP BRep + 有界采样 | 增加更可靠的全局/自适应厚度候选、分型/倒扣分析、装配与公差链能力，并以标准 CAD fixture + 专家模型集验证 |
| P1 | 工程知识库扩充与治理 | 已有结构化知识卡和来源约束 | 扩展原厂 TDS、标准、工艺窗口、CMF、质量与验证知识，建立来源有效期、复审人、规则版本和回归样本 |
| P1 | 实训教学分析 | 已有 Revision、Finding、Test、Gate、事件日志 | 输出学生 Trade-off、证据使用、Revision 质量、重复问题、风险关闭和 Gate 过程指标，形成可解释能力画像 |
| P1 | 真实平台集成 | 连接器目前 fail-closed / gateway / mock | 依据真实 inAgent/PLM/LMS 协议完成沙箱联调、幂等、权限、失败补偿和真实回执验证 |
| P2 | 前端工业设计能力扩展 | 工程评审后半段较强 | 补用户研究、场景证据、竞品、需求优先级、草图/图像理解、概念版本与设计语言比较，同时保留证据和人审边界 |
| P2 | 长任务记忆检索 | 已有任务事件持久化和有限历史摘要 | 增加 evidence-aware run history 检索、实体/Requirement 定向召回和上下文压缩质量测试 |

专业化成效建议以真实任务指标衡量：任务完成率、FAILED/中止率、错误放行率、Critical/High-risk miss、Evidence binding、Unsupported claim、Revision 后重新验证正确率、人工纠错时间、专家评分和学生学习增益。
