# Collaboration Concurrency Test Plan

Correctness and authority safety take precedence over throughput. All harness runs create an independent temp database, artifact directory, users, project, server port and run directory; they must not use development collaboration data.

| Level | Scope | Entry point | Status |
| --- | --- | --- | --- |
| A | Deterministic HTTP races: entity conflicts, idempotency, immutable artifacts, RBAC, approvals, final-freeze, Agent/human revalidation, and event invariants. | `npm run test:concurrency:race` | IMPLEMENTED — authenticated REST; includes a 20-process client race |
| B | Authenticated HTTP + WebSocket fan-out, concurrent writers, disconnect and HTTP catch-up before resumed streaming. | `npm run test:concurrency:websocket` | IMPLEMENTED — 50 observers / 100 events per fan-out scenario |
| C | Bounded localhost profiles C1/C2/C3 with latency/throughput metrics and invariant reports. | `npm run test:concurrency:load` | IMPLEMENTED — external Node processes, isolated per profile |
| D | Short, controlled multi-wave localhost soak smoke, retaining one service/project/event chain. | `npm run test:concurrency:soak` | IMPLEMENTED AS `SOAK_SMOKE`; long-duration soak remains NOT_LIVE_VERIFIED |

Current race invariants: exactly one same-entity winner; no duplicate side effect for one idempotency key; changed payload under the same key is rejected; final entity version and event count match committed results; unauthorized writes and Agent-run completions do not mutate authority-bearing state; a frozen Revision cannot receive a concurrent engineering mutation. These are localhost HTTP clients, not physical devices and not a capacity claim.

Hard failures for every future profile: lost update, silent overwrite, unauthorized successful write, duplicate idempotent side effect, broken event chain, duplicate event sequence, tampered artifact accepted, stale approval used for freeze, invalid freeze, or frozen-revision mutation.

Candidate project SLOs (not industry standards and not yet frozen): in a future classroom profile, unexpected 5xx = 0, data corruption = 0, ordinary command p95 ≤ 800 ms, read p95 ≤ 500 ms, WebSocket delivery p95 ≤ 500 ms, and 100-event catch-up ≤ 2 s. Actual results must retain host fingerprint, seed, profile and raw metrics before any conclusion. One earlier C3 sample exceeded the candidate command p95 and the latest bounded sample did not; neither sample establishes an SLO.
