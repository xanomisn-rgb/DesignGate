# v0.24.1 Concurrency Validation

Date: 2026-09-15

## Actual completed run

| Field | Actual value |
| --- | --- |
| DesignGate version | 0.24.1 |
| Transport | Localhost HTTP REST → CollaborationServer → TeamProjectRepository → CommandService → SQLite TeamStore |
| Database | SQLite (`DatabaseSync`), WAL, `BEGIN IMMEDIATE`, 5-second connection-local busy timeout |
| Simulated concurrent authenticated clients | 50 WebSocket observers; 40 external-process HTTP clients in C3 |
| Physical devices | 0 |
| Race suite | 14 tests, passed after the final rerun (`npm run test:concurrency`, 2026-09-15) |
| Existing baseline | `npm run check` passed; `npm test`: 404 passed / 1 skipped; `npm run test:collaboration`: 83 passed |

Verified local-network behaviors:

- Same BOM entity: 20 simultaneous authenticated HTTP writers → 1 commit, 19 `ENTITY_VERSION_CONFLICT`, no duplicate entity row.
- Same key/same payload: 20 simultaneous HTTP submissions → 1 event and 19 deterministic replays.
- Same key/different payload: one commit and one `IDEMPOTENCY_CONFLICT`.
- Different BOM entities: 20 simultaneous HTTP writes → 20 commits and 0 false entity conflicts.
- Post-run invariant checker recomputes event hash links/sequences and validates registered artifact/evidence bindings.
- Fifty authenticated WebSocket observers each received all 100 server-committed HTTP events in strictly monotonic event-sequence order, without duplicate event IDs.
- Twenty concurrent same-filename/different-byte multipart CAD uploads created twenty distinct immutable artifact IDs; every registered artifact byte stream matched its SHA-256 metadata after upload.
- Nineteen simultaneous Viewer write attempts were denied with `PERMISSION_DENIED`; the only committed write came from the authorized owner and no unauthorized domain event was appended.
- A teacher approval released concurrently with an authorized BOM mutation was either made `STALE` by the mutation or revalidated against the current state; no old-state approval remained current.
- A final-freeze request released concurrently with an engineering mutation never produced both a frozen Revision and that mutation. One authority transition won; the competing transition was rejected.
- Two concurrent final-freeze requests create exactly one freeze record. The losing request returns HTTP 409 / `FROZEN_REVISION`, not a misleading 5xx.
- Two teachers may retain distinct, auditable current approvals only when each binding validates against the same current state.
- Twenty independent Node processes login and submit a same-entity HTTP race: one command commits, nineteen receive `ENTITY_VERSION_CONFLICT`, and no lost update is observed.
- TeamStore configures a 5-second SQLite busy timeout to absorb brief lock contention. This is a connection-local bounded wait, not multi-server coordination or a durability/availability guarantee.
- Agent runs now have authenticated HTTP start/complete routes. A non-requester cannot complete a run (`403 AGENT_RUN_COMPLETION_FORBIDDEN`); a relevant human change during the run produces `REVALIDATION_REQUIRED` on completion.
- Fifty WebSocket observers received a monotonic, duplicate-free 100-event stream while 100 different BOM entities were written concurrently.
- A disconnected observer caught up all 100 concurrently committed events through the authenticated HTTP event API, then resumed a WebSocket stream and received only the next event (`event_seq` 102).
- C1/C2/C3 external-process localhost runs completed with 100/150/200 successful commands respectively, zero 5xx and no event-chain violations. Latest raw reports are `artifacts/concurrency/LOAD-09f04bc1-ecf7-48e0-8eeb-b73ed952d6ea.json`, `artifacts/concurrency/LOAD-82c0e6a4-a55a-46a0-97f7-921bff485d2f.json`, `artifacts/concurrency/LOAD-5c4b33ba-a19a-4bfd-bcd5-0f71ef2fc2a4.json`; aggregate: `artifacts/concurrency/CONCURRENCY-PROFILES-f13caa15-e3f6-4f60-88d0-71ceb4e52e64.json`.
- `SOAK_SMOKE` retained one isolated service/project across five waves (250 external-process commands), with zero 5xx and no invariant violations. Latest raw report: `artifacts/concurrency/LOAD-a3e7bb7d-7d91-46ef-bead-6f69edc418e3.json`.

## Metrics and limits

Collected localhost command metrics are recorded in the raw reports. The latest C1/C2/C3 command p95 values were 455.34 ms / 562.28 ms / 744.19 ms and throughput was 68.05 / 78.52 / 74.25 commands/s. The short soak-smoke p95 was 223.39 ms and throughput was 62.12 commands/s. Each raw report records CPU/RSS/heap metrics only for the runner and in-process server; external client-process and machine-wide resource usage are excluded. These figures are not capacity boundaries, active-user recommendations, classroom deployment profiles or SLO commitments.

`LOCAL_NETWORK_CONCURRENCY_VERIFIED` applies only to the bounded localhost HTTP, WebSocket, external-process and short soak-smoke tests above. `REAL_MULTI_DEVICE_CONCURRENCY_VERIFIED` is not established. Long-duration soak, machine-wide CPU/RSS and SQLite-busy telemetry, real browser/Electron multi-user interaction, and all physical-device tests remain `NOT_LIVE_VERIFIED`.

The completed checks do not constitute production approval, production release, or a claim of professional-engineering sufficiency.
