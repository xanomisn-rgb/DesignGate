# Repository Model

## Status

`VERIFIED` — the A-stage architecture regression and existing Runtime, Gate, Evidence and Solo workflow regressions pass with the repository boundary in place.

## Contract

Formal domain code consumes a repository-shaped dependency rather than importing `ProjectStateManager`. The common contract is defined by `backend/repositories/project_repository.js` and includes project reads, project/entity versions, scoped entity reads, command application, history/events and transactions.

| Mode | Repository | Authority |
| --- | --- | --- |
| Solo | `FileProjectRepository` | Existing local project JSON under Electron user data. |
| Team | `TeamProjectRepository` | Collaboration Server SQLite Team Store and authenticated command path. |

`WorkflowService` and `AgentRuntime` already receive their state dependency through constructor injection. They do not import the file implementation. `DesignGateOrchestrator` now receives `options.repository`; its default is `FileProjectRepository` for backward-compatible Solo construction.

## Remaining direct `ProjectStateManager` dependency

| Path | Reason | Status |
| --- | --- | --- |
| `backend/repositories/file_project_repository.js` | The sole Solo adapter delegates existing JSON persistence, atomic write lock and historical snapshots to the legacy state manager. | VERIFIED, intentionally bounded |
| `backend/project_state_manager.js` | Legacy implementation owned by the File adapter. | VERIFIED, intentionally bounded |

No formal domain service (`WorkflowService`, `AgentRuntime`, Orchestrator, Gate v2, Evidence Provenance) imports `ProjectStateManager`. Electron `main.js` constructs `FileProjectRepository`, not the legacy manager directly.

## Team limitation

`TeamProjectRepository` supports scoped reads, entity-version reads and the implemented governed command paths. Agent-run lifecycle is separately exposed through the authenticated collaboration server: it records a revision and relevant entity versions, restricts completion to the requester, and returns `REVALIDATION_REQUIRED` after a relevant human change. It does not grant an Agent authority to mutate engineering entities, approve residual risk, pass a Gate or freeze a Revision. Broader workflow parity and multi-server coordination remain outside this local Team boundary.
