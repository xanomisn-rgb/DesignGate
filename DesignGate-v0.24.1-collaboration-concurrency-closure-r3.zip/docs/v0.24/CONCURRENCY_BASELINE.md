# v0.24.1 Concurrency Baseline Audit

Audit date: 2026-09-15. This is a source audit before the dedicated concurrency harness is added.

| Area | Actual implementation | Current guarantee / limitation |
| --- | --- | --- |
| Server model | Node HTTP server plus `ws`, one `CollaborationServer` instance per process. | HTTP and WebSocket routes share a process; no multi-process server coordination is implemented. |
| Database | Node `DatabaseSync` SQLite store. | Per-run database path is injectable. SQLite is appropriate for the local Team MVP, not evidence of PostgreSQL-class write capacity. |
| Journal / transactions | `PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;` and `BEGIN IMMEDIATE` in `TeamStore.transaction`. | Authority-critical state changes are serialized by SQLite write transactions. No explicit `busy_timeout` is configured yet. |
| Command scope | `TeamProjectRepository → CommandService → TeamStore.applyEntityCommand`. | Entity versions are checked inside the transaction. Distinct entities can use the same base project version; writes still serialize at SQLite transaction scope. |
| Event sequence / hash chain | Each transaction reads the project tail event, appends `event_seq + 1`, and hashes the preceding hash. | Transaction scope protects one-store sequence assignment; cross-process database behavior has not been load verified. |
| Idempotency | Unique `(project_id, idempotency_key)` plus payload SHA comparison inside command transaction. | Same payload replays an existing result; different payload is rejected. Artifact HTTP upload has a separate append path and needs E2E concurrency coverage. |
| Artifact store | Immutable UUID storage key, temp-file then rename, SHA-256 metadata; registry then audit event. | Same filename cannot overwrite earlier content. Upload registry/audit path is not one SQLite transaction with filesystem storage and requires fault/concurrency testing. |
| WebSocket | Server broadcasts compact committed event envelopes; clients can REST catch up by `event_seq`. | No per-client delivery acknowledgement or retransmit buffer. Convergence must be proven through catch-up tests. |
| Presence | In-memory TTL map, outside project state/event chain. | Process-local only; no durable or cross-server presence. |
| Agent coordinator | Run snapshots relevant entity versions and marks completion `REVALIDATION_REQUIRED` when those versions changed. | Current test coverage is deterministic, not concurrent network traffic. |
| Approval / freeze | Commands use TeamStore transactions; FinalFreezeService recomputes current evidence/DFMEA/Gate/approval bindings. | Correctness is covered by command tests; real concurrent freeze/mutation races are not yet verified. |

Existing tests cover optimistic entity conflict, idempotency replay, WebSocket catch-up, artifact immutability, Agent stale detection, Gate and final-freeze denial/success paths. They are predominantly single-process deterministic tests, not a load or multi-client network validation.

Status before the new harness: `IMPLEMENTED_BUT_NOT_LIVE_VERIFIED` for local collaboration concurrency; `NOT_IMPLEMENTED` for a dedicated E2E stress/soak harness. No real multi-device concurrency result exists.
