# Solo → Team Migration

Status: `IMPLEMENTED` for server-hosted preflight and confirmed import. The Electron import wizard and a multi-computer transfer run are not yet live-verified.

Migration is explicit. Connecting a Team client never uploads or changes a Solo project.

## Safe workflow

1. On the host that can read the Solo project and its referenced files, make a backup of the Solo project JSON and the referenced CAD/evidence files.
2. Run a non-mutating preflight:

   ```powershell
   npm.cmd run collaboration:migrate -- --project C:\path\solo-project.json --target DG-TEAM-001
   ```

3. Review the plan. `READY_WITH_WARNINGS` means a referenced file is missing and must not be executed. The preflight reports SHA-256 values for every discovered CAD/evidence file and does not create a Team project.
4. Only after an authorized owner has reviewed the plan, run the explicit execution on the Team server host:

   ```powershell
   npm.cmd run collaboration:migrate -- --project C:\path\solo-project.json --target DG-TEAM-001 --execute --owner OWNER-1 --data-dir C:\DesignGate\team-data
   ```

5. Connect to Team mode and inspect the imported project, immutable artifact metadata, audit event, and `HISTORICAL_REQUIRES_REVALIDATION` records.

## Imported-state rules

- Imported CAD and evidence bytes are stored as new immutable Team artifacts and verified with SHA-256 during import.
- The Team project receives a new owner membership and a `SOLO_PROJECT_IMPORTED` hash-chain audit event.
- Requirements, BOM, revision lineage, DFMEA definitions, and append-only test history are retained as migration data.
- Imported legacy evidence and test records are historical and require current-revision revalidation. They do not establish a current PASS, Gate decision, approval, or local freeze.
- The Team project does not retain the source machine’s absolute file paths; the migration report returns artifact IDs and hashes for traceability.
- Missing referenced files reject execution before Team project creation. A failed import is never reported as successful.

## Boundaries

This tool runs where the original files are readable. It is not a browser upload endpoint and is not an automatic Solo/Team synchronization mechanism. It does not delete or modify the Solo project, contact production systems, perform external archiving, or authorize production release.
