# Collaboration Core baseline audit

**Audit date:** 2026-09-14  
**Source of truth audited:** `DesignGate-v0.23-continuation-checkpoint-version-display-source-r3.zip`  
**Source SHA-256:** `F3FA6AF9E5DAFB3D8231BBEABB22093230849532054D6B4F008B41759AD5A561`  
**Package version:** `0.22.3-p1-prep`  
**Git identity:** `NOT_IMPLEMENTED` — the audited working copy is not a Git work tree, so no commit or tag is available.

This document records facts found in the supplied source before Collaboration Core implementation. A status of `VERIFIED` means the stated source path and behavior were directly inspected in this audit; it does not mean real multi-device operation has been demonstrated.

## Existing authority model

| Concern | Actual source path(s) | Baseline behavior | Status |
| --- | --- | --- | --- |
| Project persistence | `backend/project_state_manager.js` | One JSON document per project beneath a local `projects` directory, plus immutable-on-write numbered JSON history snapshots. Electron uses `app.getPath('userData')/projects`. | VERIFIED |
| Solo repository behavior | `backend/project_state_manager.js`, `backend/workflow_service.js` | Domain services read and write `ProjectStateManager` directly. No repository interface separates JSON persistence from domain services. | VERIFIED |
| Project version | `backend/project_state_manager.js` | `saveProject(data, expectedVersion)` compares `expectedVersion` with the stored document version, then increments `data.version`. | VERIFIED |
| Version conflict | `backend/project_state_manager.js` | Mismatched expected version throws `VERSION_CONFLICT`; no last-write-wins path was found in this state manager. | VERIFIED |
| Entity version | project JSON model | Requirements, BOM items, DFMEA items, comments and tasks have no server-maintained entity version contract. | NOT_IMPLEMENTED |
| Write lock | `backend/project_state_manager.js` | A short-lived `<project>.json.lock` is acquired with exclusive file creation during one local write. It protects a local file write only. | VERIFIED |
| Review coordination | `main.js` | `activeReviews` is an in-process `Set`; a project is blocked during an Electron formal-review worker run. | VERIFIED |
| Agent coordination | `backend/agent_runtime.js`, `main.js` | `AgentRuntime.isActive(projectId)` and an in-memory active-run map prevent concurrent local runs for a project. The runtime checks its base project version before and during execution. | VERIFIED |
| Cross-computer lock/coordinator | server-side collaboration service | No process-independent review, agent, revision or final-freeze coordinator was found. | NOT_IMPLEMENTED |

## Identity, authority and approvals

| Concern | Actual source path(s) | Baseline behavior | Status |
| --- | --- | --- | --- |
| User identity | `main.js` | No user account, authenticated session, server-side actor identity or project membership exists. | NOT_IMPLEMENTED |
| Local reviewer secret | `main.js` | A local `reviewer_pin.json` stores a salted scrypt PIN under Electron user data. It gates local PIN setup and the local freeze command. | VERIFIED |
| Approval identity | `backend/workflow_service.js`, `main.js` | Local freeze records free-text `approved_by`, a reason, timestamp and `LOCAL_DESKTOP_APPROVAL`; the PIN is checked locally before calling the workflow. | VERIFIED |
| Team approval binding | collaboration approval service | No approval record binds a server actor, team role, project version, evidence set and verification/gate state hashes. | NOT_IMPLEMENTED |
| RBAC | server-side permission service | No role IDs, membership checks, permission matrix or server-side authority check exists for Team Mode. | NOT_IMPLEMENTED |
| Existing local safety boundary | `backend/workflow_service.js`, `backend/gate/gate_v2.js` | A local freeze rechecks current evidence, DFMEA, Gate 3, review hash and revision conditions. It explicitly records `external_release:false`. | VERIFIED |

## Engineering-state and provenance behavior

| Concern | Actual source path(s) | Baseline behavior | Status |
| --- | --- | --- | --- |
| Workflow mutations | `backend/workflow_service.js` | Profile, BOM, requirements, evidence, verification, DFMEA plan/test, risk actions, decisions, revisions and local freeze all call `ProjectStateManager` directly. | VERIFIED |
| Revision | `backend/workflow_service.js` | `newRevision` records lineage and a design snapshot, clears current CAD geometry, verifications, review/freeze state and refreshes DFMEA bindings. | VERIFIED |
| Evidence bytes | `backend/workflow_service.js` | Evidence files are copied under a SHA-256-derived path; `addEvidence` creates provenance and revision manifests. Existing bytes are not overwritten by the normal add path. | VERIFIED |
| Evidence currency | `backend/evidence/evidence_provenance_service.js`, `backend/workflow_service.js` | A current formal verification requires project, revision and (where applicable) verification-plan binding to match. Old-revision evidence is rejected for current verification. | VERIFIED |
| CAD integration | `backend/integrations/cad_adapter.js`, `backend/http/integration_server.js` | A loopback-only, API-key protected CAD upload endpoint exists and emits integration events. It is not a Team collaboration artifact service. | VERIFIED |
| Immutable Team artifacts | server artifact storage abstraction | No server-owned artifact metadata/store supporting authenticated multi-user CAD/evidence uploads was found. | NOT_IMPLEMENTED |
| Gate authority | `backend/gate/gate_v2.js`, `backend/workflow_service.js` | Gate v2 computes local Gate results; local freeze requires a current eligible Gate 3 result. | VERIFIED |

## Event, network and desktop structure

| Concern | Actual source path(s) | Baseline behavior | Status |
| --- | --- | --- | --- |
| Integration event log | `backend/integrations/integration_event_bus.js`, `integration_store.js`, `integration_schema.js` | Append-only JSONL external-integration events have payload hashes, a project hash chain and idempotency for supported CAD/lab/LMS event types. | VERIFIED |
| Collaboration audit event log | collaboration server | Existing integration events do not carry authenticated actor/role, entity version, command ID or collaboration event types. | NOT_IMPLEMENTED |
| HTTP | `backend/http/integration_server.js` | The existing HTTP server is deliberately loopback-only. It exposes health and multipart CAD upload only, with a fixed integration key and project authorizer callback. | VERIFIED |
| WebSocket / real-time sync | server or client | No WebSocket server, presence model, reconnect/catch-up protocol or project-event subscription was found. | NOT_IMPLEMENTED |
| Electron IPC | `main.js`, `preload.js` | A context-isolated preload exposes local IPC methods for project, workspace, pipeline, agent and file dialogs. The main process instantiates local state/workflow/runtime services. | VERIFIED |
| Team client transport | renderer/client adapter | No authenticated Collaboration API client, Team Mode selector or server repository client was found. | NOT_IMPLEMENTED |

## Baseline conclusion and implementation constraints

1. Solo mode is the current verified working model and must remain backed by `ProjectStateManager` JSON data.
2. Team mode must not share or directly write client-side project JSON files. It needs a separately hosted authority service, server-owned metadata/event storage and authenticated commands.
3. Existing WorkflowService, Gate v2, Evidence Provenance, DFMEA, CAD and AgentRuntime already contain meaningful local governance. Collaboration Core should call or adapt them through a repository/authority boundary rather than duplicate their engineering rules.
4. Current local `VERSION_CONFLICT`, evidence provenance checks, local freeze recheck and AgentRuntime project-version checks are useful foundations, but are insufficient for authenticated multi-user entity-level collaboration.
5. No evidence was collected in this audit of real LAN, multi-device or production deployment. Any such capability introduced in v0.24 must remain `IMPLEMENTED_BUT_NOT_LIVE_VERIFIED` until a real multi-device test is recorded.
