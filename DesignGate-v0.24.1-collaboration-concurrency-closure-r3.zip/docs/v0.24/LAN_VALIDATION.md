# LAN Validation Protocol

Status: `IMPLEMENTED_BUT_NOT_LIVE_VERIFIED`. This workspace has not connected two independent physical computers.

## Server computer (PC-A)

1. Copy the source/runtime directory and install dependencies with `npm.cmd install`.
2. Set a unique `DESIGNGATE_SESSION_SECRET` outside source control.
3. Start loopback-only first:

   ```powershell
   .\scripts\start_collaboration_server.ps1 -SessionSecret 'use-a-unique-secret'
   ```

4. After reviewing the trusted network and creating a narrow inbound firewall rule manually, opt in to LAN binding explicitly:

   ```powershell
   .\scripts\start_collaboration_server.ps1 -ServerHost 0.0.0.0 -AllowLan -SessionSecret 'use-a-unique-secret'
   ```

The script prints local URL, LAN candidate addresses, health URL, database path and artifact path. It never changes firewall rules. For untrusted networks use a reverse proxy and TLS; do not expose the service directly to the public internet.

## Client checks (PC-A and PC-B)

Use a dedicated test user, not a production identity:

```powershell
.\scripts\test_collaboration_client.ps1 -ServerUrl http://PC-A-LAN-IP:43124 -Username test-user -Password test-password -ProjectId DG-TEAM-001
```

The checker verifies `/health`, login, `/me`, project list, project membership, initial WebSocket `CONNECTED` event, and one reconnect. It does not send a Gate decision, approval, test result, or freeze command.

## Human multi-device checklist

1. On PC-A and PC-B, log in as different Team users to the same project.
2. Confirm presence changes on both clients.
3. Make unrelated changes concurrently; both should persist. Edit the same entity concurrently; one client must receive `ENTITY_VERSION_CONFLICT` rather than overwrite the other.
4. Upload a new artifact from one client; confirm the other client receives only a scoped event/catch-up and the immutable metadata is visible.
5. Disconnect PC-B, create comments/tasks on PC-A, reconnect PC-B and verify ordered catch-up.
6. Run the controlled DFMEA failure/retest flow. A later PASS must reference the prior FAIL; Gate/Frozen state must remain server-authoritative.
7. Attempt approval and local freeze only with the authorized teacher role. Confirm the result remains a local freeze and is not described as production release.

Record the computers, server version, network scope, results and failures. Do not mark `REAL_MULTI_DEVICE_LAN` as verified until the checklist passes on at least two independent machines.
