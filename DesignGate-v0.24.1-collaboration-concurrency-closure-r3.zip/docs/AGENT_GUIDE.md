# DesignGate Agent Guide v0.24.1

本文件描述当前 Agent Runtime 与 v0.24.1 协作边界。v0.18 版本的旧指南已保留在 `docs/history/AGENT_GUIDE_v0.18.md`，需要追溯旧行为时可查看。更完整的历史面向用户说明见 `docs/DesignGate-Agent-v0.20.3-使用说明书.docx`。

## v0.24.1 协作运行边界

协作服务的 Agent run 可通过受认证、项目范围限制的 HTTP API 开始和完成。完成权仅属于该运行的发起成员；其他项目成员不能代为提交结果。运行保存相关实体版本，若人工在运行期间修改其中任一实体，完成结果会记录为 `REVALIDATION_REQUIRED`，不能作为当前结论、Gate 通过、本地冻结或生产批准。Agent run 本身不拥有工程实体直接写入、风险接受、审批、Gate 或冻结权限。

本地并发验证范围、命令和未验证项目见 `docs/v0.24/CONCURRENCY_TEST_PLAN.md` 与 `docs/v0.24/CONCURRENCY_VALIDATION.md`。它们不代表真实多设备、容量或生产验证。

## 1. 当前执行方式

Agent 使用有状态的模型驱动执行循环：模型读取目标和当前项目上下文，先用 `update_plan` 建立 3–5 步短计划，再选择一个允许工具执行；工具结果以真实 observation 回传模型，模型根据新结果继续、重规划、提问、发起 Trade-off、提交待审批修改或结束任务。每完成 4 个分析动作会要求重新规划。普通文本不能冒充工具调用或工程 Observation。

工程写入采用人工审批边界。Agent 可以用 `propose_change` 生成原子修改草案，草案绑定项目版本与差异；用户批准后才写入项目。正式 DFMEA 测试、复测、风险接受、Gate 和冻结继续通过 Workflow/UI 的受控业务接口执行。

## 2. 快速使用

1. 新建或选择项目，保存已知 Requirement、设计参数、BOM、材料和证据。
2. 在“模型与连接”配置支持原生 Tool Calls 的兼容模型服务。
3. 可选选择任务书、图纸、BOM 或 CAD 文件；任务开始时确定本轮文件范围。
4. 在“任务 Agent”输入明确目标并启动，例如“检查当前 Rev B 进入下一轮评审还缺什么证据”。
5. 查看计划、工具参数、Observation、DATA GAP 和工程建议；缺关键信息时按 `ask_user` 提示补充。
6. Agent 提交 Proposal 时检查修改前后字段、理由、假设和影响，再决定批准或拒绝。
7. 项目发生修改后继续原任务时，Runtime 会检查 project version；旧草案或旧 CAD reference 不能跨新基线直接复用。
8. 任务完成后根据成功 OBS 记录查看结论依据。工程 Gate、DFMEA 执行记录、风险接受和冻结在对应工作流页面继续完成。

## 3. 当前 Agent 工具

| 工具 | 用途 | 是否修改正式项目 |
| --- | --- | --- |
| `prepare_engineering_assets` | 准备工程记录包目录与校验摘要 | 否 |
| `update_plan` | 建立或修订 3–5 步短计划 | 仅任务记录 |
| `read_project` | 读取当前项目、需求、设计、BOM 与证据目录 | 否 |
| `inspect_requirements` | 检查验证方法和通过判据缺口 | 否 |
| `screen_design` | 对当前或假设参数运行确定性规则筛查 | 否 |
| `compare_options` | 比较 2–4 个假设设计修改 | 否 |
| `negotiate_tradeoff` | A03→A02→A06 一轮受限多角色协商，比较 2–3 个候选 | 否 |
| `check_bom_cost` | 根据已保存真实报价核算成本和缺口 | 否 |
| `search_knowledge` | 搜索结构化材料/工艺知识卡 | 否 |
| `read_knowledge` | 读取知识卡完整条件、来源和限制 | 否 |
| `check_knowledge_reference` | 核对数值是否处于来源记录的参考范围 | 否 |
| `calculate_battery_pack` | 用精确厂商/型号按 Ns/Np 计算标称电池包量，并暴露系统电流资料缺口 | 否 |
| `read_selected_file` | 解析本轮已选择的 brief / design / BOM / CAD 文件 | 否 |
| `list_cad_references` | 列出当前项目/Revision/source 下可用 CAD 引用句柄 | 否 |
| `show_cad_reference` | 用不透明句柄定位当前 CAD 测量对象 | 否 |
| `show_reference` | 定位 BOM、设计字段、文件或来源一致 CAD 面 | 否 |
| `propose_change` | 生成设计、Requirement、BOM 规格或长期意图修改草案 | 用户批准后修改 |
| `ask_user` | 缺少决定性输入时提出一个具体问题并暂停 | 否 |
| `finish_task` | 用 OBS evidence 总结本次任务 | 否 |

工具参数均经过白名单 Schema 校验。Agent 没有 shell、任意路径读取、任意 HTTP、自动接受测试结果、自动关闭 Issue、自动风险接受或自动冻结权限。

## 3.1 v0.21.1 知识边界

`search_knowledge` 可以按 `kind`、`domain`、`manufacturer`、`exact_model` 限定；`read_knowledge` 返回来源、范围、限制、核验状态和工程放行边界。材料 Typical 值、制造服务商 DFM 建议、标准索引和电芯资料都不是自动 PASS。A02 可读取材料/人机/标准索引，A03 可读取材料/工艺/电芯，A05 可读取方法/标准索引/电芯；这些角色均只读，A06 仍无批准、风险接受或冻结绕过权限。

电池计算必须使用已登记的精确制造商和型号。缺制造商或型号返回 `DATA_GAP`；没有 BMS、母排、线束、连接器、保险和热限制时只返回 `THEORETICAL_CELL_LIMIT_ONLY`。这不是电池包测试、运行时间保证、安全认证或工程放行。

## 4. v0.20.3 长任务控制

默认累计 token 硬预算已经关闭，`cumulativeTokenBudgetEnabled=false`、`cumulativeTokenBudget=null`；默认 `maxOutputTokens=null`，应用不再固定发送旧版 1800/2500 输出上限。供应商自身上下文窗口、最大输出、速率限制和账户配额仍然生效。

| 控制 | 默认值 | 含义 |
| --- | ---: | --- |
| `maxToolSteps` | 80 / segment | 当前可恢复运行段的工具步骤上限 |
| `maxModelRequests` | 120 / segment | 当前运行段模型请求上限 |
| `maxNegotiationRounds` | 24 / segment | 当前运行段协商轮数上限 |
| `agentRunDurationMs` | 900000 ms | 当前运行段总时长 |
| `modelRequestTimeoutMs` | 120000 ms | 单次模型请求超时 |
| `reviewPipelineTimeoutMs` | 1800000 ms | 正式评审 pipeline 超时 |
| `maxLengthRecoveryAttempts` | 2 | 文本 length 截断恢复次数 |
| `maxProviderRetries` | 1 | 临时供应商错误重试 |
| 用户累计 token 预算 | 默认关闭 | 仅显式开启并设置正整数时成为硬限制 |

停止原因分开记录，包括 `USER_TOKEN_BUDGET`、`TOOL_STEP_LIMIT`、`MODEL_REQUEST_LIMIT`、`NEGOTIATION_ROUND_LIMIT`、`RUN_DURATION_LIMIT`、`MODEL_REQUEST_TIMEOUT`、`REPEATED_NO_PROGRESS` 和 `USER_CANCELLED`。用户取消或运行段停止后保存检查点；恢复时保留同一 run 的累计用量、事件历史和已批准写入。

## 5. 记忆、状态与引用

工作上下文包含目标、当前计划、近期成功 Observation 摘要和最近完整工具消息对，完整原始事件保存在任务记录中。同一项目最近完成任务的摘要可作为带历史标记的上下文进入后续任务；不同项目不会共享这一记忆。当前没有向量数据库或跨项目自动学习。

CAD reference 会绑定 project、project version、Revision 和 source SHA；几何、Revision 或项目版本变化后旧句柄失效。`finish_task` 引用的 OBS-ID 必须来自当前任务真实成功工具记录。引用存在性可以验证，但自然语言解释仍需要用户和工程评审复核。

## 6. 多角色 Trade-off

`negotiate_tradeoff` 会发起 A03→A02→A06 一轮角色协商，各角色使用隔离的提示和权限受限工具，通常使用同一已配置基础模型。协商比较明确候选、保留分歧和验证建议，不自动修改项目，也不代表首席工程批准。每次协商会产生额外模型请求并计入运行控制。

## 7. 与工程工作流的边界

主 Agent 擅长需求检查、工程筛查、知识检索、CAD reference、方案比较、成本检查、Trade-off 和修改 Proposal。DFMEA 风险定义、版本化 Verification Plan、append-only Test Execution、Retest、Correction、Residual Risk Acceptance、Failure Disposition、Gate 与 Final Design Freeze 由 Workflow/IPC/UI 的正式业务接口管理，并接受当前 Revision、Baseline、Evidence 和权限检查。

因此，Agent 任务完成状态表示分析流程已完成或已形成待人审结论；工程验证、风险关闭和冻结状态以 Workflow 中的正式记录为准。

## 8. 验证状态

本版本本地自动化记录见 `RELEASE_VALIDATION_v0.20.3.md`：`npm test` 270/270，`npm run check` 通过，CAD 17/17、参数适配 5/5、handover 3/3。这些结果验证代码路径和回归约束；真实模型长任务质量、真实企业项目、独立专家评审、生产连接以及目标 Windows/Electron 人工全验收仍保持未验证，详见 `UNVERIFIED_v0.20.3.md`。
