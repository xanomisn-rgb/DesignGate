# Batch 3 — Live model validation status

## Implementation

`eval/v1/live_runner.js` is a live-only wrapper. It checks the three required configuration values before it constructs the current `AgentModelClient` transport or an `AgentRuntime` executor:

- `DESIGNGATE_EVAL_API_KEY`
- `DESIGNGATE_EVAL_BASE_URL`
- `DESIGNGATE_EVAL_MODEL`

When present, the wrapper binds code, tool-registry, knowledge-snapshot and runtime configuration hashes, then runs through the existing AgentRuntime path. It does not accept an injected/mock transport as a live result.

## Current environment result

The checked environment has none of the required live-provider configuration values. No network or provider request was made.

| Field | Result |
| --- | --- |
| Live runner status | `BLOCKED_BY_ENVIRONMENT` |
| Milestone | `LIVE_MODEL_VALIDATION_NOT_RUN` |
| 21 dev × 3 repeat run | Not run |
| Live-model claim | Not made |

The raw check is retained at `artifacts/v0.23/batch3-live-environment-check.log`.

## Subsequent user-authorized provider probe

After this initial environment check, a user supplied provider configuration for a real transport probe. The current `AgentModelClient` produced local isolated-run records: completed runs, a `WAITING_INPUT` run and an interrupted in-progress record were retained under `artifacts/v0.23/live-dev-deepseek-v4-pro/.work/`.

This probe did **not** finish the required 21 × 3 formal sample or produce a complete formal aggregate. It is therefore retained only as partial transport evidence and does not change the milestone: `LIVE_MODEL_VALIDATION_NOT_RUN`. No credentials are stored in the project or referenced in this document.

## Formal provider-backed development run

A subsequent single-instance run completed the frozen 21-case development set three times (63 case executions). Its manifest-bound, hash-chained artifacts are under `artifacts/v0.23/live-dev-deepseek-v4-pro-formal-20260910-r2/`. Raw task outcomes: 15 `COMPLETED`, 8 `FAILED`, 40 `WAITING_INPUT`; deterministic grading: 54 pass, 9 fail. The journal verifies 21 records for each repeat.

This result remains `PENDING_HUMAN_REVIEW`: 0/63 rows have a reviewer identity or timestamp. It is not a quality certification, production claim, engineering approval, or local freeze decision.

## Recovery and integrity boundary

`eval/v1/live_journal.js` now appends each newly settled case immediately, with a canonical SHA-256 hash chain and the immutable run-manifest hash. A later invocation reuses a case only when all of the following are true:

- the journal hash chain is intact;
- the case is terminal (`COMPLETED`, `WAITING_INPUT`, `FAILED`, or `CANCELLED`), not `RUNNING`;
- its project-independent case ID and repeat number match; and
- its complete manifest binding matches the current frozen fixture, code, tool registry, knowledge snapshot, runtime configuration and model identity.

Legacy or unbound rows, partial records, changed bindings and tampered rows remain retained as historical records but are not resumable. A journal-integrity error fails closed. Resumed raw trials still pass through the same deterministic and human-review-pending grading path; a checkpoint cannot create a PASS or release result.

## Regression

- `tests/benchmark_v1.test.js`: 19 passed, including live-only configuration blocking, integrity-checked journaling and manifest-bound resume.
- `npm run check`: passed, including syntax/JSON checks for 188 JavaScript files and 40/40 historical answer-key validation.
- `npm test`: 354 passed, 0 failed, 1 explicitly skipped live-Mosquitto test (355 total).

## Boundary

The live runner being implemented is not evidence of live-model quality. `LIVE_MODEL_DEV_VALIDATED` requires an authorized provider-backed 63-run dev execution, complete bindings and subsequent audit; this package makes no final live-model or production claim.
