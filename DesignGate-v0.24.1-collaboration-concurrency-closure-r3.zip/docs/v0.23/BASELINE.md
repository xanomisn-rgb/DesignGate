# v0.23.0 Batch 0 baseline

## Artifact identity

- Source artifact: `source/DesignGate-v0.22.3-p1-prep-r1.zip`.
- Source SHA-256: `e0086ea022807f7a4bc739ac09067626b36ff421a522ad95fe6a145e4073d16d`.
- Package version: `0.22.3-p1-prep`.
- Target version: `v0.23.0`.
- Identity result: `VERIFIED`; no `ARTIFACT_MISMATCH` was found.
- Git metadata: `GIT_METADATA_UNAVAILABLE` (the delivered source archive contains no Git repository).

## Environment

- Node `v24.20.0`; npm `11.19.0`; Electron `44.2.0`.
- Python `3.13.15`.
- OCP pin: `cadquery-ocp==8.0.1.0.0`; current host Python has no importable `OCP` module.
- `npm install` completed; npm reported eight upstream advisories. No automated dependency upgrade was applied.
- Inventory: 54 test files; 148 JavaScript files under backend/connectors/tools/eval/tests before installation-generated files.

## Fresh commands and results

| Command | Actual result |
|---|---|
| `npm test` | 324 passed, 0 failed, 1 skipped (325 total) |
| `npm run check` | passed; syntax/JSON check reported 167 JavaScript files; legacy eval dataset reported 40/40 |
| `npm run test:cad` | `BLOCKED_BY_ENVIRONMENT`: host Python cannot import OCP |
| `npm run test:adapter` | passed: 5 tests |
| `npm run test:handover` | passed: 3 tests |
| `node --test --experimental-test-coverage tests/*.test.js` | passed; lines 94.82%, branches 75.58%, functions 88.86% |

The fresh coverage result does not meet the v0.23 target (lines >=95%, branches >=85%) and is not substituted with historical coverage claims.

## Safety and isolation record

- The handoff package SHA-256 matched its supplied checksum.
- Benchmark shared inventory and hash manifest were read as CodexSafe metadata. ReviewerOnly material was not searched for or opened.
- Training-case directories contain files explicitly named `gold`, `hidden_issues`, and `expected_runtime_trace`. Their presence was recorded, but their contents were not read, copied, or used.
- No business code, runtime behavior, benchmark fixture, Gold data, or version string was changed in Batch 0.

## Logs

All raw logs are under `artifacts/v0.23/baseline/`, including installation, environment, test, check, CAD, adapter, handover, OCP, and coverage logs.
