# Batch 1 — Runtime authority and checkpoint bridge

## Completed scope

- Added a 22-entry governed capability registry derived from the supplied runtime seed. It records capability identity, authority class, runtime-only caller boundary, dependencies and fail-closed/checkpoint policy. It does not claim that every registered capability has a complete implementation.
- Added a guarded workflow pipeline. Model, specialist, chief, CAD and device output is retained as `UNVERIFIED_PROPOSAL`; it cannot set verification, DFMEA risk, Gate or freeze state.
- Added explicit runtime transition rules. Freeze requires `HUMAN_APPROVAL_REQUIRED` plus a current deterministic Gate status of `ELIGIBLE`; a human cannot directly write Gate status.
- Added project-scoped, SHA-256 canonical-json checked checkpoints and append-only hash-chain runtime traces.
- Bridged the existing `AgentRuntime`: each model tool request is recorded as a proposal and trace entry; mapped existing actions advance only through the guard after successful execution. `finish_task` remains an unverified analysis summary and does not advance Gate eligibility or freeze.

## New runtime files

- `backend/runtime/capability_registry.js`
- `backend/runtime/workflow_pipeline.js`
- `backend/runtime/runtime_state_service.js`
- `backend/runtime/transition_guard.js`
- `backend/runtime/checkpoint_service.js`
- `backend/runtime/runtime_trace_service.js`

## Regression coverage

- `tests/runtime_authority.test.js` covers direct freeze denial, model PASS denial, eligible-Gate freeze prerequisites, revision and governed-binding revalidation, 22-capability registration, project-scoped checkpoint integrity, trace-chain verification and guarded pipeline transitions.
- `tests/agent_runtime.test.js` covers the existing-runtime bridge: a model tool request becomes an unverified proposal, has no authoritative verification/freeze effect, carries a mapped capability when available, advances only to `ANALYSIS_PENDING`, creates a checked checkpoint and produces a valid trace.
- The default `npm test` script now includes the new runtime test file.

## Validation

| Command | Result |
| --- | --- |
| `npm test` | PASS: 334 passed, 0 failed, 1 explicitly skipped live-Mosquitto test |
| `npm run check` | PASS: syntax/JSON and 40/40 answer-key validation |
| `npm run test:adapter` | PASS: 5 Python tests |
| `npm run test:handover` | PASS: 3 Python tests |
| `npm run test:cad` | BLOCKED_BY_ENVIRONMENT: host has Python 3.13 only and no importable `OCP` module |
| targeted runtime coverage | New registry/state/trace/pipeline modules report 100% line coverage; this is targeted coverage, not a product-wide coverage claim |

Raw logs are retained under `artifacts/v0.23/` with the `batch1-` prefix.

## Boundary

This batch adds governance and auditability to the current local runtime. It is not production approval, a completed implementation of all 22 capabilities, proof of real-model performance, or an engineering release.
