# Batch 5 CAD Oracle integration

## Implemented scope

- `tools/cad_oracle.py` performs an exact OCP B-Rep common-volume and minimum-distance calculation for each supplied pair of STEP solids. Results preserve generated `SOLID-n` identifiers, broad-phase status, witness points, overlap volume or minimum clearance, and analysis limitations.
- `tools/brep_analyzer.py` invokes this pair analysis for multi-solid STEP input while deliberately retaining the pre-existing single-solid-only boundary for surface sampling.
- Bounded surface results are normalised as `thickness_oracle` and `undercut_oracle`. They report coverage/refinement or sampled candidate regions and always set `global_mathematical_proof: false`.
- `tools/run_brep_analysis.py` and `CadAnalysisRunner` carry all three Oracle fields to the CAD adapter.
- `CadAdapter` stores a bounded `analysis_summary` with the existing revision-bound evidence and append-only CAD event history. It does not store display mesh data in project state, change the Gate, or turn a CAD result into a verification decision.

## Regression evidence

Commands run on 2026-09-10:

```text
node --test tests/cad_runner.test.js
node --test tests/cad_adapter.test.js tests/cad_workflow_integration.test.js
npm run test:cad
npm test
npm run check
```

The focused CAD suites passed: 2 runner tests, 4 CAD adapter/workflow tests (including one non-mock STEP → OCP → adapter path), and 25 Python CAD tests (3 B-Rep, 13 measurement, 1 serialized STEP fixture, 8 Oracle geometry). `npm test` and `npm run check` completed successfully in this environment; the desktop runner truncated the very large full-test transcript.

The exact pair regression covers separated, touching, overlapping, rotated-box, cylinder-through-wall, and nested-enclosure cases. The adapter regression confirms analysis reaches revision-bound evidence/project state without changing an open Gate, and that a new revision makes the original evidence stale.

## Deliberate boundaries

- Exact claims apply only to pairs of supplied B-Rep solids. Solid indexes are not semantic assembly/BOM identities, and missing components are not inferred.
- Thickness and undercut findings are bounded sample candidates, not global minima, complete demouldability conclusions, tolerance validation, or manufacturing approval.
- CAD observations remain `NEEDS_HUMAN_REVIEW`. Only a separately recorded, evidence-bound human verification can close an observation; neither an Oracle result nor a passing test implies production approval or automatic local freeze.
- This is code/analytic-fixture coverage, not validation on a real industrial CAD assembly, physical sample, or independent manufacturing review.
