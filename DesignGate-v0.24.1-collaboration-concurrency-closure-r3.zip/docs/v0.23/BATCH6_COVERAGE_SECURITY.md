# Batch 6 coverage, security, and negative paths

## Current measured baseline

On 2026-09-10, Node's native coverage mode ran the complete checked-in test command selection:

```text
390 tests total: 389 passed, 0 failed, 1 skipped
lines:    95.27%
branches: 75.77%
functions:89.50%
```

The line target is met. The repository-wide branch target of 85% is **not yet met**, so Batch 6 is in progress and must not be represented as complete.

## Added fail-closed regression paths

- Integration events reject a same-key, changed-payload replay without appending a second event.
- Runtime checkpoints reject tampered payloads, invalid identifiers, and valid-format missing records.
- A corrupted stored evidence manifest cannot become current bound evidence.
- Telemetry canonicalisation rejects non-finite and line-injected signing fields.
- CAD output now rejects negative topology counts.
- CAD runner regression covers missing input, unavailable OCP, non-JSON output, non-zero analyzer exit, timeout, wrong STEP hash, and malformed schema counts.
- Gate v2 no longer accepts an empty execution-reference array as a closure basis. A PASS can close an existing issue only when it carries at least one non-empty `test_ids` or `evaluation_ids` entry, as well as the already required revision, baseline, evidence, and rule binding.
- Gate v2 now compares that closure baseline with the active project baseline. A PASS from the same Revision but an earlier design/risk baseline remains an open issue and holds the Gate.
- Gate v2 validates every closure evidence ID as a non-empty string; a non-empty array containing `null` or other fabricated values cannot close an issue.
- Gate v2 now rejects a closure claim when the supplied current Revision is absent or empty. An empty string cannot be made to look like a current Revision merely because the closure basis contains the same empty string.

The CAD runner isolated coverage is now:

```text
lines: 100.00%
branches: 85.42%
functions: 92.86%
```

## Boundaries

Coverage measures exercised code paths; it does not establish industrial suitability, live hardware/CAD validation, expert review, production approval, or a completed desktop E2E test. No Gold data was read while adding these tests.
