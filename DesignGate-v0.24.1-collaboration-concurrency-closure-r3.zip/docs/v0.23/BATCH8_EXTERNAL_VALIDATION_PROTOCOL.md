# Batch 8 external validation protocol

## Status

This is an external-validation preparation kit. It contains no executed external trial, no reviewer result, and no quality, engineering-release, or production approval claim.

## Independent roles

The code/package custodian, model-run operator, and independent reviewer must be recorded as separate named roles. A reviewer must not author the case answer or modify the evaluated artifact after the run manifest is frozen. Gold and holdout payloads are released only to the independent grading process; the executor receives neither answers nor Gold paths.

## Required frozen bindings

Before a run begins, record the SHA-256 identities for:

- code artifact;
- tool registry;
- knowledge snapshot;
- runtime configuration; and
- model identity/configuration.

Any binding change starts a new run set. A retained, hash-chain-valid historical record remains traceable but cannot be used as a result for the new binding.

## Minimum external run plan

Run at least 200 independently recorded trials across predeclared task categories, fault conditions, and risk classes. Retain every terminal outcome (`COMPLETED`, `WAITING_INPUT`, `FAILED`, or `CANCELLED`), including negative cases. Do not replace failures with later retries; relate later retries explicitly.

Each reviewer row must include reviewer identity, review timestamp, trace/evidence references, and a rationale. Aggregate capability metrics remain `PENDING_HUMAN_REVIEW` until the designated independent reviewer signs the row set.

## Rejection conditions

Reject or repeat the affected run set if any of the following occurs:

- missing or changed frozen binding;
- broken event/journal hash chain;
- executor visibility of Gold/holdout answers;
- absent reviewer identity or timestamp;
- fabricated evidence reference, uncontrolled mutation, or model-only approval claim; or
- unrecorded provider/model configuration.

Results from this protocol cannot grant a Gate pass, local freeze, engineering release, or production approval. Real products, representative CAD/models, hardware, domain-expert review, and applicable organizational approval remain required outside this preparation kit.
