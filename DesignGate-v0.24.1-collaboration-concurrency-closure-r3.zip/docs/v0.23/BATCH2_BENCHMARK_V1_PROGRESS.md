# Batch 2 — Benchmark v1 progress

## Implemented in this pass

- Added the frozen, Codex-safe 21-case development fixture under `eval/v1/fixtures/`; the legacy `eval/cases.json` is not used by the v1 loader.
- Added a semantic canonical fixture hash check and retained the supplied source-byte SHA-256 for provenance. A changed fixture fails closed with `BENCHMARK_FREEZE_HASH_MISMATCH`.
- Added `GoldIsolationGuard`: Agent-side resolution is always denied; dev Gold is opened only by the runner after executor completion. No held-out payload is packaged or exposed.
- Added v1 run manifest binding. Missing benchmark fixture, code, tool-registry, knowledge-snapshot, runtime-config or model identity yields `UNBOUND_EVAL_RESULT`.
- Added deterministic hard-safety grading for required tools, fabricated evidence and model-only PASS/freeze claims.
- Added reproducible fault-injection dispatch and auditable output writers for manifest, cases, tool traces, hard-safety events, aggregate metrics, usage, expert-review export and validation summary.
- Added `eval/v1/agent_executor.js`, which creates an isolated project and invokes the existing `AgentRuntime`; it returns the actual durable run ID and tool trace. It does not use a parallel autonomous runtime.
- Added a structured semantic layer which is deliberately `PENDING_HUMAN_REVIEW`; it cannot override deterministic hard-safety grading or automatically create a pass.
- Added `eval/v1/multiagent/budget_guard.js`: all main/specialist/Chief reservations use one fixed shared token budget, with a durable per-role allocation snapshot and fail-closed overrun.
- Added validated human-review export rows and v1 A/B/C routing manifests. A/B/C requires the same base-model identifier, frozen fixture, knowledge snapshot and fixed shared budget; the manifest explicitly states that same-base-model roles are not independent experts.
- Added `eval/v1/multiagent/runner.js`: it invokes all A/B/C routes through a supplied execution boundary, records each route, and charges only returned integer token usage to one shared fail-closed budget. Missing usage and budget overrun fail closed. Its output is explicitly `PENDING_HUMAN_REVIEW` and preserves the same-base-model limitation.
- Added conservative per-route token preflight. When an explicit reserve is greater than remaining shared budget, the next provider route is blocked before execution; results already within budget remain auditable and an over-budget route is excluded from comparison.

## Validation

- `tests/benchmark_v1.test.js`: 21 passed.
- `npm test`: 360 passed, 0 failed, 1 explicitly skipped live-Mosquitto test.
- `npm run check`: passed, including 40/40 historical answer-key validation.
- Raw logs: `artifacts/v0.23/batch2-*.log`.

## Remaining Batch 2 scope

- Bind the A/B/C runner to a dedicated provider-backed execution campaign and complete independent human review; this is not yet run or claimed.
- A dedicated v1 CLI and complete release/coverage validation after the remaining parts land.

## Boundary

`RUNNER_IMPLEMENTED` is an implementation state only. It is not `DEV_BENCHMARK_VERIFIED`, `LIVE_MODEL_VALIDATED`, a production claim, or evidence that a real industrial workflow has been validated.
