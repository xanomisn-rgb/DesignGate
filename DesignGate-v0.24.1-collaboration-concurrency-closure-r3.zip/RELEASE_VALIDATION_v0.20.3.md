# DesignGate Agent v0.20.3-alpha — Runtime / DFMEA Closure Fix

本版本基于 `DesignGate-Agent-v0.20.2-cross-module-closure-fix.zip` 的独立副本修复。源 ZIP 未修改。

## 1. 验收结论

- 默认累计 token 硬上限：**已取消**。默认 `cumulativeTokenBudgetEnabled=false`、`cumulativeTokenBudget=null`。
- 单次输出固定 1800 / 2500：**已取消**。默认 `maxOutputTokens=null`；仅在用户/模型配置明确给出时发送输出上限。
- 模型/供应商真实上下文、输出及账户额度：**不绕过**，仍由供应商约束。
- 长任务运行控制：工具步数、模型请求数、协商轮数、运行时间、单次请求超时、用户 token 预算、无进展停止均独立计量并独立报告。
- DFMEA：风险定义、验证计划、测试执行记录三层分离；执行记录 append-only 并绑定服务端生成的当前项目/Revision/设计基线/风险基线/验证计划版本。
- 旧 JSON 重传：不能恢复已经因设计变化而失效的旧验证。
- 复测：无关联 PASS、重复 PASS、自引用/循环/错误风险/错误时间关系不能解除旧 FAILED；合格 `retest_of` 才能形成有效关闭关系。
- 残余风险接受：测试 PASS 与风险接受分离；当前策略下 severity >= 9 或 RPN >= 200 需要独立、当前基线适用的本地残余风险接受记录。
- 专业能力异常：受控隔离；某专业输入异常不再抹掉其他已完成能力，但适用且必要的能力异常仍阻断。
- 证据图：计划覆盖、历史追溯、当前有效验证分开； FAILED / PLANNED / STALE / 无效证据不进入当前有效支持路径。
- 完整性：对登记证据重新计算实际文件 SHA-256；仅有时间戳不再等价于“有效”。

## 2. 红灯优先记录

新增 v0.20.3 验收最初在 v0.20.2 行为上运行：14 项中 1 通过、13 失败。典型失败包括缺少版本化验证计划/执行记录业务接口、旧运行预算行为、人体工学异常导致整条评审中断等。修复后扩展为 19 项，19/19 通过。

原始红灯日志由开发环境保留为 `v0203-red-tests.log`；最终 ZIP 内保留可复现测试源码 `tests/professional_v0203.test.js`，不依赖日志才能复现。

## 3. 最终自动化结果

### JavaScript 全量

命令：`npm test`

- tests: 270
- pass: 270
- fail: 0
- skipped: 0

其中 v0.20.3 专项验收 19/19 通过，并已纳入默认 `npm test`。

### 语法与评测数据

命令：`npm run check`

- JavaScript syntax / JSON：108 files PASS
- eval dataset：40 cases
- gold cases：40
- validator：valid=true

### CAD / STEP / B-Rep 辅助测试

命令：`npm run test:cad`

- `test_brep.py`：3/3 PASS
- `test_brep_measurements.py`：13/13 PASS
- `test_step_fixtures.py`：1/1 PASS

测试中出现的 OCC “Incorrect syntax” 输出来自故意输入坏 STEP 的负向测试，该测试按预期 PASS。

### 参数适配

命令：`npm run test:adapter`

- 5/5 PASS

### Handover

命令：`npm run test:handover`

- 3/3 PASS

## 4. 业务闭环接口验证

闭环回归使用项目正式 workflow/orchestrator/runtime/evidence 接口，不通过直接编辑状态文件、删除 finding 或手写内部 hash 获得 PASS。已覆盖：

1. 建立风险定义与版本化验证计划。
2. 通过业务接口追加测试执行记录。
3. 设计输入变化后旧 PASS 失效。
4. 重传旧 DFMEA JSON 后旧 PASS 仍失效。
5. 原 FAILED 后提交无关联 PASS，一次或重复提交均不能解除旧失败。
6. 追加与原失败正确关联、时间更晚、证据有效、判据/结果/审核完整的 `retest_of` 记录，才能关闭对应专业问题并恢复正常 Gate 条件。
7. 高残余风险在测试 PASS 后仍阻断 Gate；追加当前基线适用的独立风险接受记录后才满足本地冻结的该项条件。
8. 修改验证验收判据生成计划 v2，历史测试记录保持不可变，但当前有效性重新计算。
9. 用户取消、段运行超时后保留同一 run 的累计用量和检查点，可继续执行。
10. 证据文件实际内容被篡改后，即使登记/检查时间戳仍存在，也不再进入当前有效支持路径。

## 5. 界面操作结果

- Renderer/UI contract 自动测试：PASS；七个主要页面可渲染，设置页能够展示新的长任务与模型输出配置，DFMEA 操作入口包含验证计划、执行记录、复测关联、更正、风险接受和当前基线信息。
- Desktop IPC / renderer integration 自动测试：PASS，覆盖真实 IPC 业务入口、任务启动/停止/持久化等。
- 原生 Electron 人工点击验收：**NOT_RUN**。当前源码工作副本未安装 `node_modules/electron` 可执行依赖；本轮没有为了制造“人工界面已验收”声明而下载/安装额外 GUI 环境。

因此“界面业务契约和 IPC 路径已自动验证”与“Windows/Electron 人工逐项点击已验证”必须区分；后者仍待目标 Windows 机执行。

## 6. 未执行事项

- 未调用付费模型。
- 未连接生产系统。
- 未执行生产放行或外部平台放行。
- 未运行真实模型长任务多轮质量评测。
- 未进行真实企业项目验证。
- 未进行独立工业设计专家验收。
- 未进行目标 Windows 机器上的 Electron 人工点击/WebGL 全验收。

本版本因此不能宣称“生产级能力已经证明”或“专业工业设计判断力已经由真实工程验证”。
## 7. 文档与交付包刷新

在不修改运行时代码的前提下，对 v0.20.3 交付文档做了一次补齐：README 补入 v0.19、v0.20、v0.20.1、v0.20.2 历史段落；新增 `CHANGELOG.md`；当前 `docs/AGENT_GUIDE.md` 和 `docs/ROADMAP.md` 更新到 v0.20.3，旧版本分别归档到 `docs/history/`；新增 v0.20.3 capability/limitations 文档；Word 使用说明书加入 `docs/DesignGate-Agent-v0.20.3-使用说明书.docx`；`docs/VALIDATION.md` 与 `validation_logs/00_INDEX.md` 增加当前索引，同时保留旧验证原文和原始日志。

文档刷新后重新执行：`npm test` 270/270 PASS、`npm run check` PASS、`npm run test:cad` 17/17 PASS、`npm run test:adapter` 5/5 PASS、`npm run test:handover` 3/3 PASS；新增/活跃 Markdown 相对链接检查 PASS，说明书 DOCX ZIP 结构检查 PASS，并重新渲染 4 页完成版面检查。

