/* Task controls within the existing visual system; no frontend redesign activated. */
const agentPanels=new Map();
NAV.find(([id])=>id==='advisor')[2]='任务 Agent';
PAGE_TEXT.advisor=['任务 Agent','提出目标，让 Agent 调用工具推进任务。'];
const AGENT_STATUS={RUNNING:'执行中',WAITING_INPUT:'等待你补充',WAITING_APPROVAL:'等待你审查变更',COMPLETED:'本次分析完成',FAILED:'执行出错',CANCELLED:'用户已停止 · 可恢复',INTERRUPTED:'执行中断 · 可恢复',PROJECT_CHANGED:'项目已变化，请基于新基线处理',RUN_TIMEOUT:'本段运行超时 · 检查点已保存',MODEL_REQUEST_TIMEOUT:'单次模型请求超时 · 可恢复',TOOL_STEP_LIMIT:'达到本段工具步数上限 · 可继续',MODEL_REQUEST_LIMIT:'达到本段模型请求上限 · 可继续',NEGOTIATION_ROUND_LIMIT:'达到本段协商轮数上限 · 可继续',TOKEN_BUDGET_EXCEEDED:'达到用户启用的累计 token 预算',NO_PROGRESS:'重复无进展已停止',BUDGET_EXCEEDED:'旧版预算停止记录'};
function agentPanelState(id){if(!agentPanels.has(id))agentPanels.set(id,{run:null,runs:[],lastRefresh:0,loading:false});return agentPanels.get(id);}
function viewAgentPanel(ui){
  if(!ui.project)return viewOverview(ui);
  const panel=agentPanelState(ui.project.project_id),r=panel.run;
  const running=r?.status==='RUNNING';
  return surface('工业设计任务 Agent',`<p class="muted">给出目标，Agent 会规划、调用工具、核对结果，再决定下一步。项目文字和所选资料的提取结果会发送至配置的模型。每任务最多20步、累计运行3分钟；可随时停止。</p><form id="agentGoalForm" class="section-gap">${area('goal','本次任务目标','',3,'required maxlength="12000" placeholder="例如：检查当前设计距离工程评审还缺什么，比较两种可维修结构的取舍，并提出待我确认的修改草案。"')}<p class="form-hint">可以先在右侧选择文件。仅选入本次任务的文件可被 Agent 解析。</p><div class="form-footer"><button class="button primary" type="submit" ${running?'disabled':''}>启动任务</button></div></form>${r?`<div class="result-summary section-gap"><div><strong>${esc(AGENT_STATUS[r.status]||r.status)}</strong><p>已执行 ${r.steps} 步 · 模型请求 ${r.rounds} 次 · ${esc(r.revision)} 版</p></div>${running?button('停止任务','agent-stop'):''}</div><p>${esc(r.goal)}</p>${r.error?`<div class="notice error">${esc(r.error)}</div>`:''}<ol>${r.plan.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>${r.question?`<form id="agentAnswerForm" class="section-gap"><p>${esc(r.question)}</p>${area('answer','补充信息','',3,'required maxlength="6000"')}<div class="form-footer"><button class="button primary" type="submit">补充并继续</button></div></form>`:''}${r.status==='WAITING_APPROVAL'?renderPatchCard(r):''}${renderNegotiations(r)}${renderReferences(r)}${['INTERRUPTED','FAILED','CANCELLED'].includes(r.status)?button('从记录继续任务','agent-resume'):''}${r.result?`<div class="section-gap"><h3>任务成果 · 模型综合建议</h3><pre class="report-text">${esc(r.result.summary)}</pre><p class="form-hint">依据：${esc(r.result.evidence_ids.join('、'))}</p><ul>${r.result.limitations.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="form-hint">分析任务完成不代表工程通过。</p></div>`:''}<div class="check-list"><div class="section-head"><h3>工具执行记录</h3>${button('导出任务记录','agent-export','small')}</div>${r.events.map(e=>`<details><summary><span>${esc(e.id)} · ${esc(e.tool)}</span><span>${esc(e.status)}</span></summary><pre class="report-text">${esc(JSON.stringify({arguments:e.arguments,result:e.output,error:e.error},null,2))}</pre></details>`).join('')}</div>`:''}<div class="section-gap"><h3>最近任务</h3>${panel.runs.map(x=>`<button class="action-row" type="button" data-action="agent-open" data-run-id="${esc(x.run_id)}"><span>${esc(AGENT_STATUS[x.status]||x.status)}</span><strong>${esc(x.goal.slice(0,90))}</strong></button>`).join('')||'<p class="muted">暂无历史任务。</p>'}</div>`);
}
views.advisor=viewAgentPanel;
const agentPanelWithExport=views.advisor;
views.advisor=u=>agentPanelWithExport(u)+(u.project?surface('工程资产导出',`<p class="form-hint">导出当前需求、BOM JSON、决策、校验目录与实验性 CAD 参数适配器。不是 PDF/XLSX 全案或工厂签核。</p>${button('导出工程记录包','export-assets','small')}`):'');
async function refreshAgentPanel(projectId,runId){
  const panel=agentPanelState(projectId);if(panel.loading)return;
  panel.loading=true;
  try{panel.runs=await api().agent('list',projectId);const id=runId||panel.run?.run_id||panel.runs[0]?.run_id;if(id)panel.run=await api().agent('get',projectId,id);panel.lastRefresh=Date.now();}
  finally{panel.loading=false;}
}
async function agentCommand(action,input={}){
  const projectId=ui.project?.project_id;if(!projectId)throw Error('请先新建项目');
  const panel=agentPanelState(projectId);
  if(action==='approve'&&input.approved&&ui.dirty)throw Error('请先保存当前表单草稿，再生成基于最新项目的提案；避免覆盖未保存修改。');
  const result=await api().agent(action,projectId,panel.run?.run_id,input);
  if(result.run_id&&result.status!=='CANCELLING')panel.run=result;
  await refreshAgentPanel(projectId,panel.run?.run_id);
  if(action==='approve'&&input.approved){clearDrafts();await refresh();}
  if(action==='approve'&&!input.approved&&input.feedback?.remember)await refresh();
}
