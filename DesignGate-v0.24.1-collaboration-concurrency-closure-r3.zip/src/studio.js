/* Warm Paper overview. Engineering data remains distinct from visual scaffolding. */
function studioIndicator(tone, text) {
  return `<span class="instrument-value"><i class="signal ${tone}" aria-hidden="true"></i>${esc(text)}</span>`;
}
function studioRail(ui) {
  const p=ui.project, open=(p?.findings||[]).filter(f=>f.status!=='RESOLVED');
  const rows=[['需求基线',p?.requirements?.length?'ready':'waiting',p?.requirements?.length?`${p.requirements.length} 项需求`:'未建立'],['工程问题',!p?.last_review?'waiting':open.length?'alert':'ready',p?.last_review?`${open.length} 项待处理`:'待评审'],['验证证据',p?.evidence?.length?'ready':'waiting',p?.evidence?.length?`${p.evidence.length} 份已登记`:'未登记']];
  return `<aside class="rail">${surface('项目状态',`<div class="instrument-header"><span>LOCAL PROJECT</span><span>REV.${esc(p?.design?.active_revision||'—')}</span></div><dl class="facts">${rows.map(([label,tone,value])=>`<div><dt>${label}</dt><dd>${studioIndicator(tone,value)}</dd></div>`).join('')}</dl><p class="form-hint">指示灯表示记录状态，不代表工程认证。</p>`)}${surface('文件资料',`<div class="artifact-list">${[['brief','企业任务书','PDF'],['design','设计图纸','PDF'],['bom','物料清单','XLSX'],['cad','几何模型','STL / STEP']].map(([key,label,ext])=>{
    const pending=ui.files[key+'File'], saved=p?.artifacts?.[key+'File'];
    const name=pending?.name||saved?.name;
    let tag=pending?'待执行解析':saved?.status||'点击选择文件';
    if(!pending&&saved?.pages)tag=`${saved.pages} PAGES PARSED`;
    if(!pending&&saved?.parts!=null)tag=`${saved.parts} PARTS PARSED`;
    if(!pending&&key==='cad'&&saved)tag='已读取 · 详见工程检查';
    return `<div class="artifact-slot ${name?'occupied':''}"><button type="button" class="artifact-main" data-action="pick-file" data-type="${key}" ${!p||ui.busy?'disabled':''}><span class="artifact-format">${ext}</span><strong>${esc(name||label)}</strong><span class="artifact-tag">${esc(tag)}</span></button>${pending?`<button class="icon-button" data-action="remove-file" data-type="${key}" aria-label="移除待解析${label}">${icon('close',16)}</button>`:''}</div>`;
  }).join('')}</div><p class="form-hint">选择文件后执行评审。STEP 尚不支持实体预览；不显示虚假的 MESH READY。</p>`)}</aside>`;
}
function studioBlueprint(p) {
  const g=p.design?.cad_geometry, b=g?.bounding_box;
  const dims=b&&[b.width,b.depth,b.height].every(x=>Number.isFinite(x)&&x>0)?[b.width,b.depth,b.height]:null;
  return `<div class="blueprint"><div class="viewport-toolbar"><span>REV.${esc(p.design?.active_revision||'—')}</span><span>${dims?'ENVELOPE / mm':'VIEWPORT / NO MODEL'}</span></div><div class="blueprint-grid" aria-label="工程视图">${dims?`<svg viewBox="0 0 400 180" role="img" aria-label="模型外包络示意，不是实体模型"><rect x="${200-70*dims[0]/Math.max(...dims)}" y="20" width="${140*dims[0]/Math.max(...dims)}" height="${140*dims[2]/Math.max(...dims)}" fill="none" stroke="currentColor"/><text x="200" y="170" text-anchor="middle">${dims.map(x=>Number(x.toFixed(2))).join(' × ')} mm</text></svg><span class="viewport-caption">外包络比例示意 · 非实体模型</span>`:`<div class="viewport-empty">${icon('cube',30)}<strong>${g?'当前几何尚无可用预览':'等待工程几何资料'}</strong><span>选择模型并执行评审以读取几何信息</span>${button('选择几何文件','pick-file','viewport-button','data-type="cad"')}</div>`}<span class="viewport-axis" aria-hidden="true">Z ↑ &nbsp; X →</span></div></div>`;
}
function studioOverview(ui) {
  const p=ui.project;
  if(!p)return surface('从一个真实的设计问题开始',`<p class="muted">建立项目，逐步连接设计意图、工程参数和验证依据。</p><div class="section-gap">${button('新建设计项目','new-project','primary')}</div>`);
  const d=p.design||{};
  const metrics=[['产品品类',p.product?.category],['基准工艺',d.process],['目标尺寸',d.dimensions],['主要材料',d.material]];
  return `<div class="stage-track">${['需求定义','工程验证','设计冻结'].map((t,i)=>`<div class="stage"><span class="number">0${i+1}</span>${t}</div>${i<2?'<div class="stage-line"></div>':''}`).join('')}</div><section class="surface snapshot"><div class="section-head"><h2>当前方案工程快照</h2><span class="micro">REV.${esc(d.active_revision)}</span></div><div class="snapshot-layout"><div class="snapshot-data">${metrics.map(([label,value])=>`<div><span>${label}</span><strong>${esc(value||'待提供')}</strong></div>`).join('')}<div class="snapshot-actions">${button('编辑项目资料','goto-project','small')}${button('咨询设计顾问','goto-advisor','small subtle')}</div></div>${studioBlueprint(p)}</div></section>${surface('下一步行动',[[1,'建立需求基线','明确用户、场景与通过判据','project'],[2,'补充工程参数','材料、工艺与几何数据','engineering'],[3,'完成评审闭环','用证据记录验证与决策','verification']].map(([n,t,sub,v])=>`<button class="action-row" data-view="${v}"><span class="row-number">0${n}</span><strong>${t}</strong><p>${sub}</p>${icon('arrow',18)}</button>`).join(''))}${surface('评审记录',table(['版本','评审阶段','结果','时间'],ui.history.filter(h=>h.review_id).slice(-5).reverse().map(h=>`<tr><td class="mono">REV.${esc(h.revision)}</td><td>${esc(h.stage)}</td><td>${status(h.decision)}</td><td class="mono">${esc(new Date(h.created_at).toLocaleString('zh-CN'))}</td></tr>`),'尚无评审记录'))}`;
}
viewRail=studioRail;
viewOverview=studioOverview;
views.overview=studioOverview;
