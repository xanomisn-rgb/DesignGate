// Explicit isolated browser preview. Never installed over the Electron IPC bridge.
if(!window.designGateAPI&&location.protocol.startsWith('http')){
 const project={project_id:'DG-PREVIEW',project_name:'新能源电机控制器（界面示例）',version:1,product:{category:'电机控制器壳体',target_users:['整车系统工程师'],environment:['整车安装空间 / 示例']},design:{active_revision:'B.2',material:'铝合金 · 示例资料',process:'压铸',dimensions:null},requirements:[
 {req_id:'RQ-001',text:'项目目标与范围',verification_method:'设计评审',acceptance_criteria:'由项目负责人确认范围与边界'},
 {req_id:'RQ-010',text:'动力性能需求',verification_method:'台架测试',acceptance_criteria:''},
 {req_id:'RQ-013',text:'高压连接器防护等级',verification_method:'试验验证',acceptance_criteria:'以签署的防护规范与试验方案为准'},
 {req_id:'RQ-015',text:'维护与服务性',verification_method:'装拆验证',acceptance_criteria:'记录维护路径和关键工具可达性'},
 {req_id:'RQ-030',text:'尺寸与空间约束',verification_method:'装配检查',acceptance_criteria:''}
 ],bom:[],findings:[],evidence:[],verifications:[],memory:{design_intent:{}},gate:{current_stage:'Gate 2',status:'OPEN'}};
 const unavailable=async()=>{throw Error('浏览器仅预览界面；真实任务、项目保存与评审请在 Electron 桌面端执行。');};
 window.designGateAPI={listProjects:async()=>[structuredClone(project)],getProject:async()=>structuredClone(project),getConfig:async()=>({model:'未连接 / 视觉预览',apiKey:''}),workspace:async(action)=>{if(action==='history')return [];return unavailable();},agent:async(action)=>{if(action==='list')return [];return unavailable();},saveConfig:unavailable,saveProject:unavailable,runPipeline:unavailable,selectProjectFile:unavailable,saveFile:unavailable,healthcheck:unavailable};
 document.addEventListener('DOMContentLoaded',()=>{const note=document.createElement('div');note.className='preview-banner';note.textContent='界面预览 · 合成项目 · 不连接模型、不保存工程数据 · STL 可在浏览器本地查看';document.body.prepend(note);});
}
