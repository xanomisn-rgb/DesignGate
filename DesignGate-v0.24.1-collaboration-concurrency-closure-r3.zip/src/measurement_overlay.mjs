// Display references only: these colours are not manufacturing acceptance criteria.
export function overlayData(g){
 const mesh=g?.display_mesh,m=g?.surface_measurements;
 if(!g?.source_sha256||mesh?.source_sha256!==g.source_sha256||m?.source_sha256!==g.source_sha256)return null;
 if(g.measurement_revision&&m.measurement_revision!==g.measurement_revision)return null;
 if(!Array.isArray(mesh.positions)||mesh.positions.length>270000||mesh.positions.length%9||!mesh.positions.every(Number.isFinite)||!Array.isArray(mesh.face_ids)||mesh.face_ids.length!==mesh.positions.length/9||!Array.isArray(m.samples)||m.samples.length>4096)return null;
 const faces=new Map();
 const coverage=new Map((m.coverage?.face_coverage||[]).filter(x=>Number.isInteger(x?.face_id)).map(x=>[x.face_id,x]));
 for(const id of new Set(mesh.face_ids))if(Number.isInteger(id)){
  const c=coverage.get(id),state=c?.state||(c?.accepted>0?'MEASURED':'UNMEASURED');
  faces.set(id,{id,samples:[],angles:[],chords:[],occluded:0,measurement_state:state,
   unmeasured_reason:state==='UNMEASURED'?(c?.reason||'NOT_SAMPLED'):null});
 }
 for(const s of m.samples||[]){
  if(!s||!Number.isInteger(s.face_id)||!mesh.face_ids.includes(s.face_id)||!Array.isArray(s.point_mm)||s.point_mm.length!==3||!s.point_mm.every(Number.isFinite))continue;
  const f=faces.get(s.face_id)||{id:s.face_id,samples:[],angles:[],chords:[],occluded:0,measurement_state:'MEASURED',unmeasured_reason:null};f.samples.push(s);
  if(!coverage.has(s.face_id)&&f.measurement_state==='UNMEASURED'){f.measurement_state='PARTIALLY_MEASURED';f.unmeasured_reason=null;}
  if(Number.isFinite(s.signed_draft_deg)&&Math.abs(s.signed_draft_deg)<89.99)f.angles.push(Math.abs(s.signed_draft_deg));
  if(Number.isFinite(s.normal_chord_mm))f.chords.push(s.normal_chord_mm);
  if(s.visibility_plus==='OCCLUDED'&&s.visibility_minus==='OCCLUDED')f.occluded++;
  faces.set(s.face_id,f);
 }
 const threshold=m.applicable_threshold;
 for(const f of faces.values()){
  f.minimum=f.angles.length?Math.min(...f.angles):null;
  f.raw_range={absolute_signed_draft_deg:f.angles.length?[Math.min(...f.angles),Math.max(...f.angles)]:null,
   normal_chord_mm:f.chords.length?[Math.min(...f.chords),Math.max(...f.chords)]:null};
  if(f.measurement_state==='UNMEASURED'){
   f.engineering_status='UNMEASURED';f.colour=[.72,.20,.52];
  }else if(threshold?.metric==='absolute_signed_draft_deg'&&Number.isFinite(threshold.minimum)&&threshold.authority==='REVIEWED'){
   f.engineering_status=f.minimum===null?'NOT_EVALUATED':f.minimum>=threshold.minimum?'MEETS_APPLICABLE_THRESHOLD':'BELOW_APPLICABLE_THRESHOLD';
   f.colour=f.engineering_status==='MEETS_APPLICABLE_THRESHOLD'?[.18,.58,.35]:f.engineering_status==='BELOW_APPLICABLE_THRESHOLD'?[.86,.18,.12]:[.48,.55,.60];
  }else{
   f.engineering_status='NOT_EVALUATED';f.colour=[.20,.52,.70];
  }
 }
 const colours=new Float32Array(mesh.positions.length);
 mesh.face_ids.forEach((id,i)=>{const c=faces.get(id)?.colour||[.48,.55,.60];for(let j=0;j<3;j++)colours.set(c,i*9+j*3);});
 return {faces,colours,source_sha256:g.source_sha256,measurement_revision:m.measurement_revision||g.measurement_revision||null,
  pull_direction:m.pull_direction,threshold:threshold||null,scope:'FACE_SAMPLED_RAW_VALUES_NOT_ENGINEERING_PASS'};
}
export function faceReference(g,hash,id,revision=null){
 const overlay=overlayData(g);return overlay?.source_sha256===hash&&(!revision||revision===overlay.measurement_revision)&&Number.isInteger(id)&&overlay.faces.get(id)?.measurement_state!=='UNMEASURED'?overlay.faces.get(id)||null:null;
}
export function faceDisplayLabel(face){
 if(face?.measurement_state==='UNMEASURED')return `面 ${face.id} · UNMEASURED · ${face.unmeasured_reason||'NOT_SAMPLED'}`;
 const value=Number.isFinite(face?.minimum)?`${face.minimum.toFixed(2)}°`:'无有效角度样点';
 return `面 ${face?.id} · ${value} · ${face?.engineering_status||'NOT_EVALUATED'} · 双向遮挡 ${face?.occluded||0} 样点`;
}
