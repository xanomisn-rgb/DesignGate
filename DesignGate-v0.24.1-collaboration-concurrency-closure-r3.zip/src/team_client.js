(function exposeTeamClient(root, factory) {
  const TeamClient = factory();
  if (typeof module === 'object' && module.exports) module.exports = TeamClient;
  if (root) root.TeamClient = TeamClient;
})(typeof globalThis === 'undefined' ? null : globalThis, function createTeamClient() {
  class TeamClient {
    constructor({ baseUrl, fetchImpl, eventTransport = null } = {}) {
      this.baseUrl = String(baseUrl || '').replace(/\/$/, '');
      this.fetchImpl = fetchImpl || globalThis.fetch;
      this.sessionToken = null;
      this.user = null;
      this.eventTransport = eventTransport;
      if (!this.baseUrl) throw new Error('TEAM_SERVER_URL_REQUIRED');
      if (typeof this.fetchImpl !== 'function') throw new Error('TEAM_FETCH_UNAVAILABLE');
    }

    async request(path, { method = 'GET', body, authenticated = true } = {}) {
      const headers = { accept: 'application/json' };
      if (body !== undefined) headers['content-type'] = 'application/json';
      if (authenticated) {
        if (!this.sessionToken) throw new Error('TEAM_SESSION_REQUIRED');
        headers.authorization = `Bearer ${this.sessionToken}`;
      }
      const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      const payload = response.status === 204 ? {} : await response.json();
      if (!response.ok) {
        const error = new Error(payload.code || `TEAM_HTTP_${response.status}`);
        error.code = payload.code || `TEAM_HTTP_${response.status}`;
        error.status = response.status;
        error.details = payload;
        throw error;
      }
      return payload;
    }

    async login(credentials) {
      const session = await this.request('/api/auth/login', { method: 'POST', body: credentials, authenticated: false });
      if (!session.token || !session.user) throw new Error('TEAM_SESSION_INVALID');
      this.sessionToken = session.token;
      this.user = session.user;
      return this.user;
    }

    async logout() {
      if (this.sessionToken) await this.request('/api/auth/logout', { method: 'POST' });
      this.sessionToken = null;
      this.user = null;
    }

    async listProjects() {
      return (await this.request('/api/projects')).projects || [];
    }

    async getProject(projectId) {
      return (await this.request(`/api/projects/${encodeURIComponent(projectId)}`)).project;
    }

    async applyCommand(projectId, command) {
      return this.request(`/api/projects/${encodeURIComponent(projectId)}/commands`, {
        method: 'POST',
        body: command
      });
    }

    async uploadArtifact(projectId, { revision_id, artifact_type, file, filename } = {}) {
      if (!this.sessionToken) throw new Error('TEAM_SESSION_REQUIRED');
      if (!(file instanceof Blob) || typeof filename !== 'string' || !filename) throw new Error('TEAM_ARTIFACT_FILE_REQUIRED');
      const form = new FormData();
      form.append('revision_id', String(revision_id || ''));
      form.append('artifact_type', String(artifact_type || ''));
      form.append('file', file, filename);
      const response = await this.fetchImpl(`${this.baseUrl}/api/projects/${encodeURIComponent(projectId)}/artifacts`, {
        method: 'POST', headers: { accept: 'application/json', authorization: `Bearer ${this.sessionToken}` }, body: form
      });
      const payload = await response.json();
      if (!response.ok) {
        const error = new Error(payload.code || `TEAM_HTTP_${response.status}`);
        error.code = payload.code || `TEAM_HTTP_${response.status}`;
        error.status = response.status;
        error.details = payload;
        throw error;
      }
      return payload.artifact;
    }

    async listMembers(projectId) {
      return (await this.request(`/api/projects/${encodeURIComponent(projectId)}/members`)).members || [];
    }

    async heartbeat(projectId, status = 'ONLINE') {
      return (await this.request(`/api/projects/${encodeURIComponent(projectId)}/presence`, { method: 'POST', body: { status } })).presence;
    }

    async listPresence(projectId) {
      return (await this.request(`/api/projects/${encodeURIComponent(projectId)}/presence`)).presence || [];
    }

    subscribeEvents(projectId, onEvent) {
      if (!this.sessionToken) throw new Error('TEAM_SESSION_REQUIRED');
      if (!this.eventTransport?.subscribe || !this.eventTransport?.unsubscribe) throw new Error('TEAM_EVENT_TRANSPORT_UNAVAILABLE');
      const subscriptionId = this.eventTransport.subscribe({ baseUrl: this.baseUrl, projectId, token: this.sessionToken }, onEvent);
      return () => this.eventTransport.unsubscribe(subscriptionId);
    }
  }

  return TeamClient;
});
