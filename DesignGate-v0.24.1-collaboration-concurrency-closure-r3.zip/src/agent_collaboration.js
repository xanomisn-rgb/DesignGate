/* Structured project collaboration, using the existing visual system. */
function renderPatchCard(r){
 const d=r.draft;
 return `<section class="notice patch-card"><h3>${esc(d.proposal.title)}</h3><p>${esc(d.proposal.reason)}</p><p>假设：${esc(d.proposal.assumptions.join('；')||'未填写')}</p><div class="table-wrap"><table><thead><tr><th>对象 / 字段</th><th>原值</th><th>提议值</th></tr></thead><tbody>${(d.diff||[]).map(x=>`<tr><td>${esc([x.entity,x.id,x.field].filter(Boolean).join(' / '))}</td><td><pre>${esc(JSON.stringify(x.old_value))}</pre></td><td><pre>${esc(JSON.stringify(x.new_value))}</pre></td></tr>`).join('')}</tbody></table></div><p>合并至 Revision ${esc(r.revision)}，基线版本 ${d.base_version}。BOM 规格变更会作废原报价；旧验证绑定清除并立即本地复筛，仍需正式评审。</p><label>驳回理由（可选）<textarea id="rejectionReason" maxlength="2000" rows="2"></textarea></label><label><input type="checkbox" id="rememberRejection">明确记为本项目长期约束（非通用工程规则）</label><div class="actions">${button('审查后合并提案','agent-approve','primary')}${button('拒绝 / 保留原状','agent-reject')}</div></section>`;
}
function renderNegotiations(r){
 return r.events.filter(e=>e.tool==='negotiate_tradeoff').map(e=>`<section class="surface section-gap"><div class="surface-pad"><h3>工程取舍协商 · ${esc(e.status)}</h3><p>${esc(e.arguments?.topic||'')}</p><p class="form-hint">三个角色使用同一配置模型分别调用；立场与推荐均待验证。</p>${(e.output?.transcript||e.partial_transcript||[]).map(x=>`<article class="decision-item"><h4>${esc(x.role)} · ${esc(x.label)}</h4><p>${esc(x.position)}</p><p>回应：${esc(x.response_to_previous)}</p><p>倾向：${esc(x.preferred_option)}</p><p>风险：${esc(x.risks.join('；'))}</p><p>保留问题：${esc(x.unresolved.join('；'))}</p><p class="form-hint">依据：${esc(x.evidence_ids.join('、'))}</p></article>`).join('')}${e.error?`<p>${esc(e.error)}</p>`:''}</div></section>`).join('');
}
function renderReferences(r){
 return `<div class="actions section-gap">${r.events.map((e,i)=>e.status==='SUCCEEDED'&&e.tool==='show_reference'?button('定位 '+esc(e.output.reference.id),'focus-reference','small',`data-event-index="${i}"`):'').join('')}</div>`;
}
function focusAgentReference(index){
 const r=agentPanelState(ui.project.project_id).run?.events[index]?.output?.reference;
 if(!r||r.project_id!==ui.project.project_id){toast('引用不属于当前项目');return;}
 if(r.version!==ui.project.version){toast('引用来自旧项目版本，请重新定位');return;}
 capture();ui.focusReference=r;
 if(r.kind==='bom'){ui.view='project';ui.projectTab='bom';}
 if(r.kind==='design')ui.view='engineering';
 if(r.kind==='cad_face')ui.view='overview';
 render();highlightAgentReference(true);
}
function highlightAgentReference(scroll=false){
 const r=ui.focusReference;if(!r||r.project_id!==ui.project?.project_id||r.version!==ui.project.version)return;
 let el;
 if(r.kind==='cad_face'){document.dispatchEvent(new CustomEvent('designgate:focus-face',{detail:{source_sha256:r.source_sha256,face_id:Number(r.id)}}));return;}
 if(r.kind==='bom')el=[...document.querySelectorAll('[data-part-id]')].find(e=>e.dataset.partId===r.id);
 if(r.kind==='design')el=[...document.querySelectorAll('#engineeringForm [name]')].find(e=>e.name===r.id);
 if(r.kind==='file')el=[...document.querySelectorAll('[data-action="pick-file"]')].find(e=>e.dataset.type+'File'===r.id)?.closest('.file-row');
 if(el){el.classList.add('agent-reference-focus');if(scroll){el.scrollIntoView({block:'center',behavior:'auto'});if(el.focus)el.focus({preventScroll:true});}}
 else if(scroll)toast('当前页面没有对应字段或文件插槽；引用只作位置提示。');
}
function renderHealth(ui){
 const labels={HTTP_REACHABLE:'端点可达 · 业务未验证',MOCK_READY:'模拟模式 · 无网络检测',CONTRACT_PENDING:'契约待配置',CONFIG_ERROR:'配置错误',AUTH_REQUIRED:'需要鉴权',UNAVAILABLE:'不可达'};
 const results=ui.health?'<p>'+esc(ui.health.checked_at)+'</p>'+ui.health.results.map(r=>`<p><span class="health-dot ${r.status==='HTTP_REACHABLE'?'ok':r.status==='UNAVAILABLE'||r.status==='CONFIG_ERROR'?'bad':'pending'}" aria-hidden="true"></span><strong>${esc(r.label)}</strong> · ${esc(labels[r.status]||r.status)}<br><span class="muted">${esc(r.detail)}</span></p>`).join(''):'<p class="form-hint">尚未检测</p>';
 return surface('生态连接自检',`<p class="muted">只请求运行环境明确配置的健康 URL，不发送项目数据或执行归档。端点可达不等于业务集成完成。</p>${button('检查生态系统连接','healthcheck','',ui.busy?'disabled':'')}<div role="status" aria-live="polite">${results}</div>`);
}
