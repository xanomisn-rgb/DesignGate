import * as THREE from './vendor/three.module.js';
import {overlayData,faceDisplayLabel} from './measurement_overlay.mjs';
let dispose=()=>{}, localMesh=null, lastGeometry=null, projectKey=null;
function readSTL(buffer){
 const view=new DataView(buffer), out=[];
 if(buffer.byteLength>=84&&84+50*view.getUint32(80,true)===buffer.byteLength){
  const count=view.getUint32(80,true);if(count>100000)throw Error('预览最多支持 100000 面片');
  for(let i=0;i<count;i++)for(let j=0;j<9;j++)out.push(view.getFloat32(84+i*50+12+j*4,true));
 }else{
  const text=new TextDecoder('utf-8',{fatal:true}).decode(buffer),pattern=/\bvertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)/g;
  for(const m of text.matchAll(pattern)){out.push(Number(m[1]),Number(m[2]),Number(m[3]));if(out.length>900000)throw Error('预览面片过多');}
 }
 if(!out.length||out.length%9||out.some(n=>!Number.isFinite(n)))throw Error('STL 坐标无效或面片不完整');
 return new Float32Array(out);
}
function mount(g){
 dispose(); dispose=()=>{};const host=document.getElementById('geometryViewport');if(!host)return;
 const status=document.getElementById('meshStatus');let renderer;
 const dark=!!host.closest('.dark');host.dataset.modelState='empty';
 const overlay=overlayData(g),panel=document.getElementById('faceMeasurements');
 if(panel){panel.replaceChildren();for(const f of overlay?.faces.values()||[]){const b=document.createElement('button');b.type='button';b.dataset.faceId=String(f.id);b.className='button small';b.textContent=faceDisplayLabel(f);b.disabled=f.measurement_state==='UNMEASURED'||!f.samples.length;b.onclick=()=>document.dispatchEvent(new CustomEvent('designgate:focus-face',{detail:{source_sha256:g.source_sha256,face_id:f.id}}));panel.appendChild(b);}}
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});}catch{status.textContent='当前环境无法建立 WebGL 视口；没有执行几何预览。';for(const b of panel?.querySelectorAll('button')||[])b.disabled=true;document.getElementById('meshMode').disabled=true;return;}
 document.getElementById('meshMode').disabled=false;
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor(dark?0x1c2c38:0xe9eff4);host.appendChild(renderer.domElement);
 const scene=new THREE.Scene(), camera=new THREE.PerspectiveCamera(38,1,.01,1000),group=new THREE.Group();scene.add(group);
 scene.add(new THREE.HemisphereLight(0xd8edff,0x344654,3));const lamp=new THREE.DirectionalLight(0xffffff,4);lamp.position.set(3,5,4);scene.add(lamp);
 const grid=new THREE.GridHelper(5,20,dark?0x54748a:0xaabcca,dark?0x294250:0xd0dce5);grid.position.y=-1.25;scene.add(grid);
 let mesh,geometry,material,raf=0,drag=null,targetX=.15,targetY=-.5,zoom=4.8,downPoint=null;
 let centre=new THREE.Vector3(),scale=1,baseStatus='';const aim=new THREE.Vector3(),targetAim=new THREE.Vector3(),arrows=[],selection=new THREE.Group();group.add(selection);const raycaster=new THREE.Raycaster();
 const positions=g?.display_mesh?.positions?new Float32Array(g.display_mesh.positions):localMesh;
 if(positions){
  host.dataset.modelState='loaded';
  geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.computeVertexNormals();geometry.computeBoundingBox();
  const size=geometry.boundingBox.getSize(new THREE.Vector3()),extent=Math.max(size.x,size.y,size.z);
  if(!Number.isFinite(extent)||extent<=0){status.textContent='模型尺寸无效';renderer.dispose();return;}
  geometry.center();geometry.scale(2/extent,2/extent,2/extent);
  material=new THREE.MeshStandardMaterial({color:0xbdc9d0,metalness:.65,roughness:.32,side:THREE.DoubleSide});mesh=new THREE.Mesh(geometry,material);group.add(mesh);
  status.textContent=g?.display_mesh?`STEP 实体三角化 · ${positions.length/9} 面片 · 来源 ${g.source_sha256?.slice(0,12)} · 预览非工程放行`:`STL 本地预览 · ${positions.length/9} 面片 · 单位未确认 · 尚未登记为项目证据`;
   baseStatus=status.textContent;
 } else status.textContent='等待模型 / 本地预览 STL，或在桌面端选择 STEP 后执行工程评审。';
 camera.position.set(0,.3,zoom);camera.lookAt(0,0,0);
 const resize=()=>{if(!host.isConnected)return;renderer.setSize(host.clientWidth,host.clientHeight);camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();};
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 const down=e=>{downPoint=[e.clientX,e.clientY];drag=[e.clientX,e.clientY];host.setPointerCapture(e.pointerId);};
 const move=e=>{if(!drag)return;targetY+=(e.clientX-drag[0])*.007;targetX+=(e.clientY-drag[1])*.007;drag=[e.clientX,e.clientY];};
 const up=e=>{drag=null;if(mesh&&overlay&&downPoint&&Math.hypot(e.clientX-downPoint[0],e.clientY-downPoint[1])<4){const b=host.getBoundingClientRect();raycaster.setFromCamera(new THREE.Vector2((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1),camera);const hit=raycaster.intersectObject(mesh)[0];if(hit)focus({source_sha256:g.source_sha256,face_id:g.display_mesh.face_ids[hit.faceIndex]});}downPoint=null;};const wheel=e=>{e.preventDefault();zoom=Math.min(12,Math.max(2,zoom+e.deltaY*.005));};
 host.addEventListener('pointerdown',down);host.addEventListener('pointermove',move);host.addEventListener('pointerup',up);host.addEventListener('pointercancel',up);host.addEventListener('wheel',wheel,{passive:false});
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function frame(){if(!host.isConnected)return;const rate=reduced?1:.16;group.rotation.x+=(targetX-group.rotation.x)*rate;group.rotation.y+=(targetY-group.rotation.y)*rate;camera.position.z+=(zoom-camera.position.z)*rate;aim.lerp(targetAim,rate);camera.lookAt(aim);renderer.render(scene,camera);raf=requestAnimationFrame(frame);}frame();
 function setMode(v){if(!material)return;material.wireframe=v==='wire';material.vertexColors=v==='heat'&&!!overlay;material.color.setHex(material.vertexColors?0xffffff:0xbdc9d0);material.needsUpdate=true;status.textContent=baseStatus+(v==='heat'?' · 蓝色为有样点但未按阈值判定；紫色为 UNMEASURED；仅显示原始测量覆盖，不构成工程放行':'');}
 document.getElementById('meshMode').onchange=e=>setMode(e.target.value);
 function clearArrows(){for(const a of arrows){selection.remove(a);a.line.geometry.dispose();a.line.material.dispose();a.cone.geometry.dispose();a.cone.material.dispose();}arrows.length=0;}
 function focus(d){if(!overlay||d.source_sha256!==overlay.source_sha256)return;const f=overlay.faces.get(Number(d.face_id));if(!f||f.measurement_state==='UNMEASURED'||!f.samples.length)return;clearArrows();targetX=0;targetY=0;targetAim.copy(new THREE.Vector3(...f.samples[0].point_mm).sub(centre).multiplyScalar(scale));zoom=3;
 const direction=overlay.pull_direction;if(Array.isArray(direction)&&direction.length===3&&direction.every(Number.isFinite)&&Math.hypot(...direction)>0){for(const s of f.samples.filter(s=>s.visibility_plus==='OCCLUDED'&&s.visibility_minus==='OCCLUDED').slice(0,8))for(const sign of [-1,1]){const a=new THREE.ArrowHelper(new THREE.Vector3(...direction).normalize().multiplyScalar(sign),new THREE.Vector3(...s.point_mm).sub(centre).multiplyScalar(scale),.25,0xc83930,.08,.04);selection.add(a);arrows.push(a);}}
 const attr=geometry.getAttribute('color');attr.array.set(overlay.colours);g.display_mesh.face_ids.forEach((id,i)=>{if(id===f.id)for(let j=0;j<3;j++)attr.array.set([.95,.95,.95],i*9+j*3);});attr.needsUpdate=true;setMode('heat');document.getElementById('meshMode').value='heat';status.textContent+=' · 已聚焦面 '+f.id+'；白色为选中面，箭头仅为双向遮挡样点方向';for(const b of panel?.querySelectorAll('button')||[])b.classList.toggle('is-selected',Number(b.dataset.faceId)===f.id);document.dispatchEvent(new CustomEvent('designgate:face-selected',{detail:{source_sha256:g.source_sha256,face_id:f.id}}));}
 const onFocus=e=>focus(e.detail||{});document.addEventListener('designgate:focus-face',onFocus);
 document.getElementById('meshReset').onclick=()=>{targetX=.15;targetY=-.5;zoom=4.8;targetAim.set(0,0,0);clearArrows();};
 document.getElementById('meshPreviewFile').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{if(f.size>50*1024*1024)throw Error('文件超过 50 MB');localMesh=readSTL(await f.arrayBuffer());mount(null);}catch(error){status.textContent=error.message;}};
 dispose=()=>{host.removeEventListener('pointerdown',down);host.removeEventListener('pointermove',move);host.removeEventListener('pointerup',up);host.removeEventListener('pointercancel',up);host.removeEventListener('wheel',wheel);document.removeEventListener('designgate:focus-face',onFocus);clearArrows();cancelAnimationFrame(raf);observer.disconnect();geometry?.dispose();material?.dispose();grid.geometry.dispose();grid.material.dispose();renderer.dispose();renderer.forceContextLoss();host.replaceChildren();};
}
document.addEventListener('designgate:render',e=>{if(projectKey!==e.detail.projectId){localMesh=null;projectKey=e.detail.projectId;}lastGeometry=e.detail.geometry;mount(lastGeometry);});
mount(lastGeometry);
