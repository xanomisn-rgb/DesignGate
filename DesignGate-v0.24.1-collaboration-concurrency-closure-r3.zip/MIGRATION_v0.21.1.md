# v0.21.1 migration

## What changes on load

- Existing `knowledge/curated` data is retained unchanged.
- New data is isolated under `knowledge/expansion/` and is loaded by `KnowledgeService` only when the files are present.
- Existing curated IDs take precedence if an expansion upsert repeats an ID. This preserves old property units, conditions and executable-rule bindings while still adding the newly supplied source registry and all non-duplicate records.
- Standards are represented as `standard_index`; quarantine is read-only `quarantine`; neither is added to `executable_rules.json`.
- The review `basis_hash` now includes the governed knowledge fingerprint and release label. An old review cannot satisfy the new fingerprint at local freeze; no history, Evidence, DFMEA execution record, approval, or finding is deleted.

## Compatibility

- Projects without the expansion folder continue to load with the curated baseline.
- Existing `search_knowledge`, `read_knowledge`, and `check_knowledge_reference` calls remain valid. New filter fields are optional.
- Only `calculate_battery_pack` is new, and it is read-only.
- Legacy material archives remain legacy/unreviewed; no legacy value is promoted during migration.

## Operator action

Re-run the required review for the current revision after installing v0.21.1. Confirm project applicability, source scope, acceptance criteria, and evidence separately; do not treat migration as verification or production release.
