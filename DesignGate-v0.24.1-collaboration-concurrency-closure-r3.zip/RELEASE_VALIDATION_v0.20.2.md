# v0.20.2 Cross-module Closure Fix

| Issue | Root cause | Change | Regression |
|---|---|---|---|
| Invalid date / unknown requirement could verify | Test and link validation was incomplete | ISO-parsable completion time and existing requirement checks | PASS |
| Design edits left DFMEA tests current | DFMEA risk baseline omitted design/requirements | Conservative `dfmea_design_hash` stales non-failed tests on design/requirement changes | PASS |
| New execution altered risk baseline | Test IDs were included in definition fingerprint | Execution records are not part of the risk-definition fingerprint | PASS |
| Professional issue could not close | Passing check had no matching issue ID | Stable `PROF-*-INCOMPLETE` check/issue relation | PASS |
| Registered file appeared validated | Graph assumed integrity state | Graph reports unverified registration unless an integrity timestamp exists | PASS |
| Optional form enabled empty DFMEA | Default JSON was `{}` | Empty UI field preserves not-enabled semantics | PASS |

State boundary: risk definition/controls and its baseline are distinct from immutable execution records. A PASS test needs current revision/baseline, valid evidence, actual result, criterion, reviewer and valid time. A failed test remains blocking until a later, linked retest validates it; production approval is never implied.

Migration: existing projects retain tests and evidence. On the next review, `dfmea_design_hash` is added. Where a relevant design/requirement baseline changed, non-failed test records become `STALE`; failed history is retained. No historical record is deleted.

Validation: targeted closure tests plus the full local suite and `npm run check` were run. Native Electron interaction is NOT_RUN because the source ZIP lacks a local Electron executable. No paid model, production integration, external release, real-project validation, or expert review was run.
