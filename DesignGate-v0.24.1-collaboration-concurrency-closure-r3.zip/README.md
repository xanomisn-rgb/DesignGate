# DesignGate v0.24.1 — Collaboration Closure / Local Concurrency Validation

The current package version is `0.24.1`. It retains the collaboration core and adds a governed localhost concurrency harness: authenticated REST races, external-process clients, WebSocket fan-out under concurrent writes, C1/C2/C3 bounded load profiles, and a short multi-wave soak smoke. Agent-run start/complete is now an authenticated, project-scoped API; only its requester can complete it, and a relevant engineering change produces `REVALIDATION_REQUIRED`.

Run `npm run test:concurrency`, `npm run test:concurrency:load`, or `npm run test:concurrency:soak` for their respective local scopes. Raw reports are written to `artifacts/concurrency/`; see [the test plan](docs/v0.24/CONCURRENCY_TEST_PLAN.md) and [actual validation record](docs/v0.24/CONCURRENCY_VALIDATION.md). These are bounded localhost checks, not real multi-device validation, a capacity certification, a production release, engineering approval, or external validation.

The v0.23 continuation checkpoint text follows as historical context.

# DesignGate Agent 0.21.1 — Governed Knowledge Integration

v0.21.1 integrates the verified knowledge-expansion package through `KnowledgeService`, role-scoped Agent reads, review baselines and a deterministic battery-pack calculator. Materials remain source-conditioned reference, manufacturing-service guidance remains advisory, standards remain indexes, and quarantine remains unavailable as current evidence. No knowledge record is promoted to a hard Gate or engineering-release claim by this update.

Start with [START_HERE_v0.21.1.md](START_HERE_v0.21.1.md), read [MIGRATION_v0.21.1.md](MIGRATION_v0.21.1.md), and see actual commands/results in [RELEASE_VALIDATION_v0.21.1.md](RELEASE_VALIDATION_v0.21.1.md). The prior v0.20.3 material follows as historical context.

# DesignGate Agent 0.20.3-alpha

Runtime / DFMEA Closure Fix。默认取消项目自身 180000 累计 token 硬上限和固定 1800/2500 单次输出上限；将长任务停止原因拆分为工具步数、模型请求、协商轮数、运行超时、模型请求超时、用户预算和无进展；DFMEA 改为风险定义、版本化验证计划与 append-only 执行记录，并补齐复测、残余风险接受、证据完整性和普通用户操作入口。

**当前使用说明：[START_HERE_v0.20.3.md](START_HERE_v0.20.3.md)**；**最终本地验证：[RELEASE_VALIDATION_v0.20.3.md](RELEASE_VALIDATION_v0.20.3.md)**；**限制：[LIMITS_v0.20.3.md](LIMITS_v0.20.3.md)**；**迁移：[MIGRATION_v0.20.3.md](MIGRATION_v0.20.3.md)**。

**完整说明书（Word，含核心优势与竞争力）：[docs/DesignGate-Agent-v0.20.3-使用说明书.docx](docs/DesignGate-Agent-v0.20.3-使用说明书.docx)**；**版本历史：[CHANGELOG.md](CHANGELOG.md)**；**当前 Agent 指南：[docs/AGENT_GUIDE.md](docs/AGENT_GUIDE.md)**。

自动化最终结果：`npm test` 270/270；`npm run check` 通过；CAD 17/17、参数适配 5/5、handover 3/3。真实模型长任务、生产系统、真实项目、独立专家及目标 Windows Electron 人工点击仍未验证。

## v0.20.2 — Cross-module Closure Fix（历史）

补强跨模块 DFMEA 关闭关系：验证日期与 Requirement 链接校验更严格；设计/需求变化会使相关非失败测试进入 STALE；风险定义指纹与执行记录进一步解耦；专业能力 Issue 使用稳定 ID 形成可关闭关系；Evidence Graph 不再把“已登记文件”直接视为已验证。迁移保留旧测试和证据，不删除 FAILED 历史。详细记录见 [RELEASE_VALIDATION_v0.20.2.md](RELEASE_VALIDATION_v0.20.2.md)。

## v0.20.1 — DFMEA Closure Fix（历史）

修复 planned/unknown 测试被错误视为 verified、空 DFMEA 被评估、reopened risk 只报告不阻断、Revision 继承测试结论、Requirement 关联丢失、规则 ID 被误当 Evidence 等问题；风险定义被纳入基线，非当前测试进入 STALE。迁移说明见 [MIGRATION_v0.20.1.md](MIGRATION_v0.20.1.md)，验证记录见 [RELEASE_VALIDATION_v0.20.1.md](RELEASE_VALIDATION_v0.20.1.md)。

## v0.20.0 — Professional Capability Foundation（历史）

建立统一 Professional Capability Contract，并加入人体工学静态腕力矩筛查、CMF 相容性矩阵、DFMEA 风险引擎和 Evidence Graph。该版本明确把 unavailable solver、缺失证据和未审核专业结论保持为可见的未验证状态。真实模型 A/B、独立专家复核和真实项目验证当时仍未执行。详见 [START_HERE_v0.20.md](START_HERE_v0.20.md) 与 [RELEASE_VALIDATION_v0.20.md](RELEASE_VALIDATION_v0.20.md)。

## v0.19.0 — Runtime Reliability / Reference UI（历史）

针对 v0.18.1 的真实模型失败轨迹修复工具恢复、引用定位、CAD reference、预算/重规划和长链状态问题，并加入参考图前端版本。v0.19 本地验证为 227/227；旧 200-run 仅作为修复前诊断基线，不能代表 v0.19 的真实模型成绩。详见 [START_HERE_v0.19.md](START_HERE_v0.19.md)、[RELEASE_VALIDATION_v0.19.md](RELEASE_VALIDATION_v0.19.md) 与 [FRONTEND_UPDATE.md](FRONTEND_UPDATE.md)。

以下为 v0.18.1 及更早历史说明。

# DesignGate Agent 0.18.1-alpha

Eval Integrity Hotfix。修复行为 Gold 自相矛盾、证据绑定字段缺失和未审核 deterministic FAIL 污染正式能力分母的问题；新增 Gold validator、trace-derived capability grader、真实 Scenario harness 与 Single/Multi live harness，并明确 provider seed 是否实际采用。

**当前使用说明：[START_HERE_v0.18.1.md](START_HERE_v0.18.1.md)**。

以下为 v0.18.0 历史说明。

# DesignGate Agent 0.18.0-alpha

Capability & Scenario Validation Release。新增 40-case capability dataset、行为 gold schema、多 trial 隔离 runner、确定性 code grader、F01-F17 failure taxonomy、4 个工业设计 scenario 和 10-case Single vs Multi A/B 计划。没有真实模型配置时能力状态保持 `UNVERIFIED`。

**当前使用说明：[START_HERE_v0.18.md](START_HERE_v0.18.md)**；**能力矩阵：[docs/CAPABILITY_MATRIX.md](docs/CAPABILITY_MATRIX.md)**；**限制：[docs/LIMITATIONS.md](docs/LIMITATIONS.md)**。

以下为历史说明，以 v0.18 的范围和限制为准。

# DesignGate Agent 0.17.0-alpha

新增来源绑定的曲面采样参考着色与面定位代码、有界提案自省重试、Gate 3 本地冻结交接包导出（PDF / CSV / Markdown / JSON）。中文 PDF 已嵌入字体并渲染检查。三维交互因当前浏览器安全策略限制，仍待 Windows 验收；没有自动工厂签核或真实模型质量认证。

**当前使用说明：[START_HERE_v0.17.md](START_HERE_v0.17.md)**；**权限与本地验收：[LOCAL_VALIDATION_AND_ACCESS.md](LOCAL_VALIDATION_AND_ACCESS.md)**。

以下为历史说明，以 v0.17 的范围和限制为准。

# DesignGate Agent 0.16.0-alpha

新增单实体 STEP 的有界曲面法线/穿实体距离/方向遮挡采样，A03 的所选 CAD 实测工具，以及带来源和完整样点的工程记录导出。提供 4 个可复现 STEP 样件。没有将采样结果转换为全局最小壁厚、整件无倒扣或自动制造放行。

**当前启动与能力边界：[START_HERE_v0.16.md](START_HERE_v0.16.md)**。

以下为历史说明，冲突处以 v0.16 为准。

# DesignGate Agent 0.15.0-alpha

本轮新增可选择保留的驳回理由记忆、角色知识与工具权限隔离、工程记录 ZIP 导出，以及默认只检查参数映射的实验性 FreeCAD 适配器。延续 v0.14 的蓝图视觉与可选 STEP BRep 基础解析。

**当前启动与验收说明：[START_HERE_v0.15.md](START_HERE_v0.15.md)**。真实模型 baseline、Windows Electron / WebGL 与 FreeCAD 实机执行仍待验收。当前导出是 JSON 工程记录，不是 PDF/XLSX 完整交付包或工厂签核书。

以下是历史说明，版本能力及限制以 v0.15 说明为准。

# DesignGate Agent 0.13.0-alpha

本版优先实现统一数据规则与真实模型评测流程：9 个数值参考绑定、3 个声明检查、7 个停用旧阈值；24 个明确标注为合成的基准案例，独立答案键、模型运行器、人工标注和对比指标。130 项自动化测试通过；真实模型评测尚未运行。

**先读 [v0.13 启动、迁移与评测说明](START_HERE_v0.13.md)**。规则缺来源会保持 UNKNOWN；不要用旧评审通过记录代替本次知识版本的复核。没有新增 BRep 内核。

以下为历史版本说明，冲突处以 v0.13 为准。

# DesignGate Agent 0.12.0-alpha

本版扩展原子变更提案、BOM 规格与长期意图，加入 A03→A02→A06 三角色模型协商，收拢知识读取，并提供引用定位与只读健康自检。

**启动与验收请先读 [v0.12 使用说明](START_HERE_v0.12.md)**。角色协商仍是模型建议，正式工程放行继续要求证据和人工审批。新增界面沿用原视觉系统。

以下保留旧版本说明；涉及功能数量、变更与协商的内容以 v0.12 说明为准。

# DesignGate Agent 0.11.0

本版增强 Agent 的知识检索与条件核对：26 张来源可追溯的知识卡、10 个公开原厂/供应商来源、9 个可执行参考范围。升级搜索并新增知识读取与参考核对工具；旧材料数值隔离，默认不再输出无条件物性。

**先读 [v0.11 启动与使用说明](START_HERE_v0.11.md)**，其中包含示例任务、来源清单、迁移影响和能力边界。维护知识库请读 [入库规范](knowledge/KNOWLEDGE_POLICY.md)。

验证结果：95/95 项测试通过，47 个 JavaScript 文件及 JSON 语法检查通过。尚未联调真实模型 API 或验收 Windows Electron 运行；本次没有新增 CAD 实体内核。新增参考范围不等于正式 Gate 规则。

## 0.10.0 Agent 执行器（历史说明）

本版新增目标驱动的 Agent 执行器：模型选择工具 → 执行本地工具 → 读取真实结果 → 调整计划 → 提问或提交草案 → 继续任务。原有工程评审引擎保留，用于规则与证据判断。

进入左侧「任务 Agent」，输入具体目标并启动。需要先在「模型与连接」配置支持 Tool Calls 的模型服务；仅能文字问答的模型不能执行本流程。详细能力、步骤预算、隐私、恢复与限制见 [Agent 使用说明](docs/AGENT_GUIDE.md)。本次暂停视觉改造，沿用已有界面，仅加入任务操作控件。

Windows PowerShell 请使用 `npm.cmd`；没有 `py` 时可以使用已安装的 `python`：

```powershell
python -m pip install -r requirements.txt
npm.cmd install
npm.cmd test
npm.cmd start
```

命令应在包含 package.json 和 requirements.txt 的 DesignGate 内层文件夹运行。Python 未安装时先安装并配置 PATH；Agent 中不涉及文件解析的工具无需 Python。

0.10.0 测试结果：83 项自动化测试通过。模型策略响应、网络服务和 Electron 宿主在集成测试中使用替身；规则、状态保存、审批应用、文件解析和工具循环运行真实代码。尚未使用用户实际模型进行联调，也未完成原生桌面端到端验收。这里的 Agent 使用 JavaScript 状态机实现，尚未接入 LangGraph；并非仅把原问答界面改名。

以下为保留的 0.9.0 基础模块说明，其中“设计顾问没有工具循环”等旧版本描述由本节及 AGENT_GUIDE 更新。

工业设计桌面工作台：项目需求、设计顾问、工程规则筛查、方案比较、验证证据与本地版本冻结。

本次在上传的 v0.7.2 源码上重构核心流程和前端，保留 Electron / JavaScript / Python 技术栈。它是面向专业工作流的开发版本；尚未完成桌面运行验收与真实企业系统集成，不能把规则通过视为整机合规或量产放行。

## 快速启动

准备 Node.js 20 或更高版本，以及 Python 3（本次解析测试使用 3.12）。在本目录执行：

```bash
python -m pip install -r requirements.txt
npm install
npm test
npm run check
npm start
```

macOS / Linux 的 Python 命令可能是 `python3`。若程序找不到解释器，可设置 `PYTHON_BIN` 为 Python 可执行文件的完整路径，不要附加命令参数。Python 和其依赖需要独立安装；桌面打包不会自动包含它们。`reportlab` 用于测试 PDF 样本，解析依赖 `pypdf` 和 `openpyxl`。

交付包含完整源码，不包含 node_modules、安装包或 API 密钥。受当前环境限制，没有完成 Electron 依赖安装和打包验证，也没有生成可复现依赖锁文件。首次安装后应保留实际生成的 package-lock.json，并在目标系统验收后固定 Python 依赖。

## 第一次使用

1. 新建项目，在「项目资料」填写使用人群、环境、需求、验证方法和通过判据。
2. 在 BOM 页填入真实部件与报价。缺少数量、单价、币种或报价来源时，系统不输出完整总价。
3. 在「工程评审」选择阶段和工艺，输入真实参数，也可选择 PDF、XLSX、STL 或 STEP。STL 必须明确单位与开模方向；STEP 支持基础 BRep 解析与有界曲面采样，但不做全局壁厚、全局倒扣或装配干涉证明。
4. 查看每项检查的通过、失败、未知或未实现状态，按问题清单补资料和修改设计。检查没有再次出现，不代表问题已关闭。
5. 在「方案决策」填写方案、评价权重、评分理由及硬约束状态，保存选择依据。
6. 在「验证与版本」添加真实证据文件，记录观察、判定和复核人。修改设计或需求后，旧验证不再适用于新基线。Gate 3 条件满足后，输入本机审批口令才能本地冻结；后续变更需新建版本。
7. 可选：在「设置」配置兼容 Chat Completions 的模型服务，使用设计顾问。模型建议不能改变工程门禁。顾问调用会发送当前项目的部分文字上下文；模型辅助评审说明默认关闭。

## 本次升级

- 需求、设计参数、BOM 和验证记录采用结构化契约，保留 0、false 与缺失值的区别。
- 明确规则覆盖清单、字段来源、证据指纹与版本；资料不足返回 HOLD，未实现功能不会伪装通过。
- 问题闭环需对应检查在匹配规则版本与输入指纹下明确通过；历史问题不会因本轮未检出而自动消失。
- 增加带理由的加权方案矩阵、报价完整性检查、验证计划、决策记录和本地冻结审批。
- 项目保存使用原子替换、乐观版本检查、历史快照与本地文件锁；解析运行于工作线程，避免阻塞窗口主线程。
- 前端重制为七个工作区：总览、项目资料、设计顾问、工程评审、方案决策、验证与版本、设置。暖灰画布、炭黑导航、橄榄绿操作色、统一排版和状态表达；首页图片是场景示意，不是项目成果。
- 旧示例项目移到 examples/legacy_projects，不自动导入新项目。旧测试只作为 tests/legacy 中的历史参考。

## 数据与升级

实际项目保存在 Electron `userData/projects`，配置和本地审批凭据保存在同一用户数据目录。界面可导出项目 JSON；导出不包含证据文件原始字节，完整备份应复制用户数据目录。

本版 appId / productName 已改为 DesignGate Studio，用户数据目录可能与旧版不同。升级前备份旧目录。尚未提供自动迁移程序：旧项目需重新核对需求、字段来源、验证证据和版本关系；旧版的 PASS / FROZEN 记录不能当作本版审核证明。examples/legacy_projects 是原始历史示例，包含旧状态和断言，不是本版验收结果。

本机口令只能区分本地操作，不能证明企业人员身份。文件哈希用于检测字节变化，不证明报告真实性。持有本机文件权限的人仍可修改项目和审批文件。

## 模型与外部连接

模型设置保存 base URL、模型名、温度和补充风格指令。API Key 仅在操作系统安全存储可用时加密落盘；Linux 的 basic_text 后端被拒绝，否则只在会话内存使用。前端不会读取已保存密钥。

外部检索和 PLM 归档默认关闭。连接器默认 mock，mock 不产生真实成功回执。真实连接需要 `DESIGNGATE_MODE=production`，并配置 `INAGENT_ENDPOINT` / `INAGENT_API_KEY`、`PLM_ENDPOINT` / `PLM_API_KEY`。这里的 endpoint 是你自己按实际平台协议实现的适配网关，不是已完成的厂商官方 SDK。网关响应契约见 connectors 源码。LMS、平台文档上传与平台工作流尚未实现。

## 能力边界

- 当前工程门禁是单零件、有限规则范围的筛查，不覆盖整机、装配公差链、电气安全、CAE 或真实制造验证。
- STL 是网格与面片角度启发式筛查，不证明倒扣、壁厚或模具可行性；STEP 已接入基础 BRep 解析及有界曲面法线、弦长和方向遮挡采样，但不证明全局最小壁厚、无倒扣、装配无干涉或模具批准。
- PDF 提取基于文本和有限模式，不含 OCR，不保证识别图纸尺寸语义；冲突或缺项需人工确认。
- 本地知识 JSON 是继承的候选索引，物性、标准有效性和供应商信息没有在本次全面复核。
- 设计顾问是带项目上下文的模型咨询，尚无自动联网研究、图像理解、CAD 生成或可自主迭代的工具执行循环。
- 模型辅助评审说明是临时辅助展示，核心持久化记录以确定性规则结果为准。
- 本地文件锁无自动崩溃恢复。异常关闭后如残留锁，应先确认无进程占用、备份数据，再人工处理；不可用作多用户服务端数据库。

详细设计见 docs/DESIGN_SYSTEM.md，测试与待验收项见 docs/VALIDATION.md，后续工程化路线见 docs/ROADMAP.md。

安全实现参考：[Electron safeStorage](https://www.electronjs.org/docs/latest/api/safe-storage)。桌面依赖版本来源：[Electron Releases](https://releases.electronjs.org/)。依赖的实际安装与兼容性仍需在目标机器验证。
