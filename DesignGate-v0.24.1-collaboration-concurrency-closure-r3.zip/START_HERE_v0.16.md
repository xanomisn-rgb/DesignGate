# v0.16.0-alpha — BRep 曲面采样与制造角色实测工具

本轮优先推进 CAD 测量，未将全部建议宣称为已完成。它仍是待工业项目验收的开发版。

## 现在可以测什么

单个有效 STEP 实体：在 BRep 曲面 UV 域做最多 5×5 个采样，检查裁剪边界与法线朝向；从实体内部沿内法线与边界求交，得到带位置、面编号、来源 SHA-256 的 **法线穿实体距离（normal chord）**。指定开模方向后计算有符号曲面法线角度，并沿正反方向做遮挡采样。

这些计算使用 BRep 曲面导数及实体求交，不读取 nominalWall 或 draftAngle 作为测量答案，也不依赖显示网格三角形法线。已在序列化 STEP 样件上复测 1.3 mm 薄板、1.2 mm 开口壳体、0.8° 锥面及封闭空腔遮挡。

**必须保留的区别**：法线穿实体距离不是局部特征尺寸，更不是全局最小壁厚。曲面法线角度包括端面；负角度不能单独证明倒扣。遮挡样点不等于完整模具脱模分析，未遮挡也不等于整件无倒扣。因此 minimum_mm 与 has_undercuts 仍为 null，真实局部数值存在 sampled_minimum_chord_mm 和 samples 中。

## 怎么使用

解压并进入内层 **DesignGate**，确认这里能看到 package.json。在 Windows PowerShell 执行：

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-cad.txt
npm.cmd install
npm.cmd test
npm.cmd run test:cad
npm.cmd start
```

不要输入 bash。npm.cmd 解决 PowerShell 对 npm.ps1 的限制；找不到 package.json 说明还没进入内层文件夹。OCP 是可选依赖，未安装时保留未评估结果；可设置 PYTHON_BIN 指向实际装有依赖的 Python。

1. 新建测试项目，在工程参数设置开模方向为 `0,0,1`，选择 `samples/brep` 中的 STEP 样件。
2. 执行工程评审后，中央工程测量区显示采样最短法线距离、有效样点与面覆盖数。体积、显示预览和采样均不能自动通过 Gate。
3. 要让 Agent 或 A03 实际读取文件，需在启动该任务前再次选入 CAD，沿用本次用户设置的开模方向。工程评审会清空原来的文件选择，不代表任务自动获得该文件访问权限。
4. 给 Agent 的目标示例：`读取本次所选 CAD，报告实际曲面采样、来源和覆盖率；区分名义参数与测量，列出尚不能判断的项目。不要将采样最小值当成全局最小壁厚。`
5. 协商中的 A03 可调用 `measure_selected_cad` 重新解析本次选择的文件。A02/A06 被后端禁止调用；没有文件或解析失败时保留错误。它不自动修改项目、不批准结论。
6. 导出工程记录 ZIP 时，如项目保存了来源一致的曲面采样，会新增 `06_BRep_Surface_Samples.json`，含全部采样行、方向、覆盖信息与源文件哈希。送往模型的上下文只保留最多 12 个代表样点以控制长度。

## 覆盖与性能边界

- 本轮只对单实体做曲面采样，多实体装配不混算壁厚或干涉。
- 最多 64 个面、每面 25 个 UV 位置、采样阶段 12 秒；达到限制保留覆盖统计。底层单次几何调用不能在中途精细取消，外层 Python 进程有 30 秒限制。
- 不按面积均匀分布，可能漏掉细小薄区、角点和窄面；不能据此证明没有缺陷。
- 法线偏移与分类容差是数值算法设置，不是制造阈值。数值退化或朝向无法验证的样点计入失败，不输出猜测。
- 修改假设参数后，screen_design 标记旧 CAD 为 ORIGINAL_GEOMETRY_NOT_PATCH_VALIDATED；不会声称 JSON Patch 已更新几何。
- STL 旧路径中的固定 1° 不足计数已取消，保留面片角度统计与启发式说明。工艺合格角度必须来自适用条件及可追溯规则。

## 尚未完成的项目

本版没有新增整面缺陷热力图、双向拾取、自动 CAD 改型或 ECN 正式签发。沿用三维预览，WebGL / Windows Electron 和 FreeCAD 实机验收仍待完成。JSON 工程记录包不是全套 PDF/XLSX 交接文件。

真实模型评测仍无 baseline：本次检查发现 DESIGNGATE_EVAL_API_KEY / BASE_URL / MODEL 均未配置，live 入口在请求前拒绝运行；`eval/NOT_RUN_v0.16.json` 仅记录离线计划与代码/知识指纹，不包含质量分数。需在本地配置可调用模型，并由领域人员复核案例及输出，才能报告可信召回率。不要把密钥写进源码或发到聊天。

金属工艺知识缺口保持 UNKNOWN，未用无来源数值填补。审美偏好仍需用户选择是否记入项目，不能取代安全要求或不可修改的系统权限。

## 实现依据

- [OpenCascade BRepAdaptor_Surface](https://dev.opencascade.org/doc/refman/html/class_b_rep_adaptor___surface.html)：曲面适配与坐标系处理。
- [OpenCascade IntCurvesFace_ShapeIntersector](https://occt3d.com/dev/doc/refman/html/class_int_curves_face___shape_intersector.html)：指定直线区间的边界求交及交点参数。

上述是 API 依据，不能作为壁厚/拔模制造合格标准。样件是本项目程序构造的解析几何，不是专家标注的真实工业项目。
