# v0.20.3 问题—代码修改—回归测试对照表

| 问题 | 主要代码 | 主要回归测试 |
|---|---|---|
| 默认累计 token 180000 硬停止 | `backend/runtime_config.js`, `backend/agent_runtime.js`, `main.js` | `default Agent run continues... exceeds legacy 180000`; `shared specialist/negotiation accounting...`; legacy config migration |
| 单次输出 1800/2500 与 length 直接失败 | `connectors/agent_model_client.js`, `main.js`, runtime config/UI | `model transport omits max_tokens...`; `explicit model max output... plain text length truncation...` |
| 工具/请求/协商/超时混为预算 | `backend/agent_runtime.js`, `backend/runtime_config.js`, eval failure/metrics | timeout distinct; no-progress; cancellation resume; timeout resume |
| 设计变化后旧验证可被旧 JSON 复活 | `backend/dfmea_records.js`, `backend/workflow_service.js`, `backend/fmea_service.js`, `backend/orchestrator.js` | `design change invalidates old execution and resubmitting old DFMEA JSON cannot restore verification` |
| 风险定义与验证执行混在一个 JSON | `backend/dfmea_records.js`, `backend/orchestrator.js`, `backend/workflow_service.js` | retest does not change risk-definition baseline/plan version; plan v2 immutable history |
| 无关联 PASS 可消除旧 FAILED | `backend/dfmea_records.js`, `backend/fmea_service.js`, `backend/professional_gate.js` | unrelated PASS repeated cannot clear FAILED; qualified linked retest closes failure |
| 测试 PASS 自动等于高风险接受 | `backend/dfmea_records.js`, `backend/professional_gate.js`, `backend/workflow_service.js` | high residual risk remains Gate-blocking until applicable acceptance |
| 专业能力异常导致整条评审丢失 | `backend/capability_contract.js`, `backend/orchestrator.js` | invalid ergonomics input is isolated and does not erase completed DFMEA result |
| FAILED/STALE/无效证据进入有效路径 | `backend/evidence_graph.js`, `backend/fmea_service.js` | failed/planned/stale/invalid records never appear as current valid evidence support paths |
| 时间戳被当作完整性 | `backend/evidence_graph.js` 等证据验证路径 | tampering registered evidence file invalidates current support |
| 旧项目测试状态迁移丢失/漂白 | `backend/dfmea_records.js` migration | legacy migration preserves original test status/history |
| 普通用户缺少复测/接受等入口 | `src/app.js`, `src/components.js`, `main.js`, workflow APIs | `tests/ui_contract.test.js` + desktop IPC/integration + v0.20.3 workflow tests |
| 旧评测器只认 BUDGET_EXCEEDED | `eval/code_grader.js`, `eval/failure_taxonomy.js`, `eval/metrics.js`, `eval/run.js` | full `npm test` 270/270 |

## 验收命令

```bash
npm test
npm run check
npm run test:cad
npm run test:adapter
npm run test:handover
```

最终结果见 `RELEASE_VALIDATION_v0.20.3.md`。
