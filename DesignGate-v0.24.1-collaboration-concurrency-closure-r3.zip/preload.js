const { contextBridge, ipcRenderer } = require("electron");
const WebSocket = require('ws');

const teamSubscriptions = new Map();
function teamEventEndpoint(baseUrl, projectId) {
  if (typeof projectId !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(projectId)) throw new Error('INVALID_TEAM_PROJECT_ID');
  const url = new URL(baseUrl);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('INVALID_TEAM_SERVER_URL');
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  url.pathname = `/api/projects/${encodeURIComponent(projectId)}/events`;
  url.search = '';
  url.hash = '';
  return url.toString();
}
function subscribeTeamEvents({ baseUrl, projectId, token }, listener) {
  if (typeof token !== 'string' || !token) throw new Error('TEAM_SESSION_REQUIRED');
  if (typeof listener !== 'function') throw new Error('TEAM_EVENT_LISTENER_REQUIRED');
  const id = `team-event-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const subscription = { active: true, reconnectTimer: null, socket: null };
  const connect = () => {
    if (!subscription.active) return;
    const socket = new WebSocket(teamEventEndpoint(baseUrl, projectId), { headers: { authorization: `Bearer ${token}` } });
    subscription.socket = socket;
    socket.on('open', () => listener({ type: 'TEAM_EVENT_TRANSPORT_CONNECTED', project_id: projectId }));
    socket.on('message', bytes => { try { listener(JSON.parse(bytes.toString('utf8'))); } catch { listener({ type: 'TEAM_EVENT_TRANSPORT_INVALID_MESSAGE', project_id: projectId }); } });
    socket.on('error', () => {});
    socket.on('close', () => {
      if (!subscription.active) return;
      listener({ type: 'TEAM_EVENT_TRANSPORT_RECONNECTING', project_id: projectId });
      subscription.reconnectTimer = setTimeout(connect, 1000);
    });
  };
  teamSubscriptions.set(id, subscription);
  connect();
  return id;
}
function unsubscribeTeamEvents(id) {
  const subscription = teamSubscriptions.get(id);
  if (!subscription) return;
  subscription.active = false;
  clearTimeout(subscription.reconnectTimer);
  subscription.socket?.close();
  teamSubscriptions.delete(id);
}

contextBridge.exposeInMainWorld("designGateAPI", {
  healthcheck: () => ipcRenderer.invoke('designGate:healthcheck'),
  agent: (action, projectId, runId, input={}) => ipcRenderer.invoke('designGate:agent', {action,projectId,runId,input}),
  workspace: (action, projectId, input, version) => ipcRenderer.invoke("designGate:workspace", {action,projectId,input,version}),
  getConfig: () => ipcRenderer.invoke("designGate:getConfig"),
  saveConfig: (cfg) => ipcRenderer.invoke("designGate:saveConfig", cfg),
  listProjects: () => ipcRenderer.invoke("designGate:listProjects"),
  getProject: (projectId) => ipcRenderer.invoke("designGate:getProject", projectId),
  saveProject: (projectData) => ipcRenderer.invoke("designGate:saveProject", projectData),
  runPipeline: (params) => ipcRenderer.invoke("designGate:runPipeline", params),
  selectProjectFile: (fileType) => ipcRenderer.invoke("designGate:selectProjectFile", fileType),
  saveFile: (defaultName, content, filters) =>
    ipcRenderer.invoke("designGate:saveFile", { defaultName, content, filters }),
  teamEvents: { subscribe: subscribeTeamEvents, unsubscribe: unsubscribeTeamEvents }
});
