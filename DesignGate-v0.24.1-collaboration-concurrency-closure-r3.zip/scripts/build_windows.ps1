$ErrorActionPreference = 'Stop'
npm run electron:build -- --win --x64
$exe = Join-Path $PSScriptRoot '..\dist\win-unpacked\DesignGate Studio.exe'
if (Test-Path $exe) { Write-Host "Built Windows application: $exe" }
