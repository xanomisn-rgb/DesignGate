[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$ServerUrl,
  [Parameter(Mandatory = $true)][string]$Username,
  [Parameter(Mandatory = $true)][string]$Password,
  [string]$ProjectId = ''
)

$base = $ServerUrl.TrimEnd('/')
function Invoke-Json([string]$Method, [string]$Path, $Body = $null, [hashtable]$Headers = @{}) {
  $params = @{ Method = $Method; Uri = "$base$Path"; Headers = $Headers; ErrorAction = 'Stop' }
  if ($null -ne $Body) { $params.ContentType = 'application/json'; $params.Body = ($Body | ConvertTo-Json -Compress) }
  return Invoke-RestMethod @params
}

function Receive-ConnectedEvent([System.Net.WebSockets.ClientWebSocket]$Socket) {
  $buffer = New-Object byte[] 4096
  $segment = [ArraySegment[byte]]::new($buffer)
  $cancel = [Threading.CancellationTokenSource]::new(10000)
  $result = $Socket.ReceiveAsync($segment, $cancel.Token).GetAwaiter().GetResult()
  if ($result.MessageType -ne [System.Net.WebSockets.WebSocketMessageType]::Text) { throw 'WEBSOCKET_EXPECTED_TEXT_EVENT' }
  return [Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count) | ConvertFrom-Json
}

try {
  $health = Invoke-Json 'GET' '/health'
  $login = Invoke-Json 'POST' '/api/auth/login' @{ username = $Username; password = $Password }
  if ([string]::IsNullOrWhiteSpace($login.token)) { throw 'LOGIN_TOKEN_MISSING' }
  $headers = @{ Authorization = "Bearer $($login.token)" }
  $me = Invoke-Json 'GET' '/api/auth/me' $null $headers
  $projects = Invoke-Json 'GET' '/api/projects' $null $headers
  $selected = if ([string]::IsNullOrWhiteSpace($ProjectId)) { $null } else { $ProjectId }
  $websocket = 'SKIPPED_NO_PROJECT'
  if ($selected) {
    $null = Invoke-Json 'GET' "/api/projects/$selected" $null $headers
    $wsBase = $base -replace '^https://', 'wss://' -replace '^http://', 'ws://'
    $uri = [Uri]"$wsBase/api/projects/$selected/events"
    foreach ($attempt in 1..2) {
      $socket = [System.Net.WebSockets.ClientWebSocket]::new()
      try {
        $socket.Options.SetRequestHeader('Authorization', "Bearer $($login.token)")
        $cancel = [Threading.CancellationTokenSource]::new(10000)
        $socket.ConnectAsync($uri, $cancel.Token).GetAwaiter().GetResult()
        $event = Receive-ConnectedEvent $socket
        if ($event.type -ne 'CONNECTED') { throw 'WEBSOCKET_CONNECTED_EVENT_MISSING' }
        $websocket = if ($attempt -eq 2) { 'CONNECTED_AND_RECONNECTED' } else { 'CONNECTED' }
      } finally {
        if ($socket.State -eq [System.Net.WebSockets.WebSocketState]::Open) { $socket.CloseAsync([System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure, 'validation', [Threading.CancellationToken]::None).GetAwaiter().GetResult() }
        $socket.Dispose()
      }
    }
  }
  [pscustomobject]@{ status = 'LOCAL_CLIENT_CHECK_COMPLETED'; health = $health.status; user_id = $me.user.user_id; project_count = @($projects.projects).Count; websocket = $websocket; note = 'This verifies one client connection only. It does not prove a real multi-device LAN run or production readiness.' } | ConvertTo-Json -Compress
} catch {
  [Console]::Error.WriteLine("COLLABORATION_CLIENT_CHECK_FAILED:$($_.Exception.Message)")
  exit 1
}
