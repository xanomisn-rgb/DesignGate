[CmdletBinding()]
param(
  [string]$ServerHost = '127.0.0.1',
  [int]$Port = 43124,
  [string]$DataDirectory = (Join-Path (Get-Location) 'data\collaboration'),
  [string]$ArtifactDirectory = '',
  [string]$SessionSecret = $env:DESIGNGATE_SESSION_SECRET,
  [switch]$AllowLan
)

$loopbackHosts = @('127.0.0.1', 'localhost', '::1')
if ($loopbackHosts -notcontains $ServerHost -and -not $AllowLan -and $env:DESIGNGATE_ALLOW_LAN -ne 'true') {
  throw 'LAN_BIND_REQUIRES_DESIGNGATE_ALLOW_LAN: pass -AllowLan or set DESIGNGATE_ALLOW_LAN=true after reviewing network access. This script never changes Windows Firewall.'
}
if ([string]::IsNullOrWhiteSpace($SessionSecret) -or $SessionSecret -eq 'replace_with_a_long_random_local_secret') {
  throw 'DESIGNGATE_SESSION_SECRET_REQUIRED: provide a unique local session secret through -SessionSecret or DESIGNGATE_SESSION_SECRET.'
}
if ($Port -lt 1 -or $Port -gt 65535) { throw 'INVALID_SERVER_PORT' }

$projectRoot = Split-Path -Parent $PSScriptRoot
$resolvedData = [System.IO.Path]::GetFullPath($DataDirectory)
$resolvedArtifacts = if ([string]::IsNullOrWhiteSpace($ArtifactDirectory)) { Join-Path $resolvedData 'artifacts' } else { [System.IO.Path]::GetFullPath($ArtifactDirectory) }
$env:DESIGNGATE_SERVER_HOST = $ServerHost
$env:DESIGNGATE_SERVER_PORT = [string]$Port
$env:DESIGNGATE_COLLABORATION_DIR = $resolvedData
$env:DESIGNGATE_ARTIFACT_DIR = $resolvedArtifacts
$env:DESIGNGATE_SESSION_SECRET = $SessionSecret

$lanIps = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress -Unique)
Write-Host "DesignGate Collaboration Server"
Write-Host "Local URL: http://127.0.0.1:$Port"
if ($lanIps.Count -gt 0) { $lanIps | ForEach-Object { Write-Host "LAN candidate URL: http://${_}:$Port" } } else { Write-Host 'LAN candidate URL: unavailable (no non-loopback IPv4 address detected)' }
Write-Host "Health URL: http://$ServerHost`:$Port/health"
Write-Host "Database path: $(Join-Path $resolvedData 'database\designgate-collaboration.sqlite')"
Write-Host "Artifact path: $resolvedArtifacts"
Write-Host 'Firewall remains unchanged. Configure an inbound rule manually only after limiting the trusted network scope.'

Push-Location $projectRoot
try { & node (Join-Path $projectRoot 'tools\collaboration_server.js') } finally { Pop-Location }
