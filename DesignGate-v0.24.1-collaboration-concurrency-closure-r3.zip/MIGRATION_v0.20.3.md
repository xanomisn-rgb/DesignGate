# v0.20.3 迁移说明

## 1. 运行配置

### 历史默认 180000

旧项目/配置中的 `maxTokens=180000` 被识别为 v0.20.2 的历史应用默认值。在用户没有明确开启新累计预算的情况下，迁移为：

```json
{
  "cumulativeTokenBudgetEnabled": false,
  "cumulativeTokenBudget": null
}
```

不会迁移成更大的固定数字，也不使用 `Infinity` 持久化。

### 历史显式非默认预算

如果旧 `maxTokens` 是正整数且不是历史默认 180000，并且没有新字段覆盖，则视为用户曾显式设置的预算，迁移为启用的新累计预算。用户随后可在设置页关闭。

### 新配置字段

- `maxOutputTokens`: nullable positive integer
- `modelContextWindowTokens`: nullable positive integer
- `modelRequestTimeoutMs`
- `maxLengthRecoveryAttempts`
- `cumulativeTokenBudgetEnabled`
- `cumulativeTokenBudget`
- `maxToolSteps`
- `maxModelRequests`
- `maxNegotiationRounds`
- `agentRunDurationMs`
- `reviewPipelineTimeoutMs`

## 2. DFMEA 数据

schema 迁移到 `3.1`。

### 风险定义

`dfmea` 只保留风险定义/控制等定义数据；新提交中夹带的 `verification_tests` 不再被当作当前有效执行记录。

### 验证计划

迁移旧嵌入式测试时，可以生成 `MIGRATED_PLAN_REQUIRES_REVIEW` 的历史计划用于追溯；它不等价于当前已经验证。

### 测试执行历史

旧 `dfmea.verification_tests` 会被复制成 append-only 历史记录并保留原始状态，不删除 FAILED，也不把旧 PASS 自动转换成当前 PASS。迁移记录标记：

`LEGACY_UNBOUND_REQUIRES_REVALIDATION`

旧客户端 `baseline_fingerprint` 仅保存在 `legacy_client_baseline` 作为历史信息，不能成为当前有效性依据。

### 当前有效性

当前有效性每次由服务端依据以下关系重新计算：

- project id
- active Revision
- 当前设计依赖基线 hash
- 当前风险定义 hash
- 当前验证计划 id/version/hash
- 测试记录自身 hash
- 证据文件当前完整性
- 复测关系/完成时间/风险关系
- 更正/处置/接受记录的适用性

客户端提交 PASS/STALE/VERIFIED 或旧 hash 不能直接恢复当前验证。

### 更正与风险接受

- 测试纠错：追加 `dfmea_test_corrections`，不覆盖原测试。
- 残余风险接受：追加 `risk_acceptances`，绑定当前基线。
- 旧失败不再适用时：必须建立明确处置/审核关系，不自动消失。

## 3. 冻结

旧冻结资格不跨新基线自动继承。冻结入口会独立重新校验当前专业结果、测试有效性、失败关闭关系、证据完整性和要求的残余风险接受记录。

“本地冻结”仍不等于生产放行。
