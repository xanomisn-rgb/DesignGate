# DesignGate v0.15.0-alpha — 后端行动与角色隔离

这是可审查的开发版源码包。沿用 v0.14 的海军蓝工程画板、暖纸面板、朱红操作点缀；本轮主要改动后端及必要的操作控件。

## Windows 启动

解压后进入里面的 **DesignGate** 文件夹，确认能看到 package.json。不要输入 bash，也不要把代码块的语言名称或 PowerShell 提示符一起复制。

```powershell
cd "你的解压目录\DesignGate"
Test-Path .\package.json
python -m pip install -r requirements.txt
npm.cmd install
npm.cmd test
npm.cmd run check
npm.cmd start
```

Test-Path 应返回 True。如为 False，先找到含 package.json 的文件夹再运行 npm。npm.cmd 可避免 PowerShell 对 npm.ps1 的脚本限制。使用带空格的完整路径时写成 `& "C:\Program Files\nodejs\npm.cmd" start`。

可选 STEP 基础解析依赖：`python -m pip install -r requirements-cad.txt`；验证：`npm.cmd run test:cad`。某些 Python / 操作系统组合可能没有对应 OCP 安装包，安装失败时保留轻量解析，不能宣称已启用 BRep。启动前备份旧项目；不要直接覆盖旧源码目录及依赖。

## 本轮新增

1. **驳回理由与项目记忆**：提案卡填写理由，可明确勾选“记为本项目长期约束”。未勾选只影响本次任务；勾选后保存至项目并跨 Revision 保留。它是用户偏好，不晋升为工程规则。记录新约束会清除旧评审与批准状态，需重新评审；设计参数保持原值。支持写入后中断恢复与版本冲突检查。
2. **角色能力隔离**：A03 可读工艺知识、已有 CAD 摘要与候选筛查；A02 可读材料知识及造型相关字段；A06 可读证据台账。服务端校验权限，不能靠伪造工具名称越权。每角色保留自己的历史立场切片，每轮至多两次工具调用，计入总任务预算。仍使用同一配置模型；读取 CAD 摘要不是重新测量。
3. **工程记录包**：任务 Agent 页的导出按钮通过原生保存窗口生成 ZIP，包含需求追溯、BOM、批准参数计划、决策和最近至多 30 次任务记录、未知项及 SHA-256 清单。未报价保持 null，未签核保持未签核；原文件不覆盖。BOM 当前是 JSON，尚未实现 XLSX 回写及五件套 PDF/XLSX 工程交付。
4. **实验性 FreeCAD 参数适配器**：导出已批准且仍与当前设计一致的数值参数；人工将字段映射到已有对象的 Length / Angle 属性，检查对象、类型、表达式和旧值。默认 dry_run=True，只检查；显式关闭后使用事务修改，失败回滚，不自动保存。仅替身对象测试通过，未在 FreeCAD 实机验收。不能对任意 STEP 自动抽壳、倒角或恢复建模历史。
5. **模型上下文减负**：向模型发送几何摘要而非大量显示三角形坐标；原始几何保留在本地项目状态中，工程 ZIP 也只包含几何摘要。评测指纹加入本轮角色、补丁与导出模块，便于后续真实模型对比。

## 现有 CAD 与评测的准确边界

- OCP 可选 BRep 路径提供 STEP 拓扑、包围盒、体积、质心和显示网格；不提供已验证的实体壁厚分布、精确拔模、倒扣/干涉认证。
- 云端浏览器禁用 WebGL，未完成 3D 视口视觉验收。请在 Windows Electron 检查导入、旋转、缩放及失败提示；界面高亮不能代替实体量测证据。
- FreeCAD 适配器需要单独的实际文档验收。先备份，在副本中检查 dry-run 报告，不应直接用于生产 CAD。
- 尚未获得真实模型 baseline。现有案例为合成草稿，测试通过不等于模型召回率、专家复核或工厂签核。真实运行需要在本地配置 DESIGNGATE_EVAL_API_KEY、DESIGNGATE_EVAL_BASE_URL、DESIGNGATE_EVAL_MODEL，再运行 `npm.cmd run eval:live`；切勿将密钥写进代码或发到聊天。
- 未实现企业身份签名、完整五件套交付、CAD 自动薄壁修复、草图尺寸的已验证提取。本版不新增未经核验的材料阈值。

## 验证入口

`npm.cmd test` 汇总原有与本轮 JavaScript 测试；`npm.cmd run check` 检查代码语法与 JSON；`npm.cmd run test:adapter` 检查 FreeCAD 适配器替身；`npm.cmd run test:cad` 检查可选 OCP 的解析几何样件。发布验证结果见 RELEASE_VALIDATION_v0.15.md。
