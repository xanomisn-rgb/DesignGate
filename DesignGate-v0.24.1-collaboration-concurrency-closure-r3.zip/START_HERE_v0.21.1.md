# DesignGate v0.21.1 — Governed Knowledge Integration

This release imports a verified, local knowledge delta without turning reference material into automatic engineering approval.

## Use

1. Run `npm test` and `npm run check` from this folder.
2. In the Task Agent, use `search_knowledge` with `kind`, `domain`, `manufacturer`, and `exact_model` when known.
3. Read a selected card before citing it. The returned source metadata, scope, limitations, verification status, and `hard_gate:false` are part of the result.
4. For a battery estimate use `calculate_battery_pack` with exact manufacturer/model plus integer `ns` and `np`.
5. Supply BMS, busbar, wire, connector, fuse, and thermal continuous-current limits only when those values are traceable and current. Otherwise the result remains `THEORETICAL_CELL_LIMIT_ONLY`.
6. Continue formal Requirement, Evidence, DFMEA, Gate, risk-acceptance and local-freeze work in their existing workflows. Agent knowledge tools do not write a test result or close risk.

## Boundaries

- `21700 5000mAh` without manufacturer and exact model returns `DATA_GAP`.
- Bare mAh is not Wh. Pack nominal voltage/capacity/energy are calculated as `Ns × Vcell`, `Np × Ahcell`, and `Ns × Np × Vcell × Ahcell`.
- A 2S2P pack of EVE INR21700/50E calculates to 7.3 V, 10 Ah, and 73 Wh nominal. It is not a verified battery-pack, runtime, safety, or product claim.
- Manufacturer typical values, HDT, UL94 material ratings, service-provider DFM guidelines, and standards indexes remain conditioned reference information.
- `Q-*` quarantine records are historical/review-required and are not current evidence.
- No paid standard text, external production system, automated release, or production approval is included.

## Review and freeze behavior

The review baseline records the full knowledge fingerprint. A modified knowledge release therefore invalidates reliance on the old review and requires re-review before a local freeze request. Existing DFMEA, Evidence, approval, cancellation/recovery, project isolation, and production-release boundaries are unchanged.

See [MIGRATION_v0.21.1.md](MIGRATION_v0.21.1.md) and [RELEASE_VALIDATION_v0.21.1.md](RELEASE_VALIDATION_v0.21.1.md).
