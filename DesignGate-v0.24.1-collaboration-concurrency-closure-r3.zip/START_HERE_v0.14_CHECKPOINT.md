# DesignGate 0.14 — development checkpoint

This is NOT a completed v1.0 or a manufacturing-release tool. Read this before the older version documents.

## Implemented in this checkpoint

- Navy blueprint / warm-paper / vermilion frontend art direction, metadata typography, restrained transitions, reduced-motion styling.
- Three.js local STL preview code and rendering of STEP display meshes from the saved geometry analysis. Cloud browser cannot initialize WebGL, so interactive 3D is NOT verified.
- Optional OpenCascade (OCP) STEP parsing, topology validity, millimetre bounding box, aggregate solid volume and centroid, bounded tessellation with source-hash / face IDs.
- Online deterministic proposal regression critique before proposal presentation and again before application. This is NOT `eval/metrics.js`: offline model-quality metrics require labelled reference answers and cannot establish engineering truth online.
- Gate fix: a required failed check now rejects release even if the producer emitted no Finding.

## Verification

- Existing Node regression suite: 130 / 130 passed in this environment.
- Additional proposal / gate checks: run `npm.cmd run test:upgrade`.
- Optional OCP regression: two analytic / invalid-input tests passed using OCP 8.0.1.0.0 on Linux Python 3.12. The 20 × 30 × 1.3 mm box has volume 780 mm³. Height is NOT claimed as wall-thickness measurement.
- No Windows GUI verification. No true model baseline: DESIGNGATE_EVAL_API_KEY / BASE_URL / MODEL are not configured.
- Browser QA: BLOCKED by disabled WebGL. See design-qa.md.

## Not implemented in this iteration

Wall-thickness distribution, surface draft mapping, visibility-based undercut detection, Finding-to-surface highlight, CAD modification macros, BOM XLSX writeback, handover PDF/XLSX package, sketch understanding, new causal knowledge, role-isolated tool execution, rejection memory, long-horizon scheduler, supplier-data expansion and expert-reviewed live evaluation baseline.

These must not be presented as finished capabilities. CAD display meshes must not be inserted into model messages in full; a subsequent iteration should provide bounded geometry summaries and dedicated reference tools. No invented test, award-compliance or factory-signoff claims.

## Windows startup

Open PowerShell in the inner `DesignGate` directory containing package.json:

```powershell
Test-Path .\package.json
python -m pip install -r requirements.txt
npm.cmd install
npm.cmd test
npm.cmd run test:upgrade
npm.cmd run check
npm.cmd start
```

Optional B-Rep environment (availability depends on the Python / OS wheel):

```powershell
python -m venv .venv-cad
.\.venv-cad\Scripts\python.exe -m pip install -r requirements.txt -r requirements-cad.txt
$env:PYTHON_BIN = (Resolve-Path .\.venv-cad\Scripts\python.exe).Path
npm.cmd start
```

No PowerShell policy change or Bash is required. Do not send API keys in chat.

`npm run dev` serves only the src directory and a clearly labelled synthetic visual preview; it cannot run live agents, edit saved desktop projects or issue real approvals. Electron uses its real IPC bridge instead.

## References consulted

- https://cadquery.readthedocs.io/en/latest/importexport.html — STEP exchange does not restore original parametric feature history.
- https://threejs.org/docs/ — Three.js rendering / geometry documentation.

The use of these libraries is not evidence of validated moldability.
