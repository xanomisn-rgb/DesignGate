# v0.20.3 运行限制清单

## 已取消的应用自身限制

| 项目 | v0.20.2 / 旧行为 | v0.20.3 |
|---|---|---|
| Agent 累计 token 默认硬上限 | 180000 | 默认关闭；`cumulativeTokenBudgetEnabled=false`，值为 `null` |
| 旧 `maxTokens=180000` 默认配置 | 可隐式继续限制 | 迁移为关闭累计预算 |
| 模型客户端默认单次输出 | 1800 | 默认不设置；`maxOutputTokens=null` |
| main.js 顾问/说明请求 | 固定 2500 | 使用统一模型配置，不再硬编码 2500 |
| 请求 token 预留 | 固定按旧输出限制预留 | 与实际 `maxOutputTokens` 配置一致；未配置时不虚构 1800 预留 |
| `finish_reason=length` | 直接失败 | 普通文本受控续写；截断工具参数绝不执行并要求完整重生成 |

## 仍保留、且默认可配置的运行控制

这些控制用于阻止无限循环、重复副作用和不可恢复卡死，不属于模型 token 配额绕过。

| 控制 | 默认值 | 语义 |
|---|---:|---|
| `maxOutputTokens` | `null` | 应用不主动附加单次输出上限；供应商若自身有上限仍生效 |
| `modelContextWindowTokens` | `null` | 仅在有确认配置时用于上下文能力配置，不猜测模型上限 |
| `modelRequestTimeoutMs` | 120000 ms | 单次模型请求超时 |
| `maxLengthRecoveryAttempts` | 2 | length 截断恢复次数，硬上界 4 |
| `maxProviderRetries` | 1 | 临时供应商错误重试，硬上界 2 |
| `maxToolSteps` | 80 / 段 | 每个可恢复运行段的工具步数 |
| `maxModelRequests` | 120 / 段 | 每个可恢复运行段的模型请求数 |
| `maxNegotiationRounds` | 24 / 段 | 每个可恢复运行段的多角色协商轮数 |
| `agentRunDurationMs` | 900000 ms | 每个可恢复运行段的总运行时间 |
| `reviewPipelineTimeoutMs` | 1800000 ms | 正式评审 pipeline 超时 |
| 用户取消 | 保留 | 保存检查点，状态 `CANCELLED`，可恢复 |
| 无进展检测 | 保留 | 相同失败/无效调用反复出现时 `NO_PROGRESS` 停止 |
| 权限检查 | 保留 | 工具/角色/项目作用域仍强制执行 |
| 用户自愿累计 token 预算 | 默认关闭 | 只有用户显式开启并提供正整数时成为硬限制 |

## 独立停止原因

不再统一混为 `BUDGET_EXCEEDED`：

- `TOKEN_BUDGET_EXCEEDED` / `USER_TOKEN_BUDGET`
- `TOOL_STEP_LIMIT`
- `MODEL_REQUEST_LIMIT`
- `NEGOTIATION_ROUND_LIMIT`
- `RUN_TIMEOUT` / `RUN_DURATION_LIMIT`
- `MODEL_REQUEST_TIMEOUT`
- `NO_PROGRESS` / `REPEATED_NO_PROGRESS`
- `CANCELLED` / `USER_CANCELLED`

## 供应商边界

DesignGate 只取消自己的固定小上限。模型供应商的上下文窗口、单次最大输出、速率限制、账号余额/配额及服务端拒绝仍然有效，且本项目不尝试绕过。
