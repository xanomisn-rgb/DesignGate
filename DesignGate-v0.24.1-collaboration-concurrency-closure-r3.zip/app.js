const ui={view:'overview',project:null,projects:[],history:[],config:{},busy:false,error:'',mobileNav:false,dirty:false,files:{},stage:'Gate 2',cadOptions:{},integration:{inagentRAG:false,archivePLM:false,modelNarrative:false},formDrafts:{},messages:[],reqDraft:null,bomDraft:null,matrixDraft:null,matrixResult:null};
const state={currentTab:'designgate'};const projectDrafts=new Map();
const api=()=>{if(!window.designGateAPI)throw Error('请通过 npm start 打开桌面客户端；直接打开 HTML 不能连接本地工程服务。');return window.designGateAPI;};
function toast(message){const el=document.getElementById('toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),3200);}
function data(id){const f=document.getElementById(id);return f?Object.fromEntries(new FormData(f).entries()):{};}
function capture(){if(typeof document==='undefined')return;for(const f of document.querySelectorAll('#app form')){const values=Object.fromEntries(new FormData(f).entries());for(const el of f.querySelectorAll('input[type="password"]'))delete values[el.name];ui.formDrafts[f.id]={...ui.formDrafts[f.id],...values};}}
function render(){if(typeof document==='undefined')return;document.getElementById('app').innerHTML=viewShell(ui);const release=document.querySelector('.sidebar-note');if(release)release.textContent='DesignGate Agent · 0.22.3-p1-prep';for(const [id,values]of Object.entries(ui.formDrafts)){const f=document.getElementById(id);if(!f)continue;for(const [name,v]of Object.entries(values)){const el=f.elements.namedItem(name);if(el&&el.type!=='password')el.value=v;}}if(typeof highlightAgentReference==='function')highlightAgentReference();}
function clearDrafts(){ui.formDrafts={};ui.reqDraft=null;ui.bomDraft=null;ui.matrixDraft=null;ui.dirty=false;}
async function refresh(){if(ui.project){const id=ui.project.project_id;ui.project=await api().getProject(id);ui.history=await api().workspace('history',id,{},ui.project.version);}ui.projects=await api().listProjects();}
async function busy(fn){if(ui.busy)return;capture();ui.busy=true;ui.error='';render();try{await fn();}catch(e){ui.error=e.message;toast(e.message);}finally{ui.busy=false;render();}}
async function changeProject(id){capture();if(ui.project)projectDrafts.set(ui.project.project_id,{formDrafts:ui.formDrafts,reqDraft:ui.reqDraft,bomDraft:ui.bomDraft,matrixDraft:ui.matrixDraft,files:ui.files,cadOptions:ui.cadOptions,stage:ui.stage,messages:ui.messages,dirty:ui.dirty});clearDrafts();ui.files={};ui.cadOptions={};ui.stage="Gate 2";ui.messages=[];Object.assign(ui,projectDrafts.get(id)||{});ui.project=await api().getProject(id);ui.error='';ui.matrixResult=null;await refresh();render();}
function navigate(view){capture();ui.view=view;ui.mobileNav=false;ui.error='';render();window.scrollTo({top:0,behavior:'instant'});}
async function mutate(action,input){if(!ui.project)throw Error('请先新建项目');const r=await api().workspace(action,ui.project.project_id,input,ui.project.version);if(r?.cancelled)return r;clearDrafts();await refresh();toast('已保存');return r;}
function readRequirements(){const source=ui.reqDraft||ui.project.requirements||[],d={...ui.formDrafts.profileForm,...data('profileForm')};return source.map((r,i)=>({...r,req_id:d['req_id_'+i]??r.req_id,text:d['req_text_'+i]??r.text,verification_method:d['req_method_'+i]??r.verification_method,acceptance_criteria:d['req_criteria_'+i]??r.acceptance_criteria}));}
function readBom(){const source=ui.bomDraft||ui.project.bom||[],d={...ui.formDrafts.bomForm,...data('bomForm')};return source.map((r,i)=>{const row={...r};for(const k of ['part_id','part_name','material_specified','process','quantity','unit_cost','currency','quote_source']){const v=d[`bom_${k}_${i}`]??r[k];row[k]=['quantity','unit_cost'].includes(k)?v===''||v==null?null:Number(v):v??'';}return row;});}
function readMatrix(){const source=ui.matrixDraft||ui.project.decision_matrix||{criteria:[],alternatives:[]},d={...ui.formDrafts.matrixForm,...data('matrixForm')};const criteria=source.criteria.map((c,i)=>({id:d['criterion_id_'+i]??c.id,name:d['criterion_name_'+i]??c.name,weight:Number(d['criterion_weight_'+i]??c.weight)}));const alternatives=source.alternatives.map((a,i)=>({id:a.id,name:d['alternative_name_'+i]??a.name,constraints_status:d['alternative_constraints_'+i]??a.constraints_status,scores:Object.fromEntries(criteria.map((c,j)=>{const raw=d[`score_${i}_${j}`]??a.scores?.[source.criteria[j].id]?.value;return [c.id,{value:raw==null||raw===''?null:Number(raw),reason:d[`reason_${i}_${j}`]??a.scores?.[source.criteria[j].id]?.reason??''}];}))}));return {criteria,alternatives};}
function engineeringInput(){capture();const d=ui.formDrafts.engineeringForm||{},numbers=['nominalWall','localMaxWall','ribThickness','draftAngle','sheetThickness','bendRadius','internalCornerRadius','cavityDepthInches','textureDepthMm','weightG','cogOffsetMm','operationForceN','operationDurationS','glossMeasurementAngleDeg'],flags=['hasUndercut','hasSharpInsideCorners','toolingStrategySpecified','gateLocationSpecified','partingLineSpecified','hasTexture'],params={};for(const k of ['manufacturingSupplier','textureCode','process','material','assembly','dimensions','batteryAttachment','finish','color','gloss','durability','envelopeDimensions','gripSection','cogCoordinatesMm','cogReference','gripPosture','targetPopulation','populationSource','materialFamily','materialGrade','substrate','useEnvironment','cmfCompatibilityEvidence','cmfSamplePlan','cmfDurabilityPlan','cmfKnowledgeStatus','cmfSource','cmfSourceVersion','cmfApplicability','cmfUnits','cmfExceptions','fastenerType','serviceTool','servicePart','serviceAccess','disassemblySteps','irreversibleJoints','assemblyServiceConflicts'])if(k in d)params[k]=d[k]||null;for(const k of numbers)if(k in d)params[k]=d[k]===''?null:Number(d[k]);for(const k of flags)if(k in d)params[k]=d[k]===''?null:d[k]==='true';if('cad_unit'in d)ui.cadOptions.unit=d.cad_unit||null;if('pull_direction'in d){const v=d.pull_direction.trim();ui.cadOptions.pull_direction=v?v.split(',').map(Number):null;}if(d.stage)ui.stage=d.stage;return {designParams:params,proposalText:d.proposalText||''};}
function readDfmeaInput(){const raw=(ui.formDrafts.engineeringForm||{}).dfmea_json?.trim();if(!raw)return undefined;try{const value=JSON.parse(raw);if(!value||typeof value!=='object'||Array.isArray(value))throw Error('DFMEA 必须是对象');return value;}catch(error){throw Error('DFMEA JSON 无效：'+error.message);}}
async function runReview(forceStage){if(!ui.project){toast('请先新建项目');return;}const fields={...engineeringInput(),dfmea:readDfmeaInput()};await busy(async()=>{const r=await api().runPipeline({projectId:ui.project.project_id,revision:ui.project.design.active_revision,expectedVersion:ui.project.version,stage:forceStage||ui.stage,...fields,files:Object.fromEntries(Object.entries(ui.files).map(([k,v])=>[k,v.path])),cadOptions:ui.cadOptions,...ui.integration});clearDrafts();ui.files={};await refresh();ui.project.last_review=r;ui.view='engineering';ui.reviewTab='checks';toast('评审完成：'+r.gate.decision);});}
async function pickFile(type){const r=await api().selectProjectFile(type);if(r?.success){ui.files[type+'File']={path:r.filePath,name:r.fileName};toast('文件已选择，将在下一次评审中解析');}}
async function handleAction(action,el){
 if(action==='export-assets'){await busy(async()=>{if(!ui.project)throw Error('请先选择项目');const r=await api().workspace('export-assets',ui.project.project_id,{},ui.project.version);if(r.success)toast('工程记录包已导出；不是工厂签核文件');});return;}
 if(action==='export-handover'){await busy(async()=>{if(!ui.project)throw Error('请先选择项目');const r=await api().workspace('export-handover',ui.project.project_id,{},ui.project.version);if(r.success)toast('冻结交接包已导出；工厂签核与奖项文案仍待完成');});return;}
 if(action==='focus-reference'){focusAgentReference(Number(el.dataset.eventIndex));return;}
 if(action==='healthcheck'){await busy(async()=>{ui.health=await api().healthcheck();});return;}
 if(action.startsWith('agent-')){
  const rejectionFeedback=action==='agent-reject'?{reason:document.getElementById('rejectionReason')?.value||'',remember:document.getElementById('rememberRejection')?.checked===true}:{};
  await busy(async()=>{
   if(action==='agent-open')await refreshAgentPanel(ui.project.project_id,el.dataset.runId);
   else if(action==='agent-export'){
    const r=agentPanelState(ui.project.project_id).run;
    if(r)await api().saveFile(`DesignGate-Agent-${r.run_id}.json`,JSON.stringify(r,null,2),[{name:'Agent 任务记录',extensions:['json']}]);
   }
   else if(action==='agent-stop')await agentCommand('cancel');
   else if(action==='agent-resume')await agentCommand('resume');
   else if(action==='agent-approve'||action==='agent-reject')await agentCommand('approve',{approved:action==='agent-approve',feedback:rejectionFeedback});
  });return;
 }
 if(action==='new-project'){document.getElementById('newProjectDialog').showModal();return;}
 if(action==='close-dialog'){document.getElementById('newProjectDialog').close();return;}
 if(action==='menu'){capture();ui.mobileNav=!ui.mobileNav;render();return;}
 if(action.startsWith('goto-')){navigate(action.slice(5));return;}
 if(action==='run-review'||action==='run-gate3'){await runReview(action==='run-gate3'?'Gate 3':null);return;}
 if(action==='pick-file'){await busy(()=>pickFile(el.dataset.type));return;}
 if(action==='remove-file'){capture();delete ui.files[el.dataset.type+'File'];render();return;}
 if(action==='add-evidence'){await busy(()=>mutate('evidence',{}));return;}
 if(action==='suggest-question'){const f=document.getElementById('advisorForm');f.elements.question.value=el.dataset.question;f.elements.question.focus();return;}
 if(action==='export'){await busy(async()=>{const p=ui.project;if(!p)throw Error('无项目可导出');const doc={...p,exported_at:new Date().toISOString(),export_scope:'本地项目记录，模型建议不构成工程证明'};const r=await api().saveFile(`DesignGate-${p.project_id}-${p.design.active_revision}.json`,JSON.stringify(doc,null,2),[{name:'项目记录 JSON',extensions:['json']}]);if(r.success)toast('项目记录已导出');});return;}
 capture();const index=Number(el.dataset.index);
 if(action==='add-requirement'||action==='remove-requirement'){ui.reqDraft=readRequirements();if(action==='add-requirement'){let n=1;while(ui.reqDraft.some(r=>r.req_id==='REQ-'+String(n).padStart(2,'0')))n++;ui.reqDraft.push({req_id:'REQ-'+String(n).padStart(2,'0'),text:'',verification_method:'',acceptance_criteria:''});}else ui.reqDraft.splice(index,1);ui.formDrafts.profileForm=Object.fromEntries(Object.entries(ui.formDrafts.profileForm||{}).filter(([k])=>!k.startsWith('req_')));}
 if(action==='add-part'||action==='remove-part'){ui.bomDraft=readBom();if(action==='add-part')ui.bomDraft.push({part_id:'P-'+Date.now().toString().slice(-6),part_name:'',quantity:null,unit_cost:null,currency:'CNY'});else ui.bomDraft.splice(index,1);delete ui.formDrafts.bomForm;}
 if(['add-criterion','remove-criterion','add-alternative','remove-alternative'].includes(action)){ui.matrixDraft=readMatrix();if(action==='add-criterion')ui.matrixDraft.criteria.push({id:'C-'+Date.now().toString().slice(-6),name:'',weight:1});if(action==='remove-criterion')ui.matrixDraft.criteria.splice(index,1);if(action==='add-alternative')ui.matrixDraft.alternatives.push({id:'ALT-'+Date.now().toString().slice(-6),name:'',constraints_status:'UNKNOWN',scores:{}});if(action==='remove-alternative')ui.matrixDraft.alternatives.splice(index,1);delete ui.formDrafts.matrixForm;}
 ui.dirty=true;render();
}
async function handleSubmit(e){e.preventDefault();const id=e.target.id,d=Object.fromEntries(new FormData(e.target));
 if(id==='agentGoalForm'||id==='agentAnswerForm'){
  await busy(async()=>{
   if(id==='agentGoalForm')await agentCommand('start',{goal:d.goal,files:Object.fromEntries(Object.entries(ui.files).map(([k,v])=>[k,v.path])),cadOptions:ui.cadOptions});
   else await agentCommand('resume',{answer:d.answer});
   delete ui.formDrafts[id];ui.dirty=false;
  });return;
 }
 if(id==='newProjectForm'){document.getElementById('newProjectDialog').close();await busy(async()=>{const project_id='DG-'+crypto.randomUUID().slice(0,8).toUpperCase();await api().saveProject({project_id,project_name:d.project_name.trim()});await changeProject(project_id);ui.view='project';toast('项目已创建');});return;}
 if(id==='engineeringForm'){await runReview();return;}
 const requirements=id==='profileForm'?readRequirements():null,bom=id==='bomForm'?readBom():null,matrix=id==='matrixForm'?readMatrix():null;
 await busy(async()=>{
  if(id==='profileForm')await mutate('profile',{project_name:d.project_name,product:{...ui.project.product,category:d.category,target_users:d.target_users.split('、').filter(Boolean),environment:d.environment.split('、').filter(Boolean)},requirements});
  else if(id==='bomForm')await mutate('profile',{bom});
  else if(id==='matrixForm'){const r=await mutate('matrix',{decision_matrix:matrix});ui.matrixResult=r.comparison;}
  else if(id==='decisionForm')await mutate('decision',{...d,alternatives:d.alternatives.split('\n').map(x=>x.trim()).filter(Boolean)});
  else if(id==='verificationForm')await mutate('verification',d);
  else if(id==='dfmeaPlanForm'){
    const existing=ui.project.dfmea_verification_plan?.items||[],item={plan_item_id:d.plan_item_id.trim(),failure_mode_ids:[d.failure_mode_id],method:d.method.trim(),acceptance_criteria:d.acceptance_criteria.trim()};
    await mutate('dfmea-plan',{items:[...existing.filter(x=>x.plan_item_id!==item.plan_item_id&&!x.failure_mode_ids?.includes(d.failure_mode_id)),item],change_reason:d.change_reason||'User updated verification plan'});
  }
  else if(id==='dfmeaTestForm')await mutate('dfmea-test',{...d,failure_mode_ids:undefined,retest_of:d.retest_of||null,completed_at:new Date(d.completed_at).toISOString()});
  else if(id==='dfmeaCorrectionForm')await mutate('dfmea-correction',{corrects_test_id:d.corrects_test_id,reason:d.reason,corrected_by:d.corrected_by,replacement_fields:{note:d.note||''}});
  else if(id==='riskAcceptanceForm')await mutate('risk-acceptance',{...d,follow_up_actions:d.follow_up_actions.split('\n').map(x=>x.trim()).filter(Boolean)});
  else if(id==='failureDispositionForm')await mutate('dfmea-failure-disposition',{failed_test_id:d.failed_test_id,reason:d.reason,reviewed_by:d.reviewed_by});
  else if(id==='freezeForm')await mutate('freeze',{...d,review_id:ui.project.last_review?.review_id});
  else if(id==='revisionForm')await mutate('revision',d);
  else if(id==='pinForm')await mutate('pin',d);
  else if(id==='settingsForm'){await api().saveConfig({...d,temperature:Number(d.temperature),maxOutputTokens:d.maxOutputTokens||null,modelContextWindowTokens:d.modelContextWindowTokens||null,modelRequestTimeoutMs:d.modelRequestTimeoutMs, maxLengthRecoveryAttempts:d.maxLengthRecoveryAttempts,cumulativeTokenBudgetEnabled:d.cumulativeTokenBudgetEnabled==='true',cumulativeTokenBudget:d.cumulativeTokenBudget||null,maxToolSteps:d.maxToolSteps,maxModelRequests:d.maxModelRequests,maxNegotiationRounds:d.maxNegotiationRounds,agentRunDurationMs:d.agentRunDurationMs,reviewPipelineTimeoutMs:d.reviewPipelineTimeoutMs});ui.config=await api().getConfig();delete ui.formDrafts.settingsForm;ui.dirty=false;toast('模型与运行配置已保存');}
  else if(id==='integrationForm'){ui.integration={inagentRAG:d.inagentRAG==='true',archivePLM:d.archivePLM==='true',modelNarrative:d.modelNarrative==='true'};delete ui.formDrafts.integrationForm;ui.dirty=false;toast('本次会话的调用选项已保存');}
  else if(id==='advisorForm'){ui.messages.push({role:'user',content:d.question});const r=await api().workspace('consult',ui.project.project_id,{question:d.question,mode:'chat'},ui.project.version);ui.messages.push({role:'assistant',content:r.text});ui.messages=ui.messages.slice(-16);delete ui.formDrafts.advisorForm;ui.dirty=false;}
 });
}
async function init(){render();document.addEventListener('click',async e=>{const el=e.target.closest('button');if(!el||el.disabled)return;try{if(el.dataset.view){navigate(el.dataset.view);return;}for(const [attr,key]of [['projectTab','projectTab'],['engineeringTab','engineeringTab'],['reviewTab','reviewTab']])if(el.dataset[attr]){capture();ui[key]=el.dataset[attr];render();return;}if(el.dataset.action)await handleAction(el.dataset.action,el);}catch(err){ui.error=err.message;toast(err.message);render();}});document.addEventListener('submit',handleSubmit);document.addEventListener('change',async e=>{if(e.target.id==='projectSelector')await busy(()=>changeProject(e.target.value));});document.addEventListener('input',e=>{if(e.target.closest('#app form'))ui.dirty=true;});try{ui.projects=await api().listProjects();ui.config=await api().getConfig();if(ui.projects.length){ui.project=await api().getProject(ui.projects[0].project_id);await refresh();}}catch(e){ui.error=e.message;}render();}
function formatPipelineResultToMarkdown(res={}) {
 const cell=v=>String(v??'待提供').replace(/\|/g,'／').replace(/\n/g,' ');
 let md=`# DesignGate 工程评审\n\n项目：${res.project_id} · Revision ${res.revision} · ${res.stage}\n\n`;
 md+=`**${res.gate?.decision||'UNKNOWN'}** — ${res.gate?.status_summary||''}\n\n冻结状态：${res.gate?.freeze_status||'NOT_REQUESTED'}；归档：${res.archive_status||'LOCAL_ONLY'}\n\n`;
 md+='> 结论限于本轮规则覆盖范围。用户填写、文件提取、模型建议和实测证据需分别确认。\n\n';
 md+='## 下一步行动\n\n';for(const a of res.workspace?.next_actions||[])md+=`- ${a.action}（${a.status}）\n`;
 md+='\n## 专业能力状态\n\n| 能力 | 状态 | 方法 | 结论/待补项 |\n| --- | --- | --- | --- |\n';for(const capability of Object.values(res.professional_capabilities||{})){const outcome=capability.result?.missing_inputs?.join(', ')||capability.result?.compatibility||capability.result?.verification_gaps?.join(', ')||capability.result?.static_wrist_moment_nm||'—';md+=`| ${cell(capability.capability)} | ${cell(capability.status)} | ${cell(capability.method)} | ${cell(outcome)} |\n`;}
 if(res.evidence_graph)md+=`\nEvidence Graph：${res.evidence_graph.nodes?.length||0} 个节点，${res.evidence_graph.edges?.length||0} 条可追溯关系。\n`;
 md+='\n## 检查覆盖与结果\n\n| 检查 | 状态 | 必需阶段 | 说明 |\n| --- | --- | --- | --- |\n';for(const c of res.checks||[])md+=`| ${cell(c.check_id)} | ${c.status} | Gate ${c.required_for_gate} | ${cell(c.reason)} |\n`;
 md+='\n## 问题与闭环\n\n| 问题 | 严重度 | 状态 | 判断与行动 |\n| --- | --- | --- | --- |\n';for(const f of res.findings||[])md+=`| ${cell(f.issue_id)} | ${f.severity} | ${f.status} | ${cell(f.finding)}；${cell(f.recommendation)} |\n`;
 const diff=res.revision_diff?.metrics;if(diff)md+=`\n已验证关闭 ${diff.resolved_count} 项；仍未解决 ${diff.unresolved_count} 项；待复核 ${diff.pending_verification_count||0} 项。\n`;
 md+='\n## 需求验证计划\n\n| 需求 | 方法 | 通过判据 | 当前结果 |\n| --- | --- | --- | --- |\n';for(const v of res.workspace?.verification_plan||[])md+=`| ${cell(v.req_id)} ${cell(v.requirement)} | ${cell(v.method)} | ${cell(v.acceptance)} | ${v.result} |\n`;
 const cost=res.workspace?.cost; if(cost)md+=`\n## BOM 成本\n\n状态：${cost.status}；完整总额：${cost.total??'未能计算'} ${cost.currency||''}。${cost.scope}\n`;
 const matrix=res.workspace?.decision_matrix;if(matrix?.ranking?.length){md+='\n## 方案比较（用户评分）\n\n| 方案 | 加权分 | 硬约束 |\n| --- | --- | --- |\n';for(const a of matrix.ranking)md+=`| ${cell(a.name)} | ${a.score??'缺少评分'} | ${a.eligible?'已声明通过':'待验证'} |\n`;}
 if(state.currentTab==='cmf'){md+='\n## CMF 草案（未验证）\n\n| 部件 | 材料 | 表面 | 色彩 | 光泽 | 验证 | 状态 |\n| --- | --- | --- | --- | --- | --- | --- |\n';for(const c of res.specialized_artifacts?.cmf_matrix||[])md+=`| ${cell(c.part_name)} | ${cell(c.base_material)} | ${cell(c.finish_process)} | ${cell(c.color_code)} | ${cell(c.gloss_range)} | ${cell(c.reliability_standard)} | ${cell(c.status)} |\n`;}
 md+='\n## 材料与外部证据\n\n';md+=`材料索引：${res.material_verification?.verified?'本地索引匹配（物性与有效性未复核）':res.material_verification?.reason||'未提供'}\n\n`;
 for(const c of res.rag_candidates||[])md+=`- ${cell(c.title)}：${cell(c.excerpt)}（候选证据，未用于门禁）\n`;
 if(res.narrative)md+=`\n## 模型辅助说明（${res.narrative_status}）\n\n${res.narrative}\n`;
 for(const l of res.limitations||[])md+=`\n- ${l}`;
 return md;
}

function renderMarkdown(md) {
  if (!md) return "";

  let html = escapeHtml(md);

  html = html.replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (match, lang, code) => {
    return `<pre><code class="lang-${lang}">${code.trim()}</code></pre>`;
  });

  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

  html = html.replace(/((?:^\|[^\n]*\|\r?\n)+)/gm, (match) => {
    const lines = match.trim().split(/\r?\n/);
    if (lines.length < 2) return match;

    let tableHtml = "<table><thead>";
    const headerCells = lines[0].split("|").slice(1, -1);
    tableHtml += "<tr>" + headerCells.map(c => `<th>${c.trim()}</th>`).join("") + "</tr></thead><tbody>";

    for (let i = 2; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      const rowCells = lines[i].split("|").slice(1, -1);
      tableHtml += "<tr>" + rowCells.map(c => {
        let cellText = c.trim();
        cellText = cellText.replace(/\bCRITICAL\b/g, '<span style="border: 1px solid rgba(239, 68, 68, 0.4); background: rgba(239, 68, 68, 0.14); color: #fca5a5; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-size: 11px; font-family: var(--font-mono);">CRITICAL</span>');
        cellText = cellText.replace(/\bBLOCKER\b/g, '<span style="border: 1px solid rgba(239, 68, 68, 0.5); background: rgba(239, 68, 68, 0.2); color: #f87171; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-size: 11px; font-family: var(--font-mono);">BLOCKER</span>');
        cellText = cellText.replace(/\bHIGH\b/g, '<span style="border: 1px solid rgba(249, 115, 22, 0.4); background: rgba(249, 115, 22, 0.14); color: #fdba74; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-size: 11px; font-family: var(--font-mono);">HIGH</span>');
        cellText = cellText.replace(/\bMEDIUM\b/g, '<span style="border: 1px solid rgba(234, 179, 8, 0.35); background: rgba(234, 179, 8, 0.12); color: #fde047; padding: 2px 6px; border-radius: 4px; font-weight: 600; font-size: 11px; font-family: var(--font-mono);">MEDIUM</span>');
        cellText = cellText.replace(/\bLOW\b/g, '<span style="border: 1px solid rgba(148, 163, 184, 0.25); background: rgba(148, 163, 184, 0.08); color: #94a3b8; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-family: var(--font-mono);">LOW</span>');
        cellText = cellText.replace(/\bINFO\b/g, '<span style="border: 1px solid rgba(59, 130, 246, 0.25); background: rgba(59, 130, 246, 0.08); color: #93c5fd; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-family: var(--font-mono);">INFO</span>');
        cellText = cellText.replace(/\b(PASS|RESOLVED)\b/g, '<span style="border: 1px solid rgba(16, 185, 129, 0.4); background: rgba(16, 185, 129, 0.14); color: #6ee7b7; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-size: 11px; font-family: var(--font-mono);">$1</span>');
        cellText = cellText.replace(/\bREVISE\b/g, '<span style="border: 1px solid rgba(239, 68, 68, 0.4); background: rgba(239, 68, 68, 0.14); color: #f87171; padding: 2px 6px; border-radius: 4px; font-weight: 700; font-size: 11px; font-family: var(--font-mono);">REVISE</span>');
        cellText = cellText.replace(/\b(NEED_HUMAN_REVIEW|UNKNOWN|HOLD)\b/g, '<span style="border: 1px solid rgba(168, 85, 247, 0.35); background: rgba(168, 85, 247, 0.12); color: #d8b4fe; padding: 2px 6px; border-radius: 4px; font-size: 11px; font-family: var(--font-mono);">$1</span>');
        return `<td>${cellText}</td>`;
      }).join("") + "</tr>";
    }

    tableHtml += "</tbody></table>";
    return tableHtml;
  });

  html = html.replace(/^#### (.*$)/gim, "<h4>$1</h4>");
  html = html.replace(/^### (.*$)/gim, "<h3>$1</h3>");
  html = html.replace(/^## (.*$)/gim, "<h2>$1</h2>");
  html = html.replace(/^# (.*$)/gim, "<h1>$1</h1>");

  html = html.replace(/\*\*([^\*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*([^\*]+)\*/g, "<em>$1</em>");

  html = html.replace(/^> (.*$)/gim, "<blockquote>$1</blockquote>");
  html = html.replace(/^\s*[-*] (.*$)/gim, "<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>)/s, "<ul>$1</ul>");

  html = html.replace(/\n\n+/g, "</p><p>");
  html = "<p>" + html + "</p>";
  html = html.replace(/<p><\/p>/g, "");
  html = html.replace(/<p>\s*(<(?:table|thead|tbody|tr|th|td|ul|ol|li|h1|h2|h3|h4|pre|blockquote)>)/g, "$1");
  html = html.replace(/(<\/(?:table|thead|tbody|tr|th|td|ul|ol|li|h1|h2|h3|h4|pre|blockquote)>)\s*<\/p>/g, "$1");

  return html;
}

function escapeHtml(str) {
  if (!str || typeof str !== "string") return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

if(typeof document!=='undefined'){
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 setInterval(async()=>{
  if(ui.view!=='advisor'||!ui.project||ui.busy)return;
  const id=ui.project.project_id,panel=agentPanelState(id);
  if(panel.loading||panel.run?.status!=='RUNNING'&&Date.now()-panel.lastRefresh<10000)return;
  const before=JSON.stringify(panel.run);
  try{
   await refreshAgentPanel(id);
   if(before!==JSON.stringify(panel.run))panel.needsRender=true;
   if(ui.view==='advisor'&&ui.project?.project_id===id&&panel.needsRender&&!document.activeElement?.closest('form')){capture();render();panel.needsRender=false;}
  }catch(e){panel.lastRefresh=Date.now();toast(e.message);}
 },1200);
}
