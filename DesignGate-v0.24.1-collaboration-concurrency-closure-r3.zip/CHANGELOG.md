# DesignGate 版本历史

## v0.24.1 — Collaboration Closure / Local Concurrency Validation

- Adds authenticated HTTP race coverage for entity/version conflicts, idempotency, immutable artifact uploads, RBAC, approval/freeze transitions, and Agent/human revalidation.
- Adds a 20-process REST race, WebSocket fan-out under concurrent writers, isolated C1/C2/C3 external-process load profiles, a short multi-wave localhost soak smoke, raw JSON reports and event-chain/evidence invariant validation.
- Maps a concurrent frozen-Revision rejection to HTTP 409 rather than a misleading HTTP 500.
- Adds project-scoped Agent-run start/complete routes. Completion is restricted to the initiating member and detects changed relevant entity versions as `REVALIDATION_REQUIRED`; Agent output remains non-authoritative.
- See `docs/v0.24/CONCURRENCY_TEST_PLAN.md` and `docs/v0.24/CONCURRENCY_VALIDATION.md`. This does not establish capacity, real multi-device behavior, production readiness, engineering release, or automatic approval.

## v0.23 continuation checkpoint — governed integration hardening

- Tightens Gate v2 issue closure: a PASS must carry non-empty Revision, current baseline, test/evaluation, evidence, and rule bindings; empty Revision values cannot close an issue.
- Retains bounded CAD oracle and packaging work, with explicit `PACKAGED_NOT_UI_VERIFIED` status.
- Adds a training-only kernel with four public task templates, immutable session/attempt checks, named instructor review, and no Gate/freeze/engineering-approval output.
- Adds an external-validation preparation protocol and blank manifest, explicitly separate from executed independent validation.
- Current local evidence and remaining limits are in `docs/v0.23/RELEASE_READINESS.md`; this checkpoint makes no production or engineering-release claim.

## v0.21.1 — Governed Knowledge Integration

- Imports the verified delta as immutable project-local expansion data: 36 knowledge cards (including 8 concrete battery cells), 15 standards indexes, 10 battery-pack rules and 3 quarantine records; duplicate curated card IDs retain their established condition semantics.
- `KnowledgeService` exposes kinds, domains, source metadata, verification status, limitations and `engineering_release:false`; standard indexes and quarantine cannot become executable rules.
- Adds exact manufacturer/model battery retrieval and deterministic Ns/Np V/Ah/Wh calculations. Missing identity remains `DATA_GAP`; incomplete BMS/interconnect/fuse/thermal inputs remain `THEORETICAL_CELL_LIMIT_ONLY`.
- Adds agent filters and a read-only `calculate_battery_pack` tool; expands read-only role knowledge boundaries for A02, A03 and A05. The chief role gains no approval bypass.
- Review baselines include the governed knowledge fingerprint, so a changed knowledge release requires a fresh review before local freeze. This does not make a reference result a PASS or production approval.
- See `START_HERE_v0.21.1.md`, `MIGRATION_v0.21.1.md` and `RELEASE_VALIDATION_v0.21.1.md`.

本文件用于补齐 README 中曾经缺失的版本空档，并索引现有历史文档。旧 README 段落、旧 Release Validation、旧 START_HERE 和历史验证记录均保留。没有现成证据的内容不会在这里补写成“已完成”。

## v0.20.3-alpha — Runtime / DFMEA Closure Fix

- 默认取消应用自身 180000 累计 token 硬上限，默认累计预算关闭；默认 `maxOutputTokens=null`。
- 长任务停止原因拆分为工具步数、模型请求、协商轮数、运行时长、请求超时、用户预算、无进展和取消，并支持可恢复 segment。
- DFMEA 风险定义、版本化 Verification Plan 与 append-only Test Execution 分层；补齐旧 PASS 失效、Retest 关系、Residual Risk Acceptance、Evidence re-hash 和专业能力异常隔离。
- 本地验证：270/270；check PASS；CAD 17/17；adapter 5/5；handover 3/3。
- 使用说明书补充“核心优势与竞争力”章节，归纳语义—几何—工程数据联合评审、证据与状态治理、多角色 Trade-off、Revision—Verification—Risk Closure 四项优势；该更新仅涉及文档与打包。
- 详见：`START_HERE_v0.20.3.md`、`RELEASE_VALIDATION_v0.20.3.md`、`FIX_TEST_MATRIX_v0.20.3.md`、`MIGRATION_v0.20.3.md`、`UNVERIFIED_v0.20.3.md`。

## v0.20.2 — Cross-module Closure Fix

- 加强测试完成时间与 Requirement 关系校验；设计/需求基线变化会使相关非失败测试 STALE。
- 风险定义指纹与执行记录进一步解耦；专业 Issue 使用稳定 ID 形成关闭关系；Evidence Graph 不再把登记本身当验证。
- 历史测试和 FAILED 记录保留。
- 详见：`RELEASE_VALIDATION_v0.20.2.md`。

## v0.20.1 — DFMEA Closure Fix

- 修复 planned/unknown 被当 verified、空 DFMEA、reopened risk 未进入 Gate、Revision 继承测试结论、Requirement 关联丢失、规则 ID 与 Evidence 混淆等缺陷。
- 风险定义纳入 baseline，非当前测试进入 STALE。
- 详见：`RELEASE_VALIDATION_v0.20.1.md`、`MIGRATION_v0.20.1.md`。

## v0.20.0-alpha — Professional Capability Foundation

- 建立 Professional Capability Contract。
- 新增人体工学静态腕力矩筛查、CMF compatibility matrix、DFMEA risk engine、Evidence Graph。
- 真实模型 A/B、真实项目与独立专家仍保持 UNVERIFIED。
- 详见：`START_HERE_v0.20.md`、`RELEASE_VALIDATION_v0.20.md`。

## v0.19.0-alpha — Runtime Reliability / Reference UI

- 针对 v0.18.1 真实模型失败轨迹修复工具恢复、错误参数重复、CAD reference、预算与重规划等路径。
- 本地验证记录为 227/227；旧 200-run 只作为修复前诊断，不是 v0.19 live 成绩。
- 增加参考图前端版，并保持工程后端边界。
- 详见：`START_HERE_v0.19.md`、`RELEASE_VALIDATION_v0.19.md`、`FRONTEND_UPDATE.md`。

## v0.18.1-alpha — Eval Integrity Hotfix

- 修复行为 Gold 自相矛盾、证据绑定字段和 capability denominator 污染。
- 新增 Gold validator、trace-derived capability grader、scenario/live harness。
- 详见：`START_HERE_v0.18.1.md`、`RELEASE_VALIDATION_v0.18.1.md`。

## v0.18.0-alpha — Capability & Scenario Validation

- 新增 40-case capability dataset、行为 Gold schema、multi-trial runner、F01–F17 failure taxonomy、4 个 scenario 和 10-case Single vs Multi A/B 计划。
- 详见：`START_HERE_v0.18.md`、`RELEASE_VALIDATION_v0.18.md`、`docs/CAPABILITY_MATRIX.md`、`docs/LIMITATIONS.md`。

## v0.17.0-alpha — Measurement Display / Reflection / Freeze Handover

- 新增来源绑定的曲面采样参考显示、有界 Proposal 自省重试、Gate 3 本地冻结交接包。
- 详见：`START_HERE_v0.17.md`。

## v0.16.0-alpha — BRep Surface Sampling

- 新增 OCP/STEP 有界曲面法线、穿实体弦长、方向遮挡采样与 CAD 工具。
- 详见：`START_HERE_v0.16.md`、`RELEASE_VALIDATION_v0.16.md`。

## v0.15.0-alpha — Backend Actions / Role Isolation

- 新增可保留驳回理由、角色知识/工具权限隔离、工程记录 ZIP 和实验性 FreeCAD 参数适配。
- 详见：`START_HERE_v0.15.md`、`RELEASE_VALIDATION_v0.15.md`。

## v0.14 — UI / BRep Checkpoint

- 当前包保留 `START_HERE_v0.14_CHECKPOINT.md` 作为该阶段检查点。README 早期历史中仅以 v0.14 作为 v0.15 的视觉/BRep 前置版本引用；没有独立 release validation 时不补写额外“已验证”结论。

## v0.13.0-alpha — Rule Unification / Model Evaluation

- 统一来源绑定规则与合成评测流程，规则缺来源保持 UNKNOWN。
- 详见：`START_HERE_v0.13.md`。

## v0.12.0-alpha — Controlled Changes / Negotiation

- 增加原子变更 Proposal、BOM 规格/长期意图和 A03→A02→A06 三角色协商。
- 详见：`START_HERE_v0.12.md`、`docs/VALIDATION_v0.12.md`。

## v0.11.0 — Knowledge Governance

- 增强知识检索、条件核对、来源卡与旧数据隔离。
- 详见：`START_HERE_v0.11.md`、`knowledge/KNOWLEDGE_POLICY.md`。

## v0.10.0 — Agent Runtime Foundation

- 建立模型选工具→执行→Observation→继续/提案/提问的有状态 Agent 执行器。
- 历史验证记录保留在 `docs/VALIDATION.md` 后半部分；旧 Agent Guide 已归档到 `docs/history/AGENT_GUIDE_v0.18.md`。

## v0.9.0 及更早

README 保留项目资料、规则筛查、方案比较、验证/版本和本地冻结的早期基础说明；本包也仍保留 v0.7.x 相关历史来源痕迹。没有完整 release 文档的更早版本不在本 changelog 中补造细节。
