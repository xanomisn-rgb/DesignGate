# DesignGate Agent v0.18.1-alpha Release Validation

## Scope

Eval Integrity Hotfix. No product permission, engineering release authority, CAD global solver, or external connector capability was added.

## Integrity fixes

1. Corrected impossible pause/tool constraints in E25, E27, E31, E36, E38 and E40.
2. Corrected E30/E39 so `show_reference` itself is not a critical failure; only a successfully used stale binding is critical.
3. Added `answer_key_validator.js`, including tool overlap, pause satisfiability, semantic state vocabulary, label leakage and selected-file fixture feasibility checks.
4. Added run/project/revision/source metadata to serialized observations. Missing metadata on cited evidence fails CG06-CG08.
5. Added generic execution of expected/forbidden state events and critical fail conditions.
6. Separated `deterministic_status` from `formal_status`. Unreviewed deterministic failures never enter formal denominators.
7. Added direct trace/rubric capability dimensions. Annotation-dependent dimensions remain null before review.
8. Added executable Scenario and Single/Multi live harnesses. Scenario denominators come from immutable fixtures.
9. Added provider seed requested/supported/applied fields; unsupported seed is not sent.
10. Added quality gain, cost multipliers, efficiency-adjusted gain and conditional routing to A/B comparison.
11. Standardized the default offline plan at 40 cases x 5 trials.
12. Added bounded strict `finish_task` schema repair for provider compatibility without accepting invalid structures.

## Automated regression actually executed

- JavaScript tests: 202/202 pass, including all retained regressions and new integrity/live-harness tests.
- Syntax/JSON and Gold validator: all pass, 40/40 Gold valid.
- CAD/BRep: 2 + 8 + 1 pass.
- Parameter adapter: 5/5 pass.
- Handover: 3/3 pass.

## DeepSeek live run

- Endpoint: `https://api.deepseek.com/v1`
- Model requested and returned in run metadata: `deepseek-v4-pro`
- Atomic cases: 40
- Trials per case: 5
- Collected trials: 200/200
- Concurrency: 2
- Requested seed: 42; provider seed supported/applied: false/false
- Wall time: approximately 34.22 minutes
- Runtime outcomes: 99 COMPLETED, 41 WAITING_INPUT, 6 WAITING_APPROVAL, 31 FAILED, 23 BUDGET_EXCEEDED
- Provider-reported cumulative tokens: 10,400,839
- Estimated cumulative tokens: 19,934,272
- Mean model requests: 7.93
- Mean/P50/P95 tokens: 99,671 / 97,671 / 173,248
- Mean/P50/P95 active latency: 20,455 / 21,265 / 29,535 ms

The API key is not persisted in the run, report, source, or release package.

## Observed, not formal

Direct trace observations after draft2 Gold calibration:

- Planning: 1.000
- Routing: 0.727
- Retrieval: 0.711
- Tool Use: 0.613
- Evidence Grounding: 0.812
- State Safety: 0.948
- Security: 0.983
- Applicability / Trade-off / Unknown Handling: null pending human review
- Cited-evidence run/project/revision binding failures: 0

Strict deterministic checks produced 33 PASS and 167 FAIL. This is not the Agent intelligence pass rate: it includes missing required tools, any validation error, invalid terminal outcomes, state rules and other deterministic failures, while content recall/precision is still unreviewed.

## Formal capability status

`UNVERIFIED`

- Human reviewed trials: 0/200
- Expert reviewed Gold: 0/40
- Formal grade eligible trials: 0
- Task Success, Issue/Unknown quality and pass@k/pass^k remain null by design.

## Calibration disclosure

The run exposed draft Gold/tool-feasibility defects and a generic E01-E24 tool requirement that was too blunt. Gold was corrected while still explicitly draft and the unchanged trace was rescored. Therefore this result is a post-run integrity calibration and observed diagnostic, not a preregistered formal baseline. A formal baseline requires expert review, human annotations, a frozen answer-key hash and a new run or an explicitly approved reuse protocol.

## Main observed weaknesses

- Required retrieval/tool coverage is inconsistent, especially on CAD boundary and long-chain cases.
- 27% of trials ended in FAILED or BUDGET_EXCEEDED runtime outcomes.
- E25 and E33-E35 show substantial token/loop pressure.
- DeepSeek frequently emitted an incompatible structured finish shape; strict repair made it recoverable, but the repair itself is observable tool error and token cost.
- CAD reference tasks E28-E30/E39 show repeated invalid `show_reference` attempts.

## Next required review

An identified human reviewer must complete the generated annotation file. An engineering-domain expert must review each Gold label. Only then should `eval/report.js score` emit formal capability metrics. Multi-Agent and Scenario live runs are now executable but have not been run against this paid endpoint in this release validation.
